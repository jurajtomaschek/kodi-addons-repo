import sys
import xbmc
import json
import xbmcplugin
import xbmcgui
import urllib.parse

from . import api

def build_url(query):
    return f"{sys.argv[0]}?{urllib.parse.urlencode(query)}"

def show_main_menu(handle):
    itemTvSeriesLatest = xbmcgui.ListItem(label="Seriály - Nové")
    url = build_url({'action': 'list_tv_shows_latest'})
    xbmcplugin.addDirectoryItem(handle, url, itemTvSeriesLatest, isFolder=True)

    itemTvSeriesPopular = xbmcgui.ListItem(label="Seriály - Populárne")
    url = build_url({'action': 'list_tv_shows_popular'})
    xbmcplugin.addDirectoryItem(handle, url, itemTvSeriesPopular, isFolder=True)

    itemMoviesLatest = xbmcgui.ListItem(label="Filmy - Nové ")
    urlMoviesLatest = build_url({'action': 'list_movies_latest'})
    xbmcplugin.addDirectoryItem(handle, urlMoviesLatest, itemMoviesLatest, isFolder=True)
    xbmcplugin.endOfDirectory(handle)

    itemMoviesPopular = xbmcgui.ListItem(label="Filmy - Populárne")
    urlMoviesPopular = build_url({'action': 'list_movies_popular'})
    xbmcplugin.addDirectoryItem(handle, urlMoviesPopular, itemMoviesPopular, isFolder=True)
    xbmcplugin.endOfDirectory(handle)

    itemMoviesTopRated = xbmcgui.ListItem(label="Filmy - Najlepšie Hodnotené")
    urlMoviesTopRated = build_url({'action': 'list_movies_toprated'})
    xbmcplugin.addDirectoryItem(handle, urlMoviesTopRated, itemMoviesTopRated, isFolder=True)
    xbmcplugin.endOfDirectory(handle)

def list_tv_shows_latest(handle):
    page = int(dict(urllib.parse.parse_qsl(sys.argv[2][1:])).get('page', 1))
    response = api.get_tv_latest(page)
    shows = response.get('results', [])
    total_pages = response.get('total_pages', 1)

    for show in shows:
        item = xbmcgui.ListItem(label=f"{show['name']} [COLOR FFAAAAAA][{show['first_air_date_year']}][/COLOR]")
        item.setInfo('video', {
            'title': f"{show['name']} [{show['first_air_date_year']}]",
            'plot': show.get('overview', ''),
            'tagline': show.get('tagline', '')
        })
        item.setArt({
            'thumb': show.get('poster_path', ''),
            'poster': show.get('poster_path', ''),
            'fanart': show.get('backdrop_path', '')
        })
        url = build_url({'action': 'list_seasons', 'tv_id': show['id']})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    # Add "Next Page" if more pages are available
    if page < total_pages:
        nextPage = page + 1
        item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
        url = build_url({'action': 'list_tv_shows_latest', 'page': page + 1})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    # Tell Kodi this is a new folder level (updateListing=False)
    xbmcplugin.endOfDirectory(handle, updateListing=False)

def list_tv_shows_popular(handle):
    page = int(dict(urllib.parse.parse_qsl(sys.argv[2][1:])).get('page', 1))
    response = api.get_tv_popular(page)
    shows = response.get('results', [])
    total_pages = response.get('total_pages', 1)

    for show in shows:
        item = xbmcgui.ListItem(label=f"{show['name']} [COLOR FFAAAAAA][{show['first_air_date_year']}][/COLOR]")
        item.setInfo('video', {
            'title': f"{show['name']} [{show['first_air_date_year']}]",
            'plot': show.get('overview', ''),
            'tagline': show.get('tagline', '')
        })
        item.setArt({
            'thumb': show.get('poster_path', ''),
            'poster': show.get('poster_path', ''),
            'fanart': show.get('backdrop_path', '')
        })
        url = build_url({'action': 'list_seasons', 'tv_id': show['id']})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    # Add "Next Page" if more pages are available
    if page < total_pages:
        nextPage = page + 1
        item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
        url = build_url({'action': 'list_tv_shows_popular', 'page': page + 1})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    # Tell Kodi this is a new folder level (updateListing=False)
    xbmcplugin.endOfDirectory(handle, updateListing=False)

def list_seasons(handle, tv_id):
    details = api.get_tv_details(tv_id)
    for season in details.get('seasons', []):
        seasonName = season.get('name', f"Séria {season['season_number']}")
        label = f"{seasonName} [{season['year']}]"
        item = xbmcgui.ListItem(label=label)
        item.setInfo('video', {
            'title': season.get('name', 'Default Value'),
            'plot': season.get('overview', 'Default Overview'),
            'tagline': season.get('tagline', '')
        })
        item.setArt({
            'thumb': season.get('poster_path', ''),
            'poster': season.get('poster_path', ''),
            'fanart': season.get('poster_path', '')
        })
        url = build_url({'action': 'list_episodes', 'tv_id': tv_id, 'season': season['season_number']})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
    xbmcplugin.endOfDirectory(handle)

def list_episodes(handle, tv_id, season):
    episodes = api.get_episodes(tv_id, season)
    for ep in episodes:
        label = f"{ep['title']}"
        if not ep.get('hasStreams'):
            label = f"[COLOR 80FF0000][B][X][/B][/COLOR] [COLOR FFAAAAAA]{label}[/COLOR]"
        item = xbmcgui.ListItem(label=label)
        item.setInfo('video', {'title': ep['title'], 'plot': ep['description']})
        item.setArt({
            'thumb': ep.get('imageUrl', ''),
            'poster': ep.get('imageUrl', ''),
            'fanart': ep.get('imageUrl', '')
        })
        url = build_url({'action': 'show_streams', 'tv_id': tv_id, 'season': season, 'episode_id': ep['id']})  # add tv_id & season here
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=False)
    xbmcplugin.endOfDirectory(handle)

def show_streams_popup(tv_id, season, episode_id):
    episodes = api.get_episodes(tv_id, season)
    episode = next((ep for ep in episodes if ep['id'] == int(episode_id)), None)
    if not episode:
        xbmcgui.Dialog().ok("Error", "Episode not found")
        return

    streams = episode.get('streams', [])
    if not streams:
        xbmcgui.Dialog().ok("Streams", "No streams available for this episode.")
        return

    items = [f"{s['sizeInGB']}GB - {s['name']} " for s in streams]
    choice = xbmcgui.Dialog().select("Select a Stream", items)
    if choice == -1:
        return  # cancelled

    stream_id = streams[choice]['id']
    stream_url = api.get_streams(stream_id)

    xbmc.log(f"Selected stream ID: {stream_id}", xbmc.LOGINFO)
    xbmc.log(f"Resolved stream URL: {stream_url}", xbmc.LOGINFO)

    if not stream_url:
        xbmcgui.Dialog().ok("Error", "Stream URL is empty or invalid.")
        return
    
    list_item = xbmcgui.ListItem(path=stream_url)
    list_item.setInfo('video', {'title': episode['title']})
    list_item.setProperty("IsPlayable", "true")
    
    # Instead of setResolvedUrl, play it directly
    xbmc.Player().play(stream_url, list_item)

def list_movies_latest(handle):
    page = int(dict(urllib.parse.parse_qsl(sys.argv[2][1:])).get('page', 1))
    response = api.get_movies_latest(page)
    movies = response.get('results', [])
    total_pages = response.get('total_pages', 1)

    for movie in movies:
        label = f"{movie['title_with_original_title']} [COLOR FFAAAAAA][{movie['release_date'][:4]}][/COLOR]"
        item = xbmcgui.ListItem(label=label)
        item.setArt({
            'poster': movie.get('poster_path', ''),
            'fanart': movie.get('backdrop_path', '')
        })
        item.setInfo('video', {
            'title': movie['title'],
            'plot': movie.get('overview', '')
        })
        url = build_url({'action': 'list_movie_versions', 'movie_id': movie['id']})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    if page < total_pages:
        nextPage = page + 1
        item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
        url = build_url({'action': 'list_movies_latest', 'page': nextPage})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    xbmcplugin.endOfDirectory(handle, updateListing=False)

def list_movies_popular(handle):
    page = int(dict(urllib.parse.parse_qsl(sys.argv[2][1:])).get('page', 1))
    response = api.get_movies_popular(page)
    movies = response.get('results', [])
    total_pages = response.get('total_pages', 1)

    for movie in movies:
        label = f"{movie['title_with_original_title']} [COLOR FFAAAAAA][{movie['release_date'][:4]}][/COLOR]"
        item = xbmcgui.ListItem(label=label)
        item.setArt({
            'poster': movie.get('poster_path', ''),
            'fanart': movie.get('backdrop_path', '')
        })
        item.setInfo('video', {
            'title': movie['title'],
            'plot': movie.get('overview', '')
        })
        url = build_url({'action': 'list_movie_versions', 'movie_id': movie['id']})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    if page < total_pages:
        nextPage = page + 1
        item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
        url = build_url({'action': 'list_movies_popular', 'page': nextPage})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    xbmcplugin.endOfDirectory(handle, updateListing=False)

def list_movies_toprated(handle):
    page = int(dict(urllib.parse.parse_qsl(sys.argv[2][1:])).get('page', 1))
    response = api.get_movies_toprated(page)
    movies = response.get('results', [])
    total_pages = response.get('total_pages', 1)

    for movie in movies:
        label = f"{movie['title_with_original_title']} [COLOR FFAAAAAA][{movie['release_date'][:4]}][/COLOR]"
        item = xbmcgui.ListItem(label=label)
        item.setArt({
            'poster': movie.get('poster_path', ''),
            'fanart': movie.get('backdrop_path', '')
        })
        item.setInfo('video', {
            'title': movie['title'],
            'plot': movie.get('overview', '')
        })
        url = build_url({'action': 'list_movie_versions', 'movie_id': movie['id']})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    if page < total_pages:
        nextPage = page + 1
        item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
        url = build_url({'action': 'list_movies_toprated', 'page': nextPage})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    xbmcplugin.endOfDirectory(handle, updateListing=False)


def list_movie_versions(handle, movie_id):
    versions = api.get_movie_versions(movie_id)
    for version in versions:
        label = f"{version['name']} ({version['sizeInGB']} GB)"
        item = xbmcgui.ListItem(label=label)
        item.setInfo('video', {'title': version['name'], 'size': version['sizeInGB']})
        item.setProperty('IsPlayable', 'true')
        url = build_url({'action': 'play_movie_stream', 'stream_id': version['id']})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=False)
    xbmcplugin.endOfDirectory(handle)

def play_movie_stream(handle, stream_id):
    streamUrl = api.get_streams(stream_id)
    if streamUrl:
        item = xbmcgui.ListItem(path=streamUrl)
        xbmcplugin.setResolvedUrl(handle, True, listitem=item)