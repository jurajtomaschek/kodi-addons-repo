import ssl
import json
import xbmc
import xbmcaddon

from urllib.request import urlopen, Request
from urllib.error import HTTPError

addon = xbmcaddon.Addon()
api_key = addon.getSetting('api_key')

#BASE_API_URL = "https://localhost:7009"  # Make sure it's https if your server uses it

BASE_API_URL = "https://media-vault-app-service-b8cmhsbsaefadbex.northeurope-01.azurewebsites.net"

# Create unverified SSL context
ssl_context = ssl._create_unverified_context()

def _get_json(endpoint):
    full_url = f"{BASE_API_URL}{endpoint}"
    req = Request(full_url)
    # ✅ LOG the full request URL
    
    xbmc.log(f"Calling: {full_url}", xbmc.LOGINFO)

    try:
        with urlopen(req, context=ssl_context, timeout=10) as response:
            return json.loads(response.read().decode())
    except HTTPError as e:
        xbmc.log(f"[HTTPError] {e.code} - {e.reason}", xbmc.LOGERROR)
        xbmc.log(e.read().decode(), xbmc.LOGERROR)
        raise
    except Exception as ex:
        xbmc.log(f"[Exception] {str(ex)}", xbmc.LOGERROR)
        raise

def get_tv_latest(page=1):
    return _get_json(f"/media/tmdb/tvseries/latest?page={page}")

def get_tv_popular(page=1):
    return _get_json(f"/media/tmdb/tvseries/popular?page={page}")

def get_tv_details(tv_id):
    return _get_json(f"/media/tmdb/tvseries/{tv_id}")

def get_episodes(tv_id, season):
    return _get_json(f"/media/tmdb/tvseries/{tv_id}/season/{season}/episodes")

def get_movies_latest(page=1):
    return _get_json(f"/media/tmdb/movies/latest?page={page}")

def get_movies_popular(page=1):
    return _get_json(f"/media/tmdb/movies/popular?page={page}")

def get_movies_toprated(page=1):
    return _get_json(f"/media/tmdb/movies/toprated?page={page}")

def get_movie_versions(movie_id):
    return _get_json(f"/media/tmdb/movies/{movie_id}")

def get_streams(stream_id):
    return _get_json(f"/media/stream/{stream_id}")
