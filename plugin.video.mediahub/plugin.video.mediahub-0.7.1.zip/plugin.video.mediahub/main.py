import sys
import urllib.parse
import xbmcplugin
import xbmcgui

from resources.lib import api, ui

BASE_URL = sys.argv[0]
HANDLE = int(sys.argv[1])
ARGS = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))

def router():
    action = ARGS.get('action')

    if action == 'list_tv_shows_latest':
        ui.list_tv_shows_latest(HANDLE)
    elif action == 'list_tv_shows_popular':
        ui.list_tv_shows_popular(HANDLE)
    elif action == 'list_seasons':
        tv_id = int(ARGS['tv_id'])
        ui.list_seasons(HANDLE, tv_id)
    elif action == 'list_episodes':
        tv_id = int(ARGS['tv_id'])
        season = int(ARGS['season'])
        ui.list_episodes(HANDLE, tv_id, season)
    elif action == 'show_streams':
        tv_id = int(ARGS['tv_id'])
        season = int(ARGS['season'])
        episode_id = int(ARGS['episode_id'])
        ui.show_streams_popup(tv_id, season, episode_id)
    elif action == 'list_movies_latest':
        ui.list_movies_latest(HANDLE)
    elif action == 'list_movies_popular':
        ui.list_movies_popular(HANDLE)
    elif action == 'list_movies_toprated':
        ui.list_movies_toprated(HANDLE)
    elif action == 'list_movie_versions':
        movie_id = ARGS['movie_id']
        ui.list_movie_versions(HANDLE, movie_id)
    elif action == 'play_movie_stream':
        stream_id = ARGS['stream_id']
        ui.play_movie_stream(HANDLE, stream_id)
    else:
        ui.show_main_menu(HANDLE)

if __name__ == '__main__':
    router()
