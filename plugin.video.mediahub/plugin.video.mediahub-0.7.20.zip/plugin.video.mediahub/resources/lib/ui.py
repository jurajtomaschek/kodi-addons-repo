import sys
import xbmc
import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmcvfs
import os
import urllib.parse
from urllib.error import HTTPError, URLError
from . import api
import uuid
from .downloads_db import DownloadsDb, now_iso


db = DownloadsDb()

def _is_vfs_path(path):
    return "://" in path

def _join_path(base, filename):
    if _is_vfs_path(base):
        return base.rstrip("/\\") + "/" + filename
    return os.path.join(base, filename)

def build_url(query):
    return f"{sys.argv[0]}?{urllib.parse.urlencode(query)}"

def get_icons_path(image_name):
    addon = xbmcaddon.Addon()
    addon_path = addon.getAddonInfo('path')
    return os.path.join(addon_path, 'resources', 'icons', image_name)

def show_main_menu(handle):

    xbmcplugin.setPluginCategory(handle, "Hlavné Menu")
    # xbmcplugin.setContent(handle, "movies")

    # Movies
    menuItemMovies = xbmcgui.ListItem(label="Filmy")
    menuItemMovies.setInfo('video', { 'plot': u"\u00A0" })
    menuItemMovies.setArt({
        'icon': get_icons_path('movies.png'),
        'thumb': get_icons_path('movies.png')
    })
    urlMovies = build_url({'action': 'menu_item_movies'})
    xbmcplugin.addDirectoryItem(handle, urlMovies, menuItemMovies, isFolder=True)

    # TV Shows
    menuItemTvShows = xbmcgui.ListItem(label="Seriály")
    menuItemTvShows.setInfo('video', { 'plot': u"\u00A0" })
    menuItemTvShows.setArt({
        'icon': get_icons_path('tvshows.png'),
        'thumb': get_icons_path('tvshows.png')
    })
    urlTvShows = build_url({'action': 'menu_item_tvshows'})
    xbmcplugin.addDirectoryItem(handle, urlTvShows, menuItemTvShows, isFolder=True)

    # Downloads
    menuItemDownloads = xbmcgui.ListItem(label="Downloads")
    menuItemDownloads.setInfo('video', { 'plot': u"\u00A0" })
    menuItemDownloads.setArt({
        'icon': get_icons_path('downloads.png'),
        'thumb': get_icons_path('downloads.png')
    })
    urlDownloads = build_url({'action': 'show_downloads_menu'})
    xbmcplugin.addDirectoryItem(handle, urlDownloads, menuItemDownloads, isFolder=True)

    # # Watch History
    # menuItemWatchHistory = xbmcgui.ListItem(label="História Pozerania")
    # menuItemWatchHistory.setInfo('video', { 'plot': u"\u00A0" })
    # urlWatchHistory = build_url({'action': 'menu_item_watch_history'})
    # xbmcplugin.addDirectoryItem(handle, urlWatchHistory, menuItemWatchHistory, isFolder=True)

    xbmcplugin.endOfDirectory(handle)

def menu_item_movies(handle):

    xbmcplugin.setPluginCategory(handle, "Filmy")
    #xbmcplugin.setContent(handle, "movies")

    # Latest Movies
    menuItemMoviesLatest = xbmcgui.ListItem(label="Nové ")
    menuItemMoviesLatest.setInfo('video', { 'plot': u"\u00A0" })
    menuItemMoviesLatest.setArt({
        'icon': get_icons_path('new.png'),
        'thumb': get_icons_path('new.png')
    })
    urlMoviesLatest = build_url({'action': 'menu_item_movies_latest'})
    xbmcplugin.addDirectoryItem(handle, urlMoviesLatest, menuItemMoviesLatest, isFolder=True)

    # Popular Movies
    menuItemMoviesPopular = xbmcgui.ListItem(label="Populárne")
    menuItemMoviesPopular.setInfo('video', { 'plot': u"\u00A0" })
    menuItemMoviesPopular.setArt({
        'icon': get_icons_path('popular1.png'),
        'thumb': get_icons_path('popular1.png')
    })
    urlMoviesPopular = build_url({'action': 'menu_item_movies_popular'})
    xbmcplugin.addDirectoryItem(handle, urlMoviesPopular, menuItemMoviesPopular, isFolder=True)

    # Top Rated Movies
    menuItemMoviesTopRated = xbmcgui.ListItem(label="Najlepšie Hodnotené")
    menuItemMoviesTopRated.setInfo('video', { 'plot': u"\u00A0" })
    menuItemMoviesTopRated.setArt({
        'icon': get_icons_path('top-rated.png'),
        'thumb': get_icons_path('top-rated.png')
    })
    urlMoviesTopRated = build_url({'action': 'menu_item_movies_toprated'})
    xbmcplugin.addDirectoryItem(handle, urlMoviesTopRated, menuItemMoviesTopRated, isFolder=True)

    # # Genres
    # menuItemMoviesGenres = xbmcgui.ListItem(label="Podľa Žánrov")
    # menuItemMoviesGenres.setInfo('video', { 'plot': u"\u00A0" })
    # urlMoviesGenres = build_url({'action': 'menu_item_movies_genres'})
    # xbmcplugin.addDirectoryItem(handle, urlMoviesGenres, menuItemMoviesGenres, isFolder=True)

    # Search
    menuItemMoviesSearch = xbmcgui.ListItem(label="Hľadať")
    menuItemMoviesSearch.setProperty('IsPlayable', 'false')
    menuItemMoviesSearch.setInfo('video', { 'plot': u"\u00A0" })
    menuItemMoviesSearch.setArt({
        'icon': get_icons_path('search.png'),
        'thumb': get_icons_path('search.png')
    })
    urlMoviesSearch = build_url({'action': 'menu_item_movies_search'})
    xbmcplugin.addDirectoryItem(handle, urlMoviesSearch, menuItemMoviesSearch, isFolder=True)

    xbmcplugin.endOfDirectory(handle)

def menu_item_tvshows(handle):

    xbmcplugin.setPluginCategory(handle, "Seriály")

    # Latest Tv Shows
    menuItemTvShowsLatest = xbmcgui.ListItem(label="Nové ")
    menuItemTvShowsLatest.setInfo('video', { 'plot': u"\u00A0" })
    menuItemTvShowsLatest.setArt({
        'icon': get_icons_path('new.png'),
        'thumb': get_icons_path('new.png')
    })
    urlTvShowsLatest = build_url({'action': 'list_tv_shows_latest'})
    xbmcplugin.addDirectoryItem(handle, urlTvShowsLatest, menuItemTvShowsLatest, isFolder=True)

    # Popular Tv Shows
    menuItemTvShowsPopular = xbmcgui.ListItem(label="Populárne")
    menuItemTvShowsPopular.setInfo('video', { 'plot': u"\u00A0" })
    menuItemTvShowsPopular.setArt({
        'icon': get_icons_path('popular1.png'),
        'thumb': get_icons_path('popular1.png')
    })
    urlTvShowsPopular = build_url({'action': 'list_tv_shows_popular'})
    xbmcplugin.addDirectoryItem(handle, urlTvShowsPopular, menuItemTvShowsPopular, isFolder=True)

    # Top Rated Tv Shows
    menuItemTvShowsSlovak = xbmcgui.ListItem(label="Slovenské")
    menuItemTvShowsSlovak.setInfo('video', { 'plot': u"\u00A0" })
    menuItemTvShowsSlovak.setArt({
        'icon': get_icons_path('slovak.png'),
        'thumb': get_icons_path('slovak.png')
    })
    urlTvShowsSlovak = build_url({'action': 'list_tv_shows_sk'})
    xbmcplugin.addDirectoryItem(handle, urlTvShowsSlovak, menuItemTvShowsSlovak, isFolder=True)

    # # Genres
    # menuItemMoviesGenres = xbmcgui.ListItem(label="Podľa Žánrov")
    # menuItemMoviesGenres.setInfo('video', { 'plot': u"\u00A0" })
    # urlMoviesGenres = build_url({'action': 'menu_item_movies_genres'})
    # xbmcplugin.addDirectoryItem(handle, urlMoviesGenres, menuItemMoviesGenres, isFolder=True)

    # Search
    menuItemTvSearch = xbmcgui.ListItem(label="Hľadať")
    menuItemTvSearch.setProperty('IsPlayable', 'false')
    menuItemTvSearch.setInfo('video', { 'plot': u"\u00A0" })
    menuItemTvSearch.setArt({
        'icon': get_icons_path('search.png'),
        'thumb': get_icons_path('search.png')
    })
    urlTvSearch = build_url({'action': 'menu_item_tvshows_search'})
    xbmcplugin.addDirectoryItem(handle, urlTvSearch, menuItemTvSearch, isFolder=True)

    xbmcplugin.endOfDirectory(handle)

def menu_item_movies_latest(handle):
    page = int(dict(urllib.parse.parse_qsl(sys.argv[2][1:])).get('page', 1))
    response = api.get_movies_latest(page)
    movies = response.get('results', [])
    total_pages = response.get('total_pages', 1)

    for movie in movies:
        label = (
            f"{movie['title_with_original_title']} [COLOR FFAAAAAA][{movie['release_date'][:4]}][/COLOR] "
            f"{_format_vote_hearts(movie.get('vote_count'))}"
        )
        item = xbmcgui.ListItem(label=label)
        item.setArt({
            'poster': movie.get('poster_path', ''),
            'fanart': movie.get('backdrop_path', '')
        })
        item.setInfo('video', {
            'title': movie['title'],
            'plot': movie.get('overview', '')
        })
        url = build_url({'action': 'list_movie_versions', 'movie_id': movie['id']})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    if page < total_pages:
        nextPage = page + 1
        item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
        url = build_url({'action': 'menu_item_movies_latest', 'page': nextPage})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    xbmcplugin.endOfDirectory(handle, updateListing=False)

def menu_item_movies_popular(handle):
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    filter_type = params.get('filter_type')
    year = params.get('year')
    page = int(params.get('page', 1))
    
    # If no filter type, show submenu
    if not filter_type:
        xbmcplugin.setPluginCategory(handle, "Populárne")
        xbmcplugin.setContent(handle, "movies")
        
        # All Times
        item = xbmcgui.ListItem(label="Všetky roky")
        item.setInfo('movies', { 'plot': u"\u00A0" })
        url = build_url({'action': 'menu_item_movies_popular', 'filter_type': 'all_time'})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
        
        # By Year
        item = xbmcgui.ListItem(label="Podľa Roku")
        item.setInfo('video', { 'plot': u"\u00A0" })
        url = build_url({'action': 'menu_item_movies_popular', 'filter_type': 'by_year'})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
        
        xbmcplugin.endOfDirectory(handle)
        return
    
    # If filter_type is 'by_year' but no year selected, show year selector
    if filter_type == 'by_year' and not year:
        xbmcplugin.setPluginCategory(handle, "Populárne - Podľa Roku")
        xbmcplugin.setContent(handle, "movies")
        
        import datetime
        current_year = datetime.datetime.now().year
        
        # Show years from current year back to 1940
        for yr in range(current_year, 1940, -1):
            item = xbmcgui.ListItem(label=str(yr))
            item.setInfo('movies', { 'plot': u"\u00A0" })
            url = build_url({'action': 'menu_item_movies_popular', 'filter_type': 'by_year', 'year': yr})
            xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
        
        xbmcplugin.endOfDirectory(handle)
        return
    
    # Show movies based on filter
    if filter_type == 'all_time':
        response = api.get_movies_popular(page)
    elif filter_type == 'by_year' and year:
        response = api.get_movies_popular(page, year)
    else:
        response = api.get_movies_popular(page)
    
    movies = response.get('results', [])
    total_pages = response.get('total_pages', 1)

    for movie in movies:
        label = f"{movie['title_with_original_title']} [COLOR FFAAAAAA][{movie['release_date'][:4]}][/COLOR]"
        item = xbmcgui.ListItem(label=label)
        item.setArt({
            'poster': movie.get('poster_path', ''),
            'fanart': movie.get('backdrop_path', '')
        })
        item.setInfo('video', {
            'title': movie['title'],
            'plot': movie.get('overview', '')
        })
        url = build_url({'action': 'list_movie_versions', 'movie_id': movie['id']})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    if page < total_pages:
        nextPage = page + 1
        extra_params = {'filter_type': filter_type}
        if year:
            extra_params['year'] = year
        item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
        url = build_url({'action': 'menu_item_movies_popular', 'page': nextPage, **extra_params})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    xbmcplugin.endOfDirectory(handle, updateListing=False)

def menu_item_movies_toprated(handle):
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    filter_type = params.get('filter_type')
    year = params.get('year')
    page = int(params.get('page', 1))
    
    # If no filter type, show submenu
    if not filter_type:
        xbmcplugin.setPluginCategory(handle, "Najlepšie Hodnotené")
        xbmcplugin.setContent(handle, "movies")
        
        # All Times
        item = xbmcgui.ListItem(label="Všetky roky")
        item.setInfo('movies', { 'plot': u"\u00A0" })
        url = build_url({'action': 'menu_item_movies_toprated', 'filter_type': 'all_time'})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
        
        # By Year
        item = xbmcgui.ListItem(label="Podľa Roku")
        item.setInfo('video', { 'plot': u"\u00A0" })
        url = build_url({'action': 'menu_item_movies_toprated', 'filter_type': 'by_year'})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
        
        xbmcplugin.endOfDirectory(handle)
        return
    
    # If filter_type is 'by_year' but no year selected, show year selector
    if filter_type == 'by_year' and not year:
        xbmcplugin.setPluginCategory(handle, "Najlepšie Hodnotené - Podľa Roku")
        xbmcplugin.setContent(handle, "movies")
        
        import datetime
        current_year = datetime.datetime.now().year
        
        # Show years from current year back to 1990
        for yr in range(current_year, 1940, -1):
            item = xbmcgui.ListItem(label=str(yr))
            item.setInfo('movies', { 'plot': u"\u00A0" })
            url = build_url({'action': 'menu_item_movies_toprated', 'filter_type': 'by_year', 'year': yr})
            xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
        
        xbmcplugin.endOfDirectory(handle)
        return
    
    # Show movies based on filter
    if filter_type == 'all_time':
        response = api.get_movies_toprated(page)
    elif filter_type == 'by_year' and year:
        response = api.get_movies_toprated(page, year)
    else:
        response = api.get_movies_toprated(page)
    
    movies = response.get('results', [])
    total_pages = response.get('total_pages', 1)

    for movie in movies:
        label = f"{movie['title_with_original_title']} [COLOR FFAAAAAA][{movie['release_date'][:4]}][/COLOR]"
        item = xbmcgui.ListItem(label=label)
        item.setArt({
            'poster': movie.get('poster_path', ''),
            'fanart': movie.get('backdrop_path', '')
        })
        item.setInfo('video', {
            'title': movie['title'],
            'plot': movie.get('overview', '')
        })
        url = build_url({'action': 'list_movie_versions', 'movie_id': movie['id']})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    if page < total_pages:
        nextPage = page + 1
        extra_params = {'filter_type': filter_type}
        if year:
            extra_params['year'] = year
        item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
        url = build_url({'action': 'menu_item_movies_toprated', 'page': nextPage, **extra_params})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    xbmcplugin.endOfDirectory(handle, updateListing=False)

def menu_item_movies_search(handle):
    # Get parameters from URL
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    search_query = params.get('search_query')
    page = int(params.get('page', 1))
    
    # Only show keyboard if no search_query (initial search)
    if not search_query:
        keyboard = xbmc.Keyboard('', 'Hľadať Filmy')
        keyboard.doModal()
        if keyboard.isConfirmed():
            search_query = keyboard.getText()
        else:
            return  # User cancelled
    
    if search_query:
        response = api.get_movies_search(search_query, page)
        movies = response.get('results', [])
        total_pages = response.get('total_pages', 1)

        for movie in movies:
            year = movie.get("release_date", "")[:4] if movie.get("release_date") else "----"
            label = (
                f"{movie['title_with_original_title']} [COLOR FFAAAAAA][{year}][/COLOR] "
                f" {_format_vote_hearts(movie.get('vote_count'))}"
            )
            item = xbmcgui.ListItem(label=label)
            item.setArt({
                'poster': movie.get('poster_path', ''),
                'fanart': movie.get('backdrop_path', '')
            })
            item.setInfo('video', {
                'title': movie['title'],
                'plot': movie.get('overview', '')
            })
            url = build_url({'action': 'list_movie_versions', 'movie_id': movie['id']})
            xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

        if page < total_pages:
            nextPage = page + 1
            item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
            url = build_url({'action': 'menu_item_movies_search', 'page': nextPage, 'search_query': search_query})
            xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

        xbmcplugin.endOfDirectory(handle, updateListing=False)




    # itemTvSeriesLatest = xbmcgui.ListItem(label="Seriály - Nové")
    # url = build_url({'action': 'list_tv_shows_latest'})
    # xbmcplugin.addDirectoryItem(handle, url, itemTvSeriesLatest, isFolder=True)

    # itemTvSeriesPopular = xbmcgui.ListItem(label="Seriály - Populárne")
    # url = build_url({'action': 'list_tv_shows_popular'})
    # xbmcplugin.addDirectoryItem(handle, url, itemTvSeriesPopular, isFolder=True)

    # itemTvSeriesSk = xbmcgui.ListItem(label="Seriály - SK")
    # url = build_url({'action': 'list_tv_shows_sk'})
    # xbmcplugin.addDirectoryItem(handle, url, itemTvSeriesSk, isFolder=True)

def _get_tv_year(show):
    year = show.get("first_air_date_year")
    if year:
        return str(year)

    first_air_date = show.get("first_air_date") or ""
    return first_air_date[:4] if first_air_date else "----"

def _format_vote_hearts(vote_count):
    if vote_count is None:
        vote_count = 0

    if vote_count < 200:
        filled_hearts = 0
    elif vote_count < 500:
        filled_hearts = 1
    elif vote_count <= 1000:
        filled_hearts = 2
    else:
        filled_hearts = 3

    hearts = []
    for index in range(3):
        if index < filled_hearts:
            # use a softer golden tone instead of bright yellow
            hearts.append("[COLOR FFB8860B]★[/COLOR]")
        else:
            # slightly darker grey for empty stars
            hearts.append("[COLOR FF909090]☆[/COLOR]")
    return "".join(hearts)

def _build_tv_show_item(show, include_vote_count=False, include_hearts=True):
    year = _get_tv_year(show)
    display_title = show.get("name_with_original_name") or show.get("name") or ""
    vote_count = show.get("vote_count")
    hearts = _format_vote_hearts(vote_count) if include_hearts else ""
    votes_suffix = f"[{vote_count}]" if include_vote_count and vote_count is not None else ""

    item = xbmcgui.ListItem(
        label=f"{display_title} [COLOR FFAAAAAA][{year}][/COLOR] {hearts} {votes_suffix}".strip()
    )
    item.setArt({
        'poster': show.get('poster_path', ''),
        'fanart': show.get('backdrop_path', '')
    })
    item.setInfo('video', {
        'title': show.get('name') or display_title,
        'plot': show.get('overview', '')
    })
    return item

def menu_item_tvshows_search(handle):
    # Get parameters from URL
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    search_query = params.get('search_query')
    page = int(params.get('page', 1))
    
    # Only show keyboard if no search_query (initial search)
    if not search_query:
        keyboard = xbmc.Keyboard('', 'Hľadať Seriály')
        keyboard.doModal()
        if keyboard.isConfirmed():
            search_query = keyboard.getText()
        else:
            return  # User cancelled
    
    if search_query:
        response = api.get_tv_search(search_query, page)
        shows = response.get('results', [])
        total_pages = response.get('total_pages', 1)

        for show in shows:
            item = _build_tv_show_item(show, include_vote_count=True, include_hearts=False)
            url = build_url({'action': 'list_seasons', 'tv_id': show['id']})
            xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

        if page < total_pages:
            nextPage = page + 1
            item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
            url = build_url({'action': 'menu_item_tvshows_search', 'page': nextPage, 'search_query': search_query})
            xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

        xbmcplugin.endOfDirectory(handle, updateListing=False)

def list_tv_shows_latest(handle):
    page = int(dict(urllib.parse.parse_qsl(sys.argv[2][1:])).get('page', 1))
    response = api.get_tv_latest(page)
    shows = response.get('results', [])
    total_pages = response.get('total_pages', 1)

    for show in shows:
        item = _build_tv_show_item(show, include_vote_count=True, include_hearts=False)
        url = build_url({'action': 'list_seasons', 'tv_id': show['id']})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    # Add "Next Page" if more pages are available
    if page < total_pages:
        nextPage = page + 1
        item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
        url = build_url({'action': 'list_tv_shows_latest', 'page': page + 1})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    # Tell Kodi this is a new folder level (updateListing=False)
    xbmcplugin.endOfDirectory(handle, updateListing=False)

def list_tv_shows_popular(handle):
    page = int(dict(urllib.parse.parse_qsl(sys.argv[2][1:])).get('page', 1))
    response = api.get_tv_popular(page)
    shows = response.get('results', [])
    total_pages = response.get('total_pages', 1)

    for show in shows:
        item = _build_tv_show_item(show, include_hearts=False)
        url = build_url({'action': 'list_seasons', 'tv_id': show['id']})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    # Add "Next Page" if more pages are available
    if page < total_pages:
        nextPage = page + 1
        item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
        url = build_url({'action': 'list_tv_shows_popular', 'page': page + 1})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    # Tell Kodi this is a new folder level (updateListing=False)
    xbmcplugin.endOfDirectory(handle, updateListing=False)

def list_tv_shows_sk(handle):
    page = int(dict(urllib.parse.parse_qsl(sys.argv[2][1:])).get('page', 1))
    response = api.get_tv_sk(page)
    shows = response.get('results', [])
    total_pages = response.get('total_pages', 1)

    for show in shows:
        item = _build_tv_show_item(show, include_hearts=False)
        url = build_url({'action': 'list_seasons', 'tv_id': show['id']})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    # Add "Next Page" if more pages are available
    if page < total_pages:
        nextPage = page + 1
        item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
        url = build_url({'action': 'list_tv_shows_sk', 'page': page + 1})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    # Tell Kodi this is a new folder level (updateListing=False)
    xbmcplugin.endOfDirectory(handle, updateListing=False)

def list_seasons(handle, tv_id):
    details = api.get_tv_details(tv_id)
    for season in details.get('seasons', []):
        seasonName = season.get('name', f"Séria {season['season_number']}")
        label = f"{seasonName} [{season['year']}]"
        item = xbmcgui.ListItem(label=label)
        item.setInfo('video', {
            'title': season.get('name', 'Default Value'),
            'plot': season.get('overview', 'Default Overview'),
            'tagline': season.get('tagline', '')
        })
        item.setArt({
            'thumb': season.get('poster_path', ''),
            'poster': season.get('poster_path', ''),
            'fanart': season.get('poster_path', '')
        })
        url = build_url({'action': 'list_episodes', 'tv_id': tv_id, 'season': season['season_number']})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
    xbmcplugin.endOfDirectory(handle)

def list_episodes(handle, tv_id, season):
    episodes = api.get_episodes(tv_id, season)
    for ep in episodes:
        label = f"{ep['title']}"
        if not ep.get('hasStreams'):
            label = f"[COLOR 80FF0000][B][X][/B][/COLOR] [COLOR FFAAAAAA]{label}[/COLOR]"
        item = xbmcgui.ListItem(label=label)
        item.setInfo('video', {'title': ep['title'], 'plot': ep['description']})
        item.setArt({
            'thumb': ep.get('imageUrl', ''),
            'poster': ep.get('imageUrl', ''),
            'fanart': ep.get('imageUrl', '')
        })
        url = build_url({'action': 'show_streams', 'tv_id': tv_id, 'season': season, 'episode_id': ep['id']})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
    xbmcplugin.endOfDirectory(handle)

def show_streams_popup(handle, tv_id, season, episode_id):
    episodes = api.get_episodes(tv_id, season)
    episode = next((ep for ep in episodes if ep['id'] == int(episode_id)), None)
    if not episode:
        xbmcgui.Dialog().notification("Streams", "Episode not found.", xbmcgui.NOTIFICATION_ERROR, 2500)
        xbmcplugin.endOfDirectory(handle)
        return

    streams = episode.get('streams', [])
    if not streams:
        xbmcgui.Dialog().notification("Streams", "No streams available for this episode.", xbmcgui.NOTIFICATION_INFO, 2500)
        xbmcplugin.endOfDirectory(handle)
        return

    for stream in streams:
        label = f"[COLOR FF00C8FF][{stream['sizeInGB']} GB][/COLOR] {stream['name']}"
        item = xbmcgui.ListItem(label=label)
        item.setInfo('video', {
            'plot': f"{stream['name']}\n\nSize: {stream['sizeInGB']} GB",
        })
        item.setInfo('video', {'title': stream['name'], 'size': stream['sizeInGB']})
        item.setProperty('IsPlayable', 'true')
        url = build_url({'action': 'play_movie_stream', 'stream_id': stream['id']})
        filename = f"{episode.get('title', 'Episode')} - {stream.get('name', 'Stream')}"
        item.addContextMenuItems([("Download", f"RunPlugin({build_url({'action': 'download_movie_stream', 'stream_id': stream['id'], 'filename': filename})})")])
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=False)

    xbmcplugin.endOfDirectory(handle)

def list_movie_versions(handle, movie_id):
    versions = api.get_movie_versions(movie_id)
    for version in versions:
        label = f"[COLOR FF00C8FF][{version['sizeInGB']} GB][/COLOR] {version['name']}"
        item = xbmcgui.ListItem(label=label)
        item.setInfo('video', {
            'plot': f"{version['name']}\n\nSize: {version['sizeInGB']} GB",
        })
        item.setProperty('IsPlayable', 'true')
        url = build_url({'action': 'play_movie_stream', 'stream_id': version['id']})
        item.addContextMenuItems([("Download", f"RunPlugin({build_url({'action': 'download_movie_stream', 'stream_id': version['id'], 'filename': version['name']})})")])
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=False)
    xbmcplugin.endOfDirectory(handle)

def play_movie_stream(handle, stream_id):
    try:
        streamUrl = api.get_streams(stream_id)
    except HTTPError as e:
        xbmc.log(f"[play_movie_stream] HTTP {e.code} for stream {stream_id}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Stream error", f"Server returned {e.code}. Please try again later.")
        return
    except URLError as e:
        xbmc.log(f"[play_movie_stream] URL error for stream {stream_id}: {e.reason}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Stream error", "Network issue while resolving stream.")
        return
    except Exception as e:
        xbmc.log(f"[play_movie_stream] Unexpected error for stream {stream_id}: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Stream error", "Could not resolve stream.")
        return

    if streamUrl:
        item = xbmcgui.ListItem(path=streamUrl)
        xbmcplugin.setResolvedUrl(handle, True, listitem=item)

def download_movie_stream(stream_id, filename):
    safe_filename = "".join(c for c in filename if c.isalnum() or c in (' ', '-', '_')).rstrip() + ".mp4"

    try:
        stream_url = api.get_streams(stream_id)
    except HTTPError as e:
        xbmc.log(f"[download_movie_stream] HTTP {e.code} for stream {stream_id}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Download", f"Server returned {e.code}. Please try again later.")
        return
    except URLError as e:
        xbmc.log(f"[download_movie_stream] URL error for stream {stream_id}: {e.reason}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Download", "Network issue while resolving stream.")
        return
    except Exception as e:
        xbmc.log(f"[download_movie_stream] Unexpected error for stream {stream_id}: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Download", "Could not resolve stream.")
        return

    if not stream_url:
        xbmcgui.Dialog().ok("Download", "Stream URL not available")
        return

    addon = xbmcaddon.Addon()
    default_dir = addon.getSetting("download_path") or ""
    save_dir = default_dir

    if not save_dir:
        save_dir = xbmcgui.Dialog().browse(0, "Choose save directory", "files", "", False, False, "")
        if not save_dir:
            return

    if not xbmcvfs.exists(save_dir):
        xbmcvfs.mkdirs(save_dir)

    # VFS paths (content://, smb://, storage://) can report missing; don't block on exists.
    if not xbmcvfs.exists(save_dir) and not _is_vfs_path(save_dir):
        xbmcgui.Dialog().ok("Download", "Download folder is not accessible.")
        return

    filepath = _join_path(save_dir, safe_filename)
    download_id = str(uuid.uuid4())

    db.set(download_id, {
        "id": download_id,
        "stream_id": stream_id,
        "filename": safe_filename,
        "path": filepath,
        "url": stream_url,
        "status": "queued",
        "progress": 0,
        "bytes_total": None,
        "bytes_done": 0,
        "attempts": 0,
        "created_at": now_iso(),
        "updated_at": now_iso()
    })

    xbmcgui.Dialog().notification("Queued", f"{safe_filename}", xbmcgui.NOTIFICATION_INFO, 2500)

def show_downloads_menu(handle):
    xbmcplugin.setPluginCategory(handle, "Downloads")
    addon = xbmcaddon.Addon()
    max_attempts = max(1, int(addon.getSetting("download_retry_limit") or 0) + 1)

    clear_item = xbmcgui.ListItem(label="Vymazať históriu sťahovania")
    clear_item.setArt({
        'icon': get_icons_path('clear.png'),
        'thumb': get_icons_path('clear.png')
    })
    clear_item.setInfo('video', {'plot': 'Vumazať všetky záznamy o sťahovaní (súbory nebudú odstránené).'})
    clear_url = build_url({'action': 'clear_download_history'})
    xbmcplugin.addDirectoryItem(handle, clear_url, clear_item, isFolder=False)

    data = db.list()
    items = sorted(data.values(), key=lambda x: x.get("created_at", ""), reverse=True)

    for it in items:
        download_id = it.get("id")
        status = it.get("status", "?")
        progress = it.get("progress", 0) or 0
        filename = it.get("filename", "Unknown")
        path = it.get("path", "")
        attempts = it.get("attempts", 0) or 0
        error = it.get("error")

        if status == "downloading":
            label = f"[{progress}%] - {filename}"
        elif status == "queued":
            label = f"Čaká na stiahnutie - {filename}"
        elif status == "complete":
            label = f"[[COLOR FF90EE90]100%[/COLOR]] - {filename}"
        elif status == "failed":
            label = f"Chyba - {filename}"
        elif status == "canceled":
            label = f"Zrušené - {filename}"
        else:
            label = f"{status} - {filename}"

        li = xbmcgui.ListItem(label=label)
        plot = f"Status: {status}, Progress: {progress}%, Attempts: {attempts}/{max_attempts}"
        if error:
            plot += f"\nError: {error}"
        li.setInfo('video', {'plot': plot})

        if status == "complete":
            li.setArt({'icon': 'done.png'})

        # Context menu: cancel queued/downloading
        if status in ("queued", "downloading"):
            li.addContextMenuItems([
                ("Cancel", f"RunPlugin({build_url({'action':'cancel_download','id': download_id})})")
            ])

        url = ""
        if status == "complete" and path and xbmcvfs.exists(path):
            url = path
            li.setProperty("IsPlayable", "true")

        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=False)

    xbmcplugin.endOfDirectory(handle)

def cancel_download(download_id):
    db.update(download_id, {"status": "canceled", "updated_at": now_iso()})
    xbmcgui.Dialog().notification("Canceled", "Download canceled", xbmcgui.NOTIFICATION_INFO, 2000)

def clear_download_history():
    confirm = xbmcgui.Dialog().yesno("Vymazať históriu sťahovania", "Stiahnuté súbory nebudú odstránené. Pokračovať?", yeslabel="Áno", nolabel="Nie")
    if not confirm:
        return

    db.clear_all()
    #xbmcgui.Dialog().notification("Downloads", "History cleared", xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin("Container.Refresh")
