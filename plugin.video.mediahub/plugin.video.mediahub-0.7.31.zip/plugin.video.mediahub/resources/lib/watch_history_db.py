import json
import os
import time
import xbmcaddon
import xbmcvfs


class WatchHistoryDb:
    def __init__(self, filename="watch_history.json"):
        addon = xbmcaddon.Addon()
        self._dir = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
        if not xbmcvfs.exists(self._dir):
            xbmcvfs.mkdirs(self._dir)

        self._path = os.path.join(self._dir, filename)
        self._lockdir = os.path.join(self._dir, ".watch_history_lock")

    def list(self) -> dict:
        return self._with_lock(self._load_unlocked)

    def mutate(self, fn):
        def op():
            data = self._load_unlocked()
            result = fn(data)
            self._atomic_write_unlocked(data)
            return result
        return self._with_lock(op)

    def remove(self, history_id: str):
        def op():
            data = self._load_unlocked()
            removed = data.pop(history_id, None)
            self._atomic_write_unlocked(data)
            return removed
        return self._with_lock(op)

    def clear_all(self):
        def op():
            self._atomic_write_unlocked({})
            return None
        return self._with_lock(op)

    def _with_lock(self, fn, timeout_sec=10.0, poll_sec=0.05):
        start = time.time()
        while True:
            if xbmcvfs.mkdir(self._lockdir):
                break
            if time.time() - start >= timeout_sec:
                raise TimeoutError("Could not acquire watch history lock in time")
            time.sleep(poll_sec)

        try:
            return fn()
        finally:
            try:
                if xbmcvfs.exists(self._lockdir):
                    xbmcvfs.rmdir(self._lockdir)
            except Exception:
                pass

    def _load_unlocked(self) -> dict:
        if not xbmcvfs.exists(self._path):
            return {}
        try:
            f = xbmcvfs.File(self._path, "r")
            raw = f.read()
            f.close()
            return json.loads(raw) if raw else {}
        except Exception:
            return {}

    def _atomic_write_unlocked(self, data: dict):
        tmp = self._path + ".tmp"
        payload = json.dumps(data, ensure_ascii=False, separators=(",", ":"))

        f = xbmcvfs.File(tmp, "w")
        f.write(payload)
        f.close()

        if xbmcvfs.exists(self._path):
            xbmcvfs.delete(self._path)
        xbmcvfs.rename(tmp, self._path)
