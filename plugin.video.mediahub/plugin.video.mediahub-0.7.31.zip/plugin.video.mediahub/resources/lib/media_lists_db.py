import json
import os
import time
import xbmcaddon
import xbmcvfs


MEDIA_LIST_KEYS = ("favorites",)
LEGACY_MEDIA_LIST_KEYS = ("watchlist",)


class MediaListsDb:
    def __init__(self, filename="media_lists.json"):
        addon = xbmcaddon.Addon()
        self._dir = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
        if not xbmcvfs.exists(self._dir):
            xbmcvfs.mkdirs(self._dir)

        self._path = os.path.join(self._dir, filename)
        self._lockdir = os.path.join(self._dir, ".media_lists_lock")

    def list(self, collection=None) -> dict:
        data = self._with_lock(self._load_unlocked)
        if collection:
            return dict(data.get(collection, {}))
        return data

    def upsert(self, collection: str, item_id: str, record: dict):
        if collection not in MEDIA_LIST_KEYS:
            return False

        def op():
            data = self._load_unlocked()
            records = data[collection]
            existing = records.get(item_id, {})
            added = not existing
            stored = dict(record)
            timestamp = now_iso()
            stored["id"] = item_id
            stored["added_at"] = existing.get("added_at") or timestamp
            stored["updated_at"] = timestamp
            records[item_id] = {
                key: value for key, value in stored.items()
                if value not in (None, "")
            }
            self._atomic_write_unlocked(data)
            return added
        return self._with_lock(op)

    def remove(self, collection: str, item_id: str):
        if collection not in MEDIA_LIST_KEYS:
            return None

        def op():
            data = self._load_unlocked()
            removed = data[collection].pop(item_id, None)
            self._atomic_write_unlocked(data)
            return removed
        return self._with_lock(op)

    def clear(self, collection: str):
        if collection not in MEDIA_LIST_KEYS:
            return None

        def op():
            data = self._load_unlocked()
            data[collection] = {}
            self._atomic_write_unlocked(data)
            return None
        return self._with_lock(op)

    def _with_lock(self, fn, timeout_sec=10.0, poll_sec=0.05):
        start = time.time()
        while True:
            if xbmcvfs.mkdir(self._lockdir):
                break
            if time.time() - start >= timeout_sec:
                raise TimeoutError("Could not acquire media lists lock in time")
            time.sleep(poll_sec)

        try:
            return fn()
        finally:
            try:
                if xbmcvfs.exists(self._lockdir):
                    xbmcvfs.rmdir(self._lockdir)
            except Exception:
                pass

    def _load_unlocked(self) -> dict:
        data = {}
        if xbmcvfs.exists(self._path):
            try:
                f = xbmcvfs.File(self._path, "r")
                raw = f.read()
                f.close()
                data = json.loads(raw) if raw else {}
            except Exception:
                data = {}

        if not isinstance(data, dict):
            data = {}

        normalized = {}
        favorites = data.get("favorites", {})
        normalized["favorites"] = dict(favorites) if isinstance(favorites, dict) else {}

        for key in LEGACY_MEDIA_LIST_KEYS:
            records = data.get(key, {})
            if isinstance(records, dict):
                for item_id, record in records.items():
                    normalized["favorites"].setdefault(item_id, record)
        return normalized

    def _atomic_write_unlocked(self, data: dict):
        tmp = self._path + ".tmp"
        payload = json.dumps(data, ensure_ascii=False, separators=(",", ":"))

        f = xbmcvfs.File(tmp, "w")
        f.write(payload)
        f.close()

        if xbmcvfs.exists(self._path):
            xbmcvfs.delete(self._path)
        xbmcvfs.rename(tmp, self._path)


def now_iso():
    return time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime())
