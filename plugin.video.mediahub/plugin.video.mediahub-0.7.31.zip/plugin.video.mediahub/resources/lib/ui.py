import sys
import xbmc
import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmcvfs
import os
import urllib.parse
from urllib.error import URLError
from . import api
import uuid
from .downloads_db import DownloadsDb, now_iso
from .media_lists_db import MEDIA_LIST_KEYS, MediaListsDb
from .watch_history_db import WatchHistoryDb


db = DownloadsDb()
media_lists_db = MediaListsDb()
watch_history_db = WatchHistoryDb()

QUEUE_STATUSES = ("queued", "paused")
MAX_WATCH_HISTORY_ITEMS = 200
ANIMATION_GENRE_ID = 16

COLLECTION_TITLES = {
    "favorites": "Favorites"
}

COLLECTION_ADD_LABELS = {
    "favorites": "Add to Media Hub Favorites"
}

COLLECTION_REMOVE_LABELS = {
    "favorites": "Remove from Media Hub Favorites"
}

COLLECTION_RECORD_KEYS = (
    "kind",
    "media_type",
    "movie_id",
    "tv_id",
    "season",
    "episode_id",
    "stream_id",
    "title",
    "tv_title",
    "season_title",
    "episode_title",
    "year",
    "poster",
    "fanart",
    "stream_name",
    "size_gb"
)

VIDEO_FILE_EXTENSIONS = {
    ".3gp",
    ".avi",
    ".divx",
    ".flv",
    ".iso",
    ".m2ts",
    ".m4v",
    ".mkv",
    ".mov",
    ".mp4",
    ".mpeg",
    ".mpg",
    ".mts",
    ".ogm",
    ".ts",
    ".vob",
    ".webm",
    ".wmv"
}

def _is_vfs_path(path):
    return "://" in path

def _join_path(base, filename):
    if _is_vfs_path(base):
        return base.rstrip("/\\") + "/" + filename
    return os.path.join(base, filename)

def _video_extension(value):
    if not value:
        return ""

    path = urllib.parse.urlparse(value).path if "://" in value else value
    name = os.path.basename(urllib.parse.unquote(path)).strip()
    ext = os.path.splitext(name)[1].lower()
    return ext if ext in VIDEO_FILE_EXTENSIONS else ""

def _strip_video_extensions(value):
    base = (value or "").strip()
    while True:
        ext = _video_extension(base)
        if not ext:
            return base
        base = os.path.splitext(base)[0].rstrip(" .")

def _safe_download_filename(filename, source_url=""):
    ext = _video_extension(filename) or _video_extension(source_url)
    base = _strip_video_extensions(filename)
    invalid_chars = set('<>:"/\\|?*')
    safe_base = "".join(
        " " if c in invalid_chars or ord(c) < 32 else c
        for c in base
    ).strip(" .")
    if not safe_base:
        safe_base = "download"

    if ext:
        while safe_base.lower().endswith(ext):
            safe_base = safe_base[:-len(ext)].rstrip(" .")
        if not safe_base:
            safe_base = "download"

    return f"{safe_base}{ext}"

def _stream_display_name(stream):
    return stream.get("originalName") or stream.get("name") or "Stream"

def _clean_query_value(value):
    if value is None:
        return ""
    return str(value).strip()

def _addon_bool_setting(setting_id, default=False):
    value = xbmcaddon.Addon().getSetting(setting_id)
    if value == "":
        return default
    return value.lower() == "true"

def _filter_anime_enabled():
    return _addon_bool_setting("filter_anime", True)

def _is_probable_anime(show):
    genre_ids = show.get("genre_ids") or []
    try:
        has_animation_genre = ANIMATION_GENRE_ID in [int(genre_id) for genre_id in genre_ids]
    except (TypeError, ValueError):
        has_animation_genre = False

    original_language = _clean_query_value(show.get("original_language")).lower()
    origin_country = [
        _clean_query_value(country).upper()
        for country in (show.get("origin_country") or [])
    ]

    return has_animation_genre and (
        original_language == "ja" or "JP" in origin_country
    )

def _filter_tv_shows(shows):
    if not _filter_anime_enabled():
        return shows
    return [show for show in shows if not _is_probable_anime(show)]

def _movie_display_title(movie):
    return (
        movie.get("title_with_original_title")
        or movie.get("title")
        or movie.get("original_title")
        or "Movie"
    )

def _movie_release_year(movie):
    release_date = _clean_query_value(movie.get("release_date"))
    if len(release_date) >= 4:
        return release_date[:4]
    return _clean_query_value(movie.get("year"))

def _build_movie_versions_url(movie):
    return build_url({
        'action': 'list_movie_versions',
        'movie_id': movie.get('id', ''),
        'title': _movie_display_title(movie),
        'year': _movie_release_year(movie),
        'poster': movie.get('poster_path', ''),
        'fanart': movie.get('backdrop_path', '')
    })

def build_url(query):
    return f"{sys.argv[0]}?{urllib.parse.urlencode(query)}"

def get_icons_path(image_name):
    addon = xbmcaddon.Addon()
    addon_path = addon.getAddonInfo('path')
    return os.path.join(addon_path, 'resources', 'icons', image_name)

def _as_int(value, default=0):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default

def _queue_position(record):
    value = _as_int(record.get("queue_position"), 0)
    return value if value > 0 else 999999

def _normalize_queue_positions(data):
    queued = []
    for download_id, record in data.items():
        if record.get("status") not in QUEUE_STATUSES:
            continue
        if not record.get("id"):
            record["id"] = download_id
        queued.append((download_id, record))

    queued.sort(key=lambda item: (
        _queue_position(item[1]),
        item[1].get("created_at") or "",
        item[0]
    ))

    for index, (_, record) in enumerate(queued, start=1):
        record["queue_position"] = index

def _list_downloads_normalized():
    def op(data):
        _normalize_queue_positions(data)
        return {download_id: dict(record) for download_id, record in data.items()}
    return db.mutate(op)

def _next_queue_position(data):
    positions = [
        _as_int(record.get("queue_position"), 0)
        for record in data.values()
        if record.get("status") in QUEUE_STATUSES
    ]
    return max(positions or [0]) + 1

def _queue_count(data):
    return sum(1 for record in data.values() if record.get("status") in QUEUE_STATUSES)

def _download_action_queries(record, queue_count=0):
    download_id = record.get("id")
    status = record.get("status")
    position = _as_int(record.get("queue_position"), 0)
    actions = []

    if status in QUEUE_STATUSES:
        if position > 1:
            actions.append(("Move up", {'action': 'move_download', 'id': download_id, 'direction': 'up'}))
            actions.append(("Move to top", {'action': 'move_download', 'id': download_id, 'direction': 'top'}))
        if position and position < queue_count:
            actions.append(("Move down", {'action': 'move_download', 'id': download_id, 'direction': 'down'}))
            actions.append(("Move to bottom", {'action': 'move_download', 'id': download_id, 'direction': 'bottom'}))

    if status in ("queued", "downloading"):
        actions.append(("Pause", {'action': 'pause_download', 'id': download_id}))
    elif status == "paused":
        actions.append(("Resume", {'action': 'resume_download', 'id': download_id}))

    if status in ("queued", "downloading", "paused", "failed"):
        actions.append(("Cancel", {'action': 'cancel_download', 'id': download_id}))

    if status in ("failed", "canceled"):
        actions.append(("Retry", {'action': 'retry_download', 'id': download_id}))

    return actions

def _format_bytes(value):
    size = _as_int(value, 0)
    if size <= 0:
        return "unknown"

    units = ("B", "KB", "MB", "GB", "TB")
    index = 0
    amount = float(size)
    while amount >= 1024 and index < len(units) - 1:
        amount /= 1024
        index += 1

    if index == 0:
        return f"{int(amount)} {units[index]}"
    return f"{amount:.1f} {units[index]}"

def _media_lists_snapshot():
    try:
        data = media_lists_db.list()
    except Exception as ex:
        xbmc.log(f"[media_lists] Could not read media lists: {ex}", xbmc.LOGWARNING)
        data = {}

    return {
        key: data.get(key, {}) if isinstance(data.get(key, {}), dict) else {}
        for key in MEDIA_LIST_KEYS
    }

def _collection_title(collection):
    return COLLECTION_TITLES.get(collection, "Media List")

def _collection_id(record):
    kind = record.get("kind")
    if kind == "movie" and record.get("movie_id") not in (None, ""):
        return f"movie:{record.get('movie_id')}"
    if kind == "tv_show" and record.get("tv_id") not in (None, ""):
        return f"tv:{record.get('tv_id')}"
    if kind == "season" and all(record.get(key) not in (None, "") for key in ("tv_id", "season")):
        return f"season:{record.get('tv_id')}:{record.get('season')}"
    if kind == "episode" and all(record.get(key) not in (None, "") for key in ("tv_id", "season", "episode_id")):
        return f"episode:{record.get('tv_id')}:{record.get('season')}:{record.get('episode_id')}"
    if kind == "stream" and record.get("stream_id") not in (None, ""):
        return f"stream:{record.get('stream_id')}"
    return ""

def _collection_action_query(action, collection, record, item_id=None):
    query = {
        "action": action,
        "collection": collection,
        "item_id": item_id or _collection_id(record)
    }
    for key in COLLECTION_RECORD_KEYS:
        value = record.get(key)
        if value not in (None, ""):
            query[key] = value
    return query

def _collection_context_menu_items(record, collections=None):
    item_id = _collection_id(record)
    if not item_id:
        return []

    collections = collections or _media_lists_snapshot()
    items = []
    for collection in MEDIA_LIST_KEYS:
        if item_id in collections.get(collection, {}):
            label = COLLECTION_REMOVE_LABELS[collection]
            query = {
                "action": "remove_media_list_item",
                "collection": collection,
                "item_id": item_id
            }
        else:
            label = COLLECTION_ADD_LABELS[collection]
            query = _collection_action_query("add_media_list_item", collection, record, item_id)
        items.append((label, f"RunPlugin({build_url(query)})"))
    return items

def _add_collection_context_menu(item, record, collections=None, extra_items=None):
    context_items = list(extra_items or [])
    context_items.extend(_collection_context_menu_items(record, collections))
    if context_items:
        item.addContextMenuItems(context_items, True)

def _collection_record_from_movie(movie):
    return {
        "kind": "movie",
        "movie_id": movie.get("id"),
        "title": _movie_display_title(movie),
        "year": _movie_release_year(movie),
        "poster": movie.get("poster_path", ""),
        "fanart": movie.get("backdrop_path", "")
    }

def _collection_record_from_tv_show(show):
    return {
        "kind": "tv_show",
        "tv_id": show.get("id"),
        "title": show.get("name_with_original_name") or show.get("name") or show.get("original_name") or "TV Show",
        "year": _get_tv_year(show),
        "poster": show.get("poster_path", ""),
        "fanart": show.get("backdrop_path", "")
    }

def _collection_record_from_season(tv_id, tv_title, season, season_title, year, poster, fanart):
    title = f"{tv_title} - {season_title}" if tv_title else season_title
    return {
        "kind": "season",
        "tv_id": tv_id,
        "season": season,
        "title": title,
        "tv_title": tv_title,
        "season_title": season_title,
        "year": year,
        "poster": poster,
        "fanart": fanart
    }

def _collection_record_from_episode(tv_id, season, episode_id, tv_title, episode_title, poster, fanart):
    title = f"{tv_title} - {episode_title}" if tv_title else episode_title
    return {
        "kind": "episode",
        "media_type": "episode",
        "tv_id": tv_id,
        "season": season,
        "episode_id": episode_id,
        "title": title,
        "tv_title": tv_title,
        "episode_title": episode_title,
        "poster": poster,
        "fanart": fanart
    }

def _collection_record_from_movie_stream(stream, movie_id, movie_title, year, poster, fanart):
    display_name = _stream_display_name(stream)
    return {
        "kind": "stream",
        "media_type": "movie",
        "movie_id": movie_id,
        "stream_id": stream.get("id"),
        "title": movie_title or display_name,
        "year": year,
        "poster": poster,
        "fanart": fanart,
        "stream_name": display_name,
        "size_gb": stream.get("sizeInGB")
    }

def _collection_record_from_episode_stream(stream, tv_id, season, episode_id, tv_title, episode_title, poster, fanart):
    display_name = _stream_display_name(stream)
    title = f"{tv_title} - {episode_title}" if tv_title else episode_title
    return {
        "kind": "stream",
        "media_type": "episode",
        "tv_id": tv_id,
        "season": season,
        "episode_id": episode_id,
        "stream_id": stream.get("id"),
        "title": title,
        "tv_title": tv_title,
        "episode_title": episode_title,
        "poster": poster,
        "fanart": fanart,
        "stream_name": display_name,
        "size_gb": stream.get("sizeInGB")
    }

def _collection_record_from_params(params):
    record = {
        key: params.get(key)
        for key in COLLECTION_RECORD_KEYS
        if params.get(key) not in (None, "")
    }
    item_id = params.get("item_id") or _collection_id(record)
    if item_id:
        record["id"] = item_id
    return item_id, record

def _collection_label(record):
    kind = record.get("kind")
    title = record.get("title") or record.get("stream_name") or "Media"
    year = record.get("year")

    if kind == "movie":
        return f"[Movie] {title} [COLOR FFAAAAAA][{year}][/COLOR]" if year else f"[Movie] {title}"
    if kind == "tv_show":
        return f"[TV] {title} [COLOR FFAAAAAA][{year}][/COLOR]" if year else f"[TV] {title}"
    if kind == "season":
        season_title = record.get("season_title") or f"Séria {record.get('season', '')}".strip()
        tv_title = record.get("tv_title")
        label = f"{tv_title} - {season_title}" if tv_title else title
        return f"[Season] {label}"
    if kind == "episode":
        return f"[Episode] {title}"
    if kind == "stream":
        stream_name = record.get("stream_name") or title
        if stream_name != title:
            return f"[Stream] {title} - {stream_name}"
        return f"[Stream] {stream_name}"
    return title

def _collection_plot(record):
    lines = []
    kind = record.get("kind")
    if kind:
        lines.append(f"Type: {kind.replace('_', ' ')}")
    if record.get("stream_name"):
        lines.append(f"Stream: {record.get('stream_name')}")
    if record.get("size_gb"):
        lines.append(f"Size: {record.get('size_gb')} GB")
    if record.get("tv_title"):
        lines.append(f"TV show: {record.get('tv_title')}")
    if record.get("season"):
        lines.append(f"Season: {record.get('season')}")
    if record.get("episode_title"):
        lines.append(f"Episode: {record.get('episode_title')}")
    if record.get("added_at"):
        lines.append(f"Added: {record.get('added_at').replace('T', ' ')}")
    return "\n".join(lines) or u"\u00A0"

def _collection_art(record):
    art = {}
    if record.get("poster"):
        art["poster"] = record.get("poster")
        art["thumb"] = record.get("poster")
    if record.get("fanart"):
        art["fanart"] = record.get("fanart")
    return art

def _collection_open_query(record):
    kind = record.get("kind")
    if kind == "movie":
        return {
            "action": "list_movie_versions",
            "movie_id": record.get("movie_id", ""),
            "title": record.get("title", ""),
            "year": record.get("year", ""),
            "poster": record.get("poster", ""),
            "fanart": record.get("fanart", "")
        }
    if kind == "tv_show":
        return {
            "action": "list_seasons",
            "tv_id": record.get("tv_id", "")
        }
    if kind == "season":
        return {
            "action": "list_episodes",
            "tv_id": record.get("tv_id", ""),
            "season": record.get("season", ""),
            "tv_title": record.get("tv_title", ""),
            "poster": record.get("poster", ""),
            "fanart": record.get("fanart", "")
        }
    if kind == "episode":
        return {
            "action": "show_streams",
            "tv_id": record.get("tv_id", ""),
            "season": record.get("season", ""),
            "episode_id": record.get("episode_id", ""),
            "tv_title": record.get("tv_title", ""),
            "poster": record.get("poster", ""),
            "fanart": record.get("fanart", "")
        }
    if kind == "stream":
        query = {
            "action": "play_movie_stream",
            "stream_id": record.get("stream_id", "")
        }
        for key in (
            "media_type",
            "movie_id",
            "tv_id",
            "season",
            "episode_id",
            "tv_title",
            "episode_title",
            "title",
            "year",
            "poster",
            "fanart",
            "stream_name"
        ):
            value = record.get(key)
            if value not in (None, ""):
                query[key] = value
        return query
    return {}

def _collection_is_folder(record):
    return record.get("kind") != "stream"

def show_media_collection(handle, collection):
    source_collection = collection
    if source_collection not in MEDIA_LIST_KEYS:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    title = _collection_title(source_collection)
    xbmcplugin.setPluginCategory(handle, title)
    try:
        xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_UNSORTED)
    except Exception:
        pass

    collections = _media_lists_snapshot()
    records = sorted(
        collections.get(source_collection, {}).values(),
        key=lambda record: record.get("added_at") or "",
        reverse=True
    )
    if records:
        clear_item = xbmcgui.ListItem(label=f"Clear {_collection_title(source_collection)}")
        clear_item.setArt({
            'icon': get_icons_path('clear.png'),
            'thumb': get_icons_path('clear.png')
        })
        clear_item.setInfo('video', {'plot': f"Remove all local {_collection_title(source_collection).lower()} entries."})
        clear_url = build_url({'action': 'clear_media_list', 'collection': source_collection})
        xbmcplugin.addDirectoryItem(handle, clear_url, clear_item, isFolder=False)
    elif not records:
        empty_item = xbmcgui.ListItem(label=f"{title} is empty")
        empty_item.setInfo('video', {'plot': u"\u00A0"})
        xbmcplugin.addDirectoryItem(handle, "", empty_item, isFolder=False)
        xbmcplugin.endOfDirectory(handle)
        return

    for record in records:
        item_id = record.get("id") or _collection_id(record)
        if not item_id:
            continue

        item = xbmcgui.ListItem(label=_collection_label(record))
        item.setInfo('video', {
            'title': record.get("title") or record.get("stream_name") or "Media",
            'plot': _collection_plot(record)
        })
        art = _collection_art(record)
        if art:
            item.setArt(art)

        if record.get("kind") == "stream":
            item.setProperty('IsPlayable', 'true')

        context_items = _collection_context_menu_items(record, collections)
        context_items.append((
            f"Clear {_collection_title(source_collection)}",
            f"RunPlugin({build_url({'action': 'clear_media_list', 'collection': source_collection})})"
        ))
        item.addContextMenuItems(context_items, True)

        open_query = _collection_open_query(record)
        url = build_url(open_query) if open_query else ""
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=_collection_is_folder(record))

    xbmcplugin.endOfDirectory(handle)

def show_favorites(handle):
    show_media_collection(handle, "favorites")

def add_media_list_item(collection, params):
    if collection not in MEDIA_LIST_KEYS:
        xbmcgui.Dialog().notification("Media List", "Unknown list", xbmcgui.NOTIFICATION_ERROR, 2000)
        return

    item_id, record = _collection_record_from_params(params or {})
    if not item_id:
        xbmcgui.Dialog().notification(_collection_title(collection), "Item cannot be saved", xbmcgui.NOTIFICATION_ERROR, 2000)
        return

    try:
        added = media_lists_db.upsert(collection, item_id, record)
    except Exception as ex:
        xbmc.log(f"[media_lists] Could not add item {item_id} to {collection}: {ex}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification(_collection_title(collection), "Could not save item", xbmcgui.NOTIFICATION_ERROR, 2500)
        return

    message = "Added" if added else "Updated"
    xbmcgui.Dialog().notification(_collection_title(collection), f"{message}: {_collection_label(record)}", xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin("Container.Refresh")

def remove_media_list_item(collection, item_id):
    if collection not in MEDIA_LIST_KEYS or not item_id:
        return

    try:
        removed = media_lists_db.remove(collection, item_id)
    except Exception as ex:
        xbmc.log(f"[media_lists] Could not remove item {item_id} from {collection}: {ex}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification(_collection_title(collection), "Could not remove item", xbmcgui.NOTIFICATION_ERROR, 2500)
        return

    if removed:
        xbmcgui.Dialog().notification(_collection_title(collection), "Item removed", xbmcgui.NOTIFICATION_INFO, 1500)
    xbmc.executebuiltin("Container.Refresh")

def clear_media_list(collection):
    if collection not in MEDIA_LIST_KEYS:
        return

    title = _collection_title(collection)
    confirm = xbmcgui.Dialog().yesno(title, f"All local {title.lower()} entries will be removed. Continue?", yeslabel="Yes", nolabel="No")
    if not confirm:
        return

    media_lists_db.clear(collection)
    xbmc.executebuiltin("Container.Refresh")

def _history_id(record):
    media_type = record.get("media_type")
    if media_type == "movie" and record.get("movie_id") not in (None, ""):
        return f"movie:{record.get('movie_id')}"
    if media_type == "episode" and all(record.get(key) not in (None, "") for key in ("tv_id", "season", "episode_id")):
        return f"episode:{record.get('tv_id')}:{record.get('season')}:{record.get('episode_id')}"
    return f"stream:{record.get('stream_id')}"

def _trim_watch_history(data):
    if len(data) <= MAX_WATCH_HISTORY_ITEMS:
        return

    ordered = sorted(
        data.items(),
        key=lambda item: item[1].get("last_played_at") or item[1].get("created_at") or ""
    )
    for history_id, _ in ordered[:len(data) - MAX_WATCH_HISTORY_ITEMS]:
        data.pop(history_id, None)

def _record_watch_history(stream_id, params):
    if not stream_id:
        return

    params = params or {}
    media_type = params.get("media_type") or "stream"
    stream_name = params.get("stream_name") or params.get("filename") or ""
    title = params.get("title") or stream_name or f"Stream {stream_id}"
    timestamp = now_iso()
    record = {
        "stream_id": stream_id,
        "media_type": media_type,
        "movie_id": params.get("movie_id"),
        "tv_id": params.get("tv_id"),
        "season": params.get("season"),
        "episode_id": params.get("episode_id"),
        "tv_title": params.get("tv_title"),
        "episode_title": params.get("episode_title"),
        "title": title,
        "year": params.get("year"),
        "poster": params.get("poster"),
        "fanart": params.get("fanart"),
        "stream_name": stream_name,
        "last_played_at": timestamp
    }
    history_id = _history_id(record)
    record["id"] = history_id

    def op(data):
        existing = data.get(history_id, {})
        record["created_at"] = existing.get("created_at") or timestamp
        record["play_count"] = _as_int(existing.get("play_count"), 0) + 1
        data[history_id] = {
            key: value for key, value in record.items()
            if value not in (None, "")
        }
        _trim_watch_history(data)

    try:
        watch_history_db.mutate(op)
    except Exception as ex:
        xbmc.log(f"[watch_history] Could not record stream {stream_id}: {ex}", xbmc.LOGWARNING)

def _history_label(record):
    title = record.get("title") or record.get("stream_name") or "Stream"
    year = record.get("year")
    if record.get("media_type") == "movie" and year:
        return f"{title} [COLOR FFAAAAAA][{year}][/COLOR]"
    if record.get("media_type") == "episode":
        return f"[TV] {title}"
    return title

def _history_plot(record):
    lines = []
    if record.get("stream_name"):
        lines.append(f"Stream: {record.get('stream_name')}")
    if record.get("last_played_at"):
        lines.append(f"Last played: {record.get('last_played_at').replace('T', ' ')}")
    if record.get("play_count"):
        lines.append(f"Play count: {record.get('play_count')}")
    return "\n".join(lines) or u"\u00A0"

def _history_play_query(record):
    query = {
        "action": "play_movie_stream",
        "stream_id": record.get("stream_id", "")
    }
    for key in (
        "media_type",
        "movie_id",
        "tv_id",
        "season",
        "episode_id",
        "tv_title",
        "episode_title",
        "title",
        "year",
        "poster",
        "fanart",
        "stream_name"
    ):
        value = record.get(key)
        if value not in (None, ""):
            query[key] = value
    return query

def _history_episode_navigation_context_menu_items(record):
    if record.get("media_type") != "episode":
        return []

    tv_id = record.get("tv_id")
    if tv_id in (None, ""):
        return []

    tv_show_url = build_url({
        'action': 'list_seasons',
        'tv_id': tv_id
    })
    items = [(
        "Prejsť na seriál",
        f"Container.Update({tv_show_url})"
    )]

    season = record.get("season")
    if season not in (None, ""):
        season_url = build_url({
            'action': 'list_episodes',
            'tv_id': tv_id,
            'season': season,
            'tv_title': record.get('tv_title') or '',
            'poster': record.get('poster') or '',
            'fanart': record.get('fanart') or ''
        })
        items.append((
            "Prejsť na sériu",
            f"Container.Update({season_url})"
        ))

    return items

def show_main_menu(handle):

    xbmcplugin.setPluginCategory(handle, "Hlavné Menu")
    # xbmcplugin.setContent(handle, "movies")

    # Movies
    menuItemMovies = xbmcgui.ListItem(label="Filmy")
    menuItemMovies.setInfo('video', { 'plot': u"\u00A0" })
    menuItemMovies.setArt({
        'icon': get_icons_path('movies.png'),
        'thumb': get_icons_path('movies.png')
    })
    urlMovies = build_url({'action': 'menu_item_movies'})
    xbmcplugin.addDirectoryItem(handle, urlMovies, menuItemMovies, isFolder=True)

    # TV Shows
    menuItemTvShows = xbmcgui.ListItem(label="Seriály")
    menuItemTvShows.setInfo('video', { 'plot': u"\u00A0" })
    menuItemTvShows.setArt({
        'icon': get_icons_path('tvshows.png'),
        'thumb': get_icons_path('tvshows.png')
    })
    urlTvShows = build_url({'action': 'menu_item_tvshows'})
    xbmcplugin.addDirectoryItem(handle, urlTvShows, menuItemTvShows, isFolder=True)

    # Downloads
    menuItemDownloads = xbmcgui.ListItem(label="Downloads")
    menuItemDownloads.setInfo('video', { 'plot': u"\u00A0" })
    menuItemDownloads.setArt({
        'icon': get_icons_path('downloads.png'),
        'thumb': get_icons_path('downloads.png')
    })
    urlDownloads = build_url({'action': 'show_downloads_menu'})
    xbmcplugin.addDirectoryItem(handle, urlDownloads, menuItemDownloads, isFolder=True)

    # Watch History
    menuItemWatchHistory = xbmcgui.ListItem(label="História pozerania")
    menuItemWatchHistory.setInfo('video', { 'plot': u"\u00A0" })
    menuItemWatchHistory.setArt({
        'icon': get_icons_path('done.png'),
        'thumb': get_icons_path('done.png')
    })
    urlWatchHistory = build_url({'action': 'show_watch_history'})
    xbmcplugin.addDirectoryItem(handle, urlWatchHistory, menuItemWatchHistory, isFolder=True)

    # Favorites
    menuItemFavorites = xbmcgui.ListItem(label="Favorites")
    menuItemFavorites.setInfo('video', { 'plot': u"\u00A0" })
    menuItemFavorites.setArt({
        'icon': get_icons_path('popular1.png'),
        'thumb': get_icons_path('popular1.png')
    })
    urlFavorites = build_url({'action': 'show_favorites'})
    xbmcplugin.addDirectoryItem(handle, urlFavorites, menuItemFavorites, isFolder=True)

    xbmcplugin.endOfDirectory(handle)

def show_watch_history(handle):
    xbmcplugin.setPluginCategory(handle, "História pozerania")
    try:
        xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_UNSORTED)
    except Exception:
        pass

    data = watch_history_db.list()
    records = sorted(
        data.values(),
        key=lambda record: record.get("last_played_at") or record.get("created_at") or "",
        reverse=True
    )

    if records:
        clear_item = xbmcgui.ListItem(label="Vymazať históriu pozerania")
        clear_item.setArt({
            'icon': get_icons_path('clear.png'),
            'thumb': get_icons_path('clear.png')
        })
        clear_item.setInfo('video', {'plot': 'Vymazať všetky lokálne záznamy histórie pozerania.'})
        clear_url = build_url({'action': 'clear_watch_history'})
        xbmcplugin.addDirectoryItem(handle, clear_url, clear_item, isFolder=False)
    else:
        empty_item = xbmcgui.ListItem(label="História je prázdna")
        empty_item.setInfo('video', {'plot': u"\u00A0"})
        xbmcplugin.addDirectoryItem(handle, "", empty_item, isFolder=False)
        xbmcplugin.endOfDirectory(handle)
        return

    for record in records:
        if not record.get("stream_id"):
            continue

        history_id = record.get("id") or _history_id(record)
        item = xbmcgui.ListItem(label=_history_label(record))
        item.setInfo('video', {
            'title': record.get("title") or record.get("stream_name") or "Stream",
            'plot': _history_plot(record)
        })
        art = {}
        if record.get("poster"):
            art['poster'] = record.get("poster")
            art['thumb'] = record.get("poster")
        if record.get("fanart"):
            art['fanart'] = record.get("fanart")
        if art:
            item.setArt(art)
        item.setProperty('IsPlayable', 'true')
        context_items = _history_episode_navigation_context_menu_items(record)
        context_items.extend([
            ("Odstrániť z histórie", f"RunPlugin({build_url({'action': 'remove_watch_history_item', 'id': history_id})})"),
            ("Vymazať históriu pozerania", f"RunPlugin({build_url({'action': 'clear_watch_history'})})")
        ])
        item.addContextMenuItems(context_items, True)

        url = build_url(_history_play_query(record))
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=False)

    xbmcplugin.endOfDirectory(handle)

def remove_watch_history_item(history_id):
    removed = watch_history_db.remove(history_id)
    if removed:
        xbmcgui.Dialog().notification("História pozerania", "Záznam odstránený", xbmcgui.NOTIFICATION_INFO, 1500)
    xbmc.executebuiltin("Container.Refresh")

def clear_watch_history():
    confirm = xbmcgui.Dialog().yesno("Vymazať históriu pozerania", "Všetky lokálne záznamy histórie pozerania budú odstránené. Pokračovať?", yeslabel="Áno", nolabel="Nie")
    if not confirm:
        return

    watch_history_db.clear_all()
    xbmc.executebuiltin("Container.Refresh")

def menu_item_movies(handle):

    xbmcplugin.setPluginCategory(handle, "Filmy")
    #xbmcplugin.setContent(handle, "movies")

    # Latest Movies
    menuItemMoviesLatest = xbmcgui.ListItem(label="Nové ")
    menuItemMoviesLatest.setInfo('video', { 'plot': u"\u00A0" })
    menuItemMoviesLatest.setArt({
        'icon': get_icons_path('new.png'),
        'thumb': get_icons_path('new.png')
    })
    urlMoviesLatest = build_url({'action': 'menu_item_movies_latest'})
    xbmcplugin.addDirectoryItem(handle, urlMoviesLatest, menuItemMoviesLatest, isFolder=True)

    # Popular Movies
    menuItemMoviesPopular = xbmcgui.ListItem(label="Populárne")
    menuItemMoviesPopular.setInfo('video', { 'plot': u"\u00A0" })
    menuItemMoviesPopular.setArt({
        'icon': get_icons_path('popular1.png'),
        'thumb': get_icons_path('popular1.png')
    })
    urlMoviesPopular = build_url({'action': 'menu_item_movies_popular'})
    xbmcplugin.addDirectoryItem(handle, urlMoviesPopular, menuItemMoviesPopular, isFolder=True)

    # Top Rated Movies
    menuItemMoviesTopRated = xbmcgui.ListItem(label="Najlepšie Hodnotené")
    menuItemMoviesTopRated.setInfo('video', { 'plot': u"\u00A0" })
    menuItemMoviesTopRated.setArt({
        'icon': get_icons_path('top-rated.png'),
        'thumb': get_icons_path('top-rated.png')
    })
    urlMoviesTopRated = build_url({'action': 'menu_item_movies_toprated'})
    xbmcplugin.addDirectoryItem(handle, urlMoviesTopRated, menuItemMoviesTopRated, isFolder=True)

    # # Genres
    # menuItemMoviesGenres = xbmcgui.ListItem(label="Podľa Žánrov")
    # menuItemMoviesGenres.setInfo('video', { 'plot': u"\u00A0" })
    # urlMoviesGenres = build_url({'action': 'menu_item_movies_genres'})
    # xbmcplugin.addDirectoryItem(handle, urlMoviesGenres, menuItemMoviesGenres, isFolder=True)

    # Search
    menuItemMoviesSearch = xbmcgui.ListItem(label="Hľadať")
    menuItemMoviesSearch.setProperty('IsPlayable', 'false')
    menuItemMoviesSearch.setInfo('video', { 'plot': u"\u00A0" })
    menuItemMoviesSearch.setArt({
        'icon': get_icons_path('search.png'),
        'thumb': get_icons_path('search.png')
    })
    urlMoviesSearch = build_url({'action': 'menu_item_movies_search'})
    xbmcplugin.addDirectoryItem(handle, urlMoviesSearch, menuItemMoviesSearch, isFolder=True)

    xbmcplugin.endOfDirectory(handle)

def menu_item_tvshows(handle):

    xbmcplugin.setPluginCategory(handle, "Seriály")

    # Latest Tv Shows
    menuItemTvShowsLatest = xbmcgui.ListItem(label="Nové seriály")
    menuItemTvShowsLatest.setInfo('video', { 'plot': u"\u00A0" })
    menuItemTvShowsLatest.setArt({
        'icon': get_icons_path('new.png'),
        'thumb': get_icons_path('new.png')
    })
    urlTvShowsLatest = build_url({'action': 'list_tv_shows_latest'})
    xbmcplugin.addDirectoryItem(handle, urlTvShowsLatest, menuItemTvShowsLatest, isFolder=True)

    # Recently aired seasons and episodes
    menuItemTvShowsRecentlyAired = xbmcgui.ListItem(label="Nové série a epizódy")
    menuItemTvShowsRecentlyAired.setInfo('video', { 'plot': u"\u00A0" })
    menuItemTvShowsRecentlyAired.setArt({
        'icon': get_icons_path('new.png'),
        'thumb': get_icons_path('new.png')
    })
    urlTvShowsRecentlyAired = build_url({'action': 'list_tv_shows_recently_aired'})
    xbmcplugin.addDirectoryItem(handle, urlTvShowsRecentlyAired, menuItemTvShowsRecentlyAired, isFolder=True)

    # Popular Tv Shows
    menuItemTvShowsPopular = xbmcgui.ListItem(label="Populárne")
    menuItemTvShowsPopular.setInfo('video', { 'plot': u"\u00A0" })
    menuItemTvShowsPopular.setArt({
        'icon': get_icons_path('popular1.png'),
        'thumb': get_icons_path('popular1.png')
    })
    urlTvShowsPopular = build_url({'action': 'list_tv_shows_popular'})
    xbmcplugin.addDirectoryItem(handle, urlTvShowsPopular, menuItemTvShowsPopular, isFolder=True)

    # Top Rated Tv Shows
    menuItemTvShowsSlovak = xbmcgui.ListItem(label="Slovenské")
    menuItemTvShowsSlovak.setInfo('video', { 'plot': u"\u00A0" })
    menuItemTvShowsSlovak.setArt({
        'icon': get_icons_path('slovak.png'),
        'thumb': get_icons_path('slovak.png')
    })
    urlTvShowsSlovak = build_url({'action': 'list_tv_shows_sk'})
    xbmcplugin.addDirectoryItem(handle, urlTvShowsSlovak, menuItemTvShowsSlovak, isFolder=True)

    # # Genres
    # menuItemMoviesGenres = xbmcgui.ListItem(label="Podľa Žánrov")
    # menuItemMoviesGenres.setInfo('video', { 'plot': u"\u00A0" })
    # urlMoviesGenres = build_url({'action': 'menu_item_movies_genres'})
    # xbmcplugin.addDirectoryItem(handle, urlMoviesGenres, menuItemMoviesGenres, isFolder=True)

    # Search
    menuItemTvSearch = xbmcgui.ListItem(label="Hľadať")
    menuItemTvSearch.setProperty('IsPlayable', 'false')
    menuItemTvSearch.setInfo('video', { 'plot': u"\u00A0" })
    menuItemTvSearch.setArt({
        'icon': get_icons_path('search.png'),
        'thumb': get_icons_path('search.png')
    })
    urlTvSearch = build_url({'action': 'menu_item_tvshows_search'})
    xbmcplugin.addDirectoryItem(handle, urlTvSearch, menuItemTvSearch, isFolder=True)

    xbmcplugin.endOfDirectory(handle)

def menu_item_movies_latest(handle):
    page = int(dict(urllib.parse.parse_qsl(sys.argv[2][1:])).get('page', 1))
    response = api.get_movies_latest(page)
    movies = response.get('results', [])
    total_pages = response.get('total_pages', 1)
    collections = _media_lists_snapshot()

    for movie in movies:
        label = (
            f"{movie['title_with_original_title']} [COLOR FFAAAAAA][{movie['release_date'][:4]}][/COLOR] "
            f"{_format_vote_hearts(movie.get('vote_count'))}"
        )
        item = xbmcgui.ListItem(label=label)
        item.setArt({
            'poster': movie.get('poster_path', ''),
            'fanart': movie.get('backdrop_path', '')
        })
        item.setInfo('video', {
            'title': movie['title'],
            'plot': movie.get('overview', '')
        })
        _add_collection_context_menu(item, _collection_record_from_movie(movie), collections)
        url = _build_movie_versions_url(movie)
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    if page < total_pages:
        nextPage = page + 1
        item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
        url = build_url({'action': 'menu_item_movies_latest', 'page': nextPage})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    xbmcplugin.endOfDirectory(handle, updateListing=False)

def menu_item_movies_popular(handle):
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    filter_type = params.get('filter_type')
    year = params.get('year')
    page = int(params.get('page', 1))
    
    # If no filter type, show submenu
    if not filter_type:
        xbmcplugin.setPluginCategory(handle, "Populárne")
        xbmcplugin.setContent(handle, "movies")
        
        # All Times
        item = xbmcgui.ListItem(label="Všetky roky")
        item.setInfo('movies', { 'plot': u"\u00A0" })
        url = build_url({'action': 'menu_item_movies_popular', 'filter_type': 'all_time'})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
        
        # By Year
        item = xbmcgui.ListItem(label="Podľa Roku")
        item.setInfo('video', { 'plot': u"\u00A0" })
        url = build_url({'action': 'menu_item_movies_popular', 'filter_type': 'by_year'})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
        
        xbmcplugin.endOfDirectory(handle)
        return
    
    # If filter_type is 'by_year' but no year selected, show year selector
    if filter_type == 'by_year' and not year:
        xbmcplugin.setPluginCategory(handle, "Populárne - Podľa Roku")
        xbmcplugin.setContent(handle, "movies")
        
        import datetime
        current_year = datetime.datetime.now().year
        
        # Show years from current year back to 1940
        for yr in range(current_year, 1940, -1):
            item = xbmcgui.ListItem(label=str(yr))
            item.setInfo('movies', { 'plot': u"\u00A0" })
            url = build_url({'action': 'menu_item_movies_popular', 'filter_type': 'by_year', 'year': yr})
            xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
        
        xbmcplugin.endOfDirectory(handle)
        return
    
    # Show movies based on filter
    if filter_type == 'all_time':
        response = api.get_movies_popular(page)
    elif filter_type == 'by_year' and year:
        response = api.get_movies_popular(page, year)
    else:
        response = api.get_movies_popular(page)
    
    movies = response.get('results', [])
    total_pages = response.get('total_pages', 1)
    collections = _media_lists_snapshot()

    for movie in movies:
        label = f"{movie['title_with_original_title']} [COLOR FFAAAAAA][{movie['release_date'][:4]}][/COLOR]"
        item = xbmcgui.ListItem(label=label)
        item.setArt({
            'poster': movie.get('poster_path', ''),
            'fanart': movie.get('backdrop_path', '')
        })
        item.setInfo('video', {
            'title': movie['title'],
            'plot': movie.get('overview', '')
        })
        _add_collection_context_menu(item, _collection_record_from_movie(movie), collections)
        url = _build_movie_versions_url(movie)
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    if page < total_pages:
        nextPage = page + 1
        extra_params = {'filter_type': filter_type}
        if year:
            extra_params['year'] = year
        item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
        url = build_url({'action': 'menu_item_movies_popular', 'page': nextPage, **extra_params})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    xbmcplugin.endOfDirectory(handle, updateListing=False)

def menu_item_movies_toprated(handle):
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    filter_type = params.get('filter_type')
    year = params.get('year')
    page = int(params.get('page', 1))
    
    # If no filter type, show submenu
    if not filter_type:
        xbmcplugin.setPluginCategory(handle, "Najlepšie Hodnotené")
        xbmcplugin.setContent(handle, "movies")
        
        # All Times
        item = xbmcgui.ListItem(label="Všetky roky")
        item.setInfo('movies', { 'plot': u"\u00A0" })
        url = build_url({'action': 'menu_item_movies_toprated', 'filter_type': 'all_time'})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
        
        # By Year
        item = xbmcgui.ListItem(label="Podľa Roku")
        item.setInfo('video', { 'plot': u"\u00A0" })
        url = build_url({'action': 'menu_item_movies_toprated', 'filter_type': 'by_year'})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
        
        xbmcplugin.endOfDirectory(handle)
        return
    
    # If filter_type is 'by_year' but no year selected, show year selector
    if filter_type == 'by_year' and not year:
        xbmcplugin.setPluginCategory(handle, "Najlepšie Hodnotené - Podľa Roku")
        xbmcplugin.setContent(handle, "movies")
        
        import datetime
        current_year = datetime.datetime.now().year
        
        # Show years from current year back to 1990
        for yr in range(current_year, 1940, -1):
            item = xbmcgui.ListItem(label=str(yr))
            item.setInfo('movies', { 'plot': u"\u00A0" })
            url = build_url({'action': 'menu_item_movies_toprated', 'filter_type': 'by_year', 'year': yr})
            xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
        
        xbmcplugin.endOfDirectory(handle)
        return
    
    # Show movies based on filter
    if filter_type == 'all_time':
        response = api.get_movies_toprated(page)
    elif filter_type == 'by_year' and year:
        response = api.get_movies_toprated(page, year)
    else:
        response = api.get_movies_toprated(page)
    
    movies = response.get('results', [])
    total_pages = response.get('total_pages', 1)
    collections = _media_lists_snapshot()

    for movie in movies:
        label = f"{movie['title_with_original_title']} [COLOR FFAAAAAA][{movie['release_date'][:4]}][/COLOR]"
        item = xbmcgui.ListItem(label=label)
        item.setArt({
            'poster': movie.get('poster_path', ''),
            'fanart': movie.get('backdrop_path', '')
        })
        item.setInfo('video', {
            'title': movie['title'],
            'plot': movie.get('overview', '')
        })
        _add_collection_context_menu(item, _collection_record_from_movie(movie), collections)
        url = _build_movie_versions_url(movie)
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    if page < total_pages:
        nextPage = page + 1
        extra_params = {'filter_type': filter_type}
        if year:
            extra_params['year'] = year
        item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
        url = build_url({'action': 'menu_item_movies_toprated', 'page': nextPage, **extra_params})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    xbmcplugin.endOfDirectory(handle, updateListing=False)

def menu_item_movies_search(handle):
    # Get parameters from URL
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    search_query = params.get('search_query')
    page = int(params.get('page', 1))
    
    # Only show keyboard if no search_query (initial search)
    if not search_query:
        keyboard = xbmc.Keyboard('', 'Hľadať Filmy')
        keyboard.doModal()
        if keyboard.isConfirmed():
            search_query = keyboard.getText()
        else:
            return  # User cancelled
    
    if search_query:
        response = api.get_movies_search(search_query, page)
        movies = response.get('results', [])
        total_pages = response.get('total_pages', 1)
        collections = _media_lists_snapshot()

        for movie in movies:
            year = movie.get("release_date", "")[:4] if movie.get("release_date") else "----"
            label = (
                f"{movie['title_with_original_title']} [COLOR FFAAAAAA][{year}][/COLOR] "
                f" {_format_vote_hearts(movie.get('vote_count'))}"
            )
            item = xbmcgui.ListItem(label=label)
            item.setArt({
                'poster': movie.get('poster_path', ''),
                'fanart': movie.get('backdrop_path', '')
            })
            item.setInfo('video', {
                'title': movie['title'],
                'plot': movie.get('overview', '')
            })
            _add_collection_context_menu(item, _collection_record_from_movie(movie), collections)
            url = _build_movie_versions_url(movie)
            xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

        if page < total_pages:
            nextPage = page + 1
            item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
            url = build_url({'action': 'menu_item_movies_search', 'page': nextPage, 'search_query': search_query})
            xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

        xbmcplugin.endOfDirectory(handle, updateListing=False)




    # itemTvSeriesLatest = xbmcgui.ListItem(label="Seriály - Nové")
    # url = build_url({'action': 'list_tv_shows_latest'})
    # xbmcplugin.addDirectoryItem(handle, url, itemTvSeriesLatest, isFolder=True)

    # itemTvSeriesPopular = xbmcgui.ListItem(label="Seriály - Populárne")
    # url = build_url({'action': 'list_tv_shows_popular'})
    # xbmcplugin.addDirectoryItem(handle, url, itemTvSeriesPopular, isFolder=True)

    # itemTvSeriesSk = xbmcgui.ListItem(label="Seriály - SK")
    # url = build_url({'action': 'list_tv_shows_sk'})
    # xbmcplugin.addDirectoryItem(handle, url, itemTvSeriesSk, isFolder=True)

def _get_tv_year(show):
    year = show.get("first_air_date_year")
    if year:
        return str(year)

    first_air_date = show.get("first_air_date") or ""
    return first_air_date[:4] if first_air_date else "----"

def _extract_year(item):
    for key in ("year", "first_air_date_year"):
        value = item.get(key)
        if value not in (None, ""):
            return str(value)

    for key in ("air_date", "first_air_date", "release_date"):
        value = item.get(key) or ""
        if len(value) >= 4:
            return value[:4]

    return "----"

def _get_episode_title(ep):
    return ep.get("title") or ep.get("name") or f"Episode {ep.get('episode_number', '?')}"

def _format_vote_hearts(vote_count):
    if vote_count is None:
        vote_count = 0

    if vote_count < 200:
        filled_hearts = 0
    elif vote_count < 500:
        filled_hearts = 1
    elif vote_count <= 1000:
        filled_hearts = 2
    else:
        filled_hearts = 3

    hearts = []
    for index in range(3):
        if index < filled_hearts:
            # use a softer golden tone instead of bright yellow
            hearts.append("[COLOR FFB8860B]★[/COLOR]")
        else:
            # slightly darker grey for empty stars
            hearts.append("[COLOR FF909090]☆[/COLOR]")
    return "".join(hearts)

def _date_only(value):
    value = _clean_query_value(value)
    if len(value) >= 10:
        return value[:10]
    return value

def _format_episode_ref(episode):
    if not isinstance(episode, dict):
        return ""

    season_number = episode.get("season_number")
    episode_number = episode.get("episode_number")
    if season_number in (None, "") or episode_number in (None, ""):
        return ""

    try:
        return f"S{int(season_number):02d}E{int(episode_number):02d}"
    except (TypeError, ValueError):
        return ""

def _recent_tv_activity_label(show):
    episode = show.get("last_episode_to_air") or {}
    episode_ref = _format_episode_ref(episode)
    air_date = _date_only(episode.get("air_date") or show.get("last_air_date"))

    if episode_ref and air_date:
        return f"{episode_ref} {air_date}"
    if episode_ref:
        return episode_ref
    return air_date

def _recent_tv_activity_plot(show):
    episode = show.get("last_episode_to_air") or {}
    episode_ref = _format_episode_ref(episode)
    episode_name = _clean_query_value(episode.get("name"))
    air_date = _date_only(episode.get("air_date") or show.get("last_air_date"))
    lines = []

    if episode_ref:
        title = f"Najnovšia epizóda: {episode_ref}"
        if episode_name:
            title = f"{title} - {episode_name}"
        lines.append(title)
    if air_date:
        lines.append(f"Dátum odvysielania: {air_date}")

    return "\n".join(lines)

def _build_tv_show_item(show, include_vote_count=False, include_hearts=True, include_recent_activity=False):
    year = _get_tv_year(show)
    display_title = show.get("name_with_original_name") or show.get("name") or ""
    vote_count = show.get("vote_count")
    hearts = _format_vote_hearts(vote_count) if include_hearts else ""
    recent_activity = ""
    if include_recent_activity:
        recent_activity_label = _recent_tv_activity_label(show)
        if recent_activity_label:
            recent_activity = f" [COLOR FF00C8FF][{recent_activity_label}][/COLOR]"

    item = xbmcgui.ListItem(
        label=f"{display_title} [COLOR FFAAAAAA][{year}][/COLOR] {hearts}{recent_activity}".strip()
    )
    plot = show.get('overview', '')
    if include_recent_activity:
        activity_plot = _recent_tv_activity_plot(show)
        if activity_plot and plot:
            plot = f"{activity_plot}\n\n{plot}"
        elif activity_plot:
            plot = activity_plot

    item.setArt({
        'poster': show.get('poster_path', ''),
        'fanart': show.get('backdrop_path', '')
    })
    item.setInfo('video', {
        'title': show.get('name') or display_title,
        'plot': plot
    })
    return item

def menu_item_tvshows_search(handle):
    # Get parameters from URL
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    search_query = params.get('search_query')
    page = int(params.get('page', 1))
    
    # Only show keyboard if no search_query (initial search)
    if not search_query:
        keyboard = xbmc.Keyboard('', 'Hľadať Seriály')
        keyboard.doModal()
        if keyboard.isConfirmed():
            search_query = keyboard.getText()
        else:
            return  # User cancelled
    
    if search_query:
        response = api.get_tv_search(search_query, page)
        shows = _filter_tv_shows(response.get('results', []))
        total_pages = response.get('total_pages', 1)
        collections = _media_lists_snapshot()

        for show in shows:
            item = _build_tv_show_item(show, include_vote_count=True)
            _add_collection_context_menu(item, _collection_record_from_tv_show(show), collections)
            url = build_url({'action': 'list_seasons', 'tv_id': show['id']})
            xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

        if page < total_pages:
            nextPage = page + 1
            item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
            url = build_url({'action': 'menu_item_tvshows_search', 'page': nextPage, 'search_query': search_query})
            xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

        xbmcplugin.endOfDirectory(handle, updateListing=False)

def list_tv_shows_latest(handle):
    page = int(dict(urllib.parse.parse_qsl(sys.argv[2][1:])).get('page', 1))
    response = api.get_tv_latest(page)
    shows = _filter_tv_shows(response.get('results', []))
    total_pages = response.get('total_pages', 1)
    collections = _media_lists_snapshot()

    for show in shows:
        item = _build_tv_show_item(show, include_vote_count=True)
        _add_collection_context_menu(item, _collection_record_from_tv_show(show), collections)
        url = build_url({'action': 'list_seasons', 'tv_id': show['id']})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    # Add "Next Page" if more pages are available
    if page < total_pages:
        nextPage = page + 1
        item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
        url = build_url({'action': 'list_tv_shows_latest', 'page': page + 1})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    # Tell Kodi this is a new folder level (updateListing=False)
    xbmcplugin.endOfDirectory(handle, updateListing=False)

def list_tv_shows_recently_aired(handle):
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    page = _as_int(params.get('page'), 1)
    days = _as_int(params.get('days'), 30)
    if page < 1:
        page = 1
    if days < 1:
        days = 30

    response = api.get_tv_recently_aired(page, days)
    shows = _filter_tv_shows(response.get('results', []))
    total_pages = response.get('total_pages', 1)
    collections = _media_lists_snapshot()

    for show in shows:
        item = _build_tv_show_item(show, include_vote_count=True, include_recent_activity=True)
        _add_collection_context_menu(item, _collection_record_from_tv_show(show), collections)
        url = build_url({'action': 'list_seasons', 'tv_id': show['id']})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    if page < total_pages:
        nextPage = page + 1
        item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
        url = build_url({'action': 'list_tv_shows_recently_aired', 'page': nextPage, 'days': days})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    xbmcplugin.endOfDirectory(handle, updateListing=False)

def list_tv_shows_popular(handle):
    page = int(dict(urllib.parse.parse_qsl(sys.argv[2][1:])).get('page', 1))
    response = api.get_tv_popular(page)
    shows = _filter_tv_shows(response.get('results', []))
    total_pages = response.get('total_pages', 1)
    collections = _media_lists_snapshot()

    for show in shows:
        item = _build_tv_show_item(show, include_hearts=False)
        _add_collection_context_menu(item, _collection_record_from_tv_show(show), collections)
        url = build_url({'action': 'list_seasons', 'tv_id': show['id']})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    # Add "Next Page" if more pages are available
    if page < total_pages:
        nextPage = page + 1
        item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
        url = build_url({'action': 'list_tv_shows_popular', 'page': page + 1})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    # Tell Kodi this is a new folder level (updateListing=False)
    xbmcplugin.endOfDirectory(handle, updateListing=False)

def list_tv_shows_sk(handle):
    page = int(dict(urllib.parse.parse_qsl(sys.argv[2][1:])).get('page', 1))
    response = api.get_tv_sk(page)
    shows = _filter_tv_shows(response.get('results', []))
    total_pages = response.get('total_pages', 1)
    collections = _media_lists_snapshot()

    for show in shows:
        item = _build_tv_show_item(show, include_hearts=False)
        _add_collection_context_menu(item, _collection_record_from_tv_show(show), collections)
        url = build_url({'action': 'list_seasons', 'tv_id': show['id']})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    # Add "Next Page" if more pages are available
    if page < total_pages:
        nextPage = page + 1
        item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
        url = build_url({'action': 'list_tv_shows_sk', 'page': page + 1})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    # Tell Kodi this is a new folder level (updateListing=False)
    xbmcplugin.endOfDirectory(handle, updateListing=False)

def list_seasons(handle, tv_id):
    try:
        details = api.get_tv_details(tv_id)
    except Exception as ex:
        xbmc.log(f"[list_seasons] Failed to load TV details for tv_id={tv_id}: {ex}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("TV Show", "Could not load seasons.")
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    tv_title = details.get('name') or details.get('original_name') or f"TV {tv_id}"
    poster = details.get('poster_path', '')
    fanart = details.get('backdrop_path') or poster
    collections = _media_lists_snapshot()

    for season in details.get('seasons', []):
        season_number = season.get('season_number')
        if season_number is None:
            xbmc.log(
                f"[list_seasons] Skipping season without season_number for tv_id={tv_id}: keys={sorted(season.keys())}",
                xbmc.LOGWARNING
            )
            continue

        seasonName = season.get('name') or f"Séria {season_number}"
        season_year = _extract_year(season)
        season_poster = season.get('poster_path') or poster
        season_fanart = fanart or season_poster
        label = f"{seasonName} [{season_year}]"
        item = xbmcgui.ListItem(label=label)
        item.setInfo('video', {
            'title': seasonName,
            'plot': season.get('overview', ''),
            'tagline': season.get('tagline', '')
        })
        item.setArt({
            'thumb': season_poster,
            'poster': season_poster,
            'fanart': season_fanart
        })
        _add_collection_context_menu(
            item,
            _collection_record_from_season(tv_id, tv_title, season_number, seasonName, season_year, season_poster, season_fanart),
            collections
        )
        url = build_url({
            'action': 'list_episodes',
            'tv_id': tv_id,
            'season': season_number,
            'tv_title': tv_title,
            'poster': poster,
            'fanart': fanart
        })
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
    xbmcplugin.endOfDirectory(handle)

def list_episodes(handle, tv_id, season, tv_title="", poster="", fanart=""):
    try:
        episodes = api.get_episodes(tv_id, season)
    except Exception as ex:
        xbmc.log(f"[list_episodes] Failed to load episodes for tv_id={tv_id} season={season}: {ex}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("TV Show", "Could not load episodes.")
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    collections = _media_lists_snapshot()
    for ep in episodes:
        episode_id = ep.get('id')
        if episode_id is None:
            xbmc.log(
                f"[list_episodes] Skipping episode without id for tv_id={tv_id} season={season}: keys={sorted(ep.keys())}",
                xbmc.LOGWARNING
            )
            continue

        title = _get_episode_title(ep)
        label = title
        if not ep.get('hasStreams'):
            label = f"[COLOR 80FF0000][B][X][/B][/COLOR] [COLOR FFAAAAAA]{label}[/COLOR]"
        item = xbmcgui.ListItem(label=label)
        item.setInfo('video', {'title': title, 'plot': ep.get('description') or ep.get('overview', '')})
        item.setArt({
            'thumb': ep.get('imageUrl', ''),
            'poster': ep.get('imageUrl', ''),
            'fanart': ep.get('imageUrl', '')
        })
        episode_poster = ep.get('imageUrl') or poster
        episode_fanart = fanart or ep.get('imageUrl', '')
        _add_collection_context_menu(
            item,
            _collection_record_from_episode(tv_id, season, episode_id, tv_title, title, episode_poster, episode_fanart),
            collections
        )
        url = build_url({
            'action': 'show_streams',
            'tv_id': tv_id,
            'season': season,
            'episode_id': episode_id,
            'tv_title': tv_title,
            'poster': episode_poster,
            'fanart': episode_fanart
        })
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
    xbmcplugin.endOfDirectory(handle)

def show_streams_popup(handle, tv_id, season, episode_id, tv_title="", poster="", fanart=""):
    episodes = api.get_episodes(tv_id, season)
    episode = next((ep for ep in episodes if ep['id'] == int(episode_id)), None)
    if not episode:
        xbmcgui.Dialog().notification("Streams", "Episode not found.", xbmcgui.NOTIFICATION_ERROR, 2500)
        xbmcplugin.endOfDirectory(handle)
        return

    streams = episode.get('streams', [])
    if not streams:
        xbmcgui.Dialog().notification("Streams", "No streams available for this episode.", xbmcgui.NOTIFICATION_INFO, 2500)
        xbmcplugin.endOfDirectory(handle)
        return

    collections = _media_lists_snapshot()
    for stream in streams:
        display_name = _stream_display_name(stream)
        episode_title = _get_episode_title(episode)
        history_title = f"{tv_title} - {episode_title}" if tv_title else episode_title
        stream_poster = poster or episode.get('imageUrl', '')
        stream_fanart = fanart or episode.get('imageUrl', '')
        label = f"[COLOR FF00C8FF][{stream['sizeInGB']} GB][/COLOR] {display_name}"
        item = xbmcgui.ListItem(label=label)
        item.setInfo('video', {
            'plot': f"{display_name}\n\nSize: {stream['sizeInGB']} GB",
        })
        item.setInfo('video', {'title': display_name, 'size': stream['sizeInGB']})
        item.setProperty('IsPlayable', 'true')
        url = build_url({
            'action': 'play_movie_stream',
            'stream_id': stream['id'],
            'media_type': 'episode',
            'tv_id': tv_id,
            'season': season,
            'episode_id': episode_id,
            'tv_title': tv_title,
            'episode_title': episode_title,
            'title': history_title,
            'poster': stream_poster,
            'fanart': stream_fanart,
            'stream_name': display_name
        })
        _add_collection_context_menu(
            item,
            _collection_record_from_episode_stream(stream, tv_id, season, episode_id, tv_title, episode_title, stream_poster, stream_fanart),
            collections,
            [("Download", f"RunPlugin({build_url({'action': 'download_movie_stream', 'stream_id': stream['id'], 'filename': display_name})})")]
        )
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=False)

    xbmcplugin.endOfDirectory(handle)

def list_movie_versions(handle, movie_id, movie_title="", year="", poster="", fanart=""):
    versions = api.get_movie_versions(movie_id)
    collections = _media_lists_snapshot()
    for version in versions:
        display_name = _stream_display_name(version)
        has_bundled_subtitles = version.get('hasBundledSubtitles', "")
        subtitles_label = " [COLOR FF00FF00][Titulky][/COLOR]" if has_bundled_subtitles else ""
        label = f"[COLOR FF00C8FF][{version['sizeInGB']} GB][/COLOR]{subtitles_label} {display_name}"
        item = xbmcgui.ListItem(label=label)
        item.setInfo('video', {
            'plot': f"{display_name}\n\nSize: {version['sizeInGB']} GB",
        })
        item.setProperty('IsPlayable', 'true')
        url = build_url({
            'action': 'play_movie_stream',
            'stream_id': version['id'],
            'media_type': 'movie',
            'movie_id': movie_id,
            'title': movie_title or display_name,
            'year': year,
            'poster': poster,
            'fanart': fanart,
            'stream_name': display_name
        })
        _add_collection_context_menu(
            item,
            _collection_record_from_movie_stream(version, movie_id, movie_title, year, poster, fanart),
            collections,
            [("Download", f"RunPlugin({build_url({'action': 'download_movie_stream', 'stream_id': version['id'], 'filename': display_name})})")]
        )
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=False)
    xbmcplugin.endOfDirectory(handle)

def play_movie_stream(handle, stream_id, params=None):
    try:
        streamUrl = api.get_streams(stream_id)
    except api.ApiError as e:
        xbmc.log(f"[play_movie_stream] HTTP {e.status_code} for stream {stream_id}: {e.message}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Stream error", e.message)
        xbmcplugin.setResolvedUrl(handle, False, listitem=xbmcgui.ListItem())
        return
    except URLError as e:
        xbmc.log(f"[play_movie_stream] URL error for stream {stream_id}: {e.reason}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Stream error", "Network issue while resolving stream.")
        xbmcplugin.setResolvedUrl(handle, False, listitem=xbmcgui.ListItem())
        return
    except Exception as e:
        xbmc.log(f"[play_movie_stream] Unexpected error for stream {stream_id}: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Stream error", "Could not resolve stream.")
        xbmcplugin.setResolvedUrl(handle, False, listitem=xbmcgui.ListItem())
        return

    if streamUrl:
        _record_watch_history(stream_id, params)
        item = xbmcgui.ListItem(path=streamUrl)
        xbmcplugin.setResolvedUrl(handle, True, listitem=item)
    else:
        xbmcplugin.setResolvedUrl(handle, False, listitem=xbmcgui.ListItem())

def download_movie_stream(stream_id, filename):
    try:
        stream_url = api.get_download_url(stream_id)
    except api.ApiError as e:
        xbmc.log(f"[download_movie_stream] HTTP {e.status_code} for stream {stream_id}: {e.message}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Download", e.message)
        return
    except URLError as e:
        xbmc.log(f"[download_movie_stream] URL error for stream {stream_id}: {e.reason}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Download", "Network issue while resolving stream.")
        return
    except Exception as e:
        xbmc.log(f"[download_movie_stream] Unexpected error for stream {stream_id}: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Download", "Could not resolve stream.")
        return

    if not stream_url:
        xbmcgui.Dialog().ok("Download", "Stream URL not available")
        return

    safe_filename = _safe_download_filename(filename, stream_url)

    addon = xbmcaddon.Addon()
    default_dir = addon.getSetting("download_path") or ""
    save_dir = default_dir

    if not save_dir:
        save_dir = xbmcgui.Dialog().browse(0, "Choose save directory", "files", "", False, False, "")
        if not save_dir:
            return

    if not xbmcvfs.exists(save_dir):
        xbmcvfs.mkdirs(save_dir)

    # VFS paths (content://, smb://, storage://) can report missing; don't block on exists.
    if not xbmcvfs.exists(save_dir) and not _is_vfs_path(save_dir):
        xbmcgui.Dialog().ok("Download", "Download folder is not accessible.")
        return

    filepath = _join_path(save_dir, safe_filename)
    download_id = str(uuid.uuid4())
    created_at = now_iso()
    record = {
        "id": download_id,
        "stream_id": stream_id,
        "filename": safe_filename,
        "path": filepath,
        "url": stream_url,
        "url_type": "file_download",
        "status": "queued",
        "progress": 0,
        "bytes_total": None,
        "bytes_done": 0,
        "attempts": 0,
        "created_at": created_at,
        "updated_at": created_at
    }

    def op(data):
        _normalize_queue_positions(data)
        record["queue_position"] = _next_queue_position(data)
        data[download_id] = record

    db.mutate(op)

    xbmcgui.Dialog().notification("Queued", f"{safe_filename}", xbmcgui.NOTIFICATION_INFO, 2500)

def show_downloads_menu(handle):
    xbmcplugin.setPluginCategory(handle, "Downloads")
    try:
        xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_UNSORTED)
    except Exception:
        pass

    addon = xbmcaddon.Addon()
    max_attempts = max(1, int(addon.getSetting("download_retry_limit") or 0) + 1)
    data = _list_downloads_normalized()
    queue_total = _queue_count(data)

    clear_item = xbmcgui.ListItem(label="Vymazať históriu sťahovania")
    clear_item.setArt({
        'icon': get_icons_path('clear.png'),
        'thumb': get_icons_path('clear.png')
    })
    clear_item.setInfo('video', {'plot': 'Vymazať dokončené, zlyhané a zrušené záznamy (súbory nebudú odstránené).'})
    clear_url = build_url({'action': 'clear_download_history'})
    xbmcplugin.addDirectoryItem(handle, clear_url, clear_item, isFolder=False)

    downloading_items = sorted(
        [item for item in data.values() if item.get("status") == "downloading"],
        key=lambda x: (_queue_position(x), x.get("updated_at") or "", x.get("created_at") or "")
    )
    queued_items = sorted(
        [item for item in data.values() if item.get("status") in QUEUE_STATUSES],
        key=lambda x: (_queue_position(x), x.get("created_at") or "", x.get("id") or "")
    )
    history_items = sorted(
        [item for item in data.values() if item.get("status") not in ("downloading",) + QUEUE_STATUSES],
        key=lambda x: x.get("updated_at") or x.get("created_at") or "",
        reverse=True
    )
    items = downloading_items + queued_items + history_items

    for it in items:
        download_id = it.get("id")
        status = it.get("status", "?")
        progress = it.get("progress", 0) or 0
        filename = it.get("filename", "Unknown")
        path = it.get("path", "")
        attempts = it.get("attempts", 0) or 0
        error = it.get("error")
        position = _as_int(it.get("queue_position"), 0)
        bytes_done = it.get("bytes_done")
        bytes_total = it.get("bytes_total")

        if status == "downloading":
            label = f"[Now {progress}%] {filename}"
        elif status == "queued":
            label = f"#{position} [Queued] {filename}"
        elif status == "paused":
            label = f"#{position} [Paused {progress}%] {filename}"
        elif status == "complete":
            label = f"[[COLOR FF90EE90]Complete[/COLOR]] {filename}"
        elif status == "failed":
            label = f"[[COLOR FFFF9090]Failed[/COLOR]] {filename}"
        elif status == "canceled":
            label = f"[Canceled] {filename}"
        else:
            label = f"[{status}] {filename}"

        li = xbmcgui.ListItem(label=label)
        plot_lines = [
            f"Status: {status}",
            f"Progress: {progress}%",
            f"Attempts: {attempts}/{max_attempts}"
        ]
        if status in QUEUE_STATUSES and position:
            plot_lines.append(f"Queue position: {position}/{queue_total}")
        elif status == "downloading":
            plot_lines.append("Queue position: downloading now")
        if bytes_total:
            plot_lines.append(f"Downloaded: {_format_bytes(bytes_done)} / {_format_bytes(bytes_total)}")
        elif bytes_done:
            plot_lines.append(f"Downloaded: {_format_bytes(bytes_done)}")
        if path:
            plot_lines.append(f"Path: {path}")
        if error:
            plot_lines.append(f"Error: {error}")
        li.setInfo('video', {'plot': "\n".join(plot_lines)})

        if status == "complete":
            li.setArt({'icon': get_icons_path('done.png'), 'thumb': get_icons_path('done.png')})
        else:
            li.setArt({'icon': get_icons_path('downloads.png'), 'thumb': get_icons_path('downloads.png')})

        actions = _download_action_queries(it, queue_total)
        if actions:
            li.addContextMenuItems([
                (label, f"RunPlugin({build_url(query)})")
                for label, query in actions
            ])

        url = ""
        if status == "complete" and path and xbmcvfs.exists(path):
            url = path
            li.setProperty("IsPlayable", "true")
        elif actions:
            url = build_url({'action': 'show_download_actions', 'id': download_id})

        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=False)

    xbmcplugin.endOfDirectory(handle)

def _refresh_downloads_container():
    xbmc.executebuiltin("Container.Refresh")

def _part_path(record):
    path = record.get("path")
    return f"{path}.part" if path else ""

def _part_size(record):
    part = _part_path(record)
    if not part:
        return 0
    try:
        if not xbmcvfs.exists(part):
            return 0
        return xbmcvfs.Stat(part).st_size()
    except Exception:
        return 0

def _delete_part_file(record):
    part = _part_path(record)
    if not part:
        return
    try:
        if xbmcvfs.exists(part):
            xbmcvfs.delete(part)
    except Exception:
        pass

def _progress_from_part(record, default=0):
    part_size = _part_size(record)
    total = _as_int(record.get("bytes_total"), 0)
    if part_size > 0 and total > 0:
        return part_size, int(100 * part_size / total)
    return part_size, default if part_size > 0 else 0

def _run_download_action(query):
    action = query.get("action")
    download_id = query.get("id")

    if action == "move_download":
        move_download(download_id, query.get("direction"))
    elif action == "pause_download":
        pause_download(download_id)
    elif action == "resume_download":
        resume_download(download_id)
    elif action == "cancel_download":
        cancel_download(download_id)
    elif action == "retry_download":
        retry_download(download_id)

def show_download_actions(download_id):
    data = _list_downloads_normalized()
    record = data.get(download_id)
    if not record:
        xbmcgui.Dialog().notification("Downloads", "Download not found", xbmcgui.NOTIFICATION_ERROR, 2000)
        return

    actions = _download_action_queries(record, _queue_count(data))
    if not actions:
        xbmcgui.Dialog().notification("Downloads", "No actions available", xbmcgui.NOTIFICATION_INFO, 2000)
        return

    choice = xbmcgui.Dialog().select(record.get("filename", "Download"), [label for label, _ in actions])
    if choice < 0:
        return

    _run_download_action(actions[choice][1])

def move_download(download_id, direction):
    if direction not in ("up", "down", "top", "bottom"):
        return

    def op(data):
        _normalize_queue_positions(data)
        items = [
            (item_id, record)
            for item_id, record in data.items()
            if record.get("status") in QUEUE_STATUSES
        ]
        items.sort(key=lambda item: (_queue_position(item[1]), item[1].get("created_at") or "", item[0]))

        index = next((i for i, (item_id, _) in enumerate(items) if item_id == download_id), None)
        if index is None:
            return None

        item = items.pop(index)
        if direction == "up":
            target = max(0, index - 1)
        elif direction == "down":
            target = min(len(items), index + 1)
        elif direction == "top":
            target = 0
        else:
            target = len(items)

        items.insert(target, item)
        updated_at = now_iso()
        for position, (_, record) in enumerate(items, start=1):
            record["queue_position"] = position
            record["updated_at"] = updated_at

        return item[1].get("filename", "Download")

    filename = db.mutate(op)
    if filename:
        xbmcgui.Dialog().notification("Downloads", f"Reordered {filename}", xbmcgui.NOTIFICATION_INFO, 1500)
    _refresh_downloads_container()

def pause_download(download_id):
    def op(data):
        record = data.get(download_id)
        if not record or record.get("status") not in ("queued", "downloading"):
            return None

        record["status"] = "paused"
        record["error"] = None
        record["updated_at"] = now_iso()
        _normalize_queue_positions(data)
        return record.get("filename", "Download")

    filename = db.mutate(op)
    if filename:
        xbmcgui.Dialog().notification("Paused", filename, xbmcgui.NOTIFICATION_INFO, 2000)
    _refresh_downloads_container()

def resume_download(download_id):
    def op(data):
        record = data.get(download_id)
        if not record or record.get("status") != "paused":
            return None

        record["status"] = "queued"
        record["error"] = None
        record["updated_at"] = now_iso()
        _normalize_queue_positions(data)
        return record.get("filename", "Download")

    filename = db.mutate(op)
    if filename:
        xbmcgui.Dialog().notification("Queued", filename, xbmcgui.NOTIFICATION_INFO, 2000)
    _refresh_downloads_container()

def retry_download(download_id):
    current = db.list().get(download_id)
    if current and current.get("status") == "canceled":
        _delete_part_file(current)

    def op(data):
        record = data.get(download_id)
        if not record or record.get("status") not in ("failed", "canceled"):
            return None

        old_status = record.get("status")
        _normalize_queue_positions(data)
        next_position = _next_queue_position(data)
        record["status"] = "queued"
        record["queue_position"] = next_position
        record["error"] = None
        record["attempts"] = 0
        record["updated_at"] = now_iso()

        if old_status == "failed":
            bytes_done, progress = _progress_from_part(record, record.get("progress", 0) or 0)
            record["bytes_done"] = bytes_done
            record["progress"] = progress
        else:
            record["bytes_done"] = 0
            record["bytes_total"] = None
            record["progress"] = 0

        return record.get("filename", "Download")

    filename = db.mutate(op)
    if filename:
        xbmcgui.Dialog().notification("Queued", filename, xbmcgui.NOTIFICATION_INFO, 2000)
    _refresh_downloads_container()

def cancel_download(download_id):
    def op(data):
        record = data.get(download_id)
        if not record:
            return None

        old_status = record.get("status")
        record["status"] = "canceled"
        record["queue_position"] = None
        record["updated_at"] = now_iso()
        if old_status != "downloading":
            record["bytes_done"] = 0
            record["progress"] = 0
        _normalize_queue_positions(data)
        return old_status, dict(record)

    result = db.mutate(op)
    if result:
        old_status, record = result
        if old_status != "downloading":
            _delete_part_file(record)
        xbmcgui.Dialog().notification("Canceled", "Download canceled", xbmcgui.NOTIFICATION_INFO, 2000)
    _refresh_downloads_container()

def clear_download_history():
    confirm = xbmcgui.Dialog().yesno("Vymazať históriu sťahovania", "Aktívne a čakajúce sťahovania zostanú zachované. Stiahnuté súbory nebudú odstránené. Pokračovať?", yeslabel="Áno", nolabel="Nie")
    if not confirm:
        return

    def op(data):
        active = {
            download_id: record
            for download_id, record in data.items()
            if record.get("status") in ("downloading",) + QUEUE_STATUSES
        }
        data.clear()
        data.update(active)
        _normalize_queue_positions(data)

    db.mutate(op)
    #xbmcgui.Dialog().notification("Downloads", "History cleared", xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin("Container.Refresh")
