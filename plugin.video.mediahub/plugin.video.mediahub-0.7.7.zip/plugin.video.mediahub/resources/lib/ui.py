import sys
import xbmc
import json
import xbmcplugin
import xbmcgui
import urllib.parse

from . import api

def build_url(query):
    return f"{sys.argv[0]}?{urllib.parse.urlencode(query)}"

def show_main_menu(handle):

    xbmcplugin.setPluginCategory(handle, "Hlavné Menu")
    xbmcplugin.setContent(handle, "movies")

    # Movies
    menuItemMovies = xbmcgui.ListItem(label="Filmy")
    menuItemMovies.setInfo('video', { 'plot': u"\u00A0" })
    urlMovies = build_url({'action': 'menu_item_movies'})
    xbmcplugin.addDirectoryItem(handle, urlMovies, menuItemMovies, isFolder=True)

    # TV Shows
    menuItemTvShows = xbmcgui.ListItem(label="Seriály")
    menuItemTvShows.setInfo('video', { 'plot': u"\u00A0" })
    urlTvShows = build_url({'action': 'menu_item_tvshows'})
    xbmcplugin.addDirectoryItem(handle, urlTvShows, menuItemTvShows, isFolder=True)

    # # Watch History
    # menuItemWatchHistory = xbmcgui.ListItem(label="História Pozerania")
    # menuItemWatchHistory.setInfo('video', { 'plot': u"\u00A0" })
    # urlWatchHistory = build_url({'action': 'menu_item_watch_history'})
    # xbmcplugin.addDirectoryItem(handle, urlWatchHistory, menuItemWatchHistory, isFolder=True)

    xbmcplugin.endOfDirectory(handle)

def menu_item_movies(handle):

    xbmcplugin.setPluginCategory(handle, "Filmy")
    xbmcplugin.setContent(handle, "movies")

    # Search
    menuItemMoviesSearch = xbmcgui.ListItem(label="Hľadať")
    menuItemMoviesSearch.setProperty('IsPlayable', 'false')
    menuItemMoviesSearch.setInfo('video', { 'plot': u"\u00A0" })
    urlMoviesSearch = build_url({'action': 'menu_item_movies_search'})
    xbmcplugin.addDirectoryItem(handle, urlMoviesSearch, menuItemMoviesSearch, isFolder=True)

    # Latest Movies
    menuItemMoviesLatest = xbmcgui.ListItem(label="Nové ")
    menuItemMoviesLatest.setInfo('video', { 'plot': u"\u00A0" })
    urlMoviesLatest = build_url({'action': 'menu_item_movies_latest'})
    xbmcplugin.addDirectoryItem(handle, urlMoviesLatest, menuItemMoviesLatest, isFolder=True)

    # Popular Movies
    menuItemMoviesPopular = xbmcgui.ListItem(label="Populárne")
    menuItemMoviesPopular.setInfo('video', { 'plot': u"\u00A0" })
    urlMoviesPopular = build_url({'action': 'menu_item_movies_popular'})
    xbmcplugin.addDirectoryItem(handle, urlMoviesPopular, menuItemMoviesPopular, isFolder=True)

    # Top Rated Movies
    menuItemMoviesTopRated = xbmcgui.ListItem(label="Najlepšie Hodnotené")
    menuItemMoviesTopRated.setInfo('video', { 'plot': u"\u00A0" })
    urlMoviesTopRated = build_url({'action': 'menu_item_movies_toprated'})
    xbmcplugin.addDirectoryItem(handle, urlMoviesTopRated, menuItemMoviesTopRated, isFolder=True)

    # # Genres
    # menuItemMoviesGenres = xbmcgui.ListItem(label="Podľa Žánrov")
    # menuItemMoviesGenres.setInfo('video', { 'plot': u"\u00A0" })
    # urlMoviesGenres = build_url({'action': 'menu_item_movies_genres'})
    # xbmcplugin.addDirectoryItem(handle, urlMoviesGenres, menuItemMoviesGenres, isFolder=True)

    xbmcplugin.endOfDirectory(handle)

def menu_item_tvshows(handle):

    xbmcplugin.setPluginCategory(handle, "Seriály")
    xbmcplugin.setContent(handle, "movies")

    # # Search
    # menuItemMoviesSearch = xbmcgui.ListItem(label="Hľadať")
    # menuItemMoviesSearch.setProperty('IsPlayable', 'false')
    # menuItemMoviesSearch.setInfo('video', { 'plot': u"\u00A0" })
    # urlMoviesSearch = build_url({'action': 'menu_item_movies_search'})
    # xbmcplugin.addDirectoryItem(handle, urlMoviesSearch, menuItemMoviesSearch, isFolder=True)

    # Latest Tv Shows
    menuItemTvShowsLatest = xbmcgui.ListItem(label="Nové ")
    menuItemTvShowsLatest.setInfo('video', { 'plot': u"\u00A0" })
    urlTvShowsLatest = build_url({'action': 'list_tv_shows_latest'})
    xbmcplugin.addDirectoryItem(handle, urlTvShowsLatest, menuItemTvShowsLatest, isFolder=True)

    # Popular Tv Shows
    menuItemTvShowsPopular = xbmcgui.ListItem(label="Populárne")
    menuItemTvShowsPopular.setInfo('video', { 'plot': u"\u00A0" })
    urlTvShowsPopular = build_url({'action': 'list_tv_shows_popular'})
    xbmcplugin.addDirectoryItem(handle, urlTvShowsPopular, menuItemTvShowsPopular, isFolder=True)

    # Top Rated Tv Shows
    menuItemTvShowsSlovak = xbmcgui.ListItem(label="Slovenské")
    menuItemTvShowsSlovak.setInfo('video', { 'plot': u"\u00A0" })
    urlTvShowsSlovak = build_url({'action': 'list_tv_shows_sk'})
    xbmcplugin.addDirectoryItem(handle, urlTvShowsSlovak, menuItemTvShowsSlovak, isFolder=True)

    # # Genres
    # menuItemMoviesGenres = xbmcgui.ListItem(label="Podľa Žánrov")
    # menuItemMoviesGenres.setInfo('video', { 'plot': u"\u00A0" })
    # urlMoviesGenres = build_url({'action': 'menu_item_movies_genres'})
    # xbmcplugin.addDirectoryItem(handle, urlMoviesGenres, menuItemMoviesGenres, isFolder=True)

    xbmcplugin.endOfDirectory(handle)

def menu_item_movies_latest(handle):
    page = int(dict(urllib.parse.parse_qsl(sys.argv[2][1:])).get('page', 1))
    response = api.get_movies_latest(page)
    movies = response.get('results', [])
    total_pages = response.get('total_pages', 1)

    for movie in movies:
        label = f"{movie['title_with_original_title']} [COLOR FFAAAAAA][{movie['release_date'][:4]}][/COLOR][{movie['vote_count']}]"
        item = xbmcgui.ListItem(label=label)
        item.setArt({
            'poster': movie.get('poster_path', ''),
            'fanart': movie.get('backdrop_path', '')
        })
        item.setInfo('video', {
            'title': movie['title'],
            'plot': movie.get('overview', '')
        })
        url = build_url({'action': 'list_movie_versions', 'movie_id': movie['id']})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    if page < total_pages:
        nextPage = page + 1
        item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
        url = build_url({'action': 'menu_item_movies_latest', 'page': nextPage})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    xbmcplugin.endOfDirectory(handle, updateListing=False)

def menu_item_movies_popular(handle):
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    filter_type = params.get('filter_type')
    year = params.get('year')
    page = int(params.get('page', 1))
    
    # If no filter type, show submenu
    if not filter_type:
        xbmcplugin.setPluginCategory(handle, "Populárne")
        xbmcplugin.setContent(handle, "movies")
        
        # All Times
        item = xbmcgui.ListItem(label="Všetky roky")
        item.setInfo('movies', { 'plot': u"\u00A0" })
        url = build_url({'action': 'menu_item_movies_popular', 'filter_type': 'all_time'})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
        
        # By Year
        item = xbmcgui.ListItem(label="Podľa Roku")
        item.setInfo('video', { 'plot': u"\u00A0" })
        url = build_url({'action': 'menu_item_movies_popular', 'filter_type': 'by_year'})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
        
        xbmcplugin.endOfDirectory(handle)
        return
    
    # If filter_type is 'by_year' but no year selected, show year selector
    if filter_type == 'by_year' and not year:
        xbmcplugin.setPluginCategory(handle, "Populárne - Podľa Roku")
        xbmcplugin.setContent(handle, "movies")
        
        import datetime
        current_year = datetime.datetime.now().year
        
        # Show years from current year back to 1940
        for yr in range(current_year, 1940, -1):
            item = xbmcgui.ListItem(label=str(yr))
            item.setInfo('movies', { 'plot': u"\u00A0" })
            url = build_url({'action': 'menu_item_movies_popular', 'filter_type': 'by_year', 'year': yr})
            xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
        
        xbmcplugin.endOfDirectory(handle)
        return
    
    # Show movies based on filter
    if filter_type == 'all_time':
        response = api.get_movies_popular(page)
    elif filter_type == 'by_year' and year:
        response = api.get_movies_popular(page, year)
    else:
        response = api.get_movies_popular(page)
    
    movies = response.get('results', [])
    total_pages = response.get('total_pages', 1)

    for movie in movies:
        label = f"{movie['title_with_original_title']} [COLOR FFAAAAAA][{movie['release_date'][:4]}][/COLOR]"
        item = xbmcgui.ListItem(label=label)
        item.setArt({
            'poster': movie.get('poster_path', ''),
            'fanart': movie.get('backdrop_path', '')
        })
        item.setInfo('video', {
            'title': movie['title'],
            'plot': movie.get('overview', '')
        })
        url = build_url({'action': 'list_movie_versions', 'movie_id': movie['id']})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    if page < total_pages:
        nextPage = page + 1
        extra_params = {'filter_type': filter_type}
        if year:
            extra_params['year'] = year
        item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
        url = build_url({'action': 'menu_item_movies_popular', 'page': nextPage, **extra_params})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    xbmcplugin.endOfDirectory(handle, updateListing=False)

def menu_item_movies_toprated(handle):
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    filter_type = params.get('filter_type')
    year = params.get('year')
    page = int(params.get('page', 1))
    
    # If no filter type, show submenu
    if not filter_type:
        xbmcplugin.setPluginCategory(handle, "Najlepšie Hodnotené")
        xbmcplugin.setContent(handle, "movies")
        
        # All Times
        item = xbmcgui.ListItem(label="Všetky roky")
        item.setInfo('movies', { 'plot': u"\u00A0" })
        url = build_url({'action': 'menu_item_movies_toprated', 'filter_type': 'all_time'})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
        
        # By Year
        item = xbmcgui.ListItem(label="Podľa Roku")
        item.setInfo('video', { 'plot': u"\u00A0" })
        url = build_url({'action': 'menu_item_movies_toprated', 'filter_type': 'by_year'})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
        
        xbmcplugin.endOfDirectory(handle)
        return
    
    # If filter_type is 'by_year' but no year selected, show year selector
    if filter_type == 'by_year' and not year:
        xbmcplugin.setPluginCategory(handle, "Najlepšie Hodnotené - Podľa Roku")
        xbmcplugin.setContent(handle, "movies")
        
        import datetime
        current_year = datetime.datetime.now().year
        
        # Show years from current year back to 1990
        for yr in range(current_year, 1940, -1):
            item = xbmcgui.ListItem(label=str(yr))
            item.setInfo('movies', { 'plot': u"\u00A0" })
            url = build_url({'action': 'menu_item_movies_toprated', 'filter_type': 'by_year', 'year': yr})
            xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
        
        xbmcplugin.endOfDirectory(handle)
        return
    
    # Show movies based on filter
    if filter_type == 'all_time':
        response = api.get_movies_toprated(page)
    elif filter_type == 'by_year' and year:
        response = api.get_movies_toprated(page, year)
    else:
        response = api.get_movies_toprated(page)
    
    movies = response.get('results', [])
    total_pages = response.get('total_pages', 1)

    for movie in movies:
        label = f"{movie['title_with_original_title']} [COLOR FFAAAAAA][{movie['release_date'][:4]}][/COLOR]"
        item = xbmcgui.ListItem(label=label)
        item.setArt({
            'poster': movie.get('poster_path', ''),
            'fanart': movie.get('backdrop_path', '')
        })
        item.setInfo('video', {
            'title': movie['title'],
            'plot': movie.get('overview', '')
        })
        url = build_url({'action': 'list_movie_versions', 'movie_id': movie['id']})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    if page < total_pages:
        nextPage = page + 1
        extra_params = {'filter_type': filter_type}
        if year:
            extra_params['year'] = year
        item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
        url = build_url({'action': 'menu_item_movies_toprated', 'page': nextPage, **extra_params})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    xbmcplugin.endOfDirectory(handle, updateListing=False)

def menu_item_movies_search(handle):
    # Get parameters from URL
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    search_query = params.get('search_query')
    page = int(params.get('page', 1))
    
    # Only show keyboard if no search_query (initial search)
    if not search_query:
        keyboard = xbmc.Keyboard('', 'Hľadať Filmy')
        keyboard.doModal()
        if keyboard.isConfirmed():
            search_query = keyboard.getText()
        else:
            return  # User cancelled
    
    if search_query:
        response = api.get_movies_search(search_query, page)
        movies = response.get('results', [])
        total_pages = response.get('total_pages', 1)

        for movie in movies:
            year = movie.get("release_date", "")[:4] if movie.get("release_date") else "----"
            label = f"{movie['title_with_original_title']} [COLOR FFAAAAAA][{year}][/COLOR][{movie['vote_count']}]"
            item = xbmcgui.ListItem(label=label)
            item.setArt({
                'poster': movie.get('poster_path', ''),
                'fanart': movie.get('backdrop_path', '')
            })
            item.setInfo('video', {
                'title': movie['title'],
                'plot': movie.get('overview', '')
            })
            url = build_url({'action': 'list_movie_versions', 'movie_id': movie['id']})
            xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

        if page < total_pages:
            nextPage = page + 1
            item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
            url = build_url({'action': 'menu_item_movies_search', 'page': nextPage, 'search_query': search_query})
            xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

        xbmcplugin.endOfDirectory(handle, updateListing=False)




    # itemTvSeriesLatest = xbmcgui.ListItem(label="Seriály - Nové")
    # url = build_url({'action': 'list_tv_shows_latest'})
    # xbmcplugin.addDirectoryItem(handle, url, itemTvSeriesLatest, isFolder=True)

    # itemTvSeriesPopular = xbmcgui.ListItem(label="Seriály - Populárne")
    # url = build_url({'action': 'list_tv_shows_popular'})
    # xbmcplugin.addDirectoryItem(handle, url, itemTvSeriesPopular, isFolder=True)

    # itemTvSeriesSk = xbmcgui.ListItem(label="Seriály - SK")
    # url = build_url({'action': 'list_tv_shows_sk'})
    # xbmcplugin.addDirectoryItem(handle, url, itemTvSeriesSk, isFolder=True)

def list_tv_shows_latest(handle):
    page = int(dict(urllib.parse.parse_qsl(sys.argv[2][1:])).get('page', 1))
    response = api.get_tv_latest(page)
    shows = response.get('results', [])
    total_pages = response.get('total_pages', 1)

    for show in shows:
        item = xbmcgui.ListItem(label=f"{show['name']} [COLOR FFAAAAAA][{show['first_air_date_year']}][/COLOR]")
        item.setInfo('video', {
            'title': f"{show['name']} [{show['first_air_date_year']}]",
            'plot': show.get('overview', ''),
            'tagline': show.get('tagline', '')
        })
        item.setArt({
            'thumb': show.get('poster_path', ''),
            'poster': show.get('poster_path', ''),
            'fanart': show.get('backdrop_path', '')
        })
        url = build_url({'action': 'list_seasons', 'tv_id': show['id']})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    # Add "Next Page" if more pages are available
    if page < total_pages:
        nextPage = page + 1
        item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
        url = build_url({'action': 'list_tv_shows_latest', 'page': page + 1})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    # Tell Kodi this is a new folder level (updateListing=False)
    xbmcplugin.endOfDirectory(handle, updateListing=False)

def list_tv_shows_popular(handle):
    page = int(dict(urllib.parse.parse_qsl(sys.argv[2][1:])).get('page', 1))
    response = api.get_tv_popular(page)
    shows = response.get('results', [])
    total_pages = response.get('total_pages', 1)

    for show in shows:
        item = xbmcgui.ListItem(label=f"{show['name']} [COLOR FFAAAAAA][{show['first_air_date_year']}][/COLOR]")
        item.setInfo('video', {
            'title': f"{show['name']} [{show['first_air_date_year']}]",
            'plot': show.get('overview', ''),
            'tagline': show.get('tagline', '')
        })
        item.setArt({
            'thumb': show.get('poster_path', ''),
            'poster': show.get('poster_path', ''),
            'fanart': show.get('backdrop_path', '')
        })
        url = build_url({'action': 'list_seasons', 'tv_id': show['id']})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    # Add "Next Page" if more pages are available
    if page < total_pages:
        nextPage = page + 1
        item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
        url = build_url({'action': 'list_tv_shows_popular', 'page': page + 1})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    # Tell Kodi this is a new folder level (updateListing=False)
    xbmcplugin.endOfDirectory(handle, updateListing=False)

def list_tv_shows_sk(handle):
    page = int(dict(urllib.parse.parse_qsl(sys.argv[2][1:])).get('page', 1))
    response = api.get_tv_sk(page)
    shows = response.get('results', [])
    total_pages = response.get('total_pages', 1)

    for show in shows:
        item = xbmcgui.ListItem(label=f"{show['name']} [COLOR FFAAAAAA][{show['first_air_date_year']}][/COLOR]")
        item.setInfo('video', {
            'title': f"{show['name']} [{show['first_air_date_year']}]",
            'plot': show.get('overview', ''),
            'tagline': show.get('tagline', '')
        })
        item.setArt({
            'thumb': show.get('poster_path', ''),
            'poster': show.get('poster_path', ''),
            'fanart': show.get('backdrop_path', '')
        })
        url = build_url({'action': 'list_seasons', 'tv_id': show['id']})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    # Add "Next Page" if more pages are available
    if page < total_pages:
        nextPage = page + 1
        item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
        url = build_url({'action': 'list_tv_shows_sk', 'page': page + 1})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    # Tell Kodi this is a new folder level (updateListing=False)
    xbmcplugin.endOfDirectory(handle, updateListing=False)

def list_seasons(handle, tv_id):
    details = api.get_tv_details(tv_id)
    for season in details.get('seasons', []):
        seasonName = season.get('name', f"Séria {season['season_number']}")
        label = f"{seasonName} [{season['year']}]"
        item = xbmcgui.ListItem(label=label)
        item.setInfo('video', {
            'title': season.get('name', 'Default Value'),
            'plot': season.get('overview', 'Default Overview'),
            'tagline': season.get('tagline', '')
        })
        item.setArt({
            'thumb': season.get('poster_path', ''),
            'poster': season.get('poster_path', ''),
            'fanart': season.get('poster_path', '')
        })
        url = build_url({'action': 'list_episodes', 'tv_id': tv_id, 'season': season['season_number']})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
    xbmcplugin.endOfDirectory(handle)

def list_episodes(handle, tv_id, season):
    episodes = api.get_episodes(tv_id, season)
    for ep in episodes:
        label = f"{ep['title']}"
        if not ep.get('hasStreams'):
            label = f"[COLOR 80FF0000][B][X][/B][/COLOR] [COLOR FFAAAAAA]{label}[/COLOR]"
        item = xbmcgui.ListItem(label=label)
        item.setInfo('video', {'title': ep['title'], 'plot': ep['description']})
        item.setArt({
            'thumb': ep.get('imageUrl', ''),
            'poster': ep.get('imageUrl', ''),
            'fanart': ep.get('imageUrl', '')
        })
        url = build_url({'action': 'show_streams', 'tv_id': tv_id, 'season': season, 'episode_id': ep['id']})  # add tv_id & season here
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=False)
    xbmcplugin.endOfDirectory(handle)

def show_streams_popup(tv_id, season, episode_id):
    episodes = api.get_episodes(tv_id, season)
    episode = next((ep for ep in episodes if ep['id'] == int(episode_id)), None)
    if not episode:
        xbmcgui.Dialog().ok("Error", "Episode not found")
        return

    streams = episode.get('streams', [])
    if not streams:
        xbmcgui.Dialog().ok("Streams", "No streams available for this episode.")
        return

    items = [f"{s['sizeInGB']}GB - {s['name']} " for s in streams]
    choice = xbmcgui.Dialog().select("Select a Stream", items)
    if choice == -1:
        return  # cancelled

    stream_id = streams[choice]['id']
    stream_url = api.get_streams(stream_id)

    xbmc.log(f"Selected stream ID: {stream_id}", xbmc.LOGINFO)
    xbmc.log(f"Resolved stream URL: {stream_url}", xbmc.LOGINFO)

    if not stream_url:
        xbmcgui.Dialog().ok("Error", "Stream URL is empty or invalid.")
        return
    
    list_item = xbmcgui.ListItem(path=stream_url)
    list_item.setInfo('video', {'title': episode['title']})
    list_item.setProperty("IsPlayable", "true")
    
    # Instead of setResolvedUrl, play it directly
    xbmc.Player().play(stream_url, list_item)





def list_movie_versions(handle, movie_id):
    versions = api.get_movie_versions(movie_id)
    for version in versions:
        label = f"{version['name']} ({version['sizeInGB']} GB)"
        item = xbmcgui.ListItem(label=label)
        item.setInfo('video', {'title': version['name'], 'size': version['sizeInGB']})
        item.setProperty('IsPlayable', 'true')
        url = build_url({'action': 'play_movie_stream', 'stream_id': version['id']})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=False)
    xbmcplugin.endOfDirectory(handle)

def play_movie_stream(handle, stream_id):
    streamUrl = api.get_streams(stream_id)
    if streamUrl:
        item = xbmcgui.ListItem(path=streamUrl)
        xbmcplugin.setResolvedUrl(handle, True, listitem=item)