import sys
import urllib.parse
import xbmcplugin
import xbmcgui

from resources.lib import ui

BASE_URL = sys.argv[0]
HANDLE = int(sys.argv[1])
ARGS = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))

def router():
    action = ARGS.get('action')
    
    routes = {
        "menu_item_movies":             lambda: ui.menu_item_movies(HANDLE),
        "menu_item_movies_search":      lambda: ui.menu_item_movies_search(HANDLE),
        'menu_item_movies_latest':      lambda: ui.menu_item_movies_latest(HANDLE),
        'menu_item_movies_popular':     lambda: ui.menu_item_movies_popular(HANDLE),
        'menu_item_movies_toprated':    lambda: ui.menu_item_movies_toprated(HANDLE),
        
        "menu_item_tvshows":            lambda: ui.menu_item_tvshows(HANDLE),
        "menu_item_tvshows_search":     lambda: ui.menu_item_tvshows_search(HANDLE),
        'list_tv_shows_latest':         lambda: ui.list_tv_shows_latest(HANDLE),
        'list_tv_shows_popular':        lambda: ui.list_tv_shows_popular(HANDLE),
        'list_tv_shows_sk':             lambda: ui.list_tv_shows_sk(HANDLE),
        'list_seasons':                 lambda: ui.list_seasons(HANDLE, int(ARGS['tv_id'])),
        'list_episodes':                lambda: ui.list_episodes(HANDLE, int(ARGS['tv_id']), int(ARGS['season']), ARGS.get('tv_title', ''), ARGS.get('poster', ''), ARGS.get('fanart', '')),
        'show_streams':                 lambda: ui.show_streams_popup(HANDLE, int(ARGS['tv_id']), int(ARGS['season']), int(ARGS['episode_id']), ARGS.get('tv_title', ''), ARGS.get('poster', ''), ARGS.get('fanart', '')),
    
    
        'list_movie_versions':          lambda: ui.list_movie_versions(HANDLE, ARGS['movie_id'], ARGS.get('title', ''), ARGS.get('year', ''), ARGS.get('poster', ''), ARGS.get('fanart', '')),
        'play_movie_stream':            lambda: ui.play_movie_stream(HANDLE, ARGS['stream_id'], ARGS),
        'download_movie_stream':        lambda: ui.download_movie_stream(ARGS['stream_id'], ARGS['filename']),
        'show_watch_history':           lambda: ui.show_watch_history(HANDLE),
        'remove_watch_history_item':    lambda: ui.remove_watch_history_item(ARGS['id']),
        'clear_watch_history':          lambda: ui.clear_watch_history(),
        'show_downloads_menu':          lambda: ui.show_downloads_menu(HANDLE),
        'show_download_actions':        lambda: ui.show_download_actions(ARGS['id']),
        'move_download':                lambda: ui.move_download(ARGS['id'], ARGS.get('direction')),
        'pause_download':               lambda: ui.pause_download(ARGS['id']),
        'resume_download':              lambda: ui.resume_download(ARGS['id']),
        'cancel_download':              lambda: ui.cancel_download(ARGS['id']),
        'retry_download':               lambda: ui.retry_download(ARGS['id']),
        'clear_download_history':       lambda: ui.clear_download_history(),
    }
    
    if action in routes:
        routes[action]()
    else:
        ui.show_main_menu(HANDLE)

if __name__ == '__main__':
    router()
