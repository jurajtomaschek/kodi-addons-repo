import datetime
import email.utils
import errno
import hashlib
import os
import random
import re
import shutil
import socket
import ssl
import threading
import time
import urllib.error
import urllib.request
import uuid

import xbmc
import xbmcaddon
import xbmcvfs

from . import api
from .downloads_db import DownloadsDb, now_iso


CONTROL_CHECK_INTERVAL = 0.5
HEARTBEAT_INTERVAL = 5.0
LEASE_TIMEOUT_SECONDS = 45.0
RECOVERY_INTERVAL = 5.0
SOCKET_TIMEOUT_SECONDS = 12
SHUTDOWN_WAIT_SECONDS = 30.0
QUEUE_POSITION_FALLBACK = 999999
BASE_DOWNLOAD_CHUNK_SIZE = 256 * 1024
COPY_CHUNK_SIZE = 1024 * 1024
MIN_THROTTLED_CHUNK_SIZE = 4 * 1024
FREE_SPACE_RESERVE_BYTES = 16 * 1024 * 1024
BASE_RETRY_DELAY_SECONDS = 5.0
MAX_RETRY_DELAY_SECONDS = 15.0 * 60.0

CONTENT_RANGE_PATTERN = re.compile(
    r"^bytes\s+(\d+)-(\d+)/(\d+|\*)$",
    re.IGNORECASE
)
URL_SCHEME_PATTERN = re.compile(r"^[a-z][a-z0-9+.-]*://", re.IGNORECASE)
REMOTE_PLAYBACK_SCHEMES = (
    "http://",
    "https://",
    "ftp://",
    "ftps://",
    "sftp://",
    "dav://",
    "davs://",
    "smb://",
    "nfs://",
    "rtmp://",
    "rtsp://",
    "udp://",
    "plugin://"
)


class DownloadControl(Exception):
    pass


class DownloadCanceled(DownloadControl):
    pass


class DownloadPaused(DownloadControl):
    pass


class DownloadShutdown(DownloadControl):
    pass


class DownloadOwnershipLost(DownloadControl):
    pass


class DownloadFailure(Exception):
    def __init__(self, message, error_code="download_failed", retry_after=None, reset_partial=False):
        super().__init__(message)
        self.error_code = error_code
        self.retry_after = retry_after
        self.reset_partial = reset_partial


class DownloadTransientError(DownloadFailure):
    pass


class DownloadPermanentError(DownloadFailure):
    pass


class DownloadStorageError(DownloadPermanentError):
    def __init__(self, message):
        super().__init__(message, error_code="storage")


class DownloadIntegrityError(DownloadTransientError):
    def __init__(self, message, reset_partial=True):
        super().__init__(
            message,
            error_code="integrity",
            reset_partial=reset_partial
        )


class DownloadsWorker:
    def __init__(self):
        self.db = DownloadsDb()
        self.monitor = xbmc.Monitor()
        addon = xbmcaddon.Addon()
        self.addon_id = addon.getAddonInfo("id")
        self.worker_id = str(uuid.uuid4())
        self.retry_limit = 0
        self.max_attempts = 1
        self.max_concurrent = 1
        self.max_download_speed_bytes = 0
        self.max_download_speed_streaming_bytes = 0
        self.streaming_active = False
        self.download_speed_limit_bytes = 0
        self._rate_limit_available_at = time.monotonic()
        self._rate_limit_lock = threading.Lock()
        self._last_refresh = 0.0
        self._last_recovery = 0.0
        self._threads = {}
        self._thread_paths = {}
        self._active_paths = set()
        self._threads_lock = threading.Lock()
        self._responses = {}
        self._responses_lock = threading.Lock()
        self._heartbeat_times = {}
        self._heartbeat_lock = threading.Lock()
        self.staging_dir = self._configured_staging_dir(addon)
        self._refresh_settings()

    def run(self):
        xbmc.log("[DownloadsWorker] Started", xbmc.LOGINFO)
        self._migrate_stream_start_records()
        self._recover_incomplete(force=True)

        while not self.monitor.abortRequested():
            try:
                self._refresh_settings()
                self._cleanup_threads()
                self._migrate_stream_start_records()
                self._recover_incomplete()
                data = self.db.list()

                capacity = self.max_concurrent - self._active_thread_count()
                if capacity <= 0:
                    self.monitor.waitForAbort(1.0)
                    continue

                jobs = self._pick_next_jobs(data, capacity)
                if not jobs:
                    self.monitor.waitForAbort(1.0)
                    continue

                for job in jobs:
                    self._start_job(job)

                self.monitor.waitForAbort(0.25)
            except Exception as ex:
                xbmc.log(f"[DownloadsWorker] Loop error: {ex}", xbmc.LOGERROR)
                self.monitor.waitForAbort(1.0)

        self._close_active_responses()
        self._wait_for_threads()
        xbmc.log("[DownloadsWorker] Stopped", xbmc.LOGINFO)

    def _refresh_settings(self):
        self.retry_limit = max(0, self._get_int_setting("download_retry_limit", 0))
        self.max_attempts = self.retry_limit + 1
        self.max_concurrent = max(1, self._get_int_setting("max_concurrent_downloads", 1))
        self.max_download_speed_bytes = max(0, self._get_int_setting("max_download_speed_kbps", 0)) * 1024
        self.max_download_speed_streaming_bytes = max(
            0,
            self._get_int_setting("max_download_speed_streaming_kbps", 0)
        ) * 1024
        self.streaming_active = self._is_streaming_active()

        selected_limit = (
            self.max_download_speed_streaming_bytes
            if self.streaming_active
            else self.max_download_speed_bytes
        )
        self._set_download_speed_limit(selected_limit)

    def _get_int_setting(self, setting_id: str, default=0) -> int:
        try:
            value = xbmcaddon.Addon().getSetting(setting_id)
            return int(value) if value not in (None, "") else default
        except Exception:
            return default

    @staticmethod
    def _is_streaming_active() -> bool:
        try:
            player = xbmc.Player()
            if not player.isPlayingVideo():
                return False

            try:
                playing_file = (player.getPlayingFile() or "").strip().lower()
            except Exception:
                return True

            if not playing_file:
                return True
            return playing_file.startswith(REMOTE_PLAYBACK_SCHEMES)
        except Exception:
            return False

    def _set_download_speed_limit(self, limit_bytes: int):
        limit_bytes = max(0, int(limit_bytes or 0))
        with self._rate_limit_lock:
            if self.download_speed_limit_bytes == limit_bytes:
                return
            self.download_speed_limit_bytes = limit_bytes
            self._rate_limit_available_at = time.monotonic()

    def _current_download_speed_limit(self) -> int:
        with self._rate_limit_lock:
            return self.download_speed_limit_bytes

    def _download_chunk_size(self) -> int:
        limit = self._current_download_speed_limit()
        if limit <= 0:
            return BASE_DOWNLOAD_CHUNK_SIZE
        throttled_size = max(MIN_THROTTLED_CHUNK_SIZE, int(limit / 4))
        return min(BASE_DOWNLOAD_CHUNK_SIZE, throttled_size)

    def _wait_for_download_quota(self, download_id: str, byte_count: int, owner_token=None):
        if byte_count <= 0:
            return

        with self._rate_limit_lock:
            limit = self.download_speed_limit_bytes
            if limit <= 0:
                self._rate_limit_available_at = time.monotonic()
                return

            current = time.monotonic()
            available_at = max(current, self._rate_limit_available_at)
            wait_for = available_at - current
            self._rate_limit_available_at = available_at + (float(byte_count) / float(limit))

        self._wait_with_download_control(download_id, wait_for, owner_token)

    def _refund_download_quota(self, byte_count: int):
        if byte_count <= 0:
            return

        with self._rate_limit_lock:
            limit = self.download_speed_limit_bytes
            if limit <= 0:
                return

            refund_seconds = float(byte_count) / float(limit)
            self._rate_limit_available_at = max(
                time.monotonic(),
                self._rate_limit_available_at - refund_seconds
            )

    def _wait_with_download_control(self, download_id: str, wait_for: float, owner_token=None):
        if wait_for <= 0:
            return

        deadline = time.monotonic() + wait_for
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return

            if self.monitor.waitForAbort(min(remaining, CONTROL_CHECK_INTERVAL)):
                raise DownloadShutdown("Kodi is shutting down")

            if owner_token:
                self._check_control(download_id, owner_token, ("downloading",))
            if self._current_download_speed_limit() <= 0:
                return

    @staticmethod
    def _configured_staging_dir(addon):
        configured = ""
        try:
            configured = addon.getSetting("download_staging_path") or ""
        except Exception:
            pass

        if configured:
            local = DownloadsWorker._local_filesystem_path(configured)
            if local and not DownloadsWorker._destination_requires_staging(configured):
                return os.path.join(local, ".mediahub-staging")

        try:
            profile = addon.getAddonInfo("profile") or ""
        except Exception:
            profile = ""
        local_profile = DownloadsWorker._local_filesystem_path(profile)
        if not local_profile or DownloadsWorker._destination_requires_staging(profile):
            local_profile = os.getcwd()
        return os.path.join(local_profile, "download_staging")

    def _cleanup_threads(self):
        with self._threads_lock:
            finished = [
                download_id
                for download_id, thread in self._threads.items()
                if not thread.is_alive()
            ]
            for download_id in finished:
                self._threads.pop(download_id, None)
                path_key = self._thread_paths.pop(download_id, None)
                if path_key:
                    self._active_paths.discard(path_key)

    def _active_thread_count(self) -> int:
        with self._threads_lock:
            return len(self._threads)

    def _active_download_ids(self):
        with self._threads_lock:
            return set(self._threads.keys())

    def _active_path_keys(self):
        with self._threads_lock:
            return set(self._active_paths)

    @classmethod
    def _canonical_path(cls, path):
        local = cls._local_filesystem_path(path)
        if local:
            absolute = os.path.abspath(os.path.normpath(local))
            parent, filename = os.path.split(absolute)
            return os.path.normcase(os.path.join(os.path.realpath(parent), filename))
        return re.sub(r"/+", "/", str(path or "").replace("\\", "/")).rstrip("/").casefold()

    def _start_job(self, job: dict):
        download_id = job.get("id")
        destination = job.get("path")
        if not download_id or not destination:
            return
        path_key = self._canonical_path(destination)

        with self._threads_lock:
            if download_id in self._threads or path_key in self._active_paths:
                return

            thread = threading.Thread(
                target=self._run_job_thread,
                args=(job,),
                name=f"MediaHubDownload-{download_id[:8]}",
                daemon=True
            )
            self._threads[download_id] = thread
            self._thread_paths[download_id] = path_key
            self._active_paths.add(path_key)
            thread.start()

    def _run_job_thread(self, job: dict):
        download_id = job.get("id")
        try:
            self._process_job(job)
        except Exception as ex:
            # State changes belong in _process_job, where the attempt owner token
            # is known. A blind update here could overwrite a newer retry.
            xbmc.log(
                f"[DownloadsWorker] Unhandled job error for {download_id}: {ex}",
                xbmc.LOGERROR
            )
        finally:
            with self._threads_lock:
                self._threads.pop(download_id, None)
                path_key = self._thread_paths.pop(download_id, None)
                if path_key:
                    self._active_paths.discard(path_key)
            with self._heartbeat_lock:
                stale_keys = [key for key in self._heartbeat_times if key[0] == download_id]
                for key in stale_keys:
                    self._heartbeat_times.pop(key, None)

    def _wait_for_threads(self, timeout_sec=SHUTDOWN_WAIT_SECONDS):
        deadline = time.monotonic() + timeout_sec
        while time.monotonic() < deadline:
            self._close_active_responses()
            with self._threads_lock:
                threads = list(self._threads.values())
            if not threads:
                return
            for thread in threads:
                thread.join(0.1)

        with self._threads_lock:
            remaining = len(self._threads)
        if remaining:
            xbmc.log(
                f"[DownloadsWorker] Stopping with {remaining} download thread(s) still active",
                xbmc.LOGWARNING
            )

    def _register_response(self, download_id, response):
        with self._responses_lock:
            self._responses[download_id] = response

    def _unregister_response(self, download_id, response):
        with self._responses_lock:
            if self._responses.get(download_id) is response:
                self._responses.pop(download_id, None)

    def _close_active_responses(self):
        with self._responses_lock:
            responses = list(self._responses.values())
        for response in responses:
            try:
                response.close()
            except Exception:
                pass

    @staticmethod
    def _clear_stream_start_fields():
        return {
            "pause_reason": None,
            "pause_until": None,
            "pause_requested": None,
            "stream_startup_limit_until": None
        }

    def _migrate_stream_start_records(self):
        data = self.db.list()
        for download_id, record in data.items():
            has_marker = (
                record.get("pause_reason") == "stream_start" or
                record.get("pause_requested") == "stream_start" or
                record.get("stream_startup_limit_until")
            )
            if not has_marker:
                continue

            status = record.get("status")
            patch = {
                **self._clear_stream_start_fields(),
                "updated_at": now_iso()
            }
            if status == "paused":
                patch["status"] = "queued"
            self.db.transition(download_id, status, patch)

    @staticmethod
    def _parse_timestamp(value):
        if value in (None, ""):
            return None
        if isinstance(value, (int, float)):
            return float(value)
        try:
            text = str(value).strip()
            if text.endswith("Z"):
                text = text[:-1] + "+00:00"
            parsed = datetime.datetime.fromisoformat(text)
            if parsed.tzinfo is None:
                # JSON-era timestamps were local-time strings without an
                # offset. datetime.timestamp() deliberately interprets those
                # in the machine's local zone.
                return parsed.timestamp()
            return parsed.timestamp()
        except (TypeError, ValueError, OverflowError):
            return None

    @staticmethod
    def _iso_after(seconds):
        target = datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(seconds=seconds)
        return target.isoformat()

    def _lease_is_recoverable(self, record):
        if not record.get("owner_token"):
            return True
        heartbeat = self._parse_timestamp(
            record.get("owner_heartbeat_at") or record.get("updated_at")
        )
        return heartbeat is None or time.time() - heartbeat >= LEASE_TIMEOUT_SECONDS

    def _recover_incomplete(self, force=False):
        current = time.monotonic()
        if not force and current - self._last_recovery < RECOVERY_INTERVAL:
            return
        self._last_recovery = current

        data = self.db.list()
        locally_active_ids = self._active_download_ids()
        for download_id, record in data.items():
            status = record.get("status")
            if download_id in locally_active_ids:
                continue
            if status not in (
                "downloading",
                "pausing",
                "canceling",
                "repairing",
                "finalizing"
            ):
                continue
            if status == "finalizing":
                retry_at = self._parse_timestamp(record.get("next_attempt_at"))
                if retry_at is not None and retry_at > time.time():
                    continue
            if not self._lease_is_recoverable(record):
                continue

            previous_owner = record.get("owner_token")
            recovery_token = str(uuid.uuid4())
            claimed = self.db.transition(
                download_id,
                status,
                {
                    "owner_token": recovery_token,
                    "owner_worker_id": getattr(self, "worker_id", "worker"),
                    "owner_heartbeat_at": now_iso(),
                    "updated_at": now_iso()
                },
                expected_owner_token=previous_owner,
                expected_revision=record.get("revision")
            )
            if not claimed:
                continue

            record = claimed
            destination = record.get("path") or ""
            work_path = self._work_path(download_id, destination, record)
            part_size = self._get_file_size(work_path)
            expected = self._positive_int(record.get("bytes_total")) or 0
            progress = min(100, int(100 * part_size / expected)) if expected else 0
            recorded_attempts = int(record.get("attempts") or 0)
            attempts = (
                recorded_attempts
                if status == "finalizing"
                else max(0, recorded_attempts - 1)
            )
            common = {
                "owner_token": None,
                "owner_worker_id": None,
                "owner_heartbeat_at": None,
                "attempt_id": None,
                "updated_at": now_iso()
            }

            if status == "canceling":
                partial_removed = self._delete_path(work_path)
                upload_path = (
                    record.get("finalization_path")
                    or self._remote_upload_path(download_id, destination)
                )
                upload_removed = self._delete_path(upload_path)
                removed = partial_removed and upload_removed
                patch = {
                    **common,
                    "status": "canceled",
                    "queue_position": None,
                    "bytes_done": 0 if removed else part_size,
                    "progress": 0 if removed else progress,
                    "error": None if removed else "Could not remove all partial download data",
                    "error_code": None if removed else "storage",
                    "cleanup_pending": not removed,
                    "finalization_path": None if upload_removed else upload_path
                }
            elif status == "pausing":
                patch = {
                    **common,
                    "status": "paused",
                    "bytes_done": part_size,
                    "progress": progress,
                    "attempts": attempts,
                    "error": None,
                    "error_code": None
                }
            elif status == "repairing":
                final_exists = self._path_exists(destination)
                part_exists = self._path_exists(work_path)
                previous_status = record.get("repair_from_status") or "failed"
                if part_exists and not final_exists:
                    patch = {
                        **common,
                        "status": "queued",
                        "bytes_done": part_size,
                        "progress": progress,
                        "attempts": 0,
                        "error": None,
                        "error_code": None,
                        "next_attempt_at": None,
                        "repair_from_status": None
                    }
                elif final_exists and not part_exists:
                    patch = {
                        **common,
                        "status": previous_status,
                        "repair_from_status": None
                    }
                elif not final_exists and not part_exists:
                    patch = {
                        **common,
                        "status": "queued",
                        "bytes_done": 0,
                        "progress": 0,
                        "attempts": 0,
                        "error": None,
                        "error_code": None,
                        "next_attempt_at": None,
                        "repair_from_status": None
                    }
                else:
                    patch = {
                        **common,
                        "status": "failed",
                        "error": "Repair recovery found both final and partial files; neither was changed",
                        "error_code": "verification_failed",
                        "repair_from_status": None
                    }
            elif status == "finalizing":
                final_size = self._get_file_size(destination)
                final_exists = self._path_exists(destination)
                upload_path = (
                    record.get("finalization_path")
                    or self._remote_upload_path(download_id, destination)
                )
                finalization_hash = (
                    record.get("finalization_hash")
                    or record.get("expected_hash")
                )
                try:
                    if final_exists and final_size == expected and expected > 0:
                        self._verify_expected_hash(
                            destination,
                            finalization_hash,
                            download_id,
                            recovery_token,
                            ("finalizing",)
                        )
                        patch = {
                            **common,
                            "status": "complete",
                            "progress": 100,
                            "bytes_done": expected,
                            "error": None,
                            "error_code": None,
                            "next_attempt_at": None,
                            "finalization_path": None,
                            "finalization_failure_permanent": None,
                            "finalization_attempts": None,
                            "cleanup_pending": False,
                            "completed_at": record.get("completed_at") or now_iso()
                        }
                    elif final_exists:
                        patch = {
                            **common,
                            "status": "failed",
                            "error": (
                                f"Finalization recovery found {final_size} bytes at the destination; "
                                f"expected {expected}. The file was left untouched."
                            ),
                            "error_code": "verification_failed",
                            "cleanup_pending": self._path_exists(upload_path)
                        }
                    elif expected > 0 and self._get_file_size(upload_path) == expected:
                        self._verify_expected_hash(
                            upload_path,
                            finalization_hash,
                            download_id,
                            recovery_token,
                            ("finalizing",)
                        )
                        if self._path_exists(destination):
                            raise DownloadStorageError(
                                "Destination appeared during finalization recovery; refusing to overwrite it"
                            )
                        if not xbmcvfs.rename(upload_path, destination):
                            raise DownloadTransientError(
                                "Could not finish the recovered staged copy",
                                error_code="network"
                            )
                        self._verify_expected_hash(
                            destination,
                            finalization_hash,
                            download_id,
                            recovery_token,
                            ("finalizing",)
                        )
                        patch = {
                            **common,
                            "status": "complete",
                            "progress": 100,
                            "bytes_done": expected,
                            "error": None,
                            "error_code": None,
                            "next_attempt_at": None,
                            "finalization_path": None,
                            "finalization_failure_permanent": None,
                            "finalization_attempts": None,
                            "cleanup_pending": False,
                            "completed_at": record.get("completed_at") or now_iso()
                        }
                    elif record.get("finalization_failure_permanent"):
                        patch = {
                            **common,
                            "status": "failed",
                            "queue_position": None,
                            "error": record.get("error") or "Finalization failed",
                            "error_code": record.get("error_code") or "storage",
                            "cleanup_pending": True,
                            "next_attempt_at": None
                        }
                    else:
                        patch = {
                            **common,
                            "status": "queued",
                            "bytes_done": part_size,
                            "progress": progress,
                            "attempts": attempts,
                            "error": None,
                            "error_code": None,
                            "next_attempt_at": None,
                            "finalization_path": None,
                            "finalization_failure_permanent": None,
                            "finalization_attempts": None,
                            "cleanup_pending": False
                        }
                except DownloadControl:
                    # A current UI command or owner takeover won; leave it for
                    # the next loop to settle.
                    continue
                except DownloadIntegrityError as ex:
                    patch = {
                        **common,
                        "status": "failed",
                        "error": str(ex),
                        "error_code": "verification_failed",
                        "cleanup_pending": True,
                        "next_attempt_at": None
                    }
                except DownloadFailure as ex:
                    finalization_attempt = int(
                        record.get("finalization_attempts") or 0
                    ) + 1
                    max_attempts = getattr(self, "max_attempts", 1)
                    can_retry = (
                        isinstance(ex, DownloadTransientError)
                        and finalization_attempt < max_attempts
                    )
                    if can_retry:
                        delay = self._retry_delay(
                            finalization_attempt,
                            ex.retry_after
                        )
                        patch = {
                            **common,
                            "status": "finalizing",
                            "error": str(ex),
                            "error_code": ex.error_code,
                            "cleanup_pending": True,
                            "finalization_attempts": finalization_attempt,
                            "finalization_failure_permanent": False,
                            "next_attempt_at": self._iso_after(delay),
                            "retry_delay_seconds": delay
                        }
                    else:
                        patch = {
                            **common,
                            "status": "failed",
                            "queue_position": None,
                            "error": str(ex),
                            "error_code": ex.error_code,
                            "cleanup_pending": True,
                            "finalization_attempts": finalization_attempt,
                            "finalization_failure_permanent": True,
                            "next_attempt_at": None
                        }
            else:
                patch = {
                    **common,
                    "status": "queued",
                    "bytes_done": part_size,
                    "progress": progress,
                    "attempts": attempts,
                    "error": None,
                    "error_code": None,
                    "next_attempt_at": None
                }

            updated = self.db.update_owned(
                download_id,
                recovery_token,
                patch,
                expected_statuses=(status,)
            )
            if updated and patch["status"] == "complete":
                self._delete_path(work_path)

    # Kept as a compatibility alias for older callers and tests.
    def _requeue_incomplete(self):
        self._recover_incomplete(force=True)

    @staticmethod
    def _local_filesystem_path(path: str):
        try:
            translated = xbmcvfs.translatePath(path)
        except Exception:
            translated = path
        if not translated or URL_SCHEME_PATTERN.match(str(translated)):
            return None
        return str(translated)

    @classmethod
    def _destination_requires_staging(cls, path: str) -> bool:
        raw = str(path or "").strip().replace("/", "\\")
        if raw.startswith("\\\\"):
            return True
        try:
            translated = str(xbmcvfs.translatePath(path) or "")
        except Exception:
            translated = str(path or "")
        translated_windows = translated.replace("/", "\\")
        if translated_windows.startswith("\\\\"):
            return True
        return cls._local_filesystem_path(path) is None

    @staticmethod
    def _positive_int(value):
        try:
            parsed = int(str(value).strip())
            return parsed if parsed >= 0 else None
        except (TypeError, ValueError):
            return None

    # Compatibility name retained from the original worker.
    _positive_header_int = _positive_int

    @staticmethod
    def _header(headers, name):
        if headers is None:
            return None
        try:
            value = headers.get(name)
            if value is None:
                value = headers.get(name.lower())
            if value is None and hasattr(headers, "items"):
                wanted = name.casefold()
                value = next(
                    (item_value for key, item_value in headers.items()
                     if str(key).casefold() == wanted),
                    None
                )
            return value
        except Exception:
            return None

    @staticmethod
    def _parse_content_range(value):
        match = CONTENT_RANGE_PATTERN.match((value or "").strip())
        if not match:
            return None
        start = int(match.group(1))
        end = int(match.group(2))
        total = None if match.group(3) == "*" else int(match.group(3))
        if end < start or (total is not None and end >= total):
            return None
        return start, end, total

    @staticmethod
    def _write_download_chunk(file_handle, chunk: bytes, is_vfs: bool):
        if is_vfs:
            if not file_handle.write(bytearray(chunk)):
                raise DownloadStorageError("Could not write download data to the destination")
            return

        view = memoryview(chunk)
        written = 0
        while written < len(view):
            count = file_handle.write(view[written:])
            if not count:
                raise DownloadStorageError("Could not write download data to the destination")
            written += count

    @classmethod
    def _response_validators(cls, headers):
        return {
            "etag": cls._header(headers, "etag") or None,
            "last_modified": cls._header(headers, "last-modified") or None
        }

    @staticmethod
    def _resume_validator(record: dict):
        etag = (record.get("etag") or "").strip()
        if etag and not etag.lower().startswith("w/"):
            return etag
        last_modified = (record.get("last_modified") or "").strip()
        return last_modified or None

    @staticmethod
    def _queue_position(record: dict) -> int:
        try:
            position = int(record.get("queue_position") or 0)
            return position if position > 0 else QUEUE_POSITION_FALLBACK
        except (TypeError, ValueError):
            return QUEUE_POSITION_FALLBACK

    def _pick_next_jobs(self, data: dict, limit: int):
        active_ids = self._active_download_ids()
        active_paths = self._active_path_keys()
        ready = []
        current_time = time.time()

        for download_id, record in data.items():
            status = record.get("status")
            if status not in ("queued", "waiting_retry") or download_id in active_ids:
                continue
            if status == "waiting_retry":
                retry_at = self._parse_timestamp(record.get("next_attempt_at"))
                if retry_at is not None and retry_at > current_time:
                    continue
            if self._canonical_path(record.get("path")) in active_paths:
                continue

            job = dict(record)
            job["id"] = job.get("id") or download_id
            ready.append(job)

        ready.sort(key=lambda item: (
            self._queue_position(item),
            item.get("created_at") or "",
            item.get("id") or ""
        ))
        return ready[:limit]

    def _maybe_refresh_downloads_view(self, throttle_sec=10.0, force=False):
        current = time.time()
        if not force and current - self._last_refresh < throttle_sec:
            return
        folder_path = xbmc.getInfoLabel("Container.FolderPath") or ""
        if not folder_path or f"plugin://{self.addon_id}" not in folder_path:
            return
        if "action=show_downloads_menu" not in folder_path:
            return
        xbmc.executebuiltin("Container.Refresh")
        self._last_refresh = current

    def _work_path(self, download_id, destination, record=None):
        record = record or {}
        if not self._destination_requires_staging(destination):
            return f"{destination}.part"
        existing = record.get("staging_path")
        if existing and self._local_filesystem_path(existing) is not None:
            return existing
        safe_id = re.sub(r"[^A-Za-z0-9_.-]", "_", str(download_id))
        staging_dir = getattr(self, "staging_dir", None)
        if not staging_dir:
            staging_dir = self._configured_staging_dir(xbmcaddon.Addon())
            self.staging_dir = staging_dir
        return os.path.join(staging_dir, f"{safe_id}.part")

    @staticmethod
    def _remote_upload_path(download_id, destination):
        if not destination:
            return ""
        safe_id = re.sub(r"[^A-Za-z0-9_.-]", "_", str(download_id))
        return f"{destination}.uploading-{safe_id}"

    def _get_file_size(self, path: str) -> int:
        if not path:
            return 0
        local = self._local_filesystem_path(path)
        if local is not None:
            try:
                return os.path.getsize(local)
            except OSError:
                return 0
        try:
            if not xbmcvfs.exists(path):
                return 0
            return int(xbmcvfs.Stat(path).st_size())
        except Exception:
            return 0

    # Compatibility name retained for tests and UI-adjacent code.
    def _get_part_size(self, part_path: str) -> int:
        return self._get_file_size(part_path)

    def _path_exists(self, path):
        if not path:
            return False
        local = self._local_filesystem_path(path)
        if local is not None:
            return os.path.exists(local)
        try:
            return bool(xbmcvfs.exists(path))
        except Exception:
            return False

    def _delete_path(self, path):
        if not path or not self._path_exists(path):
            return True
        local = self._local_filesystem_path(path)
        if local is not None:
            try:
                os.remove(local)
                return True
            except OSError:
                return False
        try:
            return bool(xbmcvfs.delete(path)) and not xbmcvfs.exists(path)
        except Exception:
            return False

    def _ensure_local_parent(self, path):
        local = self._local_filesystem_path(path)
        if local is None:
            raise DownloadStorageError("Download staging path is not a local filesystem path")
        parent = os.path.dirname(local)
        if parent:
            try:
                os.makedirs(parent, exist_ok=True)
            except OSError as ex:
                raise DownloadStorageError(f"Could not create download directory: {ex}") from ex
        return local

    def _check_free_space(self, work_path, remaining_bytes):
        local = self._ensure_local_parent(work_path)
        parent = os.path.dirname(local) or os.curdir
        try:
            available = shutil.disk_usage(parent).free
        except OSError as ex:
            raise DownloadStorageError(f"Could not determine available disk space: {ex}") from ex
        required = max(0, int(remaining_bytes)) + FREE_SPACE_RESERVE_BYTES
        if available < required:
            raise DownloadStorageError(
                f"Not enough free space: need {required} bytes, only {available} bytes available"
            )

    def _owned_update(self, download_id, owner_token, patch, expected_statuses):
        if not self.db.update_owned(
            download_id,
            owner_token,
            patch,
            expected_statuses=expected_statuses
        ):
            # A pause/cancel can win between the preceding state read and this
            # CAS. Preserve that command instead of treating it like an owner
            # theft and leaving the intermediate state for lease recovery.
            current = self.db.list().get(download_id, {})
            if current.get("owner_token") == owner_token:
                if current.get("status") in ("canceling", "canceled"):
                    raise DownloadCanceled("Canceled")
                if current.get("status") in ("pausing", "paused"):
                    raise DownloadPaused("Paused")
            raise DownloadOwnershipLost("Download attempt no longer owns this job")

    def _touch_lease(self, download_id, owner_token, expected_statuses):
        key = (download_id, owner_token)
        current = time.monotonic()
        with self._heartbeat_lock:
            previous = self._heartbeat_times.get(key, 0.0)
            if current - previous < HEARTBEAT_INTERVAL:
                return
            self._heartbeat_times[key] = current
        self._owned_update(download_id, owner_token, {
            "owner_heartbeat_at": now_iso(),
            "updated_at": now_iso()
        }, expected_statuses)

    def _check_control(self, download_id, owner_token, expected_statuses=("downloading",)):
        record = self.db.list().get(download_id)
        if not record or record.get("owner_token") != owner_token:
            raise DownloadOwnershipLost("Download attempt ownership changed")

        status = record.get("status")
        if status in ("canceling", "canceled"):
            raise DownloadCanceled("Canceled")
        if status in ("pausing", "paused"):
            raise DownloadPaused("Paused")
        if status not in tuple(expected_statuses):
            raise DownloadOwnershipLost(f"Unexpected download state: {status}")
        if self.monitor.abortRequested():
            raise DownloadShutdown("Kodi is shutting down")

        self._touch_lease(download_id, owner_token, expected_statuses)
        return record

    def _claim_job(self, job):
        download_id = job["id"]
        attempts = int(job.get("attempts") or 0)
        max_attempts = getattr(self, "max_attempts", 1)
        expected_statuses = ("queued", "waiting_retry")

        if job.get("status") == "waiting_retry":
            retry_at = self._parse_timestamp(job.get("next_attempt_at"))
            if retry_at is not None and retry_at > time.time():
                return None, None, attempts

        if attempts >= max_attempts:
            self.db.transition(download_id, expected_statuses, {
                "status": "failed",
                "error": "Retry limit reached",
                "error_code": "retry_limit",
                "queue_position": None,
                "next_attempt_at": None,
                "updated_at": now_iso()
            }, expected_revision=job.get("revision"))
            return None, None, attempts

        owner_token = str(uuid.uuid4())
        worker_id = getattr(self, "worker_id", "worker")
        current_attempt = attempts + 1
        claimed = self.db.transition(download_id, expected_statuses, {
            "status": "downloading",
            "owner_token": owner_token,
            "owner_worker_id": worker_id,
            "owner_heartbeat_at": now_iso(),
            "attempt_id": owner_token,
            "attempts": current_attempt,
            "error": None,
            "error_code": None,
            "next_attempt_at": None,
            **self._clear_stream_start_fields(),
            "updated_at": now_iso()
        }, expected_revision=job.get("revision"))
        return claimed, owner_token, attempts

    def _normalize_ticket(self, ticket):
        if not isinstance(ticket, dict):
            raise DownloadPermanentError(
                "Download service returned an invalid ticket",
                error_code="ticket"
            )
        url = ticket.get("url")
        size = ticket.get("size_bytes", ticket.get("sizeBytes"))
        if not isinstance(url, str) or not url.strip():
            raise DownloadPermanentError(
                "Download ticket does not contain a URL",
                error_code="ticket"
            )
        if isinstance(size, bool):
            size = None
        size = self._positive_int(size)
        if size is None or size <= 0:
            raise DownloadPermanentError(
                "Download ticket does not contain a valid expected file size",
                error_code="ticket_size"
            )
        return {
            "url": url.strip(),
            "size_bytes": size,
            "file_name": ticket.get("file_name", ticket.get("fileName")),
            "expires_at": ticket.get("expires_at", ticket.get("expiresAt")),
            "etag": ticket.get("etag") or None,
            "hash": ticket.get("hash") or None
        }

    def _resolve_download_ticket(self, download_id, record, owner_token):
        stream_id = record.get("stream_id")
        if stream_id:
            xbmc.log(
                f"[DownloadsWorker] Resolving download ticket for {download_id}",
                xbmc.LOGINFO
            )
            try:
                ticket_payload = api.get_download_ticket(stream_id)
            except ValueError as ex:
                raise DownloadPermanentError(
                    f"Invalid download ticket: {ex}",
                    error_code="ticket"
                ) from ex
            ticket = self._normalize_ticket(ticket_payload)
        else:
            # Migration compatibility for legacy records. New jobs never persist a URL.
            ticket = self._normalize_ticket({
                "url": record.get("url"),
                "size_bytes": record.get("bytes_total"),
                "file_name": record.get("filename"),
                "etag": record.get("etag"),
                "hash": record.get("expected_hash")
            })

        patch = {
            "bytes_total": ticket["size_bytes"],
            "ticket_file_name": ticket.get("file_name"),
            "ticket_expires_at": ticket.get("expires_at"),
            "expected_hash": ticket.get("hash"),
            # Remove signed URLs left by the JSON-era schema.
            "url": None,
            "updated_at": now_iso()
        }
        if ticket.get("etag"):
            patch["etag"] = ticket["etag"]
        self._owned_update(download_id, owner_token, patch, ("downloading",))
        return ticket

    @staticmethod
    def _parse_hash_spec(value):
        if not value or not isinstance(value, str):
            return None
        text = value.strip().lower()
        if ":" in text:
            algorithm, digest = text.split(":", 1)
            algorithm = algorithm.replace("-", "")
        elif re.fullmatch(r"[0-9a-f]{64}", text):
            algorithm, digest = "sha256", text
        elif re.fullmatch(r"[0-9a-f]{32}", text):
            algorithm, digest = "md5", text
        else:
            return None
        if algorithm not in hashlib.algorithms_available or not re.fullmatch(r"[0-9a-f]+", digest):
            return None
        return algorithm, digest

    def _hash_file(
        self,
        path,
        algorithm,
        download_id=None,
        owner_token=None,
        expected_statuses=("downloading", "finalizing")
    ):
        digest = hashlib.new(algorithm)
        last_control_check = 0.0
        local = self._local_filesystem_path(path)
        if local is not None:
            try:
                with open(local, "rb") as handle:
                    while True:
                        current = time.monotonic()
                        if (
                            download_id
                            and owner_token
                            and current - last_control_check >= CONTROL_CHECK_INTERVAL
                        ):
                            self._check_control(
                                download_id,
                                owner_token,
                                expected_statuses
                            )
                            last_control_check = current
                        chunk = handle.read(COPY_CHUNK_SIZE)
                        if not chunk:
                            break
                        digest.update(chunk)
                return digest.hexdigest()
            except OSError as ex:
                raise DownloadStorageError(f"Could not verify downloaded file: {ex}") from ex

        handle = None
        try:
            handle = xbmcvfs.File(path, "r")
            while True:
                current = time.monotonic()
                if (
                    download_id
                    and owner_token
                    and current - last_control_check >= CONTROL_CHECK_INTERVAL
                ):
                    self._check_control(
                        download_id,
                        owner_token,
                        expected_statuses
                    )
                    last_control_check = current
                chunk = handle.read(COPY_CHUNK_SIZE)
                if not chunk:
                    break
                digest.update(bytes(chunk))
            return digest.hexdigest()
        except Exception as ex:
            raise DownloadStorageError(f"Could not verify downloaded file: {ex}") from ex
        finally:
            if handle is not None:
                try:
                    handle.close()
                except Exception:
                    pass

    def _verify_expected_hash(
        self,
        path,
        expected_hash,
        download_id=None,
        owner_token=None,
        expected_statuses=("downloading", "finalizing")
    ):
        specification = self._parse_hash_spec(expected_hash)
        if not specification:
            return
        algorithm, expected = specification
        actual = self._hash_file(
            path,
            algorithm,
            download_id,
            owner_token,
            expected_statuses
        )
        if actual.lower() != expected.lower():
            raise DownloadIntegrityError(
                f"Downloaded file hash mismatch: expected {expected}, found {actual}"
            )

    def _prepare_partial(self, record, ticket, work_path):
        existing_size = self._get_file_size(work_path)
        previous_total = self._positive_int(record.get("bytes_total")) or 0
        expected_total = ticket["size_bytes"]
        previous_hash = record.get("expected_hash")
        ticket_hash = ticket.get("hash")
        previous_etag = (record.get("etag") or "").strip()
        ticket_etag = (ticket.get("etag") or "").strip()

        identity_changed = (
            (previous_total > 0 and previous_total != expected_total) or
            (existing_size > 0 and previous_hash and ticket_hash and previous_hash != ticket_hash) or
            (existing_size > 0 and previous_etag and ticket_etag and previous_etag != ticket_etag)
        )
        if existing_size > expected_total or identity_changed:
            if not self._delete_path(work_path):
                raise DownloadStorageError("Could not reset a stale partial download")
            existing_size = 0

        # Only a validator persisted alongside the existing partial can prove
        # those bytes belong to the current object. A newly supplied ticket
        # ETag must not retroactively authenticate an older legacy partial.
        effective_record = dict(record)
        if existing_size > 0 and existing_size < expected_total and not self._resume_validator(effective_record):
            xbmc.log(
                f"[DownloadsWorker] Restarting {record.get('id')}; no safe resume validator is available",
                xbmc.LOGWARNING
            )
            if not self._delete_path(work_path):
                raise DownloadStorageError("Could not reset an unverifiable partial download")
            existing_size = 0
        return existing_size, effective_record

    def _open_response(self, download_id, request):
        response = urllib.request.urlopen(request, timeout=SOCKET_TIMEOUT_SECONDS)
        self._register_response(download_id, response)
        return response

    @staticmethod
    def _parse_retry_after(headers):
        value = DownloadsWorker._header(headers, "retry-after")
        if value in (None, ""):
            return None
        try:
            return max(0.0, float(str(value).strip()))
        except (TypeError, ValueError):
            pass
        try:
            target = email.utils.parsedate_to_datetime(str(value))
            if target.tzinfo is None:
                target = target.replace(tzinfo=datetime.timezone.utc)
            return max(0.0, target.timestamp() - time.time())
        except (TypeError, ValueError, OverflowError):
            return None

    def _http_failure(self, error, auth_was_refreshed=False):
        status = int(getattr(error, "code", 0) or 0)
        retry_after = self._parse_retry_after(getattr(error, "headers", None))
        if status in (401, 403):
            message = f"Download authorization failed after URL refresh (HTTP {status})"
            return DownloadPermanentError(message, error_code="authorization")
        if status == 404:
            return DownloadPermanentError("Download file was not found (HTTP 404)", error_code="not_found")
        if status in (409, 429) or 500 <= status <= 599:
            return DownloadTransientError(
                f"Download server returned HTTP {status}",
                error_code="server_busy",
                retry_after=retry_after
            )
        if 400 <= status <= 499:
            return DownloadPermanentError(
                f"Download request failed with HTTP {status}",
                error_code="http"
            )
        return DownloadTransientError(
            f"Unexpected download response status {status}",
            error_code="network",
            retry_after=retry_after
        )

    def _download_from_ticket(self, download_id, record, owner_token, ticket, work_path):
        expected_total = ticket["size_bytes"]
        existing_size, effective_record = self._prepare_partial(record, ticket, work_path)
        if existing_size == expected_total:
            return existing_size

        self._check_free_space(work_path, expected_total - existing_size)
        if self._path_exists(record["path"]):
            raise DownloadStorageError("Destination file already exists; refusing to overwrite it")

        if existing_size > 0:
            xbmc.executebuiltin(
                f'Notification(Download,Resuming {record.get("filename") or "download"},2000)'
            )
        else:
            xbmc.executebuiltin(
                f'Notification(Download,Starting {record.get("filename") or "download"},2000)'
            )

        request = urllib.request.Request(ticket["url"])
        request.add_header("Accept-Encoding", "identity")
        if existing_size > 0:
            request.add_header("Range", f"bytes={existing_size}-")
            request.add_header("If-Range", self._resume_validator(effective_record))

        response = self._open_response(download_id, request)
        try:
            status = getattr(response, "status", response.getcode())
            if status not in (200, 206):
                synthetic = urllib.error.HTTPError(
                    ticket["url"], status, f"HTTP {status}", response.headers, None
                )
                raise synthetic

            content_length = self._positive_int(self._header(response.headers, "content-length"))
            content_range = self._parse_content_range(
                self._header(response.headers, "content-range")
            )
            if status == 206:
                if content_range is None:
                    raise DownloadTransientError(
                        "Partial response is missing a valid Content-Range header",
                        error_code="protocol"
                    )
                range_start, range_end, range_total = content_range
                if range_start != existing_size:
                    raise DownloadTransientError(
                        f"Resume range mismatch: requested {existing_size}, received {range_start}",
                        error_code="protocol"
                    )
                range_length = range_end - range_start + 1
                if range_end != expected_total - 1:
                    raise DownloadTransientError(
                        f"Partial response ended at {range_end}, expected {expected_total - 1}",
                        error_code="protocol"
                    )
                if content_length is not None and content_length != range_length:
                    raise DownloadTransientError(
                        f"Partial response length mismatch: expected {range_length}, received {content_length}",
                        error_code="protocol"
                    )
                if range_total is not None and range_total != expected_total:
                    raise DownloadIntegrityError(
                        f"Resume file size changed: ticket says {expected_total}, server says {range_total}"
                    )
            else:
                # A server may legitimately ignore Range; rewrite instead of appending.
                existing_size = 0
                if content_length is not None and content_length != expected_total:
                    raise DownloadTransientError(
                        f"Response length mismatch: ticket says {expected_total}, server says {content_length}",
                        error_code="protocol"
                    )

            response_etag = self._header(response.headers, "etag")
            ticket_etag = ticket.get("etag")
            if response_etag and ticket_etag and response_etag != ticket_etag:
                raise DownloadIntegrityError("Download ETag does not match the authoritative ticket")

            progress = int(100 * existing_size / expected_total)
            validators = self._response_validators(response.headers)
            if ticket_etag:
                validators["etag"] = ticket_etag
            self._owned_update(download_id, owner_token, {
                "bytes_total": expected_total,
                "bytes_done": existing_size,
                "progress": progress,
                **validators,
                "updated_at": now_iso()
            }, ("downloading",))

            local_work_path = self._ensure_local_parent(work_path)
            try:
                handle = open(local_work_path, "ab" if status == 206 and existing_size else "wb")
            except OSError as ex:
                raise DownloadStorageError(f"Could not open partial download: {ex}") from ex

            downloaded = existing_size
            last_saved_percent = progress
            last_progress_update = time.monotonic()
            last_control_check = 0.0
            try:
                while downloaded < expected_total:
                    current = time.monotonic()
                    if current - last_control_check >= CONTROL_CHECK_INTERVAL:
                        self._check_control(download_id, owner_token, ("downloading",))
                        last_control_check = current

                    read_size = min(self._download_chunk_size(), expected_total - downloaded)
                    self._wait_for_download_quota(download_id, read_size, owner_token)
                    try:
                        chunk = response.read(read_size)
                    except (socket.timeout, TimeoutError) as ex:
                        raise DownloadTransientError(
                            f"Download read timed out: {ex}",
                            error_code="network"
                        ) from ex

                    if not chunk:
                        self._refund_download_quota(read_size)
                        break
                    if len(chunk) < read_size:
                        self._refund_download_quota(read_size - len(chunk))

                    # A cancel arriving while read() was blocked wins before the
                    # returned bytes can be appended by a stale attempt.
                    if time.monotonic() - last_control_check >= CONTROL_CHECK_INTERVAL:
                        self._check_control(download_id, owner_token, ("downloading",))
                        last_control_check = time.monotonic()

                    self._write_download_chunk(handle, bytes(chunk), False)
                    downloaded += len(chunk)
                    current = time.monotonic()
                    percent = min(100, int(100 * downloaded / expected_total))
                    if percent >= last_saved_percent + 5 or current - last_progress_update >= 10.0:
                        self._owned_update(download_id, owner_token, {
                            "progress": percent,
                            "bytes_done": downloaded,
                            "updated_at": now_iso()
                        }, ("downloading",))
                        last_saved_percent = percent
                        last_progress_update = current
                        self._maybe_refresh_downloads_view()

                if downloaded == expected_total and content_length is None:
                    self._check_control(download_id, owner_token, ("downloading",))
                    try:
                        extra = response.read(1)
                    except (socket.timeout, ssl.SSLError, OSError, TimeoutError) as ex:
                        raise DownloadTransientError(
                            f"Could not confirm download EOF: {ex}",
                            error_code="network"
                        ) from ex
                    if extra:
                        raise DownloadIntegrityError(
                            "Download response exceeded the authoritative ticket size"
                        )

                try:
                    handle.flush()
                    os.fsync(handle.fileno())
                except OSError as ex:
                    raise DownloadStorageError(f"Could not flush partial download: {ex}") from ex
            finally:
                handle.close()

            if downloaded != expected_total:
                raise DownloadTransientError(
                    f"Download ended early: expected {expected_total} bytes, received {downloaded}",
                    error_code="early_eof"
                )
            written_size = self._get_file_size(work_path)
            if written_size != expected_total:
                raise DownloadStorageError(
                    f"Downloaded file size mismatch: expected {expected_total}, wrote {written_size}"
                )
            return downloaded
        finally:
            self._unregister_response(download_id, response)
            try:
                response.close()
            except Exception:
                pass

    def _transfer_with_auth_refresh(self, download_id, record, owner_token, work_path):
        authorization_refreshes = 0
        while True:
            self._check_control(download_id, owner_token, ("downloading",))
            ticket = self._resolve_download_ticket(download_id, record, owner_token)
            try:
                downloaded = self._download_from_ticket(
                    download_id,
                    record,
                    owner_token,
                    ticket,
                    work_path
                )
                return ticket, downloaded
            except urllib.error.HTTPError as ex:
                if ex.code in (401, 403) and authorization_refreshes == 0:
                    authorization_refreshes += 1
                    xbmc.log(
                        f"[DownloadsWorker] Refreshing expired URL for {download_id} after HTTP {ex.code}",
                        xbmc.LOGINFO
                    )
                    try:
                        ex.close()
                    except Exception:
                        pass
                    continue
                failure = self._http_failure(
                    ex,
                    auth_was_refreshed=authorization_refreshes > 0
                )
                try:
                    ex.close()
                except Exception:
                    pass
                raise failure from ex

    def _promote_local_without_overwrite(self, source, destination):
        source_local = self._ensure_local_parent(source)
        destination_local = self._ensure_local_parent(destination)
        if os.path.exists(destination_local):
            raise DownloadStorageError("Destination file already exists; refusing to overwrite it")

        try:
            os.link(source_local, destination_local)
        except FileExistsError as ex:
            raise DownloadStorageError("Destination file already exists; refusing to overwrite it") from ex
        except OSError as link_error:
            # Windows rename is an atomic no-replace operation. On POSIX,
            # hard-link promotion supplies those semantics; if the filesystem
            # cannot hard-link, fail with the verified .part intact rather than
            # expose a crash-truncated final file.
            if os.name != "nt":
                raise DownloadStorageError(
                    f"Filesystem does not support crash-safe finalization: {link_error}"
                ) from link_error
            try:
                os.rename(source_local, destination_local)
                return
            except FileExistsError as ex:
                raise DownloadStorageError(
                    "Destination file already exists; refusing to overwrite it"
                ) from ex
            except OSError as ex:
                raise DownloadStorageError(
                    f"Could not finalize the downloaded file: {ex}"
                ) from ex

        # Linking makes the final name durable without replacing anything.
        # Failure to remove the old link is cleanup-only; both names reference
        # the same verified bytes and recovery can remove the .part safely.
        try:
            os.unlink(source_local)
        except OSError as ex:
            xbmc.log(
                f"[DownloadsWorker] Final file linked but partial cleanup failed: {ex}",
                xbmc.LOGWARNING
            )
        return

    def _copy_stage_to_remote(self, download_id, owner_token, source, destination, expected_total):
        upload_path = self._remote_upload_path(download_id, destination)
        if self._path_exists(destination):
            raise DownloadStorageError("Destination file already exists; refusing to overwrite it")
        if self._path_exists(upload_path) and not self._delete_path(upload_path):
            raise DownloadTransientError(
                "Could not reset an interrupted network finalization file",
                error_code="network"
            )

        source_local = self._ensure_local_parent(source)
        target = None
        copied = 0
        try:
            target = xbmcvfs.File(upload_path, "w")
            with open(source_local, "rb") as source_handle:
                while True:
                    self._check_control(download_id, owner_token, ("finalizing",))
                    chunk = source_handle.read(COPY_CHUNK_SIZE)
                    if not chunk:
                        break
                    if not target.write(bytearray(chunk)):
                        raise DownloadTransientError(
                            "Could not copy staged data to the network destination",
                            error_code="network"
                        )
                    copied += len(chunk)
        except DownloadControl:
            raise
        except DownloadFailure:
            raise
        except Exception as ex:
            raise DownloadTransientError(
                f"Could not copy staged download: {ex}",
                error_code="network"
            ) from ex
        finally:
            if target is not None:
                try:
                    target.close()
                except Exception:
                    pass

        if copied != expected_total or self._get_file_size(upload_path) != expected_total:
            raise DownloadIntegrityError(
                f"Staged copy size mismatch: expected {expected_total}, copied {copied}"
            )
        if self._path_exists(destination):
            raise DownloadStorageError("Destination file appeared during finalization; refusing to overwrite it")
        if not xbmcvfs.rename(upload_path, destination):
            raise DownloadTransientError(
                "Could not finalize the staged network download",
                error_code="network"
            )

    def _finalize_download(
        self,
        download_id,
        record,
        owner_token,
        work_path,
        total,
        attempts,
        expected_hash=None
    ):
        if self._get_file_size(work_path) != total:
            raise DownloadStorageError("Partial file changed before finalization")
        self._check_control(download_id, owner_token, ("downloading",))

        hash_specification = self._parse_hash_spec(expected_hash)
        if hash_specification:
            hash_algorithm, expected_digest = hash_specification
            self._verify_expected_hash(
                work_path,
                expected_hash,
                download_id,
                owner_token,
                ("downloading",)
            )
            finalization_hash = f"{hash_algorithm}:{expected_digest}"
        else:
            finalization_hash = "sha256:" + self._hash_file(
                work_path,
                "sha256",
                download_id,
                owner_token,
                ("downloading",)
            )
        remote_destination = self._destination_requires_staging(record["path"])
        finalization_path = (
            self._remote_upload_path(download_id, record["path"])
            if remote_destination
            else None
        )

        finalizing = self.db.transition(
            download_id,
            "downloading",
            {
                "status": "finalizing",
                "progress": 100,
                "bytes_done": total,
                "bytes_total": total,
                "finalization_hash": finalization_hash,
                "finalization_path": finalization_path,
                "finalization_attempts": 0,
                "updated_at": now_iso()
            },
            expected_owner_token=owner_token
        )
        if not finalizing:
            self._check_control(download_id, owner_token, ("downloading",))
            raise DownloadOwnershipLost("Could not claim finalization")

        destination = record["path"]
        if not remote_destination:
            self._promote_local_without_overwrite(work_path, destination)
        else:
            self._copy_stage_to_remote(
                download_id,
                owner_token,
                work_path,
                destination,
                total
            )

        final_size = self._get_file_size(destination)
        if final_size != total:
            raise DownloadStorageError(
                f"Final file size mismatch: expected {total} bytes, found {final_size}"
            )
        if remote_destination:
            self._verify_expected_hash(
                destination,
                finalization_hash,
                download_id,
                owner_token,
                ("finalizing",)
            )

        completed_at = now_iso()
        self._owned_update(download_id, owner_token, {
            "status": "complete",
            "progress": 100,
            "bytes_done": total,
            "bytes_total": total,
            "attempts": attempts,
            "owner_token": None,
            "owner_worker_id": None,
            "owner_heartbeat_at": None,
            "attempt_id": None,
            "next_attempt_at": None,
            "error": None,
            "error_code": None,
            "completed_at": completed_at,
            "finalization_path": None,
            "finalization_failure_permanent": None,
            "finalization_attempts": None,
            "cleanup_pending": False,
            **self._clear_stream_start_fields(),
            "updated_at": completed_at
        }, ("finalizing",))

        self._delete_path(work_path)
        self._maybe_refresh_downloads_view(force=True)
        filename = record.get("filename") or os.path.basename(destination)
        xbmc.executebuiltin(f"Notification(Download,Completed {filename},3000)")

    def _normalize_exception(self, error):
        if isinstance(error, (DownloadControl, DownloadFailure)):
            return error
        if isinstance(error, urllib.error.HTTPError):
            return self._http_failure(error)

        status_code = getattr(error, "status_code", None)
        if status_code is not None:
            try:
                status_code = int(status_code)
            except (TypeError, ValueError):
                status_code = 0
            if status_code == 404:
                return DownloadPermanentError(str(error), error_code="not_found")
            if status_code in (409, 429) or 500 <= status_code <= 599:
                return DownloadTransientError(
                    str(error),
                    error_code="server_busy",
                    retry_after=self._parse_retry_after(
                        getattr(error, "headers", None)
                    )
                )
            if 400 <= status_code <= 499:
                return DownloadPermanentError(str(error), error_code="api")

        if isinstance(error, (
            urllib.error.URLError,
            socket.timeout,
            ssl.SSLError,
            TimeoutError,
            ConnectionError
        )):
            return DownloadTransientError(str(error), error_code="network")
        if isinstance(error, OSError):
            if getattr(error, "errno", None) in (
                errno.ENOSPC,
                errno.EACCES,
                errno.EROFS,
                errno.EDQUOT,
                errno.EEXIST,
                errno.ENOENT
            ):
                return DownloadStorageError(str(error))
            return DownloadTransientError(str(error), error_code="network")
        return DownloadTransientError(str(error), error_code="unexpected")

    def _retry_delay(self, current_attempt, retry_after=None):
        exponential = min(
            MAX_RETRY_DELAY_SECONDS,
            BASE_RETRY_DELAY_SECONDS * (2 ** max(0, current_attempt - 1))
        )
        base = max(exponential, float(retry_after or 0.0))
        jitter = random.uniform(0.0, min(30.0, max(1.0, base * 0.25)))
        return base + jitter

    def _part_progress(self, work_path, total, fallback=0):
        size = self._get_file_size(work_path)
        progress = min(100, int(100 * size / total)) if total > 0 else int(fallback or 0)
        return size, progress

    def _handle_control_state(self, download_id, record, owner_token, attempts_before, work_path):
        for _ in range(3):
            current = self.db.list().get(download_id, {})
            if current.get("owner_token") != owner_token:
                return True
            status = current.get("status")
            total = self._positive_int(current.get("bytes_total")) or 0

            if status == "canceling":
                partial_removed = self._delete_path(work_path)
                upload_path = (
                    current.get("finalization_path")
                    or self._remote_upload_path(download_id, record.get("path"))
                )
                upload_removed = self._delete_path(upload_path)
                removed = partial_removed and upload_removed
                size, progress = self._part_progress(work_path, total)
                updated = self.db.update_owned(
                    download_id,
                    owner_token,
                    {
                        "status": "canceled",
                        "queue_position": None,
                        "bytes_done": 0 if removed else size,
                        "progress": 0 if removed else progress,
                        "attempts": attempts_before,
                        "owner_token": None,
                        "owner_worker_id": None,
                        "owner_heartbeat_at": None,
                        "attempt_id": None,
                        "next_attempt_at": None,
                        "error": None if removed else "Could not remove all partial download data",
                        "error_code": None if removed else "storage",
                        "cleanup_pending": not removed,
                        "finalization_path": None if upload_removed else upload_path,
                        **self._clear_stream_start_fields(),
                        "updated_at": now_iso()
                    },
                    expected_statuses=("canceling",)
                )
                if updated:
                    xbmc.executebuiltin(
                        f'Notification(Download,Canceled {record.get("filename") or "download"},2500)'
                    )
                    return True
                continue

            if status == "pausing":
                size, progress = self._part_progress(
                    work_path,
                    total,
                    current.get("progress")
                )
                updated = self.db.update_owned(
                    download_id,
                    owner_token,
                    {
                        "status": "paused",
                        "bytes_done": size,
                        "progress": progress,
                        "attempts": attempts_before,
                        "owner_token": None,
                        "owner_worker_id": None,
                        "owner_heartbeat_at": None,
                        "attempt_id": None,
                        "error": None,
                        "error_code": None,
                        **self._clear_stream_start_fields(),
                        "updated_at": now_iso()
                    },
                    expected_statuses=("pausing",)
                )
                if updated:
                    xbmc.executebuiltin(
                        f'Notification(Download,Paused {record.get("filename") or "download"},2000)'
                    )
                    return True
                continue
            return False
        return True

    def _handle_shutdown(self, download_id, record, owner_token, attempts_before, work_path):
        current = self.db.list().get(download_id, {})
        if current.get("owner_token") != owner_token:
            return
        if self._handle_control_state(
            download_id,
            record,
            owner_token,
            attempts_before,
            work_path
        ):
            return

        status = current.get("status")
        total = self._positive_int(current.get("bytes_total")) or 0
        size, progress = self._part_progress(work_path, total, current.get("progress"))
        if status == "finalizing":
            patch = {
                "status": "finalizing",
                "attempts": attempts_before,
                "owner_token": None,
                "owner_worker_id": None,
                "owner_heartbeat_at": None,
                "attempt_id": None,
                "updated_at": now_iso()
            }
        else:
            patch = {
                "status": "queued",
                "bytes_done": size,
                "progress": progress,
                "attempts": attempts_before,
                "owner_token": None,
                "owner_worker_id": None,
                "owner_heartbeat_at": None,
                "attempt_id": None,
                "error": None,
                "error_code": None,
                "next_attempt_at": None,
                "updated_at": now_iso()
            }
        try:
            self._owned_update(download_id, owner_token, patch, (status,))
        except (DownloadOwnershipLost, DownloadPaused, DownloadCanceled):
            self._handle_control_state(
                download_id,
                record,
                owner_token,
                attempts_before,
                work_path
            )

    def _handle_failure(self, download_id, record, owner_token, attempts_before, work_path, error):
        current = self.db.list().get(download_id, {})
        if current.get("owner_token") != owner_token:
            return
        if self._handle_control_state(
            download_id,
            record,
            owner_token,
            attempts_before,
            work_path
        ):
            return
        if self.monitor.abortRequested():
            self._handle_shutdown(
                download_id,
                record,
                owner_token,
                attempts_before,
                work_path
            )
            return

        failure = self._normalize_exception(error)
        if isinstance(failure, DownloadOwnershipLost):
            return
        if isinstance(failure, DownloadShutdown):
            self._handle_shutdown(
                download_id,
                record,
                owner_token,
                attempts_before,
                work_path
            )
            return

        status = current.get("status")
        if status == "finalizing":
            # Once physical promotion starts, retry classification alone is
            # insufficient: a valid final file may already exist. Retain the
            # verified stage and let recovery inspect final/temp/hash evidence.
            finalization_attempt = int(
                current.get("finalization_attempts") or 0
            ) + 1
            max_attempts = getattr(self, "max_attempts", 1)
            transient = isinstance(failure, DownloadTransientError)
            can_retry = transient and finalization_attempt < max_attempts
            delay = (
                self._retry_delay(finalization_attempt, failure.retry_after)
                if can_retry
                else None
            )
            self.db.update_owned(
                download_id,
                owner_token,
                {
                    "status": "finalizing",
                    "owner_token": None,
                    "owner_worker_id": None,
                    "owner_heartbeat_at": None,
                    "attempt_id": None,
                    "error": str(failure),
                    "error_code": failure.error_code,
                    "cleanup_pending": True,
                    "finalization_attempts": finalization_attempt,
                    "finalization_failure_permanent": not can_retry,
                    "next_attempt_at": self._iso_after(delay) if delay is not None else None,
                    "retry_delay_seconds": delay,
                    "updated_at": now_iso()
                },
                expected_statuses=("finalizing",)
            )
            self._maybe_refresh_downloads_view(force=True)
            return

        if getattr(failure, "reset_partial", False):
            self._delete_path(work_path)
        total = self._positive_int(current.get("bytes_total")) or 0
        size, progress = self._part_progress(work_path, total, current.get("progress"))
        current_attempt = int(current.get("attempts") or attempts_before + 1)
        max_attempts = getattr(self, "max_attempts", 1)
        transient = isinstance(failure, DownloadTransientError)
        can_retry = transient and current_attempt < max_attempts
        if can_retry:
            delay = self._retry_delay(current_attempt, failure.retry_after)
            patch = {
                "status": "waiting_retry",
                "next_attempt_at": self._iso_after(delay),
                "retry_delay_seconds": delay,
                "error": str(failure),
                "error_code": failure.error_code,
                "bytes_done": size,
                "progress": progress,
                "owner_token": None,
                "owner_worker_id": None,
                "owner_heartbeat_at": None,
                "attempt_id": None,
                **self._clear_stream_start_fields(),
                "updated_at": now_iso()
            }
        else:
            patch = {
                "status": "failed",
                "queue_position": None,
                "next_attempt_at": None,
                "error": str(failure),
                "error_code": failure.error_code,
                "bytes_done": size,
                "progress": progress,
                "owner_token": None,
                "owner_worker_id": None,
                "owner_heartbeat_at": None,
                "attempt_id": None,
                **self._clear_stream_start_fields(),
                "updated_at": now_iso()
            }

        try:
            self._owned_update(download_id, owner_token, patch, (status,))
        except (DownloadOwnershipLost, DownloadPaused, DownloadCanceled):
            self._handle_control_state(
                download_id,
                record,
                owner_token,
                attempts_before,
                work_path
            )
            return
        self._maybe_refresh_downloads_view(force=True)
        if not can_retry:
            xbmc.executebuiltin(
                f'Notification(Download,Failed {record.get("filename") or "download"},4000)'
            )

    def _process_job(self, job: dict):
        claimed, owner_token, attempts_before = self._claim_job(job)
        if not claimed:
            return

        download_id = claimed["id"]
        destination = claimed.get("path")
        if not destination:
            self._handle_failure(
                download_id,
                claimed,
                owner_token,
                attempts_before,
                "",
                DownloadPermanentError("Download destination is missing", error_code="destination")
            )
            return

        work_path = self._work_path(download_id, destination, claimed)
        if work_path != f"{destination}.part" and claimed.get("staging_path") != work_path:
            try:
                self._owned_update(download_id, owner_token, {
                    "staging_path": work_path,
                    "updated_at": now_iso()
                }, ("downloading",))
                claimed["staging_path"] = work_path
            except (DownloadOwnershipLost, DownloadPaused, DownloadCanceled):
                self._handle_control_state(
                    download_id,
                    claimed,
                    owner_token,
                    attempts_before,
                    work_path
                )
                return

        try:
            ticket, downloaded = self._transfer_with_auth_refresh(
                download_id,
                claimed,
                owner_token,
                work_path
            )
            self._finalize_download(
                download_id,
                claimed,
                owner_token,
                work_path,
                ticket["size_bytes"],
                attempts_before + 1,
                ticket.get("hash")
            )
        except DownloadOwnershipLost:
            self._handle_control_state(
                download_id,
                claimed,
                owner_token,
                attempts_before,
                work_path
            )
            return
        except (DownloadPaused, DownloadCanceled):
            self._handle_control_state(
                download_id,
                claimed,
                owner_token,
                attempts_before,
                work_path
            )
            self._maybe_refresh_downloads_view(force=True)
        except DownloadShutdown:
            self._handle_shutdown(
                download_id,
                claimed,
                owner_token,
                attempts_before,
                work_path
            )
        except Exception as ex:
            self._handle_failure(
                download_id,
                claimed,
                owner_token,
                attempts_before,
                work_path,
                ex
            )
