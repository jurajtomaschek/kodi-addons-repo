import ssl
import json
import xbmc
import xbmcaddon
import urllib.parse

from urllib.request import urlopen, Request
from urllib.error import HTTPError

addon = xbmcaddon.Addon()
api_key = addon.getSetting('api_key')

#BASE_API_URL = "https://localhost:7009"  # Make sure it's https if your server uses it

BASE_API_URL = "https://media-vault-app-service-b8cmhsbsaefadbex.northeurope-01.azurewebsites.net"

# Create unverified SSL context
ssl_context = ssl._create_unverified_context()

def _get_json(endpoint):
    full_url = f"{BASE_API_URL}{endpoint}"
    req = Request(full_url)
    req.add_header("Accept", "application/json")
    req.add_header("x-api-key", api_key)
    
    # ✅ LOG the full request URL
    xbmc.log(f"Calling: {full_url}", xbmc.LOGINFO)

    try:
        with urlopen(req, context=ssl_context, timeout=60) as response:
            return json.loads(response.read().decode())
    except HTTPError as e:
        xbmc.log(f"[HTTPError] {e.code} - {e.reason}", xbmc.LOGERROR)
        xbmc.log(e.read().decode(), xbmc.LOGERROR)
        raise
    except Exception as ex:
        xbmc.log(f"[Exception] {str(ex)}", xbmc.LOGERROR)
        raise

def get_tv_latest(page=1):
    return _get_json(f"/media/tmdb/tvseries/latest?page={page}")

def get_tv_popular(page=1):
    return _get_json(f"/media/tmdb/tvseries/popular?page={page}")

def get_tv_sk(page=1):
    return _get_json(f"/media/tmdb/tvseries/sk?page={page}")

def get_tv_details(tv_id):
    return _get_json(f"/media/tmdb/tvseries/{tv_id}")

def get_episodes(tv_id, season):
    return _get_json(f"/media/tmdb/tvseries/{tv_id}/season/{season}/episodes")

def get_movies_search(query, page=1):
    params = urllib.parse.urlencode({"query": query, "page": page})
    return _get_json(f"/media/tmdb/movies/search?{params}")

def get_tv_search(query, page=1):
    params = urllib.parse.urlencode({"query": query, "page": page})
    return _get_json(f"/media/tmdb/tvseries/search?{params}")

def get_movies_latest(page=1):
    return _get_json(f"/media/tmdb/movies/latest?page={page}")

def get_movies_popular(page=1, year=None):
    url = f"/media/tmdb/movies/popular?page={page}"
    if year is not None:
        url += f"&firstAirDateYear={year}"
    return _get_json(url)

def get_movies_toprated(page=1, year=None):
    url = f"/media/tmdb/movies/toprated?page={page}"
    if year is not None:
        url += f"&firstAirDateYear={year}"
    return _get_json(url)

def get_movie_versions(movie_id):
    return _get_json(f"/media/tmdb/movies/{movie_id}")

def get_streams(stream_id):
    return _get_json(f"/media/stream/{stream_id}")
