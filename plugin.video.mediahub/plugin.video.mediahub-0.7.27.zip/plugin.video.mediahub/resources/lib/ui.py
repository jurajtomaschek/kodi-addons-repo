import sys
import xbmc
import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmcvfs
import os
import urllib.parse
from urllib.error import URLError
from . import api
import uuid
from .downloads_db import DownloadsDb, now_iso


db = DownloadsDb()

QUEUE_STATUSES = ("queued", "paused")

VIDEO_FILE_EXTENSIONS = {
    ".3gp",
    ".avi",
    ".divx",
    ".flv",
    ".iso",
    ".m2ts",
    ".m4v",
    ".mkv",
    ".mov",
    ".mp4",
    ".mpeg",
    ".mpg",
    ".mts",
    ".ogm",
    ".ts",
    ".vob",
    ".webm",
    ".wmv"
}

def _is_vfs_path(path):
    return "://" in path

def _join_path(base, filename):
    if _is_vfs_path(base):
        return base.rstrip("/\\") + "/" + filename
    return os.path.join(base, filename)

def _video_extension(value):
    if not value:
        return ""

    path = urllib.parse.urlparse(value).path if "://" in value else value
    name = os.path.basename(urllib.parse.unquote(path)).strip()
    ext = os.path.splitext(name)[1].lower()
    return ext if ext in VIDEO_FILE_EXTENSIONS else ""

def _strip_video_extensions(value):
    base = (value or "").strip()
    while True:
        ext = _video_extension(base)
        if not ext:
            return base
        base = os.path.splitext(base)[0].rstrip(" .")

def _safe_download_filename(filename, source_url=""):
    ext = _video_extension(filename) or _video_extension(source_url)
    base = _strip_video_extensions(filename)
    invalid_chars = set('<>:"/\\|?*')
    safe_base = "".join(
        " " if c in invalid_chars or ord(c) < 32 else c
        for c in base
    ).strip(" .")
    if not safe_base:
        safe_base = "download"

    if ext:
        while safe_base.lower().endswith(ext):
            safe_base = safe_base[:-len(ext)].rstrip(" .")
        if not safe_base:
            safe_base = "download"

    return f"{safe_base}{ext}"

def _stream_display_name(stream):
    return stream.get("originalName") or stream.get("name") or "Stream"

def build_url(query):
    return f"{sys.argv[0]}?{urllib.parse.urlencode(query)}"

def get_icons_path(image_name):
    addon = xbmcaddon.Addon()
    addon_path = addon.getAddonInfo('path')
    return os.path.join(addon_path, 'resources', 'icons', image_name)

def _as_int(value, default=0):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default

def _queue_position(record):
    value = _as_int(record.get("queue_position"), 0)
    return value if value > 0 else 999999

def _normalize_queue_positions(data):
    queued = []
    for download_id, record in data.items():
        if record.get("status") not in QUEUE_STATUSES:
            continue
        if not record.get("id"):
            record["id"] = download_id
        queued.append((download_id, record))

    queued.sort(key=lambda item: (
        _queue_position(item[1]),
        item[1].get("created_at") or "",
        item[0]
    ))

    for index, (_, record) in enumerate(queued, start=1):
        record["queue_position"] = index

def _list_downloads_normalized():
    def op(data):
        _normalize_queue_positions(data)
        return {download_id: dict(record) for download_id, record in data.items()}
    return db.mutate(op)

def _next_queue_position(data):
    positions = [
        _as_int(record.get("queue_position"), 0)
        for record in data.values()
        if record.get("status") in QUEUE_STATUSES
    ]
    return max(positions or [0]) + 1

def _queue_count(data):
    return sum(1 for record in data.values() if record.get("status") in QUEUE_STATUSES)

def _download_action_queries(record, queue_count=0):
    download_id = record.get("id")
    status = record.get("status")
    position = _as_int(record.get("queue_position"), 0)
    actions = []

    if status in QUEUE_STATUSES:
        if position > 1:
            actions.append(("Move up", {'action': 'move_download', 'id': download_id, 'direction': 'up'}))
            actions.append(("Move to top", {'action': 'move_download', 'id': download_id, 'direction': 'top'}))
        if position and position < queue_count:
            actions.append(("Move down", {'action': 'move_download', 'id': download_id, 'direction': 'down'}))
            actions.append(("Move to bottom", {'action': 'move_download', 'id': download_id, 'direction': 'bottom'}))

    if status in ("queued", "downloading"):
        actions.append(("Pause", {'action': 'pause_download', 'id': download_id}))
    elif status == "paused":
        actions.append(("Resume", {'action': 'resume_download', 'id': download_id}))

    if status in ("queued", "downloading", "paused", "failed"):
        actions.append(("Cancel", {'action': 'cancel_download', 'id': download_id}))

    if status in ("failed", "canceled"):
        actions.append(("Retry", {'action': 'retry_download', 'id': download_id}))

    return actions

def _format_bytes(value):
    size = _as_int(value, 0)
    if size <= 0:
        return "unknown"

    units = ("B", "KB", "MB", "GB", "TB")
    index = 0
    amount = float(size)
    while amount >= 1024 and index < len(units) - 1:
        amount /= 1024
        index += 1

    if index == 0:
        return f"{int(amount)} {units[index]}"
    return f"{amount:.1f} {units[index]}"

def show_main_menu(handle):

    xbmcplugin.setPluginCategory(handle, "Hlavné Menu")
    # xbmcplugin.setContent(handle, "movies")

    # Movies
    menuItemMovies = xbmcgui.ListItem(label="Filmy")
    menuItemMovies.setInfo('video', { 'plot': u"\u00A0" })
    menuItemMovies.setArt({
        'icon': get_icons_path('movies.png'),
        'thumb': get_icons_path('movies.png')
    })
    urlMovies = build_url({'action': 'menu_item_movies'})
    xbmcplugin.addDirectoryItem(handle, urlMovies, menuItemMovies, isFolder=True)

    # TV Shows
    menuItemTvShows = xbmcgui.ListItem(label="Seriály")
    menuItemTvShows.setInfo('video', { 'plot': u"\u00A0" })
    menuItemTvShows.setArt({
        'icon': get_icons_path('tvshows.png'),
        'thumb': get_icons_path('tvshows.png')
    })
    urlTvShows = build_url({'action': 'menu_item_tvshows'})
    xbmcplugin.addDirectoryItem(handle, urlTvShows, menuItemTvShows, isFolder=True)

    # Downloads
    menuItemDownloads = xbmcgui.ListItem(label="Downloads")
    menuItemDownloads.setInfo('video', { 'plot': u"\u00A0" })
    menuItemDownloads.setArt({
        'icon': get_icons_path('downloads.png'),
        'thumb': get_icons_path('downloads.png')
    })
    urlDownloads = build_url({'action': 'show_downloads_menu'})
    xbmcplugin.addDirectoryItem(handle, urlDownloads, menuItemDownloads, isFolder=True)

    # # Watch History
    # menuItemWatchHistory = xbmcgui.ListItem(label="História Pozerania")
    # menuItemWatchHistory.setInfo('video', { 'plot': u"\u00A0" })
    # urlWatchHistory = build_url({'action': 'menu_item_watch_history'})
    # xbmcplugin.addDirectoryItem(handle, urlWatchHistory, menuItemWatchHistory, isFolder=True)

    xbmcplugin.endOfDirectory(handle)

def menu_item_movies(handle):

    xbmcplugin.setPluginCategory(handle, "Filmy")
    #xbmcplugin.setContent(handle, "movies")

    # Latest Movies
    menuItemMoviesLatest = xbmcgui.ListItem(label="Nové ")
    menuItemMoviesLatest.setInfo('video', { 'plot': u"\u00A0" })
    menuItemMoviesLatest.setArt({
        'icon': get_icons_path('new.png'),
        'thumb': get_icons_path('new.png')
    })
    urlMoviesLatest = build_url({'action': 'menu_item_movies_latest'})
    xbmcplugin.addDirectoryItem(handle, urlMoviesLatest, menuItemMoviesLatest, isFolder=True)

    # Popular Movies
    menuItemMoviesPopular = xbmcgui.ListItem(label="Populárne")
    menuItemMoviesPopular.setInfo('video', { 'plot': u"\u00A0" })
    menuItemMoviesPopular.setArt({
        'icon': get_icons_path('popular1.png'),
        'thumb': get_icons_path('popular1.png')
    })
    urlMoviesPopular = build_url({'action': 'menu_item_movies_popular'})
    xbmcplugin.addDirectoryItem(handle, urlMoviesPopular, menuItemMoviesPopular, isFolder=True)

    # Top Rated Movies
    menuItemMoviesTopRated = xbmcgui.ListItem(label="Najlepšie Hodnotené")
    menuItemMoviesTopRated.setInfo('video', { 'plot': u"\u00A0" })
    menuItemMoviesTopRated.setArt({
        'icon': get_icons_path('top-rated.png'),
        'thumb': get_icons_path('top-rated.png')
    })
    urlMoviesTopRated = build_url({'action': 'menu_item_movies_toprated'})
    xbmcplugin.addDirectoryItem(handle, urlMoviesTopRated, menuItemMoviesTopRated, isFolder=True)

    # # Genres
    # menuItemMoviesGenres = xbmcgui.ListItem(label="Podľa Žánrov")
    # menuItemMoviesGenres.setInfo('video', { 'plot': u"\u00A0" })
    # urlMoviesGenres = build_url({'action': 'menu_item_movies_genres'})
    # xbmcplugin.addDirectoryItem(handle, urlMoviesGenres, menuItemMoviesGenres, isFolder=True)

    # Search
    menuItemMoviesSearch = xbmcgui.ListItem(label="Hľadať")
    menuItemMoviesSearch.setProperty('IsPlayable', 'false')
    menuItemMoviesSearch.setInfo('video', { 'plot': u"\u00A0" })
    menuItemMoviesSearch.setArt({
        'icon': get_icons_path('search.png'),
        'thumb': get_icons_path('search.png')
    })
    urlMoviesSearch = build_url({'action': 'menu_item_movies_search'})
    xbmcplugin.addDirectoryItem(handle, urlMoviesSearch, menuItemMoviesSearch, isFolder=True)

    xbmcplugin.endOfDirectory(handle)

def menu_item_tvshows(handle):

    xbmcplugin.setPluginCategory(handle, "Seriály")

    # Latest Tv Shows
    menuItemTvShowsLatest = xbmcgui.ListItem(label="Nové ")
    menuItemTvShowsLatest.setInfo('video', { 'plot': u"\u00A0" })
    menuItemTvShowsLatest.setArt({
        'icon': get_icons_path('new.png'),
        'thumb': get_icons_path('new.png')
    })
    urlTvShowsLatest = build_url({'action': 'list_tv_shows_latest'})
    xbmcplugin.addDirectoryItem(handle, urlTvShowsLatest, menuItemTvShowsLatest, isFolder=True)

    # Popular Tv Shows
    menuItemTvShowsPopular = xbmcgui.ListItem(label="Populárne")
    menuItemTvShowsPopular.setInfo('video', { 'plot': u"\u00A0" })
    menuItemTvShowsPopular.setArt({
        'icon': get_icons_path('popular1.png'),
        'thumb': get_icons_path('popular1.png')
    })
    urlTvShowsPopular = build_url({'action': 'list_tv_shows_popular'})
    xbmcplugin.addDirectoryItem(handle, urlTvShowsPopular, menuItemTvShowsPopular, isFolder=True)

    # Top Rated Tv Shows
    menuItemTvShowsSlovak = xbmcgui.ListItem(label="Slovenské")
    menuItemTvShowsSlovak.setInfo('video', { 'plot': u"\u00A0" })
    menuItemTvShowsSlovak.setArt({
        'icon': get_icons_path('slovak.png'),
        'thumb': get_icons_path('slovak.png')
    })
    urlTvShowsSlovak = build_url({'action': 'list_tv_shows_sk'})
    xbmcplugin.addDirectoryItem(handle, urlTvShowsSlovak, menuItemTvShowsSlovak, isFolder=True)

    # # Genres
    # menuItemMoviesGenres = xbmcgui.ListItem(label="Podľa Žánrov")
    # menuItemMoviesGenres.setInfo('video', { 'plot': u"\u00A0" })
    # urlMoviesGenres = build_url({'action': 'menu_item_movies_genres'})
    # xbmcplugin.addDirectoryItem(handle, urlMoviesGenres, menuItemMoviesGenres, isFolder=True)

    # Search
    menuItemTvSearch = xbmcgui.ListItem(label="Hľadať")
    menuItemTvSearch.setProperty('IsPlayable', 'false')
    menuItemTvSearch.setInfo('video', { 'plot': u"\u00A0" })
    menuItemTvSearch.setArt({
        'icon': get_icons_path('search.png'),
        'thumb': get_icons_path('search.png')
    })
    urlTvSearch = build_url({'action': 'menu_item_tvshows_search'})
    xbmcplugin.addDirectoryItem(handle, urlTvSearch, menuItemTvSearch, isFolder=True)

    xbmcplugin.endOfDirectory(handle)

def menu_item_movies_latest(handle):
    page = int(dict(urllib.parse.parse_qsl(sys.argv[2][1:])).get('page', 1))
    response = api.get_movies_latest(page)
    movies = response.get('results', [])
    total_pages = response.get('total_pages', 1)

    for movie in movies:
        label = (
            f"{movie['title_with_original_title']} [COLOR FFAAAAAA][{movie['release_date'][:4]}][/COLOR] "
            f"{_format_vote_hearts(movie.get('vote_count'))}"
        )
        item = xbmcgui.ListItem(label=label)
        item.setArt({
            'poster': movie.get('poster_path', ''),
            'fanart': movie.get('backdrop_path', '')
        })
        item.setInfo('video', {
            'title': movie['title'],
            'plot': movie.get('overview', '')
        })
        url = build_url({'action': 'list_movie_versions', 'movie_id': movie['id']})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    if page < total_pages:
        nextPage = page + 1
        item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
        url = build_url({'action': 'menu_item_movies_latest', 'page': nextPage})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    xbmcplugin.endOfDirectory(handle, updateListing=False)

def menu_item_movies_popular(handle):
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    filter_type = params.get('filter_type')
    year = params.get('year')
    page = int(params.get('page', 1))
    
    # If no filter type, show submenu
    if not filter_type:
        xbmcplugin.setPluginCategory(handle, "Populárne")
        xbmcplugin.setContent(handle, "movies")
        
        # All Times
        item = xbmcgui.ListItem(label="Všetky roky")
        item.setInfo('movies', { 'plot': u"\u00A0" })
        url = build_url({'action': 'menu_item_movies_popular', 'filter_type': 'all_time'})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
        
        # By Year
        item = xbmcgui.ListItem(label="Podľa Roku")
        item.setInfo('video', { 'plot': u"\u00A0" })
        url = build_url({'action': 'menu_item_movies_popular', 'filter_type': 'by_year'})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
        
        xbmcplugin.endOfDirectory(handle)
        return
    
    # If filter_type is 'by_year' but no year selected, show year selector
    if filter_type == 'by_year' and not year:
        xbmcplugin.setPluginCategory(handle, "Populárne - Podľa Roku")
        xbmcplugin.setContent(handle, "movies")
        
        import datetime
        current_year = datetime.datetime.now().year
        
        # Show years from current year back to 1940
        for yr in range(current_year, 1940, -1):
            item = xbmcgui.ListItem(label=str(yr))
            item.setInfo('movies', { 'plot': u"\u00A0" })
            url = build_url({'action': 'menu_item_movies_popular', 'filter_type': 'by_year', 'year': yr})
            xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
        
        xbmcplugin.endOfDirectory(handle)
        return
    
    # Show movies based on filter
    if filter_type == 'all_time':
        response = api.get_movies_popular(page)
    elif filter_type == 'by_year' and year:
        response = api.get_movies_popular(page, year)
    else:
        response = api.get_movies_popular(page)
    
    movies = response.get('results', [])
    total_pages = response.get('total_pages', 1)

    for movie in movies:
        label = f"{movie['title_with_original_title']} [COLOR FFAAAAAA][{movie['release_date'][:4]}][/COLOR]"
        item = xbmcgui.ListItem(label=label)
        item.setArt({
            'poster': movie.get('poster_path', ''),
            'fanart': movie.get('backdrop_path', '')
        })
        item.setInfo('video', {
            'title': movie['title'],
            'plot': movie.get('overview', '')
        })
        url = build_url({'action': 'list_movie_versions', 'movie_id': movie['id']})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    if page < total_pages:
        nextPage = page + 1
        extra_params = {'filter_type': filter_type}
        if year:
            extra_params['year'] = year
        item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
        url = build_url({'action': 'menu_item_movies_popular', 'page': nextPage, **extra_params})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    xbmcplugin.endOfDirectory(handle, updateListing=False)

def menu_item_movies_toprated(handle):
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    filter_type = params.get('filter_type')
    year = params.get('year')
    page = int(params.get('page', 1))
    
    # If no filter type, show submenu
    if not filter_type:
        xbmcplugin.setPluginCategory(handle, "Najlepšie Hodnotené")
        xbmcplugin.setContent(handle, "movies")
        
        # All Times
        item = xbmcgui.ListItem(label="Všetky roky")
        item.setInfo('movies', { 'plot': u"\u00A0" })
        url = build_url({'action': 'menu_item_movies_toprated', 'filter_type': 'all_time'})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
        
        # By Year
        item = xbmcgui.ListItem(label="Podľa Roku")
        item.setInfo('video', { 'plot': u"\u00A0" })
        url = build_url({'action': 'menu_item_movies_toprated', 'filter_type': 'by_year'})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
        
        xbmcplugin.endOfDirectory(handle)
        return
    
    # If filter_type is 'by_year' but no year selected, show year selector
    if filter_type == 'by_year' and not year:
        xbmcplugin.setPluginCategory(handle, "Najlepšie Hodnotené - Podľa Roku")
        xbmcplugin.setContent(handle, "movies")
        
        import datetime
        current_year = datetime.datetime.now().year
        
        # Show years from current year back to 1990
        for yr in range(current_year, 1940, -1):
            item = xbmcgui.ListItem(label=str(yr))
            item.setInfo('movies', { 'plot': u"\u00A0" })
            url = build_url({'action': 'menu_item_movies_toprated', 'filter_type': 'by_year', 'year': yr})
            xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
        
        xbmcplugin.endOfDirectory(handle)
        return
    
    # Show movies based on filter
    if filter_type == 'all_time':
        response = api.get_movies_toprated(page)
    elif filter_type == 'by_year' and year:
        response = api.get_movies_toprated(page, year)
    else:
        response = api.get_movies_toprated(page)
    
    movies = response.get('results', [])
    total_pages = response.get('total_pages', 1)

    for movie in movies:
        label = f"{movie['title_with_original_title']} [COLOR FFAAAAAA][{movie['release_date'][:4]}][/COLOR]"
        item = xbmcgui.ListItem(label=label)
        item.setArt({
            'poster': movie.get('poster_path', ''),
            'fanart': movie.get('backdrop_path', '')
        })
        item.setInfo('video', {
            'title': movie['title'],
            'plot': movie.get('overview', '')
        })
        url = build_url({'action': 'list_movie_versions', 'movie_id': movie['id']})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    if page < total_pages:
        nextPage = page + 1
        extra_params = {'filter_type': filter_type}
        if year:
            extra_params['year'] = year
        item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
        url = build_url({'action': 'menu_item_movies_toprated', 'page': nextPage, **extra_params})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    xbmcplugin.endOfDirectory(handle, updateListing=False)

def menu_item_movies_search(handle):
    # Get parameters from URL
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    search_query = params.get('search_query')
    page = int(params.get('page', 1))
    
    # Only show keyboard if no search_query (initial search)
    if not search_query:
        keyboard = xbmc.Keyboard('', 'Hľadať Filmy')
        keyboard.doModal()
        if keyboard.isConfirmed():
            search_query = keyboard.getText()
        else:
            return  # User cancelled
    
    if search_query:
        response = api.get_movies_search(search_query, page)
        movies = response.get('results', [])
        total_pages = response.get('total_pages', 1)

        for movie in movies:
            year = movie.get("release_date", "")[:4] if movie.get("release_date") else "----"
            label = (
                f"{movie['title_with_original_title']} [COLOR FFAAAAAA][{year}][/COLOR] "
                f" {_format_vote_hearts(movie.get('vote_count'))}"
            )
            item = xbmcgui.ListItem(label=label)
            item.setArt({
                'poster': movie.get('poster_path', ''),
                'fanart': movie.get('backdrop_path', '')
            })
            item.setInfo('video', {
                'title': movie['title'],
                'plot': movie.get('overview', '')
            })
            url = build_url({'action': 'list_movie_versions', 'movie_id': movie['id']})
            xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

        if page < total_pages:
            nextPage = page + 1
            item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
            url = build_url({'action': 'menu_item_movies_search', 'page': nextPage, 'search_query': search_query})
            xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

        xbmcplugin.endOfDirectory(handle, updateListing=False)




    # itemTvSeriesLatest = xbmcgui.ListItem(label="Seriály - Nové")
    # url = build_url({'action': 'list_tv_shows_latest'})
    # xbmcplugin.addDirectoryItem(handle, url, itemTvSeriesLatest, isFolder=True)

    # itemTvSeriesPopular = xbmcgui.ListItem(label="Seriály - Populárne")
    # url = build_url({'action': 'list_tv_shows_popular'})
    # xbmcplugin.addDirectoryItem(handle, url, itemTvSeriesPopular, isFolder=True)

    # itemTvSeriesSk = xbmcgui.ListItem(label="Seriály - SK")
    # url = build_url({'action': 'list_tv_shows_sk'})
    # xbmcplugin.addDirectoryItem(handle, url, itemTvSeriesSk, isFolder=True)

def _get_tv_year(show):
    year = show.get("first_air_date_year")
    if year:
        return str(year)

    first_air_date = show.get("first_air_date") or ""
    return first_air_date[:4] if first_air_date else "----"

def _extract_year(item):
    for key in ("year", "first_air_date_year"):
        value = item.get(key)
        if value not in (None, ""):
            return str(value)

    for key in ("air_date", "first_air_date", "release_date"):
        value = item.get(key) or ""
        if len(value) >= 4:
            return value[:4]

    return "----"

def _get_episode_title(ep):
    return ep.get("title") or ep.get("name") or f"Episode {ep.get('episode_number', '?')}"

def _format_vote_hearts(vote_count):
    if vote_count is None:
        vote_count = 0

    if vote_count < 200:
        filled_hearts = 0
    elif vote_count < 500:
        filled_hearts = 1
    elif vote_count <= 1000:
        filled_hearts = 2
    else:
        filled_hearts = 3

    hearts = []
    for index in range(3):
        if index < filled_hearts:
            # use a softer golden tone instead of bright yellow
            hearts.append("[COLOR FFB8860B]★[/COLOR]")
        else:
            # slightly darker grey for empty stars
            hearts.append("[COLOR FF909090]☆[/COLOR]")
    return "".join(hearts)

def _build_tv_show_item(show, include_vote_count=False, include_hearts=True):
    year = _get_tv_year(show)
    display_title = show.get("name_with_original_name") or show.get("name") or ""
    vote_count = show.get("vote_count")
    hearts = _format_vote_hearts(vote_count) if include_hearts else ""

    item = xbmcgui.ListItem(
        label=f"{display_title} [COLOR FFAAAAAA][{year}][/COLOR] {hearts}".strip()
    )
    item.setArt({
        'poster': show.get('poster_path', ''),
        'fanart': show.get('backdrop_path', '')
    })
    item.setInfo('video', {
        'title': show.get('name') or display_title,
        'plot': show.get('overview', '')
    })
    return item

def menu_item_tvshows_search(handle):
    # Get parameters from URL
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    search_query = params.get('search_query')
    page = int(params.get('page', 1))
    
    # Only show keyboard if no search_query (initial search)
    if not search_query:
        keyboard = xbmc.Keyboard('', 'Hľadať Seriály')
        keyboard.doModal()
        if keyboard.isConfirmed():
            search_query = keyboard.getText()
        else:
            return  # User cancelled
    
    if search_query:
        response = api.get_tv_search(search_query, page)
        shows = response.get('results', [])
        total_pages = response.get('total_pages', 1)

        for show in shows:
            item = _build_tv_show_item(show, include_vote_count=True)
            url = build_url({'action': 'list_seasons', 'tv_id': show['id']})
            xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

        if page < total_pages:
            nextPage = page + 1
            item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
            url = build_url({'action': 'menu_item_tvshows_search', 'page': nextPage, 'search_query': search_query})
            xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

        xbmcplugin.endOfDirectory(handle, updateListing=False)

def list_tv_shows_latest(handle):
    page = int(dict(urllib.parse.parse_qsl(sys.argv[2][1:])).get('page', 1))
    response = api.get_tv_latest(page)
    shows = response.get('results', [])
    total_pages = response.get('total_pages', 1)

    for show in shows:
        item = _build_tv_show_item(show, include_vote_count=True)
        url = build_url({'action': 'list_seasons', 'tv_id': show['id']})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    # Add "Next Page" if more pages are available
    if page < total_pages:
        nextPage = page + 1
        item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
        url = build_url({'action': 'list_tv_shows_latest', 'page': page + 1})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    # Tell Kodi this is a new folder level (updateListing=False)
    xbmcplugin.endOfDirectory(handle, updateListing=False)

def list_tv_shows_popular(handle):
    page = int(dict(urllib.parse.parse_qsl(sys.argv[2][1:])).get('page', 1))
    response = api.get_tv_popular(page)
    shows = response.get('results', [])
    total_pages = response.get('total_pages', 1)

    for show in shows:
        item = _build_tv_show_item(show, include_hearts=False)
        url = build_url({'action': 'list_seasons', 'tv_id': show['id']})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    # Add "Next Page" if more pages are available
    if page < total_pages:
        nextPage = page + 1
        item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
        url = build_url({'action': 'list_tv_shows_popular', 'page': page + 1})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    # Tell Kodi this is a new folder level (updateListing=False)
    xbmcplugin.endOfDirectory(handle, updateListing=False)

def list_tv_shows_sk(handle):
    page = int(dict(urllib.parse.parse_qsl(sys.argv[2][1:])).get('page', 1))
    response = api.get_tv_sk(page)
    shows = response.get('results', [])
    total_pages = response.get('total_pages', 1)

    for show in shows:
        item = _build_tv_show_item(show, include_hearts=False)
        url = build_url({'action': 'list_seasons', 'tv_id': show['id']})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    # Add "Next Page" if more pages are available
    if page < total_pages:
        nextPage = page + 1
        item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
        url = build_url({'action': 'list_tv_shows_sk', 'page': page + 1})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    # Tell Kodi this is a new folder level (updateListing=False)
    xbmcplugin.endOfDirectory(handle, updateListing=False)

def list_seasons(handle, tv_id):
    try:
        details = api.get_tv_details(tv_id)
    except Exception as ex:
        xbmc.log(f"[list_seasons] Failed to load TV details for tv_id={tv_id}: {ex}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("TV Show", "Could not load seasons.")
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    for season in details.get('seasons', []):
        season_number = season.get('season_number')
        if season_number is None:
            xbmc.log(
                f"[list_seasons] Skipping season without season_number for tv_id={tv_id}: keys={sorted(season.keys())}",
                xbmc.LOGWARNING
            )
            continue

        seasonName = season.get('name') or f"Séria {season_number}"
        label = f"{seasonName} [{_extract_year(season)}]"
        item = xbmcgui.ListItem(label=label)
        item.setInfo('video', {
            'title': seasonName,
            'plot': season.get('overview', ''),
            'tagline': season.get('tagline', '')
        })
        item.setArt({
            'thumb': season.get('poster_path', ''),
            'poster': season.get('poster_path', ''),
            'fanart': season.get('poster_path', '')
        })
        url = build_url({'action': 'list_episodes', 'tv_id': tv_id, 'season': season_number})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
    xbmcplugin.endOfDirectory(handle)

def list_episodes(handle, tv_id, season):
    try:
        episodes = api.get_episodes(tv_id, season)
    except Exception as ex:
        xbmc.log(f"[list_episodes] Failed to load episodes for tv_id={tv_id} season={season}: {ex}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("TV Show", "Could not load episodes.")
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    for ep in episodes:
        episode_id = ep.get('id')
        if episode_id is None:
            xbmc.log(
                f"[list_episodes] Skipping episode without id for tv_id={tv_id} season={season}: keys={sorted(ep.keys())}",
                xbmc.LOGWARNING
            )
            continue

        title = _get_episode_title(ep)
        label = title
        if not ep.get('hasStreams'):
            label = f"[COLOR 80FF0000][B][X][/B][/COLOR] [COLOR FFAAAAAA]{label}[/COLOR]"
        item = xbmcgui.ListItem(label=label)
        item.setInfo('video', {'title': title, 'plot': ep.get('description') or ep.get('overview', '')})
        item.setArt({
            'thumb': ep.get('imageUrl', ''),
            'poster': ep.get('imageUrl', ''),
            'fanart': ep.get('imageUrl', '')
        })
        url = build_url({'action': 'show_streams', 'tv_id': tv_id, 'season': season, 'episode_id': episode_id})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
    xbmcplugin.endOfDirectory(handle)

def show_streams_popup(handle, tv_id, season, episode_id):
    episodes = api.get_episodes(tv_id, season)
    episode = next((ep for ep in episodes if ep['id'] == int(episode_id)), None)
    if not episode:
        xbmcgui.Dialog().notification("Streams", "Episode not found.", xbmcgui.NOTIFICATION_ERROR, 2500)
        xbmcplugin.endOfDirectory(handle)
        return

    streams = episode.get('streams', [])
    if not streams:
        xbmcgui.Dialog().notification("Streams", "No streams available for this episode.", xbmcgui.NOTIFICATION_INFO, 2500)
        xbmcplugin.endOfDirectory(handle)
        return

    for stream in streams:
        display_name = _stream_display_name(stream)
        label = f"[COLOR FF00C8FF][{stream['sizeInGB']} GB][/COLOR] {display_name}"
        item = xbmcgui.ListItem(label=label)
        item.setInfo('video', {
            'plot': f"{display_name}\n\nSize: {stream['sizeInGB']} GB",
        })
        item.setInfo('video', {'title': display_name, 'size': stream['sizeInGB']})
        item.setProperty('IsPlayable', 'true')
        url = build_url({'action': 'play_movie_stream', 'stream_id': stream['id']})
        item.addContextMenuItems([("Download", f"RunPlugin({build_url({'action': 'download_movie_stream', 'stream_id': stream['id'], 'filename': display_name})})")])
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=False)

    xbmcplugin.endOfDirectory(handle)

def list_movie_versions(handle, movie_id):
    versions = api.get_movie_versions(movie_id)
    for version in versions:
        display_name = _stream_display_name(version)
        has_bundled_subtitles = version.get('hasBundledSubtitles', "")
        subtitles_label = " [COLOR FF00FF00][Titulky][/COLOR]" if has_bundled_subtitles else ""
        label = f"[COLOR FF00C8FF][{version['sizeInGB']} GB][/COLOR]{subtitles_label} {display_name}"
        item = xbmcgui.ListItem(label=label)
        item.setInfo('video', {
            'plot': f"{display_name}\n\nSize: {version['sizeInGB']} GB",
        })
        item.setProperty('IsPlayable', 'true')
        url = build_url({'action': 'play_movie_stream', 'stream_id': version['id']})
        item.addContextMenuItems([("Download", f"RunPlugin({build_url({'action': 'download_movie_stream', 'stream_id': version['id'], 'filename': display_name})})")])
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=False)
    xbmcplugin.endOfDirectory(handle)

def play_movie_stream(handle, stream_id):
    try:
        streamUrl = api.get_streams(stream_id)
    except api.ApiError as e:
        xbmc.log(f"[play_movie_stream] HTTP {e.status_code} for stream {stream_id}: {e.message}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Stream error", e.message)
        xbmcplugin.setResolvedUrl(handle, False, listitem=xbmcgui.ListItem())
        return
    except URLError as e:
        xbmc.log(f"[play_movie_stream] URL error for stream {stream_id}: {e.reason}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Stream error", "Network issue while resolving stream.")
        xbmcplugin.setResolvedUrl(handle, False, listitem=xbmcgui.ListItem())
        return
    except Exception as e:
        xbmc.log(f"[play_movie_stream] Unexpected error for stream {stream_id}: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Stream error", "Could not resolve stream.")
        xbmcplugin.setResolvedUrl(handle, False, listitem=xbmcgui.ListItem())
        return

    if streamUrl:
        item = xbmcgui.ListItem(path=streamUrl)
        xbmcplugin.setResolvedUrl(handle, True, listitem=item)
    else:
        xbmcplugin.setResolvedUrl(handle, False, listitem=xbmcgui.ListItem())

def download_movie_stream(stream_id, filename):
    try:
        stream_url = api.get_download_url(stream_id)
    except api.ApiError as e:
        xbmc.log(f"[download_movie_stream] HTTP {e.status_code} for stream {stream_id}: {e.message}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Download", e.message)
        return
    except URLError as e:
        xbmc.log(f"[download_movie_stream] URL error for stream {stream_id}: {e.reason}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Download", "Network issue while resolving stream.")
        return
    except Exception as e:
        xbmc.log(f"[download_movie_stream] Unexpected error for stream {stream_id}: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Download", "Could not resolve stream.")
        return

    if not stream_url:
        xbmcgui.Dialog().ok("Download", "Stream URL not available")
        return

    safe_filename = _safe_download_filename(filename, stream_url)

    addon = xbmcaddon.Addon()
    default_dir = addon.getSetting("download_path") or ""
    save_dir = default_dir

    if not save_dir:
        save_dir = xbmcgui.Dialog().browse(0, "Choose save directory", "files", "", False, False, "")
        if not save_dir:
            return

    if not xbmcvfs.exists(save_dir):
        xbmcvfs.mkdirs(save_dir)

    # VFS paths (content://, smb://, storage://) can report missing; don't block on exists.
    if not xbmcvfs.exists(save_dir) and not _is_vfs_path(save_dir):
        xbmcgui.Dialog().ok("Download", "Download folder is not accessible.")
        return

    filepath = _join_path(save_dir, safe_filename)
    download_id = str(uuid.uuid4())
    created_at = now_iso()
    record = {
        "id": download_id,
        "stream_id": stream_id,
        "filename": safe_filename,
        "path": filepath,
        "url": stream_url,
        "url_type": "file_download",
        "status": "queued",
        "progress": 0,
        "bytes_total": None,
        "bytes_done": 0,
        "attempts": 0,
        "created_at": created_at,
        "updated_at": created_at
    }

    def op(data):
        _normalize_queue_positions(data)
        record["queue_position"] = _next_queue_position(data)
        data[download_id] = record

    db.mutate(op)

    xbmcgui.Dialog().notification("Queued", f"{safe_filename}", xbmcgui.NOTIFICATION_INFO, 2500)

def show_downloads_menu(handle):
    xbmcplugin.setPluginCategory(handle, "Downloads")
    try:
        xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_UNSORTED)
    except Exception:
        pass

    addon = xbmcaddon.Addon()
    max_attempts = max(1, int(addon.getSetting("download_retry_limit") or 0) + 1)
    data = _list_downloads_normalized()
    queue_total = _queue_count(data)

    clear_item = xbmcgui.ListItem(label="Vymazať históriu sťahovania")
    clear_item.setArt({
        'icon': get_icons_path('clear.png'),
        'thumb': get_icons_path('clear.png')
    })
    clear_item.setInfo('video', {'plot': 'Vymazať dokončené, zlyhané a zrušené záznamy (súbory nebudú odstránené).'})
    clear_url = build_url({'action': 'clear_download_history'})
    xbmcplugin.addDirectoryItem(handle, clear_url, clear_item, isFolder=False)

    downloading_items = sorted(
        [item for item in data.values() if item.get("status") == "downloading"],
        key=lambda x: (_queue_position(x), x.get("updated_at") or "", x.get("created_at") or "")
    )
    queued_items = sorted(
        [item for item in data.values() if item.get("status") in QUEUE_STATUSES],
        key=lambda x: (_queue_position(x), x.get("created_at") or "", x.get("id") or "")
    )
    history_items = sorted(
        [item for item in data.values() if item.get("status") not in ("downloading",) + QUEUE_STATUSES],
        key=lambda x: x.get("updated_at") or x.get("created_at") or "",
        reverse=True
    )
    items = downloading_items + queued_items + history_items

    for it in items:
        download_id = it.get("id")
        status = it.get("status", "?")
        progress = it.get("progress", 0) or 0
        filename = it.get("filename", "Unknown")
        path = it.get("path", "")
        attempts = it.get("attempts", 0) or 0
        error = it.get("error")
        position = _as_int(it.get("queue_position"), 0)
        bytes_done = it.get("bytes_done")
        bytes_total = it.get("bytes_total")

        if status == "downloading":
            label = f"[Now {progress}%] {filename}"
        elif status == "queued":
            label = f"#{position} [Queued] {filename}"
        elif status == "paused":
            label = f"#{position} [Paused {progress}%] {filename}"
        elif status == "complete":
            label = f"[[COLOR FF90EE90]Complete[/COLOR]] {filename}"
        elif status == "failed":
            label = f"[[COLOR FFFF9090]Failed[/COLOR]] {filename}"
        elif status == "canceled":
            label = f"[Canceled] {filename}"
        else:
            label = f"[{status}] {filename}"

        li = xbmcgui.ListItem(label=label)
        plot_lines = [
            f"Status: {status}",
            f"Progress: {progress}%",
            f"Attempts: {attempts}/{max_attempts}"
        ]
        if status in QUEUE_STATUSES and position:
            plot_lines.append(f"Queue position: {position}/{queue_total}")
        elif status == "downloading":
            plot_lines.append("Queue position: downloading now")
        if bytes_total:
            plot_lines.append(f"Downloaded: {_format_bytes(bytes_done)} / {_format_bytes(bytes_total)}")
        elif bytes_done:
            plot_lines.append(f"Downloaded: {_format_bytes(bytes_done)}")
        if path:
            plot_lines.append(f"Path: {path}")
        if error:
            plot_lines.append(f"Error: {error}")
        li.setInfo('video', {'plot': "\n".join(plot_lines)})

        if status == "complete":
            li.setArt({'icon': get_icons_path('done.png'), 'thumb': get_icons_path('done.png')})
        else:
            li.setArt({'icon': get_icons_path('downloads.png'), 'thumb': get_icons_path('downloads.png')})

        actions = _download_action_queries(it, queue_total)
        if actions:
            li.addContextMenuItems([
                (label, f"RunPlugin({build_url(query)})")
                for label, query in actions
            ])

        url = ""
        if status == "complete" and path and xbmcvfs.exists(path):
            url = path
            li.setProperty("IsPlayable", "true")
        elif actions:
            url = build_url({'action': 'show_download_actions', 'id': download_id})

        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=False)

    xbmcplugin.endOfDirectory(handle)

def _refresh_downloads_container():
    xbmc.executebuiltin("Container.Refresh")

def _part_path(record):
    path = record.get("path")
    return f"{path}.part" if path else ""

def _part_size(record):
    part = _part_path(record)
    if not part:
        return 0
    try:
        if not xbmcvfs.exists(part):
            return 0
        return xbmcvfs.Stat(part).st_size()
    except Exception:
        return 0

def _delete_part_file(record):
    part = _part_path(record)
    if not part:
        return
    try:
        if xbmcvfs.exists(part):
            xbmcvfs.delete(part)
    except Exception:
        pass

def _progress_from_part(record, default=0):
    part_size = _part_size(record)
    total = _as_int(record.get("bytes_total"), 0)
    if part_size > 0 and total > 0:
        return part_size, int(100 * part_size / total)
    return part_size, default if part_size > 0 else 0

def _run_download_action(query):
    action = query.get("action")
    download_id = query.get("id")

    if action == "move_download":
        move_download(download_id, query.get("direction"))
    elif action == "pause_download":
        pause_download(download_id)
    elif action == "resume_download":
        resume_download(download_id)
    elif action == "cancel_download":
        cancel_download(download_id)
    elif action == "retry_download":
        retry_download(download_id)

def show_download_actions(download_id):
    data = _list_downloads_normalized()
    record = data.get(download_id)
    if not record:
        xbmcgui.Dialog().notification("Downloads", "Download not found", xbmcgui.NOTIFICATION_ERROR, 2000)
        return

    actions = _download_action_queries(record, _queue_count(data))
    if not actions:
        xbmcgui.Dialog().notification("Downloads", "No actions available", xbmcgui.NOTIFICATION_INFO, 2000)
        return

    choice = xbmcgui.Dialog().select(record.get("filename", "Download"), [label for label, _ in actions])
    if choice < 0:
        return

    _run_download_action(actions[choice][1])

def move_download(download_id, direction):
    if direction not in ("up", "down", "top", "bottom"):
        return

    def op(data):
        _normalize_queue_positions(data)
        items = [
            (item_id, record)
            for item_id, record in data.items()
            if record.get("status") in QUEUE_STATUSES
        ]
        items.sort(key=lambda item: (_queue_position(item[1]), item[1].get("created_at") or "", item[0]))

        index = next((i for i, (item_id, _) in enumerate(items) if item_id == download_id), None)
        if index is None:
            return None

        item = items.pop(index)
        if direction == "up":
            target = max(0, index - 1)
        elif direction == "down":
            target = min(len(items), index + 1)
        elif direction == "top":
            target = 0
        else:
            target = len(items)

        items.insert(target, item)
        updated_at = now_iso()
        for position, (_, record) in enumerate(items, start=1):
            record["queue_position"] = position
            record["updated_at"] = updated_at

        return item[1].get("filename", "Download")

    filename = db.mutate(op)
    if filename:
        xbmcgui.Dialog().notification("Downloads", f"Reordered {filename}", xbmcgui.NOTIFICATION_INFO, 1500)
    _refresh_downloads_container()

def pause_download(download_id):
    def op(data):
        record = data.get(download_id)
        if not record or record.get("status") not in ("queued", "downloading"):
            return None

        record["status"] = "paused"
        record["error"] = None
        record["updated_at"] = now_iso()
        _normalize_queue_positions(data)
        return record.get("filename", "Download")

    filename = db.mutate(op)
    if filename:
        xbmcgui.Dialog().notification("Paused", filename, xbmcgui.NOTIFICATION_INFO, 2000)
    _refresh_downloads_container()

def resume_download(download_id):
    def op(data):
        record = data.get(download_id)
        if not record or record.get("status") != "paused":
            return None

        record["status"] = "queued"
        record["error"] = None
        record["updated_at"] = now_iso()
        _normalize_queue_positions(data)
        return record.get("filename", "Download")

    filename = db.mutate(op)
    if filename:
        xbmcgui.Dialog().notification("Queued", filename, xbmcgui.NOTIFICATION_INFO, 2000)
    _refresh_downloads_container()

def retry_download(download_id):
    current = db.list().get(download_id)
    if current and current.get("status") == "canceled":
        _delete_part_file(current)

    def op(data):
        record = data.get(download_id)
        if not record or record.get("status") not in ("failed", "canceled"):
            return None

        old_status = record.get("status")
        _normalize_queue_positions(data)
        next_position = _next_queue_position(data)
        record["status"] = "queued"
        record["queue_position"] = next_position
        record["error"] = None
        record["attempts"] = 0
        record["updated_at"] = now_iso()

        if old_status == "failed":
            bytes_done, progress = _progress_from_part(record, record.get("progress", 0) or 0)
            record["bytes_done"] = bytes_done
            record["progress"] = progress
        else:
            record["bytes_done"] = 0
            record["bytes_total"] = None
            record["progress"] = 0

        return record.get("filename", "Download")

    filename = db.mutate(op)
    if filename:
        xbmcgui.Dialog().notification("Queued", filename, xbmcgui.NOTIFICATION_INFO, 2000)
    _refresh_downloads_container()

def cancel_download(download_id):
    def op(data):
        record = data.get(download_id)
        if not record:
            return None

        old_status = record.get("status")
        record["status"] = "canceled"
        record["queue_position"] = None
        record["updated_at"] = now_iso()
        if old_status != "downloading":
            record["bytes_done"] = 0
            record["progress"] = 0
        _normalize_queue_positions(data)
        return old_status, dict(record)

    result = db.mutate(op)
    if result:
        old_status, record = result
        if old_status != "downloading":
            _delete_part_file(record)
        xbmcgui.Dialog().notification("Canceled", "Download canceled", xbmcgui.NOTIFICATION_INFO, 2000)
    _refresh_downloads_container()

def clear_download_history():
    confirm = xbmcgui.Dialog().yesno("Vymazať históriu sťahovania", "Aktívne a čakajúce sťahovania zostanú zachované. Stiahnuté súbory nebudú odstránené. Pokračovať?", yeslabel="Áno", nolabel="Nie")
    if not confirm:
        return

    def op(data):
        active = {
            download_id: record
            for download_id, record in data.items()
            if record.get("status") in ("downloading",) + QUEUE_STATUSES
        }
        data.clear()
        data.update(active)
        _normalize_queue_positions(data)

    db.mutate(op)
    #xbmcgui.Dialog().notification("Downloads", "History cleared", xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin("Container.Refresh")
