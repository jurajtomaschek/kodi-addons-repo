import os
import threading
import time
import urllib.request
import xbmc
import xbmcaddon
import xbmcvfs

from . import api
from .downloads_db import DownloadsDb, now_iso

CONTROL_CHECK_INTERVAL = 1.0
QUEUE_POSITION_FALLBACK = 999999
BASE_DOWNLOAD_CHUNK_SIZE = 256 * 1024
MIN_THROTTLED_CHUNK_SIZE = 4 * 1024
REMOTE_PLAYBACK_SCHEMES = (
    "http://",
    "https://",
    "ftp://",
    "ftps://",
    "sftp://",
    "dav://",
    "davs://",
    "smb://",
    "nfs://",
    "rtmp://",
    "rtsp://",
    "udp://",
    "plugin://"
)
QUEUE_POSITION_FALLBACK = 999999


class DownloadsWorker:
    def __init__(self):
        self.db = DownloadsDb()
        self.monitor = xbmc.Monitor()
        addon = xbmcaddon.Addon()
        self.addon_id = addon.getAddonInfo("id")
        self.retry_limit = 0
        self.max_attempts = 1
        self.max_concurrent = 1
        self.max_download_speed_bytes = 0
        self.max_download_speed_streaming_bytes = 0
        self.streaming_active = False
        self.download_speed_limit_bytes = 0
        self._rate_limit_available_at = time.monotonic()
        self._rate_limit_lock = threading.Lock()
        self._last_refresh = 0.0
        self._threads = {}
        self._threads_lock = threading.Lock()
        self._refresh_settings()

    def run(self):
        xbmc.log("[DownloadsWorker] Started", xbmc.LOGINFO)
        self._migrate_stream_start_records()
        self._requeue_incomplete()

        while not self.monitor.abortRequested():
            try:
                self._refresh_settings()
                self._cleanup_threads()
                self._migrate_stream_start_records()
                data = self.db.list()

                capacity = self.max_concurrent - self._active_thread_count()
                if capacity <= 0:
                    self.monitor.waitForAbort(1.0)
                    continue

                jobs = self._pick_next_jobs(data, capacity)
                if not jobs:
                    self.monitor.waitForAbort(1.0)
                    continue

                for job in jobs:
                    self._start_job(job)

                self.monitor.waitForAbort(0.25)

            except Exception as ex:
                xbmc.log(f"[DownloadsWorker] Loop error: {ex}", xbmc.LOGERROR)
                self.monitor.waitForAbort(1.0)

        self._wait_for_threads()
        xbmc.log("[DownloadsWorker] Stopped", xbmc.LOGINFO)

    def _refresh_settings(self):
        self.retry_limit = max(0, self._get_int_setting("download_retry_limit", 0))
        self.max_attempts = self.retry_limit + 1
        self.max_concurrent = max(1, self._get_int_setting("max_concurrent_downloads", 1))
        self.max_download_speed_bytes = max(0, self._get_int_setting("max_download_speed_kbps", 0)) * 1024
        self.max_download_speed_streaming_bytes = max(0, self._get_int_setting("max_download_speed_streaming_kbps", 0)) * 1024
        self.streaming_active = self._is_streaming_active()

        selected_limit = (
            self.max_download_speed_streaming_bytes
            if self.streaming_active
            else self.max_download_speed_bytes
        )
        self._set_download_speed_limit(selected_limit)

    def _get_int_setting(self, setting_id: str, default=0) -> int:
        try:
            value = xbmcaddon.Addon().getSetting(setting_id)
            return int(value) if value not in (None, "") else default
        except Exception:
            return default

    @staticmethod
    def _is_streaming_active() -> bool:
        try:
            player = xbmc.Player()
            if not player.isPlayingVideo():
                return False

            try:
                playing_file = (player.getPlayingFile() or "").strip().lower()
            except Exception:
                return True

            if not playing_file:
                return True

            return playing_file.startswith(REMOTE_PLAYBACK_SCHEMES)
        except Exception:
            return False

    def _set_download_speed_limit(self, limit_bytes: int):
        limit_bytes = max(0, int(limit_bytes or 0))
        with self._rate_limit_lock:
            if self.download_speed_limit_bytes == limit_bytes:
                return

            self.download_speed_limit_bytes = limit_bytes
            self._rate_limit_available_at = time.monotonic()

    def _current_download_speed_limit(self) -> int:
        with self._rate_limit_lock:
            return self.download_speed_limit_bytes

    def _download_chunk_size(self) -> int:
        limit = self._current_download_speed_limit()
        if limit <= 0:
            return BASE_DOWNLOAD_CHUNK_SIZE

        throttled_size = max(MIN_THROTTLED_CHUNK_SIZE, int(limit / 4))
        return min(BASE_DOWNLOAD_CHUNK_SIZE, throttled_size)

    def _wait_for_download_quota(self, download_id: str, byte_count: int):
        if byte_count <= 0:
            return

        with self._rate_limit_lock:
            limit = self.download_speed_limit_bytes
            if limit <= 0:
                self._rate_limit_available_at = time.monotonic()
                return

            now = time.monotonic()
            available_at = max(now, self._rate_limit_available_at)
            wait_for = available_at - now
            self._rate_limit_available_at = available_at + (float(byte_count) / float(limit))

        self._wait_with_download_control(download_id, wait_for)

    def _refund_download_quota(self, byte_count: int):
        if byte_count <= 0:
            return

        with self._rate_limit_lock:
            limit = self.download_speed_limit_bytes
            if limit <= 0:
                return

            refund_seconds = float(byte_count) / float(limit)
            self._rate_limit_available_at = max(
                time.monotonic(),
                self._rate_limit_available_at - refund_seconds
            )

    def _wait_with_download_control(self, download_id: str, wait_for: float):
        if wait_for <= 0:
            return

        deadline = time.monotonic() + wait_for
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return

            if self.monitor.waitForAbort(min(remaining, CONTROL_CHECK_INTERVAL)):
                raise Exception("Kodi abortRequested")

            if self._current_download_speed_limit() <= 0:
                return

            cur = self.db.list().get(download_id, {})
            if cur.get("status") == "canceled":
                raise Exception("Canceled")
            if cur.get("status") == "paused":
                raise Exception("Paused")

    def _cleanup_threads(self):
        with self._threads_lock:
            finished = [download_id for download_id, thread in self._threads.items() if not thread.is_alive()]
            for download_id in finished:
                del self._threads[download_id]

    def _active_thread_count(self) -> int:
        with self._threads_lock:
            return len(self._threads)

    def _active_download_ids(self):
        with self._threads_lock:
            return set(self._threads.keys())

    def _start_job(self, job: dict):
        download_id = job.get("id")
        if not download_id:
            return

        with self._threads_lock:
            if download_id in self._threads:
                return

            thread = threading.Thread(
                target=self._run_job_thread,
                args=(job,),
                name=f"MediaHubDownload-{download_id[:8]}",
                daemon=True
            )
            self._threads[download_id] = thread
            thread.start()

    def _run_job_thread(self, job: dict):
        download_id = job.get("id")
        try:
            self._process_job(job)
        except Exception as ex:
            xbmc.log(f"[DownloadsWorker] Unhandled job error for {download_id}: {ex}", xbmc.LOGERROR)
            if download_id:
                self.db.update(download_id, {
                    "status": "failed",
                    "error": str(ex),
                    **self._clear_stream_start_fields(),
                    "updated_at": now_iso()
                })
        finally:
            with self._threads_lock:
                if download_id in self._threads:
                    del self._threads[download_id]

    def _wait_for_threads(self, timeout_sec=10.0):
        deadline = time.time() + timeout_sec
        while time.time() < deadline:
            with self._threads_lock:
                threads = list(self._threads.values())

            if not threads:
                return

            for thread in threads:
                thread.join(0.1)

        with self._threads_lock:
            remaining = len(self._threads)

        if remaining:
            xbmc.log(f"[DownloadsWorker] Stopping with {remaining} download thread(s) still active", xbmc.LOGWARNING)

    @staticmethod
    def _clear_stream_start_fields():
        return {
            "pause_reason": None,
            "pause_until": None,
            "pause_requested": None,
            "stream_startup_limit_until": None
        }

    def _migrate_stream_start_records(self):
        data = self.db.list()
        for download_id, record in data.items():
            has_stream_start_marker = (
                record.get("pause_reason") == "stream_start" or
                record.get("pause_requested") == "stream_start" or
                record.get("stream_startup_limit_until")
            )
            if not has_stream_start_marker:
                continue

            patch = {
                **self._clear_stream_start_fields(),
                "updated_at": now_iso()
            }
            if record.get("status") == "paused":
                patch["status"] = "queued"

            self.db.update(download_id, patch)

    def _requeue_incomplete(self):
        data = self.db.list()
        for download_id, record in data.items():
            if record.get("status") != "downloading":
                continue

            dest = record.get("path")
            part_size = self._get_part_size(dest + ".part") if dest else 0
            total = record.get("bytes_total") or 0
            progress = int(100 * part_size / total) if total > 0 else 0
            self.db.update(download_id, {
                "status": "queued",
                "progress": progress,
                "bytes_done": part_size,
                "error": None,
                **self._clear_stream_start_fields(),
                "updated_at": now_iso()
            })

    def _get_part_size(self, part_path: str) -> int:
        try:
            if not xbmcvfs.exists(part_path):
                return 0
            return xbmcvfs.Stat(part_path).st_size()
        except Exception:
            return 0

    @staticmethod
    def _queue_position(record: dict) -> int:
        try:
            position = int(record.get("queue_position") or 0)
            return position if position > 0 else QUEUE_POSITION_FALLBACK
        except (TypeError, ValueError):
            return QUEUE_POSITION_FALLBACK

    @staticmethod
    def _queue_position(record: dict) -> int:
        try:
            position = int(record.get("queue_position") or 0)
            return position if position > 0 else QUEUE_POSITION_FALLBACK
        except (TypeError, ValueError):
            return QUEUE_POSITION_FALLBACK

    def _pick_next_jobs(self, data: dict, limit: int):
        active_ids = self._active_download_ids()
        queued = []

        for download_id, record in data.items():
            if record.get("status") != "queued" or download_id in active_ids:
                continue

            job = dict(record)
            job["id"] = job.get("id") or download_id
            queued.append(job)

        queued.sort(key=lambda x: (self._queue_position(x), x.get("created_at") or "", x.get("id") or ""))
        queued.sort(key=lambda x: (self._queue_position(x), x.get("created_at") or "", x.get("id") or ""))
        return queued[:limit]

    def _maybe_refresh_downloads_view(self, throttle_sec=10.0, force=False):
        now = time.time()
        if not force and now - self._last_refresh < throttle_sec:
            return

        folder_path = xbmc.getInfoLabel("Container.FolderPath") or ""
        if not folder_path:
            return

        if f"plugin://{self.addon_id}" not in folder_path:
            return

        if "action=show_downloads_menu" not in folder_path:
            return

        xbmc.executebuiltin("Container.Refresh")
        self._last_refresh = now

    def _resolve_download_url(self, download_id: str, job: dict) -> str:
        url = job.get("url")
        if job.get("url_type") == "file_download" and url:
            return url

        stream_id = job.get("stream_id")
        if not stream_id:
            if url:
                return url
            raise Exception("Download URL missing")

        xbmc.log(f"[DownloadsWorker] Refreshing file-download URL for {download_id}", xbmc.LOGINFO)
        refreshed_url = api.get_download_url(stream_id)
        self.db.update(download_id, {
            "url": refreshed_url,
            "url_type": "file_download",
            "updated_at": now_iso()
        })
        return refreshed_url

    def _process_job(self, job: dict):
        download_id = job["id"]
        dest = job["path"]
        part = dest + ".part"
        existing_size = self._get_part_size(part)
        attempts = int(job.get("attempts") or 0)

        if attempts >= self.max_attempts:
            self.db.update(download_id, {
                "status": "failed",
                "error": "Retry limit reached",
                "attempts": attempts,
                **self._clear_stream_start_fields(),
                "updated_at": now_iso()
            })
            self._maybe_refresh_downloads_view(force=True)
            return

        current_attempt = attempts + 1
        current = self.db.list().get(download_id, {})
        if current.get("status") == "canceled":
            return
        if current.get("status") == "paused":
            return

        self.db.update(download_id, {
            "status": "downloading",
            "error": None,
            "attempts": current_attempt,
            **self._clear_stream_start_fields(),
            "updated_at": now_iso()
        })

        try:
            url = self._resolve_download_url(download_id, job)
            current = self.db.list().get(download_id, {})
            if current.get("status") == "canceled":
                return
            if current.get("status") == "paused":
                return

            if existing_size > 0:
                xbmc.executebuiltin(f'Notification(Download,Resuming {os.path.basename(dest)},2000)')
            else:
                xbmc.executebuiltin(f'Notification(Download,Starting {os.path.basename(dest)},2000)')

            request = urllib.request.Request(url)
            if existing_size > 0:
                request.add_header("Range", f"bytes={existing_size}-")

            with urllib.request.urlopen(request, timeout=60) as response:
                status = getattr(response, "status", response.getcode())
                total = 0
                content_range = response.headers.get("content-range")
                if content_range:
                    total_part = content_range.split("/")[-1].strip()
                    total = int(total_part) if total_part.isdigit() else 0

                if total == 0:
                    total_header = response.headers.get("content-length")
                    if total_header and total_header.isdigit():
                        total = int(total_header)
                        if status == 206 and existing_size > 0:
                            total += existing_size

                if status == 200 and existing_size > 0:
                    existing_size = 0

                progress = int(100 * existing_size / total) if total > 0 else 0
                self.db.update(download_id, {
                    "bytes_total": total if total > 0 else None,
                    "bytes_done": existing_size,
                    "progress": progress,
                    "attempts": current_attempt,
                    "updated_at": now_iso()
                })

                downloaded = existing_size
                last_saved_percent = progress if total > 0 else -1
                last_progress_update = time.time()
                last_control_check = time.time()
                progress_update_interval = 10.0

                folder = os.path.dirname(dest)
                if folder and not xbmcvfs.exists(folder):
                    xbmcvfs.mkdirs(folder)

                mode = "a" if existing_size > 0 and status == 206 else "w"
                f = xbmcvfs.File(part, mode)
                try:
                    while True:
                        if self.monitor.abortRequested():
                            raise Exception("Kodi abortRequested")

                        now = time.time()
                        if now - last_control_check >= CONTROL_CHECK_INTERVAL:
                            cur = self.db.list().get(download_id, {})
                            if cur.get("status") == "canceled":
                                raise Exception("Canceled")
                            if cur.get("status") == "paused":
                                raise Exception("Paused")
                            if cur.get("status") == "paused":
                                raise Exception("Paused")
                            last_control_check = now

                        read_size = self._download_chunk_size()
                        if total > 0:
                            remaining = max(0, total - downloaded)
                            if remaining <= 0:
                                break
                            read_size = min(read_size, remaining)

                        self._wait_for_download_quota(download_id, read_size)
                        chunk = response.read(read_size)
                        if not chunk:
                            self._refund_download_quota(read_size)
                            break
                        if len(chunk) < read_size:
                            self._refund_download_quota(read_size - len(chunk))

                        f.write(bytearray(chunk))
                        downloaded += len(chunk)

                        now = time.time()
                        if total > 0:
                            percent = int(100 * downloaded / total)
                            if percent >= last_saved_percent + 5 or now - last_progress_update >= progress_update_interval:
                                self.db.update(download_id, {
                                    "progress": percent,
                                    "bytes_done": downloaded,
                                    "updated_at": now_iso()
                                })
                                last_saved_percent = percent
                                last_progress_update = now
                                self._maybe_refresh_downloads_view()
                finally:
                    f.close()

            cur = self.db.list().get(download_id, {})
            if cur.get("status") == "canceled":
                raise Exception("Canceled")
            if cur.get("status") == "paused":
                raise Exception("Paused")

            cur = self.db.list().get(download_id, {})
            if cur.get("status") == "canceled":
                raise Exception("Canceled")
            if cur.get("status") == "paused":
                raise Exception("Paused")

            if xbmcvfs.exists(dest):
                xbmcvfs.delete(dest)
            xbmcvfs.rename(part, dest)

            self.db.update(download_id, {
                "status": "complete",
                "progress": 100,
                "bytes_done": downloaded,
                "attempts": current_attempt,
                **self._clear_stream_start_fields(),
                "updated_at": now_iso()
            })
            self._maybe_refresh_downloads_view(force=True)
            xbmc.executebuiltin(f'Notification(Download,Completed {os.path.basename(dest)},3000)')

        except Exception as ex:
            cur = self.db.list().get(download_id, {})
            notify_failed = False
            if cur.get("status") == "canceled":
                try:
                    if xbmcvfs.exists(part):
                        xbmcvfs.delete(part)
                except Exception:
                    pass
                xbmc.executebuiltin(f'Notification(Download,Canceled {os.path.basename(dest)},2500)')
                self.db.update(download_id, {
                    "updated_at": now_iso(),
                    "bytes_done": 0,
                    "progress": 0,
                    "bytes_done": 0,
                    "progress": 0,
                    **self._clear_stream_start_fields()
                })
            elif cur.get("status") == "paused" or str(ex) == "Paused":
                part_size = self._get_part_size(part)
                total = cur.get("bytes_total") or 0
                progress = int(100 * part_size / total) if total > 0 else cur.get("progress", 0)
                xbmc.executebuiltin(f'Notification(Download,Paused {os.path.basename(dest)},2000)')
                self.db.update(download_id, {
                    "status": "paused",
                    "bytes_done": part_size,
                    "progress": progress,
                    "error": None,
                    "attempts": attempts,
                    **self._clear_stream_start_fields(),
                    "updated_at": now_iso()
                })
            elif cur.get("status") == "paused" or str(ex) == "Paused":
                part_size = self._get_part_size(part)
                total = cur.get("bytes_total") or 0
                progress = int(100 * part_size / total) if total > 0 else cur.get("progress", 0)
                xbmc.executebuiltin(f'Notification(Download,Paused {os.path.basename(dest)},2000)')
                self.db.update(download_id, {
                    "status": "paused",
                    "bytes_done": part_size,
                    "progress": progress,
                    "error": None,
                    "attempts": attempts,
                    **self._clear_stream_start_fields(),
                    "updated_at": now_iso()
                })
            elif str(ex) == "Kodi abortRequested":
                part_size = self._get_part_size(part)
                total = cur.get("bytes_total") or 0
                progress = int(100 * part_size / total) if total > 0 else cur.get("progress", 0)
                self.db.update(download_id, {
                    "status": "queued",
                    "bytes_done": part_size,
                    "progress": progress,
                    "error": None,
                    "attempts": current_attempt,
                    **self._clear_stream_start_fields(),
                    "updated_at": now_iso()
                })
            elif current_attempt < self.max_attempts:
                self.db.update(download_id, {
                    "status": "queued",
                    "error": str(ex),
                    "attempts": current_attempt,
                    **self._clear_stream_start_fields(),
                    "updated_at": now_iso()
                })
            else:
                self.db.update(download_id, {
                    "status": "failed",
                    "error": str(ex),
                    "attempts": current_attempt,
                    **self._clear_stream_start_fields(),
                    "updated_at": now_iso()
                })
                notify_failed = True

            self._maybe_refresh_downloads_view(force=True)
            if notify_failed:
                xbmc.executebuiltin(f'Notification(Download,Failed {os.path.basename(dest)},4000)')
