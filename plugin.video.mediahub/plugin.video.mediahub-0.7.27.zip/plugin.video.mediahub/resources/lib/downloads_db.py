import json
import os
import time
import xbmcaddon
import xbmcvfs

class DownloadsDb:
    def __init__(self, filename="downloads_progress.json"):
        addon = xbmcaddon.Addon()
        self._dir = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
        if not xbmcvfs.exists(self._dir):
            xbmcvfs.mkdirs(self._dir)

        self._path = os.path.join(self._dir, filename)
        self._lockdir = os.path.join(self._dir, ".downloads_lock")

    def list(self) -> dict:
        return self._with_lock(self._load_unlocked)

    def set(self, download_id: str, record: dict):
        def op():
            data = self._load_unlocked()
            data[download_id] = record
            self._atomic_write_unlocked(data)
            return None
        return self._with_lock(op)

    def update(self, download_id: str, patch: dict):
        def op():
            data = self._load_unlocked()
            cur = data.get(download_id, {})
            cur.update(patch)
            data[download_id] = cur
            self._atomic_write_unlocked(data)
            return None
        return self._with_lock(op)

    def mutate(self, fn):
        def op():
            data = self._load_unlocked()
            result = fn(data)
            self._atomic_write_unlocked(data)
            return result
        return self._with_lock(op)

    def clear_all(self):
        def op():
            self._atomic_write_unlocked({})
            return None
        return self._with_lock(op)

    def _with_lock(self, fn, timeout_sec=10.0, poll_sec=0.05):
        start = time.time()
        while True:
            if xbmcvfs.mkdir(self._lockdir):
                break
            if time.time() - start >= timeout_sec:
                raise TimeoutError("Could not acquire downloads lock in time")
            time.sleep(poll_sec)

        try:
            return fn()
        finally:
            try:
                if xbmcvfs.exists(self._lockdir):
                    xbmcvfs.rmdir(self._lockdir)
            except Exception:
                pass

    def _load_unlocked(self) -> dict:
        if not xbmcvfs.exists(self._path):
            return {}
        try:
            f = xbmcvfs.File(self._path, "r")
            raw = f.read()
            f.close()
            return json.loads(raw) if raw else {}
        except Exception:
            return {}

    def _atomic_write_unlocked(self, data: dict):
        tmp = self._path + ".tmp"
        payload = json.dumps(data, ensure_ascii=False, separators=(",", ":"))

        f = xbmcvfs.File(tmp, "w")
        f.write(payload)
        f.close()

        if xbmcvfs.exists(self._path):
            xbmcvfs.delete(self._path)
        xbmcvfs.rename(tmp, self._path)

def now_iso():
    return time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime())
