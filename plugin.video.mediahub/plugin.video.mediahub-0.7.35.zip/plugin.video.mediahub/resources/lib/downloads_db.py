import json
import datetime
import os
import posixpath
import sqlite3
import time
from contextlib import closing, contextmanager
from urllib.parse import urlsplit, urlunsplit

import xbmcaddon
import xbmcvfs


_BUSY_TIMEOUT_MS = 10000
_QUEUE_STATUSES = frozenset(("queued", "paused", "waiting_retry"))
_TERMINAL_STATUSES = frozenset(("complete", "failed", "canceled"))
_PATH_OWNING_STATUSES = frozenset((
    "queued",
    "waiting_retry",
    "paused",
    "downloading",
    "pausing",
    "canceling",
    "repairing",
    "finalizing",
))
_MIGRATION_KEY = "downloads_progress_json_migrated_v1"


class DownloadsDb:
    """Transactional download state stored in the add-on's local profile."""

    def __init__(self, filename="downloads_progress.json"):
        addon = xbmcaddon.Addon()
        self._dir = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
        if not os.path.isdir(self._dir):
            try:
                os.makedirs(self._dir, exist_ok=True)
            except OSError:
                if not xbmcvfs.exists(self._dir):
                    xbmcvfs.mkdirs(self._dir)

        root, extension = os.path.splitext(filename)
        if extension.lower() == ".json":
            legacy_filename = filename
            database_filename = root + ".db"
        else:
            database_filename = filename
            legacy_filename = root + ".json"

        self._legacy_path = os.path.join(self._dir, legacy_filename)
        self._path = os.path.join(self._dir, database_filename)
        self._lockdir = os.path.join(self._dir, ".downloads_lock")
        self._initialize()

    def list(self) -> dict:
        with closing(self._connect()) as connection:
            rows = connection.execute(
                "SELECT download_id, payload, revision FROM downloads"
            ).fetchall()
            return {
                row["download_id"]: self._record_from_row(row)
                for row in rows
            }

    def set(self, download_id: str, record: dict):
        download_id = str(download_id)
        with self._write_connection() as connection:
            row = self._select_row(connection, download_id)
            revision = (int(row["revision"]) + 1) if row else 1
            self._store_row(connection, download_id, record, revision, replace=bool(row))
        return None

    def update(self, download_id: str, patch: dict):
        """Patch an existing row; unlike the JSON implementation, never resurrect it."""
        download_id = str(download_id)
        with self._write_connection() as connection:
            row = self._select_row(connection, download_id)
            if row is None:
                return None

            record = self._record_from_row(row)
            record.update(self._without_revision(patch))
            self._store_row(
                connection,
                download_id,
                record,
                int(row["revision"]) + 1,
                replace=True,
            )
        return None

    def mutate(self, fn):
        """Run a legacy whole-dictionary mutation inside one IMMEDIATE transaction."""
        with self._write_connection() as connection:
            rows = connection.execute(
                "SELECT download_id, payload, revision FROM downloads"
            ).fetchall()
            original_rows = {row["download_id"]: row for row in rows}
            data = {
                row["download_id"]: self._record_from_row(row)
                for row in rows
            }

            result = fn(data)
            if not isinstance(data, dict):
                raise TypeError("Downloads mutation must leave a dictionary")

            normalized = {}
            for download_id, record in data.items():
                key = str(download_id)
                if key in normalized:
                    raise ValueError(f"Duplicate download id after normalization: {key}")
                if not isinstance(record, dict):
                    raise TypeError(f"Download record {key} must be a dictionary")
                normalized[key] = record

            for download_id in set(original_rows) - set(normalized):
                connection.execute(
                    "DELETE FROM downloads WHERE download_id = ?",
                    (download_id,),
                )

            for download_id, record in normalized.items():
                old_row = original_rows.get(download_id)
                if old_row is None:
                    self._store_row(connection, download_id, record, 1, replace=False)
                    continue

                old_record = self._record_from_row(old_row)
                if self._without_revision(old_record) == self._without_revision(record):
                    continue

                self._store_row(
                    connection,
                    download_id,
                    record,
                    int(old_row["revision"]) + 1,
                    replace=True,
                )

            return result

    def clear_all(self):
        with self._write_connection() as connection:
            connection.execute("DELETE FROM downloads")
        return None

    def transition(
        self,
        download_id: str,
        expected_statuses,
        patch: dict,
        expected_owner_token=None,
        expected_revision=None,
    ):
        """Compare-and-set a record by status and, optionally, attempt owner."""
        download_id = str(download_id)
        statuses = self._normalize_statuses(expected_statuses)
        with self._write_connection() as connection:
            row = self._select_row(connection, download_id)
            if row is None:
                return None

            record = self._record_from_row(row)
            if (
                expected_revision is not None
                and int(row["revision"]) != int(expected_revision)
            ):
                return None
            if statuses is not None and record.get("status") not in statuses:
                return None
            if (
                expected_owner_token is not None
                and record.get("owner_token") != expected_owner_token
            ):
                return None

            updated = dict(record)
            updated.update(self._without_revision(patch))
            if self._would_conflict_with_path_owner(
                connection, download_id, record, updated
            ):
                return None

            revision = int(row["revision"]) + 1
            self._store_row(
                connection, download_id, updated, revision, replace=True
            )
            updated["revision"] = revision
            return updated

    def update_owned(
        self,
        download_id: str,
        owner_token,
        patch: dict,
        expected_statuses=None,
    ) -> bool:
        """Patch only when the row still belongs to the calling worker attempt."""
        download_id = str(download_id)
        statuses = self._normalize_statuses(expected_statuses)
        with self._write_connection() as connection:
            row = self._select_row(connection, download_id)
            if row is None:
                return False

            record = self._record_from_row(row)
            if record.get("owner_token") != owner_token:
                return False
            if statuses is not None and record.get("status") not in statuses:
                return False

            updated = dict(record)
            updated.update(self._without_revision(patch))
            if self._would_conflict_with_path_owner(
                connection, download_id, record, updated
            ):
                return False

            self._store_row(
                connection,
                download_id,
                updated,
                int(row["revision"]) + 1,
                replace=True,
            )
            return True

    def add_with_unique_path(self, record: dict) -> dict:
        """Reserve a collision-free destination and insert the record atomically."""
        if not isinstance(record, dict):
            raise TypeError("Download record must be a dictionary")

        download_id = record.get("id")
        if not download_id:
            raise ValueError("Download record requires an id")
        download_id = str(download_id)

        original_path = record.get("path")
        if not isinstance(original_path, str) or not original_path.strip():
            raise ValueError("Download record requires a destination path")

        candidate_number = 1
        while True:
            candidate = self._numbered_path(original_path, candidate_number)
            path_key = self._canonical_path_key(candidate)
            if not path_key:
                raise ValueError("Download destination path is invalid")

            # VFS checks can block for a long time when a network share is
            # offline. Never hold SQLite's global write transaction while
            # waiting for them.
            if self._path_exists(candidate) or self._path_exists(candidate + ".part"):
                candidate_number += 1
                continue

            with self._write_connection() as connection:
                if self._select_row(connection, download_id) is not None:
                    raise KeyError(f"Download id already exists: {download_id}")
                if self._path_is_reserved(connection, path_key, candidate):
                    candidate_number += 1
                    continue

                inserted = self._without_revision(record)
                inserted["path"] = candidate
                inserted["filename"] = self._path_filename(candidate)
                if (
                    inserted.get("status") in _QUEUE_STATUSES
                    and self._positive_int(inserted.get("queue_position")) == 0
                ):
                    inserted["queue_position"] = self._next_queue_position(connection)

                self._store_row(
                    connection, download_id, inserted, 1, replace=False
                )
                inserted["revision"] = 1
                return inserted

    def _initialize(self):
        with closing(self._connect()) as connection:
            try:
                connection.execute("PRAGMA journal_mode = WAL").fetchone()
            except sqlite3.DatabaseError:
                # Some SQLite/VFS combinations do not support WAL; transactions
                # and the busy timeout still provide correctness there.
                pass

            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS downloads (
                    download_id TEXT PRIMARY KEY,
                    status TEXT,
                    path_key TEXT COLLATE NOCASE,
                    revision INTEGER NOT NULL CHECK (revision > 0),
                    payload TEXT NOT NULL
                )
                """
            )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS downloads_meta (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                )
                """
            )
            connection.execute(
                "CREATE INDEX IF NOT EXISTS idx_downloads_status ON downloads(status)"
            )
            connection.execute(
                "CREATE INDEX IF NOT EXISTS idx_downloads_path_key ON downloads(path_key COLLATE NOCASE)"
            )
            connection.execute(
                "CREATE INDEX IF NOT EXISTS idx_downloads_revision ON downloads(revision)"
            )

        self._migrate_legacy_once()

    def _migrate_legacy_once(self):
        migration = self._read_legacy_records()
        if migration is None:
            # A malformed or temporarily unreadable legacy file must not be
            # acknowledged: a later start can retry without data loss.
            return

        with self._write_connection() as connection:
            migrated = connection.execute(
                "SELECT 1 FROM downloads_meta WHERE key = ?",
                (_MIGRATION_KEY,),
            ).fetchone()
            if migrated:
                return

            existing_paths = {
                row["path_key"]
                for row in connection.execute(
                    "SELECT path_key FROM downloads WHERE path_key IS NOT NULL"
                ).fetchall()
            }
            for download_id, record in migration.items():
                if not isinstance(record, dict):
                    continue
                exists = self._select_row(connection, str(download_id))
                if exists is None:
                    migrated_record = dict(record)
                    if migrated_record.get("stream_id"):
                        # Signed links are credentials and should never survive
                        # migration into the durable database.
                        migrated_record.pop("url", None)
                        migrated_record.pop("url_type", None)

                    original_path = migrated_record.get("path")
                    if isinstance(original_path, str) and original_path:
                        candidate_number = 1
                        while True:
                            candidate = self._numbered_path(
                                original_path,
                                candidate_number
                            )
                            candidate_key = self._canonical_path_key(candidate)
                            candidate_part_key = self._canonical_path_key(
                                candidate + ".part"
                            )
                            conflicts = any(
                                candidate_key in (existing_key, existing_part_key)
                                or candidate_part_key in (existing_key, existing_part_key)
                                for existing_key, existing_part_key in (
                                    (
                                        path_key,
                                        self._canonical_path_key(path_key + ".part")
                                    )
                                    for path_key in existing_paths
                                )
                            )
                            if not conflicts:
                                break
                            candidate_number += 1
                        migrated_record["path"] = candidate
                        migrated_record["filename"] = self._path_filename(candidate)
                        existing_paths.add(candidate_key)

                    self._store_row(
                        connection,
                        str(download_id),
                        migrated_record,
                        1,
                        replace=False
                    )

            connection.execute(
                "INSERT INTO downloads_meta(key, value) VALUES (?, ?)",
                (_MIGRATION_KEY, str(int(time.time()))),
            )

        self._remove_stale_legacy_lock()

    def _read_legacy_records(self):
        if not os.path.exists(self._legacy_path):
            return {}
        try:
            with open(self._legacy_path, "r", encoding="utf-8-sig") as legacy_file:
                raw = legacy_file.read()
            if not raw.strip():
                return {}
            data = json.loads(raw)
            return data if isinstance(data, dict) else None
        except (OSError, UnicodeError, ValueError):
            return None

    def _remove_stale_legacy_lock(self):
        """Remove only the exact, empty legacy lock directory under the profile."""
        try:
            profile = os.path.normcase(os.path.realpath(os.path.abspath(self._dir)))
            lockdir = os.path.normcase(os.path.realpath(os.path.abspath(self._lockdir)))
            if os.path.dirname(lockdir) != profile:
                return
            if os.path.basename(lockdir) != ".downloads_lock":
                return
            if os.path.isdir(lockdir):
                os.rmdir(lockdir)
        except OSError:
            # Never recursively remove it: a non-empty directory may not be a
            # stale lock and is safer left for manual inspection.
            pass

    def _connect(self):
        connection = sqlite3.connect(
            self._path,
            timeout=float(_BUSY_TIMEOUT_MS) / 1000.0,
            isolation_level=None,
        )
        connection.row_factory = sqlite3.Row
        connection.execute(f"PRAGMA busy_timeout = {_BUSY_TIMEOUT_MS}")
        return connection

    @contextmanager
    def _write_connection(self):
        connection = self._connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            yield connection
            connection.commit()
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    @staticmethod
    def _select_row(connection, download_id):
        return connection.execute(
            """
            SELECT download_id, status, path_key, payload, revision
            FROM downloads
            WHERE download_id = ?
            """,
            (download_id,),
        ).fetchone()

    def _store_row(self, connection, download_id, record, revision, replace):
        payload_record = self._without_revision(record)
        payload = json.dumps(
            payload_record,
            ensure_ascii=False,
            separators=(",", ":"),
        )
        status = payload_record.get("status")
        if status is not None:
            status = str(status)
        path_key = self._canonical_path_key(payload_record.get("path"))

        if replace:
            cursor = connection.execute(
                """
                UPDATE downloads
                SET status = ?, path_key = ?, revision = ?, payload = ?
                WHERE download_id = ?
                """,
                (status, path_key, int(revision), payload, download_id),
            )
            if cursor.rowcount != 1:
                raise KeyError(f"Download id does not exist: {download_id}")
        else:
            connection.execute(
                """
                INSERT INTO downloads(download_id, status, path_key, revision, payload)
                VALUES (?, ?, ?, ?, ?)
                """,
                (download_id, status, path_key, int(revision), payload),
            )

    @staticmethod
    def _record_from_row(row):
        record = json.loads(row["payload"])
        if not isinstance(record, dict):
            raise ValueError(f"Invalid download payload for {row['download_id']}")
        record["revision"] = int(row["revision"])
        return record

    @staticmethod
    def _without_revision(record):
        if not isinstance(record, dict):
            raise TypeError("Download record and patch must be dictionaries")
        return {key: value for key, value in record.items() if key != "revision"}

    @staticmethod
    def _normalize_statuses(expected_statuses):
        if expected_statuses is None:
            return None
        if isinstance(expected_statuses, str):
            return frozenset((expected_statuses,))
        return frozenset(expected_statuses)

    def _would_conflict_with_path_owner(
        self, connection, download_id, old_record, new_record
    ):
        old_token = old_record.get("owner_token")
        new_token = new_record.get("owner_token")
        old_status = old_record.get("status")
        new_status = new_record.get("status")
        old_path_key = self._canonical_path_key(old_record.get("path"))
        new_path_key = self._canonical_path_key(new_record.get("path"))
        is_owner_acquisition = bool(new_token) and new_token != old_token
        is_terminal_requeue = (
            old_status in _TERMINAL_STATUSES
            and new_status not in _TERMINAL_STATUSES
        )
        is_new_reservation = (
            new_status not in _TERMINAL_STATUSES
            and (
                is_owner_acquisition
                or is_terminal_requeue
                or new_path_key != old_path_key
            )
        )
        if not is_new_reservation:
            return False

        path = new_record.get("path")
        path_key = self._canonical_path_key(path)
        part_key = self._canonical_path_key(str(path or "") + ".part")
        if not path_key:
            return False

        rows = connection.execute(
            """
            SELECT download_id, path_key, payload, revision
            FROM downloads
            WHERE download_id <> ?
            """,
            (download_id,),
        ).fetchall()
        for row in rows:
            other = self._record_from_row(row)
            if other.get("status") not in _TERMINAL_STATUSES:
                other_key = row["path_key"]
                other_part_key = self._canonical_path_key(
                    str(other.get("path") or "") + ".part"
                )
                if not (
                    path_key in (other_key, other_part_key)
                    or part_key in (other_key, other_part_key)
                ):
                    continue
                if is_terminal_requeue:
                    return True
                if other.get("owner_token") or other.get("status") in (
                    "downloading",
                    "pausing",
                    "canceling",
                    "repairing",
                    "finalizing",
                ):
                    return True
                # Deterministic winner for malformed/legacy duplicate queues:
                # one claim proceeds, then its owner blocks every other row.
                if is_owner_acquisition and str(row["download_id"]) < str(download_id):
                    return True
        return False

    def _path_is_reserved(self, connection, path_key, candidate):
        candidate_part_key = self._canonical_path_key(candidate + ".part")
        rows = connection.execute(
            """
            SELECT download_id, path_key, payload, revision
            FROM downloads
            WHERE status IS NULL OR status NOT IN ('complete', 'failed', 'canceled')
            """
        ).fetchall()
        for row in rows:
            record = self._record_from_row(row)
            other_key = row["path_key"]
            if not other_key:
                continue
            other_part_key = self._canonical_path_key(
                str(record.get("path") or "") + ".part"
            )
            if (
                path_key in (other_key, other_part_key)
                or candidate_part_key in (other_key, other_part_key)
            ):
                return True
        return False

    @staticmethod
    def _path_exists(path):
        try:
            return bool(xbmcvfs.exists(path))
        except Exception:
            return os.path.exists(path)

    @staticmethod
    def _next_queue_position(connection):
        rows = connection.execute(
            "SELECT payload FROM downloads WHERE status IN ('queued', 'paused', 'waiting_retry')"
        ).fetchall()
        maximum = 0
        for row in rows:
            try:
                record = json.loads(row["payload"])
                maximum = max(
                    maximum,
                    DownloadsDb._positive_int(record.get("queue_position")),
                )
            except (TypeError, ValueError, AttributeError):
                continue
        return maximum + 1

    @staticmethod
    def _positive_int(value):
        try:
            result = int(value)
            return result if result > 0 else 0
        except (TypeError, ValueError):
            return 0

    @staticmethod
    def _numbered_path(path, number):
        if number <= 1:
            return path
        directory, filename = DownloadsDb._split_path(path)
        stem, extension = os.path.splitext(filename)
        return f"{directory}{stem} ({number}){extension}"

    @staticmethod
    def _path_filename(path):
        return DownloadsDb._split_path(path)[1]

    @staticmethod
    def _split_path(path):
        separator_at = max(path.rfind("/"), path.rfind("\\"))
        if separator_at < 0:
            return "", path
        return path[: separator_at + 1], path[separator_at + 1 :]

    @staticmethod
    def _canonical_path_key(path):
        if not isinstance(path, str) or not path.strip():
            return None

        value = path.strip()
        try:
            value = xbmcvfs.translatePath(value)
        except Exception:
            pass

        if "://" in value:
            try:
                parts = urlsplit(value.replace("\\", "/"))
                normalized_path = posixpath.normpath(parts.path or "/")
                if parts.path.endswith("/") and not normalized_path.endswith("/"):
                    normalized_path += "/"
                value = urlunsplit(
                    (parts.scheme, parts.netloc, normalized_path, parts.query, parts.fragment)
                )
            except ValueError:
                value = value.replace("\\", "/")
        else:
            absolute = os.path.abspath(os.path.normpath(value))
            parent, filename = os.path.split(absolute)
            value = os.path.join(os.path.realpath(parent), filename).replace("\\", "/")

        return value.casefold()


def now_iso():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()
