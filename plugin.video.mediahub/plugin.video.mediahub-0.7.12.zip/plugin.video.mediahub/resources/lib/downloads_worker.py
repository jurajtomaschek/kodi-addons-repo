import os
import time
import urllib.request
import xbmc
import xbmcaddon
import xbmcvfs

from .downloads_db import DownloadsDb, now_iso

class DownloadsWorker:
    def __init__(self):
        self.db = DownloadsDb()
        self.monitor = xbmc.Monitor()
        addon = xbmcaddon.Addon()
        self.addon_id = addon.getAddonInfo("id")
        # retry_limit counts retries after the first attempt; max_attempts accounts for the initial try
        self.retry_limit = max(0, int(addon.getSetting("download_retry_limit") or 0))
        self.max_attempts = self.retry_limit + 1
        self.max_concurrent = max(1, int(addon.getSetting("max_concurrent_downloads") or 1))
        self._last_refresh = 0.0

    def run(self):
        xbmc.log("[DownloadsWorker] Started", xbmc.LOGINFO)
        self._requeue_incomplete()

        while not self.monitor.abortRequested():
            try:
                data = self.db.list()  # dict: id -> record

                if self._active_downloads(data) >= self.max_concurrent:
                    self.monitor.waitForAbort(1.0)
                    continue

                next_job = self._pick_next_job(data)

                if not next_job:
                    self.monitor.waitForAbort(1.0)
                    continue

                self._process_job(next_job)

            except Exception as ex:
                xbmc.log(f"[DownloadsWorker] Loop error: {ex}", xbmc.LOGERROR)
                self.monitor.waitForAbort(1.0)

        xbmc.log("[DownloadsWorker] Stopped", xbmc.LOGINFO)

    def _requeue_incomplete(self):
        data = self.db.list()
        for download_id, record in data.items():
            if record.get("status") != "downloading":
                continue

            dest = record.get("path")
            part_size = 0
            if dest:
                part = dest + ".part"
                part_size = self._get_part_size(part)

            total = record.get("bytes_total") or 0
            progress = int(100 * part_size / total) if total > 0 else 0
            self.db.update(download_id, {
                "status": "queued",
                "progress": progress,
                "bytes_done": part_size,
                "error": None,
                "updated_at": now_iso()
            })

    def _active_downloads(self, data: dict) -> int:
        return len([x for x in data.values() if x.get("status") == "downloading"])

    def _get_part_size(self, part_path: str) -> int:
        try:
            if not xbmcvfs.exists(part_path):
                return 0
            return xbmcvfs.Stat(part_path).st_size()
        except Exception:
            return 0

    def _pick_next_job(self, data: dict):
        queued = [x for x in data.values() if x.get("status") == "queued"]
        queued.sort(key=lambda x: x.get("created_at", ""))
        return queued[0] if queued else None

    def _maybe_refresh_downloads_view(self, throttle_sec=10.0, force=False):
        now = time.time()
        if not force and now - self._last_refresh < throttle_sec:
            return

        folder_path = xbmc.getInfoLabel("Container.FolderPath") or ""
        if not folder_path:
            return

        if f"plugin://{self.addon_id}" not in folder_path:
            return

        if "action=show_downloads_menu" not in folder_path:
            return

        xbmc.executebuiltin("Container.Refresh")
        self._last_refresh = now

    def _process_job(self, job: dict):
        download_id = job["id"]
        url = job["url"]
        dest = job["path"]
        part = dest + ".part"
        existing_size = self._get_part_size(part)
        chunk_size = 256 * 1024  # larger buffer to reduce overhead
        attempts = int(job.get("attempts") or 0)

        if attempts >= self.max_attempts:
            self.db.update(download_id, {
                "status": "failed",
                "error": "Retry limit reached",
                "attempts": attempts,
                "updated_at": now_iso()
            })
            self._maybe_refresh_downloads_view(force=True)
            return

        current_attempt = attempts + 1

        # if user canceled before start
        current = self.db.list().get(download_id, {})
        if current.get("status") == "canceled":
            return

        self.db.update(download_id, {
            "status": "downloading",
            "error": None,
            "attempts": current_attempt,
            "updated_at": now_iso()
        })
        if existing_size > 0:
            xbmc.executebuiltin(f'Notification(Download,Resuming {os.path.basename(dest)},2000)')
        else:
            xbmc.executebuiltin(f'Notification(Download,Starting {os.path.basename(dest)},2000)')

        try:
            request = urllib.request.Request(url)
            if existing_size > 0:
                request.add_header("Range", f"bytes={existing_size}-")

            with urllib.request.urlopen(request, timeout=60) as response:
                status = getattr(response, "status", response.getcode())
                total = 0
                content_range = response.headers.get("content-range")
                if content_range:
                    total_part = content_range.split("/")[-1].strip()
                    total = int(total_part) if total_part.isdigit() else 0

                if total == 0:
                    total_header = response.headers.get("content-length")
                    if total_header and total_header.isdigit():
                        total = int(total_header)
                        if status == 206 and existing_size > 0:
                            total += existing_size

                if status == 200 and existing_size > 0:
                    existing_size = 0

                progress = int(100 * existing_size / total) if total > 0 else 0
                self.db.update(download_id, {
                    "bytes_total": total if total > 0 else None,
                    "bytes_done": existing_size,
                    "progress": progress,
                    "attempts": current_attempt,
                    "updated_at": now_iso()
                })

                downloaded = existing_size
                last_saved_percent = progress if total > 0 else -1
                last_progress_update = time.time()
                last_cancel_check = time.time()
                cancel_check_interval = 20.0
                progress_update_interval = 10.0

                # ensure folder exists
                folder = os.path.dirname(dest)
                if folder and not xbmcvfs.exists(folder):
                    xbmcvfs.mkdirs(folder)

                mode = "a" if existing_size > 0 and status == 206 else "w"
                f = xbmcvfs.File(part, mode)
                try:
                    while True:
                        if self.monitor.abortRequested():
                            raise Exception("Kodi abortRequested")

                        # check cancel flag in DB on a short interval
                        now = time.time()
                        if now - last_cancel_check >= cancel_check_interval:
                            cur = self.db.list().get(download_id, {})
                            if cur.get("status") == "canceled":
                                raise Exception("Canceled")
                            last_cancel_check = now

                        chunk = response.read(chunk_size)
                        if not chunk:
                            break
                        f.write(bytearray(chunk))
                        downloaded += len(chunk)

                        if total > 0:
                            percent = int(100 * downloaded / total)
                            if percent >= last_saved_percent + 5 or now - last_progress_update >= progress_update_interval:
                                self.db.update(download_id, {
                                    "progress": percent,
                                    "bytes_done": downloaded,
                                    "updated_at": now_iso()
                                })
                                last_saved_percent = percent
                                last_progress_update = now
                                self._maybe_refresh_downloads_view()
                finally:
                    f.close()

            if xbmcvfs.exists(dest):
                xbmcvfs.delete(dest)
            xbmcvfs.rename(part, dest)

            self.db.update(download_id, {
                "status": "complete",
                "progress": 100,
                "bytes_done": downloaded,
                "attempts": current_attempt,
                "updated_at": now_iso()
            })
            self._maybe_refresh_downloads_view(force=True)
            xbmc.executebuiltin(f'Notification(Download,Completed {os.path.basename(dest)},3000)')

        except Exception as ex:
            # if it was explicitly canceled, keep that status; otherwise mark failed
            cur = self.db.list().get(download_id, {})
            notify_failed = False
            if cur.get("status") == "canceled":
                try:
                    if xbmcvfs.exists(part):
                        xbmcvfs.delete(part)
                except Exception:
                    pass
                xbmc.executebuiltin(f'Notification(Download,Canceled {os.path.basename(dest)},2500)')
                self.db.update(download_id, {"updated_at": now_iso(), "progress": cur.get("progress", 0)})
            elif str(ex) == "Kodi abortRequested":
                part_size = self._get_part_size(part)
                total = cur.get("bytes_total") or 0
                progress = int(100 * part_size / total) if total > 0 else cur.get("progress", 0)
                self.db.update(download_id, {
                    "status": "queued",
                    "bytes_done": part_size,
                    "progress": progress,
                    "error": None,
                    "attempts": current_attempt,
                    "updated_at": now_iso()
                })
            elif current_attempt < self.max_attempts:
                self.db.update(download_id, {
                    "status": "queued",
                    "error": str(ex),
                    "attempts": current_attempt,
                    "updated_at": now_iso()
                })
            else:
                self.db.update(download_id, {
                    "status": "failed",
                    "error": str(ex),
                    "attempts": current_attempt,
                    "updated_at": now_iso()
                })
                notify_failed = True
            self._maybe_refresh_downloads_view(force=True)
            if notify_failed:
                xbmc.executebuiltin(f'Notification(Download,Failed {os.path.basename(dest)},4000)')
