"""Controller for the fullscreen Media Hub application shell."""

import threading
import xbmc
import xbmcgui
try:
    from .localization import tr
except ImportError:  # Direct module loading used by the lightweight test harness.
    from resources.lib.localization import tr


XML_FILENAME = "MediaHubHome.xml"
ADDON_ID = "plugin.video.mediahub"

NAV = 100
SEARCH = 200
QUIT = 220
TABS = 210
HOME_PRIMARY = 300
HOME_SECONDARY = 310
CATALOG = 400
HISTORY = 420
BROWSER = 430
DOWNLOADS = 500
SETTINGS = 510
DETAIL_ACTIONS = 600
CONTEXT_MENU = 700
FILTER_GROUPS = 800
FILTER_OPTIONS = 810
FILTER_ACTIONS = 820
FILTER_RESULTS = 830
FILTER_RESULT_ACTIONS = 840
FILTER_RESULT_CHIPS = 850
FILTER_PAGINATION = 860

# Compatibility names used by older tests and callers.
QUICK = HOME_PRIMARY
FAVORITES = HOME_SECONDARY

_BACK_ACTIONS = frozenset((9, 10, 92, 110))
BROWSER_PAGES = frozenset(("browse", "filters", "filterresults"))
DOWNLOAD_REFRESH_INTERVAL_SECONDS = 1.0
_CONTROL_NAMES = {
    NAV: "navigation",
    TABS: "tabs",
    HOME_PRIMARY: "home primary",
    HOME_SECONDARY: "home secondary",
    CATALOG: "catalog",
    HISTORY: "history",
    BROWSER: "browser",
    DOWNLOADS: "downloads",
    SETTINGS: "settings",
    DETAIL_ACTIONS: "detail actions",
    CONTEXT_MENU: "context menu",
    FILTER_GROUPS: "filter groups",
    FILTER_OPTIONS: "filter options",
    FILTER_ACTIONS: "filter actions",
    FILTER_RESULTS: "filter results",
    FILTER_RESULT_ACTIONS: "filter result actions",
    FILTER_RESULT_CHIPS: "filter result chips",
    FILTER_PAGINATION: "filter pagination",
}

_PAGE_TITLES = {
    "home": ("Home", "Everything worth watching, all in one place"),
    "movies": ("Movies", "Find and watch great movies"),
    "tv": ("TV Series", "Find your next great series"),
    "downloads": ("Downloads", "Your offline library and active transfers"),
    "favorites": ("Favourites", "Movies and series saved for later"),
    "history": ("Recently Viewed", "Continue where you left off"),
    "settings": ("Settings", "Playback, downloads and account preferences"),
    "search": ("Search", "Find movies and TV series"),
    "browse": ("Browse", "Explore Media Hub"),
    "filters": ("Discover", "Build your perfect watchlist"),
    "filterresults": ("Discovery Results", "Titles matching your filters"),
}


def _log(message, level=None):
    if level is None:
        level = xbmc.LOGDEBUG
    try:
        xbmc.log("[Media Hub app] {0}".format(message), level)
    except Exception:
        pass


def _models(value):
    if value is None:
        return []
    try:
        values = list(value)
    except TypeError:
        return []
    return [model for model in values if isinstance(model, dict)]


def _text(value):
    if value is None:
        return ""
    if isinstance(value, bool):
        return "true" if value else "false"
    return str(value)


def _model_property(model, key, default=""):
    properties = model.get("properties")
    if not isinstance(properties, dict):
        return _text(default)
    return _text(properties.get(key, default))


class MediaHubHomeDialog(xbmcgui.WindowXML):
    """Single-window, remote-first interface for every primary addon page."""

    def __init__(self, *args, **kwargs):
        self.navigation = _models(kwargs.pop("navigation", None))
        self.home_primary = _models(
            kwargs.pop("home_primary", kwargs.pop("quick_items", None))
        )
        secondary_items = kwargs.pop("home_secondary", None)
        favorite_items = kwargs.pop("favorite_items", None)
        self.home_secondary = _models(
            secondary_items if secondary_items is not None else favorite_items
        )
        self.favorite_items = _models(
            favorite_items if favorite_items is not None else self.home_secondary
        )
        self.history_items = _models(kwargs.pop("history_items", None))
        self.download_items = _models(kwargs.pop("download_items", None))
        self._download_row_targets = [
            _text(model.get("target")) for model in self.download_items
        ]
        self.settings_items = _models(kwargs.pop("settings_items", None))
        self.fallback_art = _text(kwargs.pop("fallback_art", ""))
        self.logo_art = _text(kwargs.pop("logo_art", ""))
        self.initial_page = _text(kwargs.pop("initial_page", "home")) or "home"
        self.catalog_loader = kwargs.pop("catalog_loader", None)
        self.catalog_page_loader = kwargs.pop("catalog_page_loader", None)
        self.catalog_columns = max(1, int(kwargs.pop("catalog_columns", 6)))
        self.search_loader = kwargs.pop("search_loader", None)
        self.home_loader = kwargs.pop("home_loader", None)
        self.browser_loader = kwargs.pop("browser_loader", None)
        self.discovery_targets = dict(kwargs.pop("discovery_targets", None) or {})
        self.action_handler = kwargs.pop("action_handler", None)
        self.play_handler = kwargs.pop("play_handler", None)
        self.state_loader = kwargs.pop("state_loader", None)
        self.initial_target = _text(kwargs.pop("initial_target", ""))
        self.result = None

        self._page = ""
        self._previous_page = "home"
        self._catalog_cache = {}
        self._catalog_pages = {}
        self._catalog_exhausted = set()
        self._catalog_page_loading = False
        self._filter_page_loading = False
        self._tabs = []
        self._catalog_items = []
        self._browser_items = []
        self._browser_targets = []
        self._browser_origin = "home"
        self._browser_view = {}
        self._browser_return_state = None
        self._filter_groups = []
        self._filter_options = []
        self._filter_actions = []
        self._filter_results = []
        self._filter_result_actions = []
        self._filter_result_chips = []
        self._filter_pagination = []
        self._context_items = []
        self._context_open = False
        self._context_origin_control = None
        self._nav_index = {}
        self._nav_position = None
        self._tab_position = None
        self._active_catalog_tab = ""
        self._initialized = False
        self._reactivation_state = None
        self._close_event = threading.Event()
        self._home_refresh_thread = None
        self._downloads_refresh_thread = None

        self._items_by_control = {
            NAV: self.navigation,
            TABS: self._tabs,
            HOME_PRIMARY: self.home_primary,
            HOME_SECONDARY: self.home_secondary,
            CATALOG: self._catalog_items,
            HISTORY: self.history_items,
            BROWSER: self._browser_items,
            DOWNLOADS: self.download_items,
            SETTINGS: self.settings_items,
            DETAIL_ACTIONS: [],
            CONTEXT_MENU: self._context_items,
            FILTER_GROUPS: self._filter_groups,
            FILTER_OPTIONS: self._filter_options,
            FILTER_ACTIONS: self._filter_actions,
            FILTER_RESULTS: self._filter_results,
            FILTER_RESULT_ACTIONS: self._filter_result_actions,
            FILTER_RESULT_CHIPS: self._filter_result_chips,
            FILTER_PAGINATION: self._filter_pagination,
        }

    def onInit(self):
        try:
            self.setProperty("App.FallbackArt", self.fallback_art)
            self.setProperty("App.Logo", self.logo_art)
            self.setProperty(
                "App.HomePrimaryTitle",
                tr("Continue Watching") if self.history_items else tr("Featured"),
            )
            self.setProperty(
                "App.HomeSecondaryTitle",
                tr("My List") if self.home_secondary else tr("Discover"),
            )
            self.setProperty(
                "App.HasHomeSecondary",
                "true" if self.home_secondary else "false",
            )
            if not self._initialized:
                self.setProperty(
                    "App.HomeReady",
                    "false" if callable(self.home_loader) else "true",
                )
            self.setProperty("App.ContextOpen", "false")
            self.setProperty("App.Loading", "false")
            for name, text in {
                "SearchLabel": "Search",
                "QuitLabel": "Quit",
                "LoadingLabel": "LOADING",
                "StreamOptionsLabel": "STREAM OPTIONS",
                "ContextHelp": "OK  Select     BACK  Close",
                "EmptyTitle": "No titles to show",
                "EmptyHint": "Try another tab, search, or check the API connection.",
                "OpenSettingsLabel": "Open addon settings",
                "InterfaceLabel": "Media Hub interface",
                "ModernLabel": "Modern",
                "NothingHereLabel": "Nothing here yet",
                "SummaryLabel": "SUMMARY",
            }.items():
                self.setProperty("App." + name, tr(text))
        except Exception as exc:
            _log("Could not initialize window properties: {0}".format(exc), xbmc.LOGERROR)

        self._nav_index = {
            _model_property(model, "App.Page"): index
            for index, model in enumerate(self.navigation)
            if _model_property(model, "App.Page")
        }
        for control_id in (
            NAV,
            HOME_PRIMARY,
            HOME_SECONDARY,
            HISTORY,
            DOWNLOADS,
            SETTINGS,
        ):
            self._populate_control(control_id, self._items_by_control[control_id])

        if self._initialized:
            self._restore_reactivated_window()
            return
        self._initialized = True
        self._show_page(self.initial_page, load=True)
        if self.initial_target:
            self._open_browser(self.initial_target)
        if callable(self.home_loader):
            self._home_refresh_thread = threading.Thread(
                target=self._load_home_background,
                name="MediaHubHomeLoader",
                daemon=True,
            )
            self._home_refresh_thread.start()
        if callable(self.state_loader):
            self._downloads_refresh_thread = threading.Thread(
                target=self._refresh_downloads_background,
                name="MediaHubDownloadsRefresher",
                daemon=True,
            )
            self._downloads_refresh_thread.start()

    def close(self):
        self._close_event.set()
        return super().close()

    def onClick(self, control_id):
        try:
            if control_id == CONTEXT_MENU:
                model = self._selected_model(CONTEXT_MENU)
                if model is not None:
                    self._close_context_menu(restore_focus=True)
                    self._activate(model)
                return

            if control_id == SEARCH:
                self._show_search()
                return

            if control_id == QUIT:
                self.result = {"command": "quit"}
                self.close()
                return

            model = self._selected_model(control_id)
            if model is None:
                return

            if control_id == NAV:
                page = _model_property(model, "App.Page", "home")
                self._show_page(page, load=True)
            elif control_id == TABS:
                tab = _model_property(model, "App.Tab")
                if tab == "filters":
                    self._activate(model)
                else:
                    self._load_catalog(self._page, tab, force=False)
            elif control_id == DETAIL_ACTIONS:
                self._activate_detail_action(model)
            else:
                self._activate(model)
        except Exception as exc:
            _log(
                "Click handling failed for control {0}: {1}".format(control_id, exc),
                xbmc.LOGERROR,
            )

    def onFocus(self, control_id):
        if control_id == TABS:
            self._remember_tab_position()
            return
        if control_id == FILTER_OPTIONS and self._page == "filters":
            group = self._selected_model(FILTER_GROUPS)
            section = _text(self._browser_view.get("section"))
            group_key = (
                _model_property(group, "App.FilterKey")
                if group is not None
                else ""
            )
            if group_key and group_key != section:
                target = _text(group.get("target")).strip()
                if target:
                    self._open_browser(target, replace=True)
                    selected_option_index = next(
                        (
                            index
                            for index, model in enumerate(
                                self._filter_options
                            )
                            if _model_property(
                                model,
                                "App.Selected",
                            ) == "true"
                        ),
                        0,
                    )
                    if self._filter_options:
                        try:
                            self.getControl(
                                FILTER_OPTIONS
                            ).selectItem(selected_option_index)
                        except Exception:
                            pass
            return
        if control_id != NAV:
            return
        page = self._navigation_page(self._page)
        self._select_navigation(page)
        self._remember_navigation_position()

    def onAction(self, action):
        try:
            action_id = action.getId()
        except (AttributeError, TypeError):
            try:
                action_id = int(action)
            except (TypeError, ValueError):
                return

        if self._context_open:
            if action_id in _BACK_ACTIONS or action_id in (101, 117):
                self._close_context_menu()
            return
        if action_id in (101, 117):
            self._open_context_menu()
            return
        if action_id not in _BACK_ACTIONS:
            self._sync_navigation_selection()
            self._sync_tab_selection()
            if action_id == 4:
                self._load_next_catalog_page_if_needed()
                self._load_next_filter_results_page_if_needed()
            return
        if self._page in BROWSER_PAGES:
            self._close_browser_level()
            return
        if self._page == "detail":
            self._show_page(self._previous_page, load=False)
            return

        if self._page != "home":
            self._show_page("home", load=False)
            return

        # Keep the application shell open at its root. In particular, do not
        # close the window here: repeated/queued Back actions would otherwise
        # continue through Kodi's navigation stack and leave the add-on.
        self._focus_home_content()

    def _show_page(self, page, load=True, focus=True):
        if page not in _PAGE_TITLES and page != "detail":
            page = "home"
        if page != "detail":
            self._previous_page = page
        self._page = page
        self.setProperty("App.Page", page)

        title, subtitle = _PAGE_TITLES.get(page, ("", ""))
        title, subtitle = tr(title), tr(subtitle)
        self.setProperty("App.PageTitle", title)
        self.setProperty("App.PageSubtitle", subtitle)
        navigation_page = self._navigation_page(page)
        self.setProperty("App.NavPage", navigation_page)
        self._select_navigation(navigation_page)

        if page in ("movies", "tv"):
            self._set_tabs(page)
            selected_tab = self._active_catalog_tab
            if load:
                self._load_catalog(page, selected_tab, force=False, focus=focus)
            if self._tabs:
                try:
                    self.getControl(TABS).selectItem(0)
                    self._tab_position = 0
                except Exception:
                    pass
            if focus:
                self._focus(CATALOG if self._catalog_items else TABS)
        elif page == "favorites":
            self._set_catalog(self.favorite_items)
            if focus:
                self._focus(CATALOG if self._catalog_items else NAV)
        elif page == "history":
            if focus:
                self._focus(HISTORY if self.history_items else NAV)
        elif page == "downloads":
            if focus:
                self._focus(DOWNLOADS if self.download_items else NAV)
        elif page == "settings":
            if focus:
                self._focus(SETTINGS if self.settings_items else NAV)
        elif page == "search":
            if focus:
                self._focus(CATALOG if self._catalog_items else SEARCH)
        elif page == "browse":
            restored = self._restore_browser_state(focus=focus)
            if not restored and focus:
                self._focus(BROWSER if self._browser_items else NAV)
        elif page == "filters":
            restored = self._restore_browser_state(focus=focus)
            if not restored:
                self._apply_filter_studio_view(self._browser_view, focus=focus)
        elif page == "filterresults":
            restored = self._restore_browser_state(focus=focus)
            if not restored:
                self._apply_filter_results_view(self._browser_view, focus=focus)
        elif page == "home" and focus:
            self._focus(
                HOME_PRIMARY
                if self.home_primary
                else HOME_SECONDARY
                if self.home_secondary
                else NAV
            )

    def _set_tabs(self, page):
        labels = (
            (
                (
                    tr("Popular"),
                    "popular",
                    "Trending now",
                    "category-popular.png",
                ),
                (
                    tr("New Releases"),
                    "latest",
                    "Just added",
                    "category-latest.png",
                ),
                (
                    tr("Top Rated"),
                    "top",
                    "Best reviewed",
                    "category-top-rated.png",
                ),
                (
                    tr("Discover / Filters"),
                    "filters",
                    "Build your perfect watchlist",
                    "filter-funnel.png",
                ),
            )
            if page == "movies"
            else (
                (
                    tr("Popular"),
                    "popular",
                    "Trending now",
                    "category-popular.png",
                ),
                (
                    tr("New Releases"),
                    "latest",
                    "Just added",
                    "category-latest.png",
                ),
                (
                    tr("Recently Aired"),
                    "recent",
                    "Recently shown",
                    "category-recent.png",
                ),
                (
                    tr("Slovak"),
                    "slovak",
                    "Slovak productions",
                    "category-slovak.png",
                ),
                (
                    tr("Discover / Filters"),
                    "filters",
                    "Build your perfect watchlist",
                    "filter-funnel.png",
                ),
            )
        )
        self._tabs[:] = [
            {
                "label": label,
                "command": "browse" if value == "filters" else "tab",
                "target": (
                    _text(self.discovery_targets.get(page))
                    if value == "filters"
                    else ""
                ),
                "properties": {
                    "App.Tab": value,
                    "App.Hint": hint,
                    "App.Icon": icon,
                },
            }
            for label, value, hint, icon in labels
        ]
        default_index = next(
            (
                index
                for index, model in enumerate(self._tabs)
                if _model_property(model, "App.Tab") != "filters"
            ),
            0,
        )
        active_tab = (
            _model_property(self._tabs[default_index], "App.Tab")
            if self._tabs
            else ""
        )
        self._active_catalog_tab = active_tab
        self._tab_position = default_index
        self.setProperty("App.ActiveTab", active_tab)
        self._populate_control(TABS, self._tabs)
        if self._tabs:
            try:
                self.getControl(TABS).selectItem(default_index)
            except Exception:
                pass

    def _load_catalog(self, page, tab, force=False, query="", focus=True):
        if page in ("movies", "tv") and tab:
            self.setProperty("App.ActiveTab", tab)
            if tab != "filters":
                self._active_catalog_tab = tab
        cache_key = (page, tab, query)
        if not force and cache_key in self._catalog_cache:
            self._set_catalog(self._catalog_cache[cache_key])
            if focus:
                self._focus(CATALOG if self._catalog_items else TABS)
            return

        loader = self.search_loader if page == "search" else self.catalog_loader
        if not callable(loader):
            self._set_catalog([])
            return

        self.setProperty("App.Loading", "true")
        try:
            if page == "search":
                models = loader(query)
            else:
                models = loader(page, tab)
            models = _models(models)
            self._catalog_cache[cache_key] = models
            self._catalog_pages[cache_key] = 1
            self._catalog_exhausted.discard(cache_key)
            self._set_catalog(models)
        except Exception as exc:
            _log("Could not load {0}/{1}: {2}".format(page, tab, exc), xbmc.LOGERROR)
            self._set_catalog([])
            try:
                xbmcgui.Dialog().notification(
                    "Media Hub",
                    tr("Content could not be loaded."),
                    xbmcgui.NOTIFICATION_ERROR,
                    2500,
                )
            except Exception:
                pass
        finally:
            self.setProperty("App.Loading", "false")

        if focus:
            self._focus(CATALOG if self._catalog_items else TABS)

    def _load_next_catalog_page_if_needed(self):
        if (
            self._page not in ("movies", "tv")
            or not callable(self.catalog_page_loader)
            or self._catalog_page_loading
            or not self._catalog_items
        ):
            return
        try:
            control = self.getControl(CATALOG)
            position = int(control.getSelectedPosition())
        except Exception:
            return
        # Kodi calls onAction before the panel applies the Down movement. The
        # poster panel is six columns wide, so anticipate entry into the final
        # row and fetch while the penultimate row is focused. Waiting until the
        # reported position is already in the final row is unreliable because
        # some Kodi versions stop dispatching Down at the panel boundary.
        if position < max(
            0, len(self._catalog_items) - (self.catalog_columns * 2 + 1)
        ):
            return

        tab = self._active_catalog_tab
        if not tab or tab == "filters":
            tab = next(
                (
                    _model_property(model, "App.Tab")
                    for model in self._tabs
                    if _model_property(model, "App.Tab") != "filters"
                ),
                "",
            )
        if not tab:
            return
        cache_key = (self._page, tab, "")
        if cache_key in self._catalog_exhausted:
            return
        next_page = self._catalog_pages.get(cache_key, 1) + 1
        self._catalog_page_loading = True
        self.setProperty("App.Loading", "true")
        try:
            models = _models(self.catalog_page_loader(self._page, tab, next_page))
            if not models:
                self._catalog_exhausted.add(cache_key)
                return
            existing_ids = {
                (_model_property(model, "App.Kind"), _model_property(model, "App.Id"))
                for model in self._catalog_items
                if _model_property(model, "App.Id")
            }
            additions = [
                model for model in models
                if not _model_property(model, "App.Id")
                or (
                    _model_property(model, "App.Kind"),
                    _model_property(model, "App.Id"),
                ) not in existing_ids
            ]
            self._catalog_pages[cache_key] = next_page
            if not additions:
                self._catalog_exhausted.add(cache_key)
                return
            combined = list(self._catalog_items) + additions
            self._catalog_cache[cache_key] = combined
            self._set_catalog(combined)
            try:
                self.getControl(CATALOG).selectItem(position)
            except Exception:
                pass
        except Exception as exc:
            _log(
                "Could not load catalog page {0}: {1}".format(next_page, exc),
                xbmc.LOGERROR,
            )
        finally:
            self.setProperty("App.Loading", "false")
            self._catalog_page_loading = False

    def _load_next_filter_results_page_if_needed(self):
        if (
            self._page != "filterresults"
            or not callable(self.browser_loader)
            or self._filter_page_loading
            or not self._filter_results
        ):
            return
        try:
            if int(self.getFocusId()) != FILTER_RESULTS:
                return
            control = self.getControl(FILTER_RESULTS)
            position = int(control.getSelectedPosition())
        except Exception:
            return
        # As with the regular movie/TV catalog, Kodi reports the selection
        # before applying Down. Start loading while focus is in the penultimate
        # six-column row so navigation never reaches a hard end to the grid.
        if position < max(
            0, len(self._filter_results) - (self.catalog_columns * 2 + 1)
        ):
            return

        target = _text(
            self._browser_view.get("next_page_target")
        ).strip()
        if not target:
            return

        self._filter_page_loading = True
        self.setProperty("App.Loading", "true")
        try:
            view = self.browser_loader(target)
            if not isinstance(view, dict) or (
                _text(view.get("layout")).strip().lower() != "filter_results"
            ):
                return

            existing_ids = {
                (_model_property(model, "App.Kind"), _model_property(model, "App.Id"))
                for model in self._filter_results
                if _model_property(model, "App.Id")
            }
            existing_targets = {
                _text(model.get("target"))
                for model in self._filter_results
                if _text(model.get("target"))
            }
            additions = []
            for model in _models(view.get("items")):
                media_id = _model_property(model, "App.Id")
                identity = (_model_property(model, "App.Kind"), media_id)
                item_target = _text(model.get("target"))
                if media_id and identity in existing_ids:
                    continue
                if not media_id and item_target and item_target in existing_targets:
                    continue
                additions.append(model)
                if media_id:
                    existing_ids.add(identity)
                elif item_target:
                    existing_targets.add(item_target)

            combined_view = dict(view)
            combined_view["items"] = list(self._filter_results) + additions
            if self._browser_targets:
                self._browser_targets[-1] = target
            else:
                self._browser_targets = [target]
            self._browser_view = combined_view
            self._apply_filter_results_view(combined_view, focus=False)
            try:
                self.getControl(FILTER_RESULTS).selectItem(position)
            except Exception:
                pass
        except Exception as exc:
            _log(
                "Could not load discovery results page: {0}".format(exc),
                xbmc.LOGERROR,
            )
        finally:
            self.setProperty("App.Loading", "false")
            self._filter_page_loading = False

    def _show_search(self):
        try:
            keyboard = xbmc.Keyboard("", tr("Search movies and TV series"))
            keyboard.doModal()
            if not keyboard.isConfirmed():
                return
            query = _text(keyboard.getText()).strip()
        except Exception as exc:
            _log("Could not open search keyboard: {0}".format(exc), xbmc.LOGERROR)
            return
        if not query:
            return

        self._page = "search"
        self.setProperty("App.Page", "search")
        self.setProperty("App.PageTitle", tr("Search"))
        self.setProperty("App.PageSubtitle", tr("Results for “{0}”", query))
        self._select_navigation("")
        self._load_catalog("search", "results", force=True, query=query)

    def _load_home_background(self):
        try:
            if self._close_event.is_set():
                return
            loaded = self.home_loader()
            if self._close_event.is_set():
                return
            if not isinstance(loaded, (list, tuple)) or len(loaded) != 2:
                return
            primary, secondary = (_models(loaded[0]), _models(loaded[1]))
            if primary:
                if self._close_event.is_set():
                    return
                self.home_primary[:] = primary
                self._populate_control(HOME_PRIMARY, self.home_primary)
                self.setProperty("App.HomePrimaryTitle", tr("Trending Now"))
            if secondary:
                if self._close_event.is_set():
                    return
                self.home_secondary[:] = secondary
                self._populate_control(HOME_SECONDARY, self.home_secondary)
                self.setProperty("App.HomeSecondaryTitle", tr("Popular TV Series"))
                self.setProperty("App.HasHomeSecondary", "true")
        except Exception as exc:
            _log("Could not refresh home artwork: {0}".format(exc), xbmc.LOGWARNING)
        finally:
            # The initially supplied history/favourites shelves are a fallback,
            # not an intermediate home-page render. Reveal the page only after
            # the online shelves have either replaced them or failed to load.
            if not self._close_event.is_set():
                self.setProperty("App.HomeReady", "true")

    def _refresh_downloads_background(self):
        while not self._close_event.wait(
            DOWNLOAD_REFRESH_INTERVAL_SECONDS
        ):
            if self._page != "downloads":
                continue
            self._refresh_state(downloads_only=True)

    def _set_catalog(self, models):
        self._catalog_items[:] = _models(models)
        self._populate_control(CATALOG, self._catalog_items)
        self.setProperty("App.HasCatalog", "true" if self._catalog_items else "false")

    def _show_detail(self, model):
        if self._page in BROWSER_PAGES:
            try:
                browser_focus_id = int(self.getFocusId())
            except (TypeError, ValueError):
                browser_focus_id = None
            browser_selection = (
                self._control_selection(browser_focus_id)
                if browser_focus_id in self._items_by_control
                else {}
            )
            # Kodi can report the temporary navigation handoff as focused while
            # a result click is being dispatched. The clicked model is the
            # authoritative return target, so retain it directly.
            if self._page == "filterresults":
                clicked_target = _text(model.get("target"))
                for index, candidate in enumerate(self._filter_results):
                    if candidate is model or (
                        clicked_target
                        and _text(candidate.get("target")) == clicked_target
                    ):
                        browser_focus_id = FILTER_RESULTS
                        browser_selection = {
                            "position": index,
                            "target": clicked_target,
                            "command": _text(model.get("command")),
                            "label": _text(model.get("label")),
                            "filter_key": _model_property(
                                model,
                                "App.FilterKey",
                            ),
                        }
                        break
            self._browser_return_state = {
                "page": self._page,
                "targets": list(self._browser_targets),
                "view": dict(self._browser_view),
                "items": list(self._browser_items),
                "focus_id": browser_focus_id,
                "selection": browser_selection,
            }
        elif self._page != "detail":
            self._browser_return_state = None
        self._previous_page = self._page if self._page != "detail" else self._previous_page
        self._page = "detail"
        self.setProperty("App.Page", "detail")

        properties = model.get("properties") if isinstance(model.get("properties"), dict) else {}
        detail_values = {
            "App.Detail.Title": properties.get("MediaHub.Title") or model.get("label"),
            "App.Detail.Eyebrow": properties.get("MediaHub.Eyebrow") or "MEDIA HUB",
            "App.Detail.Meta": properties.get("MediaHub.Meta") or model.get("label2"),
            "App.Detail.Description": properties.get("MediaHub.Description"),
            "App.Detail.HeroDescription": (
                properties.get("MediaHub.HeroDescription")
                or properties.get("MediaHub.Description")
            ),
            "App.Detail.Year": properties.get("App.Year") or "—",
            "App.Detail.Rating": properties.get("App.Rating") or "—",
            "App.Detail.Kind": properties.get("App.KindLabel") or "Media",
            "App.Detail.Fanart": (model.get("art") or {}).get("fanart", ""),
            "App.Detail.Poster": (model.get("art") or {}).get("poster", ""),
        }
        for key, value in detail_values.items():
            self.setProperty(key, _text(value))

        target = _text(model.get("target"))
        primary_label = tr("SEASONS") if properties.get("App.Kind") == "tv" else tr("PLAY")
        actions = [
            {
                "label": primary_label,
                "command": "browse" if callable(self.browser_loader) else "navigate",
                "target": target,
                "properties": {"App.ActionGlyph": "▶"},
            },
            {
                "label": tr("BACK"),
                "command": "back_detail",
                "target": "",
                "properties": {"App.ActionGlyph": "←"},
            },
        ]
        self._items_by_control[DETAIL_ACTIONS] = actions
        self._populate_control(DETAIL_ACTIONS, actions)

        self._focus(DETAIL_ACTIONS)

    def _activate_detail_action(self, model):
        command = _text(model.get("command")).strip().lower()
        if command == "back_detail":
            self._show_page(self._previous_page, load=False)
        else:
            self._activate(model)

    def _activate(self, model):
        command = _text(model.get("command")).strip().lower()
        target = _text(model.get("target")).strip()

        if command == "page":
            self._show_page(_model_property(model, "App.Page", "home"), load=True)
        elif command == "detail":
            self._show_detail(model)
        elif command == "browse":
            self._open_browser(target)
        elif command == "browser_replace":
            self._open_browser(target, replace=True)
        elif command == "browser_back":
            self._close_browser_level()
        elif command == "edit_filters":
            if target:
                self._open_browser(target)
        elif command == "apply_filters":
            if target:
                current_filter_target = (
                    self._browser_targets[-1]
                    if self._browser_targets
                    else ""
                )
                self._browser_targets = (
                    [current_filter_target]
                    if current_filter_target
                    else []
                )
                self._open_browser(target)
        elif command == "navigate":
            if target:
                self.result = {"command": "navigate", "target": target}
                self.close()
        elif command == "play":
            if target:
                handled = False
                if callable(self.play_handler):
                    reactivation_state = self._capture_reactivation_state()
                    self.setProperty("App.Loading", "true")
                    try:
                        outcome = self.play_handler(target)
                        handled = outcome is not False
                        if outcome is True:
                            self._reactivation_state = reactivation_state
                            self._refresh_state()
                    except Exception as exc:
                        _log(
                            "Direct playback failed for {0}: {1}".format(
                                target, exc
                            ),
                            xbmc.LOGERROR,
                        )
                    finally:
                        self.setProperty("App.Loading", "false")
                if not handled:
                    xbmc.executebuiltin("PlayMedia({0})".format(target))
        elif command == "builtin":
            if target:
                xbmc.executebuiltin(target)
        elif command == "action":
            self._run_action(target)
        elif command == "run":
            if target:
                xbmc.executebuiltin("RunPlugin({0})".format(target))
        elif command == "settings":
            xbmc.executebuiltin("Addon.OpenSettings({0})".format(ADDON_ID))
        elif command == "back_detail":
            self._show_page(self._previous_page, load=False)
        else:
            _log("Ignored unsupported app command: {0}".format(command), xbmc.LOGWARNING)

    def _open_browser(self, target, replace=False):
        target = _text(target).strip()
        if not target or not callable(self.browser_loader):
            return

        previous_page = self._page
        restore_control_id = None
        restore_selection = None
        browser_transition = previous_page in BROWSER_PAGES
        if replace and previous_page in BROWSER_PAGES:
            try:
                candidate = int(self.getFocusId())
            except (TypeError, ValueError):
                candidate = None
            if candidate in self._items_by_control:
                restore_control_id = candidate
                restore_selection = self._control_selection(candidate)
        self.setProperty("App.Loading", "true")
        try:
            view = self.browser_loader(target)
        except Exception as exc:
            _log("Could not load browser target {0}: {1}".format(target, exc), xbmc.LOGERROR)
            try:
                xbmcgui.Dialog().notification(
                    "Media Hub",
                    tr("This screen could not be loaded."),
                    xbmcgui.NOTIFICATION_ERROR,
                    2500,
                )
            except Exception:
                pass
            return
        finally:
            self.setProperty("App.Loading", "false")

        if not isinstance(view, dict):
            return
        in_place_refresh = (
            restore_control_id == FILTER_OPTIONS
            and _text(view.get("layout")).strip().lower() == "filter_studio"
            and self._can_update_control_in_place(
                FILTER_OPTIONS,
                _models(view.get("options")),
            )
        )
        if previous_page not in BROWSER_PAGES:
            self._browser_origin = previous_page
            self._browser_targets = []
        if replace and self._browser_targets:
            self._browser_targets[-1] = target
        elif not self._browser_targets or self._browser_targets[-1] != target:
            self._browser_targets.append(target)

        self._browser_view = dict(view)
        # Kodi can leave a focused list/panel visually empty when it is reset.
        # Option toggles keep the same semantic items, so update those ListItems
        # in place. Structural changes use the persistent navigation control as
        # a safe focus handoff.
        if (
            browser_transition or restore_control_id is not None
        ) and not in_place_refresh:
            self._focus(NAV)
        self._apply_browser_view(
            view,
            focus=not browser_transition,
        )
        if restore_control_id is not None:
            focus_id = self._preferred_browser_focus(restore_control_id)
            if focus_id == restore_control_id:
                restored_position = self._restore_control_selection(
                    restore_control_id,
                    restore_selection,
                )
                if not in_place_refresh:
                    self._defer_browser_focus(
                        focus_id,
                        target,
                        restored_position,
                    )
            else:
                self._focus(focus_id)
        elif browser_transition:
            self._defer_browser_focus(
                self._preferred_browser_focus(),
                target,
            )

    def _apply_browser_view(self, view, focus=True):
        layout = _text(view.get("layout")).strip().lower()
        if layout == "filter_studio":
            self._apply_filter_studio_view(view, focus=focus)
            return
        if layout == "filter_results":
            self._apply_filter_results_view(view, focus=focus)
            return

        self._page = "browse"
        self.setProperty("App.Page", "browse")
        self.setProperty("App.NavPage", self._navigation_page("browse"))
        self._select_navigation(self._navigation_page("browse"))
        self.setProperty(
            "App.BrowserTitle",
            _text(view.get("title", tr("Browse"))),
        )
        self.setProperty("App.BrowserSubtitle", _text(view.get("subtitle", "")))
        self.setProperty(
            "App.BrowserEyebrow",
            _text(view.get("eyebrow", "MEDIA HUB")),
        )
        self.setProperty(
            "App.BrowserEmpty",
            _text(view.get("empty", tr("Nothing to show yet."))),
        )
        self.setProperty(
            "App.BrowserArt",
            _text(view.get("fanart", self.fallback_art)),
        )
        self.setProperty(
            "App.BrowserDepth",
            "{0:02d}".format(max(1, len(self._browser_targets))),
        )
        self._browser_items[:] = _models(view.get("items"))
        self._populate_control(BROWSER, self._browser_items)
        self.setProperty("App.HasBrowser", "true" if self._browser_items else "false")
        if focus:
            self._focus(BROWSER if self._browser_items else NAV)

    def _apply_filter_studio_view(self, view, focus=True):
        self._page = "filters"
        self.setProperty("App.Page", "filters")
        navigation_page = self._navigation_page("filters", view)
        self.setProperty("App.NavPage", navigation_page)
        self._select_navigation(navigation_page)

        self._filter_groups[:] = _models(view.get("groups"))
        self._filter_options[:] = _models(view.get("options"))
        self._filter_actions[:] = _models(view.get("actions"))
        self._populate_control(FILTER_GROUPS, self._filter_groups)
        self._populate_control(FILTER_OPTIONS, self._filter_options)
        self._populate_control(FILTER_ACTIONS, self._filter_actions)
        primary_action_index = next(
            (
                index
                for index, model in enumerate(self._filter_actions)
                if _model_property(model, "App.Primary") == "true"
            ),
            0,
        )
        if self._filter_actions:
            try:
                self.getControl(FILTER_ACTIONS).selectItem(
                    primary_action_index
                )
            except Exception:
                pass

        selected_group_index = next(
            (
                index
                for index, model in enumerate(self._filter_groups)
                if _model_property(model, "App.Selected") == "true"
            ),
            0,
        )
        selected_group = (
            self._filter_groups[selected_group_index]
            if self._filter_groups
            else {}
        )
        if self._filter_groups:
            try:
                self.getControl(FILTER_GROUPS).selectItem(
                    selected_group_index
                )
            except Exception:
                pass
        selected_option_index = next(
            (
                index
                for index, model in enumerate(self._filter_options)
                if _model_property(model, "App.Selected") == "true"
            ),
            0,
        )
        if self._filter_options:
            try:
                self.getControl(FILTER_OPTIONS).selectItem(
                    selected_option_index
                )
            except Exception:
                pass
        active_count = max(0, int(view.get("active_count") or 0))
        properties = {
            "App.FilterTitle": view.get("title", tr("Discover")),
            "App.FilterSubtitle": view.get("subtitle", ""),
            "App.FilterEyebrow": view.get("eyebrow", "FILTER STUDIO"),
            "App.FilterSummary": view.get("summary", ""),
            "App.FilterSectionTitle": selected_group.get("label", ""),
            "App.FilterActiveCount": str(active_count),
            "App.FilterActiveLabel": (
                tr("FILTERS {0}", active_count)
                if active_count
                else tr("NO ACTIVE FILTERS")
            ),
            "App.FilterHasOptions": (
                "true" if self._filter_options else "false"
            ),
        }
        for key, value in properties.items():
            self.setProperty(key, _text(value))
        if focus:
            self._focus(
                FILTER_GROUPS
                if self._filter_groups
                else FILTER_ACTIONS
                if self._filter_actions
                else NAV
            )

    def _apply_filter_results_view(self, view, focus=True):
        self._page = "filterresults"
        self.setProperty("App.Page", "filterresults")
        navigation_page = self._navigation_page("filterresults", view)
        self.setProperty("App.NavPage", navigation_page)
        self._select_navigation(navigation_page)

        self._filter_results[:] = _models(view.get("items"))
        self._filter_result_actions[:] = _models(view.get("result_actions"))
        self._filter_result_chips[:] = _models(view.get("chips"))
        self._filter_pagination[:] = _models(
            view.get("pagination_actions")
        )
        self._populate_control(FILTER_RESULTS, self._filter_results)
        self._populate_control(
            FILTER_RESULT_ACTIONS,
            self._filter_result_actions,
        )
        self._populate_control(
            FILTER_RESULT_CHIPS,
            self._filter_result_chips,
        )
        self._populate_control(
            FILTER_PAGINATION,
            self._filter_pagination,
        )
        primary_action_index = next(
            (
                index
                for index, model in enumerate(
                    self._filter_result_actions
                )
                if _model_property(model, "App.Primary") == "true"
            ),
            0,
        )
        if self._filter_result_actions:
            try:
                self.getControl(FILTER_RESULT_ACTIONS).selectItem(
                    primary_action_index
                )
            except Exception:
                pass
        properties = {
            "App.FilterResultsTitle": view.get("title", tr("Discovery Results")),
            "App.FilterResultsSubtitle": view.get("subtitle", ""),
            "App.FilterResultsEyebrow": view.get("eyebrow", "FILTERED RESULTS"),
            "App.FilterResultsEmptyTitle": view.get(
                "empty_title",
                tr("No matching titles"),
            ),
            "App.FilterSummary": view.get("summary", ""),
            "App.FilterResultsEmpty": view.get(
                "empty",
                tr("No titles match these filters."),
            ),
            "App.FilterHasResults": (
                "true" if self._filter_results else "false"
            ),
            "App.FilterHasChips": (
                "true" if self._filter_result_chips else "false"
            ),
            "App.FilterHasPagination": (
                "true" if self._filter_pagination else "false"
            ),
        }
        for key, value in properties.items():
            self.setProperty(key, _text(value))
        if focus:
            self._focus(
                FILTER_RESULTS
                if self._filter_results
                else FILTER_RESULT_ACTIONS
                if self._filter_result_actions
                else NAV
            )

    def _restore_browser_state(self, focus=True):
        state = self._browser_return_state
        if not isinstance(state, dict):
            return False
        view = state.get("view")
        if not isinstance(view, dict):
            return False
        self._browser_targets = list(state.get("targets") or [])
        self._browser_view = dict(view)
        if _text(view.get("layout")).strip().lower() not in (
            "filter_studio",
            "filter_results",
        ):
            self._browser_items[:] = _models(state.get("items"))
            view = dict(view)
            view["items"] = list(self._browser_items)
        self._focus(NAV)
        self._apply_browser_view(view, focus=False)
        try:
            saved_focus_id = int(state.get("focus_id"))
        except (TypeError, ValueError):
            saved_focus_id = None
        focus_id = self._preferred_browser_focus(saved_focus_id)
        restored_position = None
        if focus_id == saved_focus_id:
            restored_position = self._restore_control_selection(
                focus_id,
                state.get("selection"),
            )
        if focus:
            target = (
                self._browser_targets[-1]
                if self._browser_targets
                else ""
            )
            if target:
                self._defer_browser_focus(
                    focus_id,
                    target,
                    restored_position,
                )
            else:
                self._focus(focus_id)
        self._browser_return_state = None
        return True

    def _preferred_browser_focus(self, preferred=None):
        if (
            preferred in self._items_by_control
            and self._items_by_control.get(preferred)
        ):
            return preferred
        if self._page == "filters":
            return (
                FILTER_GROUPS
                if self._filter_groups
                else FILTER_ACTIONS
                if self._filter_actions
                else NAV
            )
        if self._page == "filterresults":
            return (
                FILTER_RESULTS
                if self._filter_results
                else FILTER_RESULT_ACTIONS
                if self._filter_result_actions
                else NAV
            )
        return BROWSER if self._browser_items else NAV

    def _defer_browser_focus(self, control_id, _target, position=None):
        """Queue focus restoration on Kodi's GUI thread after this callback."""

        if (
            self._page not in BROWSER_PAGES
            or self._preferred_browser_focus(control_id) != control_id
        ):
            return
        if position is None:
            try:
                position = int(
                    self.getControl(control_id).getSelectedPosition()
                )
            except Exception:
                position = 0
        else:
            try:
                position = int(position)
            except (TypeError, ValueError):
                position = 0
        # Unlike WindowXML.setFocusId, the builtin is queued for the next GUI
        # message and therefore repaints a container that was just reset.
        xbmc.executebuiltin(
            "Control.SetFocus({0},{1},absolute)".format(
                control_id,
                max(0, position),
            )
        )

    def _navigation_page(self, page, view=None):
        view = view if isinstance(view, dict) else self._browser_view
        if page in ("filters", "filterresults"):
            return "tv" if view.get("media_type") == "tv" else "movies"
        if page == "browse":
            origin = self._browser_origin
            if origin in ("movies", "tv", "home", "downloads", "favorites",
                          "history", "settings", "search"):
                return origin
            if self._previous_page in ("movies", "tv"):
                return self._previous_page
            return "home"
        if page == "detail":
            return self._navigation_page(self._previous_page, view)
        return page

    def _reload_browser(self, target=None):
        if target:
            self._open_browser(target, replace=True)
        elif self._browser_targets:
            self._open_browser(self._browser_targets[-1], replace=True)

    def _close_browser_level(self):
        if len(self._browser_targets) > 1:
            self._browser_targets.pop()
            target = self._browser_targets.pop()
            self._open_browser(target)
            return
        self._browser_targets = []
        origin = self._browser_origin
        if origin in BROWSER_PAGES:
            origin = "home"
        self._show_page(origin, load=False)

    def _run_action(self, target):
        if not target or not callable(self.action_handler):
            return
        try:
            next_target = self.action_handler(target)
        except Exception as exc:
            _log("Action failed for {0}: {1}".format(target, exc), xbmc.LOGERROR)
            return
        self._refresh_state()
        self._reload_browser(_text(next_target).strip() if next_target else None)

    def _refresh_state(self, downloads_only=False):
        if not callable(self.state_loader):
            return
        try:
            state = self.state_loader()
        except Exception as exc:
            _log("Could not refresh app state: {0}".format(exc), xbmc.LOGWARNING)
            return
        if not isinstance(state, dict):
            return

        if not downloads_only:
            favourites = state.get("favorites")
            if favourites is not None:
                self.favorite_items[:] = _models(favourites)
                if self._page == "favorites":
                    self._set_catalog(self.favorite_items)
            history = state.get("history")
            if history is not None:
                self.history_items[:] = _models(history)
                self._populate_control(HISTORY, self.history_items)
        downloads = state.get("downloads")
        if downloads is not None:
            selection = self._control_selection(DOWNLOADS)
            self.download_items[:] = _models(downloads)
            self._populate_control(DOWNLOADS, self.download_items)
            self._restore_control_selection(DOWNLOADS, selection)

    def _control_selection(self, control_id):
        models = self._items_by_control.get(control_id)
        if models is None:
            return {}
        try:
            position = int(self.getControl(control_id).getSelectedPosition())
        except Exception:
            position = 0
        selected = models[position] if 0 <= position < len(models) else None
        return {
            "position": position,
            "target": _text(selected.get("target")) if selected else "",
            "command": _text(selected.get("command")) if selected else "",
            "label": _text(selected.get("label")) if selected else "",
            "filter_key": (
                _model_property(selected, "App.FilterKey")
                if selected else ""
            ),
        }

    def _open_context_menu(self):
        try:
            control_id = int(self.getFocusId())
        except Exception:
            return
        model = self._selected_model(control_id)
        if model is None:
            return
        actions = _models(model.get("context_actions"))
        if not actions:
            target = _model_property(model, "App.ContextTarget")
            if target:
                actions = [{
                    "label": tr("Download"),
                    "label2": tr("Add this stream to the download queue"),
                    "command": "action",
                    "target": target,
                    "properties": {"App.Badge": "QUEUE"},
                }]
        if not actions:
            return

        self._context_items[:] = actions
        self._populate_control(CONTEXT_MENU, self._context_items)
        self._context_origin_control = control_id
        self._context_open = True
        self.setProperty("App.ContextTitle", _text(model.get("label", tr("Actions"))))
        self.setProperty("App.ContextSubtitle", _text(model.get("label2", "")))
        self.setProperty("App.ContextOpen", "true")
        self._focus(CONTEXT_MENU)

    def _close_context_menu(self, restore_focus=True):
        if not self._context_open:
            return
        origin = self._context_origin_control
        self._context_open = False
        self._context_origin_control = None
        self.setProperty("App.ContextOpen", "false")
        if restore_focus and origin is not None:
            self._focus(origin)

    def _populate_control(self, control_id, models):
        try:
            control = self.getControl(control_id)
            if (
                control_id in (
                    DOWNLOADS,
                    FILTER_GROUPS,
                    FILTER_OPTIONS,
                    FILTER_ACTIONS,
                )
                and self._can_update_control_in_place(control_id, models)
            ):
                for index, model in enumerate(models):
                    self._update_list_item(
                        control.getListItem(index),
                        model,
                    )
                if control_id == DOWNLOADS:
                    self._download_row_targets = [
                        _text(model.get("target")) for model in models
                    ]
                return
            reset = getattr(control, "reset", None)
            if callable(reset):
                reset()
            items = [self._list_item(model) for model in models]
            add_items = getattr(control, "addItems", None)
            if callable(add_items):
                add_items(items)
            else:
                add_item = getattr(control, "addItem")
                for item in items:
                    add_item(item)
            if control_id == DOWNLOADS:
                self._download_row_targets = [
                    _text(model.get("target")) for model in models
                ]
        except Exception as exc:
            _log(
                "Could not populate {0} ({1}): {2}".format(
                    _CONTROL_NAMES.get(control_id, control_id),
                    control_id,
                    exc,
                ),
                xbmc.LOGERROR,
            )

    def _can_update_control_in_place(self, control_id, models):
        if control_id not in (
            DOWNLOADS,
            FILTER_GROUPS,
            FILTER_OPTIONS,
            FILTER_ACTIONS,
        ) or not models:
            return False
        identity_property = (
            "App.FilterKey"
            if control_id in (
                FILTER_GROUPS,
                FILTER_OPTIONS,
                FILTER_ACTIONS,
            )
            else None
        )
        try:
            control = self.getControl(control_id)
            if int(control.size()) != len(models):
                return False
            if control_id == DOWNLOADS:
                model_targets = [
                    _text(model.get("target")) for model in models
                ]
                return (
                    all(model_targets)
                    and self._download_row_targets == model_targets
                )
            for index, model in enumerate(models):
                current_item = control.getListItem(index)
                current_identity = _text(
                    current_item.getProperty(identity_property)
                )
                model_identity = _model_property(
                    model,
                    identity_property,
                )
                if not current_identity or current_identity != model_identity:
                    return False
        except Exception:
            return False
        return True

    @staticmethod
    def _list_item(model):
        item = xbmcgui.ListItem(
            label=tr(_text(model.get("label"))),
            label2=tr(_text(model.get("label2"))),
        )
        MediaHubHomeDialog._update_list_item(item, model, labels=False)
        return item

    @staticmethod
    def _update_list_item(item, model, labels=True):
        if labels:
            item.setLabel(tr(_text(model.get("label"))))
            item.setLabel2(tr(_text(model.get("label2"))))
        art = model.get("art")
        if isinstance(art, dict):
            normalized_art = {
                _text(key): _text(value) for key, value in art.items()
            }
            item.setArt(normalized_art)
            # WindowXML list/panel controls do not expose ListItem.Art
            # consistently across Kodi versions. Mirror artwork as ordinary
            # properties, which custom skin controls reliably resolve.
            item.setProperty(
                "MediaHub.Thumb", normalized_art.get("thumb", "")
            )
            item.setProperty(
                "MediaHub.Poster", normalized_art.get("poster", "")
            )
            item.setProperty(
                "MediaHub.Fanart", normalized_art.get("fanart", "")
            )
        properties = model.get("properties")
        if isinstance(properties, dict):
            for key, value in properties.items():
                text_key = _text(key)
                text_value = _text(value)
                if text_key in ("App.Badge", "App.Hint"):
                    text_value = tr(text_value)
                item.setProperty(text_key, text_value)

    def _selected_model(self, control_id):
        models = self._items_by_control.get(control_id)
        if models is None:
            return None
        try:
            position = int(self.getControl(control_id).getSelectedPosition())
        except Exception:
            return None
        return models[position] if 0 <= position < len(models) else None

    def _capture_reactivation_state(self):
        selections = {}
        for control_id, models in self._items_by_control.items():
            if control_id == CONTEXT_MENU:
                continue
            try:
                position = int(self.getControl(control_id).getSelectedPosition())
            except Exception:
                continue
            selected = models[position] if 0 <= position < len(models) else None
            selections[control_id] = {
                "position": position,
                "target": _text(selected.get("target")) if selected else "",
                "command": _text(selected.get("command")) if selected else "",
                "label": _text(selected.get("label")) if selected else "",
                "filter_key": (
                    _model_property(selected, "App.FilterKey")
                    if selected else ""
                ),
            }
        try:
            focus_id = int(self.getFocusId())
        except Exception:
            focus_id = (
                BROWSER
                if self._page == "browse"
                else FILTER_GROUPS
                if self._page == "filters"
                else FILTER_RESULTS
                if self._page == "filterresults"
                else NAV
            )
        return {
            "page": self._page,
            "previous_page": self._previous_page,
            "focus_id": focus_id,
            "selections": selections,
        }

    def _restore_reactivated_window(self):
        state = self._reactivation_state
        if not isinstance(state, dict):
            state = {
                "page": self._page or self.initial_page,
                "previous_page": self._previous_page,
                "selections": {},
            }

        page = _text(state.get("page", self._page or self.initial_page)) or "home"
        self._page = page
        self._previous_page = (
            _text(state.get("previous_page", self._previous_page))
            or self._previous_page
        )
        self.setProperty("App.Page", page)
        navigation_page = self._navigation_page(page)
        self.setProperty("App.NavPage", navigation_page)
        title, subtitle = _PAGE_TITLES.get(page, ("", ""))
        title, subtitle = tr(title), tr(subtitle)
        if page in ("movies", "tv"):
            title = title.upper()
        self.setProperty("App.PageTitle", title)
        self.setProperty("App.PageSubtitle", subtitle)
        self._select_navigation(navigation_page)

        if page in ("movies", "tv"):
            self._populate_control(TABS, self._tabs)
            self._set_catalog(self._catalog_items)
        elif page in ("favorites", "search"):
            self._set_catalog(self._catalog_items)
        elif page == "browse":
            view = self._browser_view
            self.setProperty("App.BrowserTitle", _text(view.get("title", "Browse")))
            self.setProperty("App.BrowserSubtitle", _text(view.get("subtitle", "")))
            self.setProperty(
                "App.BrowserEyebrow",
                _text(view.get("eyebrow", "MEDIA HUB")),
            )
            self.setProperty(
                "App.BrowserEmpty",
                _text(view.get("empty", "Nothing to show yet.")),
            )
            self.setProperty(
                "App.BrowserArt",
                _text(view.get("fanart", self.fallback_art)),
            )
            self.setProperty(
                "App.BrowserDepth",
                "{0:02d}".format(max(1, len(self._browser_targets))),
            )
            self._populate_control(BROWSER, self._browser_items)
            self.setProperty(
                "App.HasBrowser",
                "true" if self._browser_items else "false",
            )
        elif page == "filters":
            self._apply_filter_studio_view(
                self._browser_view,
                focus=False,
            )
        elif page == "filterresults":
            self._apply_filter_results_view(
                self._browser_view,
                focus=False,
            )
        elif page == "detail":
            self._populate_control(
                DETAIL_ACTIONS,
                self._items_by_control[DETAIL_ACTIONS],
            )

        selections = state.get("selections")
        if isinstance(selections, dict):
            for control_id, selection in selections.items():
                self._restore_control_selection(control_id, selection)

        try:
            focus_id = int(state.get("focus_id"))
        except (TypeError, ValueError):
            focus_id = (
                BROWSER
                if page == "browse"
                else FILTER_GROUPS
                if page == "filters"
                else FILTER_RESULTS
                if page == "filterresults"
                else NAV
            )
        self._focus(focus_id)
        self._reactivation_state = None

    def _restore_control_selection(self, control_id, selection):
        if not isinstance(selection, dict):
            return None
        try:
            control_id = int(control_id)
        except (TypeError, ValueError):
            return None
        models = self._items_by_control.get(control_id)
        if not models:
            return None

        target = _text(selection.get("target"))
        command = _text(selection.get("command"))
        label = _text(selection.get("label"))
        filter_key = _text(selection.get("filter_key"))
        matched = None
        for index, model in enumerate(models):
            if (
                filter_key
                and _model_property(model, "App.FilterKey") == filter_key
            ):
                matched = index
                break
            if target and _text(model.get("target")) == target:
                matched = index
                break
            if (
                not target
                and command
                and _text(model.get("command")) == command
                and _text(model.get("label")) == label
            ):
                matched = index
                break
        if matched is None:
            try:
                matched = int(selection.get("position", 0))
            except (TypeError, ValueError):
                matched = 0
            matched = min(max(0, matched), len(models) - 1)
        try:
            self.getControl(control_id).selectItem(matched)
        except Exception:
            return None
        return matched

    def _select_navigation(self, page):
        index = self._nav_index.get(page)
        if index is None:
            return
        try:
            self.getControl(NAV).selectItem(index)
            self._nav_position = index
        except Exception:
            pass

    def _remember_navigation_position(self):
        try:
            self._nav_position = int(
                self.getControl(NAV).getSelectedPosition()
            )
        except Exception:
            self._nav_position = None

    def _remember_tab_position(self):
        try:
            self._tab_position = int(
                self.getControl(TABS).getSelectedPosition()
            )
        except Exception:
            self._tab_position = None

    def _sync_navigation_selection(self):
        try:
            if int(self.getFocusId()) != NAV:
                return
            position = int(self.getControl(NAV).getSelectedPosition())
        except Exception:
            return

        if position == self._nav_position:
            return
        self._nav_position = position
        if not 0 <= position < len(self.navigation):
            return

        page = _model_property(self.navigation[position], "App.Page", "home")
        if page != self._page:
            self._show_page(page, load=True, focus=False)

    def _sync_tab_selection(self):
        if self._page not in ("movies", "tv"):
            return
        try:
            if int(self.getFocusId()) != TABS:
                return
            position = int(self.getControl(TABS).getSelectedPosition())
        except Exception:
            return

        if position == self._tab_position:
            return
        self._tab_position = position
        if not 0 <= position < len(self._tabs):
            return

        tab = _model_property(self._tabs[position], "App.Tab")
        if tab == "filters":
            self.setProperty("App.ActiveTab", tab)
            return
        if tab:
            self._load_catalog(
                self._page,
                tab,
                force=False,
                focus=False,
            )

    def _focus(self, control_id):
        try:
            self.setFocusId(control_id)
        except Exception as exc:
            _log("Could not focus control {0}: {1}".format(control_id, exc), xbmc.LOGERROR)

    def _focus_home_content(self):
        self._show_page("home", load=False)


def open_home(addon_path, **kwargs):
    """Open the unified Media Hub application and return its exit command."""
    dialog = None
    abort_monitor = None
    try:
        dialog = MediaHubHomeDialog(
            XML_FILENAME,
            addon_path,
            "Default",
            "1080i",
            **kwargs
        )

        class _HomeAbortMonitor(xbmc.Monitor):
            def __init__(self, window):
                super().__init__()
                self.window = window

            def onAbortRequested(self):
                window = self.window
                if window is not None:
                    window.close()

        abort_monitor = _HomeAbortMonitor(dialog)
        dialog.doModal()
        return dialog.result
    except Exception as exc:
        _log("Could not open the app window: {0}".format(exc), xbmc.LOGERROR)
        raise
    finally:
        if abort_monitor is not None:
            abort_monitor.window = None
        if dialog is not None:
            # Kodi can dismiss a modal window as part of global shutdown
            # without taking the normal WindowXML.close path.
            dialog._close_event.set()
            del dialog
