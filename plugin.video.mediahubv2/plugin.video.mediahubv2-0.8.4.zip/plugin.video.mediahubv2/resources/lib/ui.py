import sys
import hashlib
import xbmc
import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmcvfs
import os
import stat
import urllib.parse
import time
import threading
import datetime
import re
from concurrent.futures import ThreadPoolExecutor
from urllib.error import URLError
from . import api
import uuid
from .downloads_db import DownloadsDb, now_iso
from .media_lists_db import MEDIA_LIST_KEYS, MediaListsDb
from .watch_history_db import WatchHistoryDb
from .localization import SLOVAK, language, tr


db = DownloadsDb()
media_lists_db = MediaListsDb()
watch_history_db = WatchHistoryDb()

QUEUE_STATUSES = ("queued", "paused", "waiting_retry")
ACTIVE_DOWNLOAD_STATUSES = ("downloading", "pausing", "canceling", "repairing", "finalizing")
VERIFICATION_ERROR_CODE = "verification_failed"
FINALIZATION_MARKER_PREFIX = b"MEDIAHUB-FINALIZATION-V1:"
MAX_WATCH_HISTORY_ITEMS = 200
ANIMATION_GENRE_ID = 16

DISCOVERY_SORTS = (
    ("popularity.desc", "Popular"),
    ("release_date.desc", "Newest"),
    ("release_date.asc", "Oldest"),
    ("vote_average.desc", "Best rated"),
    ("vote_average.asc", "Lowest rated")
)
DISCOVERY_STATE_KEYS = (
    "genre_ids",
    "genre_names",
    "genre_id",
    "genre_name",
    "year",
    "year_from",
    "year_to",
    "sort",
    "minimum_rating",
    "minimum_vote_count",
)
DISCOVERY_SECTIONS = (
    "genre",
    "release_period",
    "minimum_rating",
    "minimum_vote_count",
    "sort",
)
DISCOVERY_MIN_YEAR = 1870

class _RepairOwnershipLost(Exception):
    pass

COLLECTION_TITLES = {
    "favorites": "Favorites"
}

COLLECTION_ADD_LABELS = {
    "favorites": "Add to Media Hub Favorites"
}

COLLECTION_REMOVE_LABELS = {
    "favorites": "Remove from Media Hub Favorites"
}

COLLECTION_RECORD_KEYS = (
    "kind",
    "media_type",
    "movie_id",
    "tv_id",
    "season",
    "episode_id",
    "stream_id",
    "title",
    "tv_title",
    "season_title",
    "episode_title",
    "year",
    "poster",
    "fanart",
    "stream_name",
    "size_gb"
)

VIDEO_FILE_EXTENSIONS = {
    ".3gp",
    ".avi",
    ".divx",
    ".flv",
    ".iso",
    ".m2ts",
    ".m4v",
    ".mkv",
    ".mov",
    ".mp4",
    ".mpeg",
    ".mpg",
    ".mts",
    ".ogm",
    ".ts",
    ".vob",
    ".webm",
    ".wmv"
}

def _is_vfs_path(path):
    return "://" in path

def _join_path(base, filename):
    if _is_vfs_path(base):
        return base.rstrip("/\\") + "/" + filename
    return os.path.join(base, filename)

def _video_extension(value):
    if not value:
        return ""

    path = urllib.parse.urlparse(value).path if "://" in value else value
    name = os.path.basename(urllib.parse.unquote(path)).strip()
    ext = os.path.splitext(name)[1].lower()
    return ext if ext in VIDEO_FILE_EXTENSIONS else ""

def _strip_video_extensions(value):
    base = (value or "").strip()
    while True:
        ext = _video_extension(base)
        if not ext:
            return base
        base = os.path.splitext(base)[0].rstrip(" .")

def _safe_download_filename(filename, source_url=""):
    ext = _video_extension(filename) or _video_extension(source_url)
    base = _strip_video_extensions(filename)
    invalid_chars = set('<>:"/\\|?*')
    safe_base = "".join(
        " " if c in invalid_chars or ord(c) < 32 else c
        for c in base
    ).strip(" .")
    if not safe_base:
        safe_base = "download"

    if ext:
        while safe_base.lower().endswith(ext):
            safe_base = safe_base[:-len(ext)].rstrip(" .")
        if not safe_base:
            safe_base = "download"

    return f"{safe_base}{ext}"

def _stream_display_name(stream):
    return stream.get("originalName") or stream.get("name") or "Stream"

def _clean_query_value(value):
    if value is None:
        return ""
    return str(value).strip()

def _addon_bool_setting(setting_id, default=False):
    value = xbmcaddon.Addon().getSetting(setting_id)
    if value == "":
        return default
    return value.lower() == "true"

def _filter_anime_enabled():
    return _addon_bool_setting("filter_anime", True)

def _is_probable_anime(show):
    genre_ids = show.get("genre_ids") or []
    try:
        has_animation_genre = ANIMATION_GENRE_ID in [int(genre_id) for genre_id in genre_ids]
    except (TypeError, ValueError):
        has_animation_genre = False

    original_language = _clean_query_value(show.get("original_language")).lower()
    origin_country = [
        _clean_query_value(country).upper()
        for country in (show.get("origin_country") or [])
    ]

    return has_animation_genre and (
        original_language == "ja" or "JP" in origin_country
    )

def _filter_tv_shows(shows):
    if not _filter_anime_enabled():
        return shows
    return [show for show in shows if not _is_probable_anime(show)]

def _movie_display_title(movie):
    return (
        movie.get("title_with_original_title")
        or movie.get("title")
        or movie.get("original_title")
        or "Movie"
    )

def _movie_release_year(movie):
    release_date = _clean_query_value(movie.get("release_date"))
    if len(release_date) >= 4:
        return release_date[:4]
    return _clean_query_value(movie.get("year"))

def _build_movie_versions_url(movie):
    return build_url({
        'action': 'list_movie_versions',
        'movie_id': movie.get('id', ''),
        'title': _movie_display_title(movie),
        'year': _movie_release_year(movie),
        'poster': movie.get('poster_path', ''),
        'fanart': movie.get('backdrop_path', '')
    })

def build_url(query):
    return f"{sys.argv[0]}?{urllib.parse.urlencode(query)}"

def get_addon_art_path(image_name="fanart.png"):
    addon = xbmcaddon.Addon()
    return os.path.join(addon.getAddonInfo('path'), 'resources', image_name)

def _media_art_url(value):
    value = str(value or "").strip()
    if value.startswith("/"):
        return "https://image.tmdb.org/t/p/original{0}".format(value)
    return value

def _set_utility_fanart(item):
    item.setArt({"fanart": get_addon_art_path()})

def _prepare_directory(handle, category, content="files"):
    xbmcplugin.setPluginCategory(handle, category)
    try:
        xbmcplugin.setContent(handle, content)
    except Exception:
        pass

def _catalog_load_failed(handle, section, ex):
    xbmc.log(f"[catalog] Failed to load {section}: {ex}", xbmc.LOGERROR)
    xbmcgui.Dialog().ok(
        "Media Hub",
        "Obsah sa nepodarilo načítať. Skontrolujte pripojenie k API."
    )
    xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)

def _as_int(value, default=0):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default

def _as_float(value, default=None):
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _split_filter_values(value, separator=","):
    return [
        item.strip()
        for item in _clean_query_value(value).split(separator)
        if item.strip()
    ]


def _normalized_genre_ids(value):
    normalized = []
    for candidate in _split_filter_values(value):
        genre_id = _as_int(candidate, 0)
        if genre_id > 0 and genre_id not in normalized:
            normalized.append(genre_id)
    return normalized


def _normalized_genre_names(value):
    return _split_filter_values(value, "|")


def _format_decimal(value):
    number = _as_float(value)
    if number is None:
        return ""
    return "{0:.1f}".format(number)


def _valid_discovery_year(value):
    year = _as_int(value, 0)
    maximum = time.gmtime().tm_year + 1
    return year if DISCOVERY_MIN_YEAR <= year <= maximum else 0

def _episode_number(item, default=0):
    if not isinstance(item, dict):
        return default
    for key in ("episode_number", "episodeNumber", "episode"):
        value = _as_int(item.get(key), 0)
        if value > 0:
            return value
    title = str(item.get("title") or item.get("name") or "")
    match = re.search(r"\bS\d{1,3}\s*E(\d{1,3})\b", title, re.IGNORECASE)
    if not match:
        match = re.search(r"\b\d{1,3}x(\d{1,3})\b", title, re.IGNORECASE)
    return _as_int(match.group(1), default) if match else default

def _discovery_state(params=None):
    if params is None:
        params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    state = {
        key: _clean_query_value(params.get(key))
        for key in DISCOVERY_STATE_KEYS
        if _clean_query_value(params.get(key))
    }

    genre_ids = _normalized_genre_ids(
        state.get("genre_ids") or state.get("genre_id")
    )
    genre_names = _normalized_genre_names(
        state.get("genre_names") or state.get("genre_name")
    )
    state.pop("genre_id", None)
    state.pop("genre_name", None)
    state.pop("genre_ids", None)
    state.pop("genre_names", None)
    if genre_ids:
        state["genre_ids"] = ",".join(str(value) for value in genre_ids)
        if genre_names:
            state["genre_names"] = "|".join(genre_names[:len(genre_ids)])

    exact_year = _valid_discovery_year(state.get("year"))
    year_from = _valid_discovery_year(state.get("year_from"))
    year_to = _valid_discovery_year(state.get("year_to"))
    state.pop("year", None)
    state.pop("year_from", None)
    state.pop("year_to", None)
    if year_from or year_to:
        year_from = year_from or DISCOVERY_MIN_YEAR
        year_to = year_to or (time.gmtime().tm_year + 1)
        if year_from <= year_to:
            state["year_from"] = str(year_from)
            state["year_to"] = str(year_to)
    elif exact_year:
        state["year"] = str(exact_year)

    minimum_rating = _as_float(state.get("minimum_rating"))
    state.pop("minimum_rating", None)
    if minimum_rating is not None and 0 <= minimum_rating <= 10:
        state["minimum_rating"] = _format_decimal(minimum_rating)

    minimum_vote_count = _as_int(state.get("minimum_vote_count"), -1)
    state["minimum_vote_count"] = str(max(0, minimum_vote_count))

    if state.get("sort") not in {value for value, _ in DISCOVERY_SORTS}:
        state["sort"] = "popularity.desc"
    return state


def _discovery_genre_ids(state):
    return _normalized_genre_ids((state or {}).get("genre_ids"))


def _discovery_genre_names(state):
    return _normalized_genre_names((state or {}).get("genre_names"))


def _discovery_state_with(state, **changes):
    updated = dict(state or {})
    for key, value in changes.items():
        if value in (None, ""):
            updated.pop(key, None)
        else:
            updated[key] = value
    return _discovery_state(updated)


def _discovery_period_label(state):
    exact = _valid_discovery_year((state or {}).get("year"))
    if exact:
        return str(exact)
    year_from = _valid_discovery_year((state or {}).get("year_from"))
    year_to = _valid_discovery_year((state or {}).get("year_to"))
    if year_from and year_to:
        return (
            str(year_from)
            if year_from == year_to
            else "{0}–{1}".format(year_from, year_to)
        )
    return "Any time"


def _discovery_genre_label(state):
    names = _discovery_genre_names(state)
    if not names:
        count = len(_discovery_genre_ids(state))
        return "{0} selected".format(count) if count else "All genres"
    if len(names) <= 2:
        return ", ".join(names)
    return "{0}, {1} (+{2})".format(names[0], names[1], len(names) - 2)


def _discovery_active_count(state):
    count = 0
    if _discovery_genre_ids(state):
        count += 1
    if (
        _valid_discovery_year((state or {}).get("year"))
        or _valid_discovery_year((state or {}).get("year_from"))
        or _valid_discovery_year((state or {}).get("year_to"))
    ):
        count += 1
    if _as_float((state or {}).get("minimum_rating")) is not None:
        count += 1
    if _as_int((state or {}).get("minimum_vote_count"), 0) > 0:
        count += 1
    if (state or {}).get("sort", "popularity.desc") != "popularity.desc":
        count += 1
    return count

def _discovery_query(action, media_type, state=None, **extra):
    query = {
        "action": action,
        "media_type": "tv" if media_type == "tv" else "movie"
    }
    query.update(state or {})
    query.update({key: value for key, value in extra.items() if value not in (None, "")})
    return query

def _replace_discovery_container(media_type, state):
    url = build_url(_discovery_query("show_discovery_filters", media_type, state))
    xbmc.executebuiltin(f"Container.Update({url})")

def _add_discovery_filter_item(handle, label, media_type, filter_name, state):
    item = xbmcgui.ListItem(label=label)
    item.setProperty('IsPlayable', 'false')
    item.setInfo('video', {'plot': u"\u00A0"})
    url = build_url(_discovery_query(
        "configure_discovery_filter",
        media_type,
        state,
        filter=filter_name
    ))
    xbmcplugin.addDirectoryItem(handle, url, item, isFolder=False)

def _queue_position(record):
    value = _as_int(record.get("queue_position"), 0)
    return value if value > 0 else 999999

def _normalize_queue_positions(data):
    queued = []
    for download_id, record in data.items():
        if record.get("status") not in QUEUE_STATUSES:
            continue
        if not record.get("id"):
            record["id"] = download_id
        queued.append((download_id, record))

    queued.sort(key=lambda item: (
        _queue_position(item[1]),
        item[1].get("created_at") or "",
        item[0]
    ))

    for index, (_, record) in enumerate(queued, start=1):
        record["queue_position"] = index

def _list_downloads_normalized():
    def op(data):
        _normalize_queue_positions(data)
        return {download_id: dict(record) for download_id, record in data.items()}
    return db.mutate(op)

def _next_queue_position(data):
    positions = [
        _as_int(record.get("queue_position"), 0)
        for record in data.values()
        if record.get("status") in QUEUE_STATUSES
    ]
    return max(positions or [0]) + 1

def _queue_count(data):
    return sum(1 for record in data.values() if record.get("status") in QUEUE_STATUSES)

def _download_action_queries(record, queue_count=0):
    download_id = record.get("id")
    status = record.get("status")
    position = _as_int(record.get("queue_position"), 0)
    actions = []

    if status in QUEUE_STATUSES:
        if position > 1:
            actions.append((tr("Move up"), {'action': 'move_download', 'id': download_id, 'direction': 'up'}))
            actions.append((tr("Move to top"), {'action': 'move_download', 'id': download_id, 'direction': 'top'}))
        if position and position < queue_count:
            actions.append((tr("Move down"), {'action': 'move_download', 'id': download_id, 'direction': 'down'}))
            actions.append((tr("Move to bottom"), {'action': 'move_download', 'id': download_id, 'direction': 'bottom'}))

    if status in ("queued", "waiting_retry", "downloading"):
        actions.append((tr("Pause"), {'action': 'pause_download', 'id': download_id}))
    elif status == "paused":
        actions.append((tr("Resume"), {'action': 'resume_download', 'id': download_id}))

    if status in ("queued", "waiting_retry", "downloading", "pausing", "paused", "failed"):
        actions.append((tr("Cancel"), {'action': 'cancel_download', 'id': download_id}))

    if status in ("failed", "canceled") and record.get("error_code") != VERIFICATION_ERROR_CODE:
        actions.append((tr("Retry"), {'action': 'retry_download', 'id': download_id}))

    if status == "complete":
        actions.append((tr("Verify"), {'action': 'verify_download', 'id': download_id}))
        actions.append((tr("Repair"), {'action': 'repair_download', 'id': download_id}))
    elif status in ("failed", "canceled") and record.get("error_code") == VERIFICATION_ERROR_CODE:
        actions.append((tr("Repair"), {'action': 'repair_download', 'id': download_id}))

    return actions

def _format_bytes(value):
    if value is None:
        return "unknown"
    size = _as_int(value, -1)
    if size < 0:
        return "unknown"

    units = ("B", "KB", "MB", "GB", "TB")
    index = 0
    amount = float(size)
    while amount >= 1024 and index < len(units) - 1:
        amount /= 1024
        index += 1

    if index == 0:
        return f"{int(amount)} {units[index]}"
    return f"{amount:.1f} {units[index]}"

def _media_lists_snapshot():
    try:
        data = media_lists_db.list()
    except Exception as ex:
        xbmc.log(f"[media_lists] Could not read media lists: {ex}", xbmc.LOGWARNING)
        data = {}

    return {
        key: data.get(key, {}) if isinstance(data.get(key, {}), dict) else {}
        for key in MEDIA_LIST_KEYS
    }

def _collection_title(collection):
    return tr(COLLECTION_TITLES.get(collection, "Media List"))

def _collection_id(record):
    kind = record.get("kind")
    if kind == "movie" and record.get("movie_id") not in (None, ""):
        return f"movie:{record.get('movie_id')}"
    if kind == "tv_show" and record.get("tv_id") not in (None, ""):
        return f"tv:{record.get('tv_id')}"
    if kind == "season" and all(record.get(key) not in (None, "") for key in ("tv_id", "season")):
        return f"season:{record.get('tv_id')}:{record.get('season')}"
    if kind == "episode" and all(record.get(key) not in (None, "") for key in ("tv_id", "season", "episode_id")):
        return f"episode:{record.get('tv_id')}:{record.get('season')}:{record.get('episode_id')}"
    if kind == "stream" and record.get("stream_id") not in (None, ""):
        return f"stream:{record.get('stream_id')}"
    return ""

def _collection_action_query(action, collection, record, item_id=None):
    query = {
        "action": action,
        "collection": collection,
        "item_id": item_id or _collection_id(record)
    }
    for key in COLLECTION_RECORD_KEYS:
        value = record.get(key)
        if value not in (None, ""):
            query[key] = value
    return query

def _collection_context_menu_items(record, collections=None):
    item_id = _collection_id(record)
    if not item_id:
        return []

    collections = collections or _media_lists_snapshot()
    items = []
    for collection in MEDIA_LIST_KEYS:
        if item_id in collections.get(collection, {}):
            label = COLLECTION_REMOVE_LABELS[collection]
            query = {
                "action": "remove_media_list_item",
                "collection": collection,
                "item_id": item_id
            }
        else:
            label = COLLECTION_ADD_LABELS[collection]
            query = _collection_action_query("add_media_list_item", collection, record, item_id)
        items.append((tr(label), f"RunPlugin({build_url(query)})"))
    return items

def _add_collection_context_menu(item, record, collections=None, extra_items=None):
    context_items = list(extra_items or [])
    context_items.extend(_collection_context_menu_items(record, collections))
    if context_items:
        item.addContextMenuItems(context_items, True)

def _collection_record_from_movie(movie):
    return {
        "kind": "movie",
        "movie_id": movie.get("id"),
        "title": _movie_display_title(movie),
        "year": _movie_release_year(movie),
        "poster": movie.get("poster_path", ""),
        "fanart": movie.get("backdrop_path", "")
    }

def _collection_record_from_tv_show(show):
    return {
        "kind": "tv_show",
        "tv_id": show.get("id"),
        "title": show.get("name_with_original_name") or show.get("name") or show.get("original_name") or "TV Show",
        "year": _get_tv_year(show),
        "poster": show.get("poster_path", ""),
        "fanart": show.get("backdrop_path", "")
    }

def _collection_record_from_season(tv_id, tv_title, season, season_title, year, poster, fanart):
    title = f"{tv_title} - {season_title}" if tv_title else season_title
    return {
        "kind": "season",
        "tv_id": tv_id,
        "season": season,
        "title": title,
        "tv_title": tv_title,
        "season_title": season_title,
        "year": year,
        "poster": poster,
        "fanart": fanart
    }

def _collection_record_from_episode(tv_id, season, episode_id, tv_title, episode_title, poster, fanart):
    title = f"{tv_title} - {episode_title}" if tv_title else episode_title
    return {
        "kind": "episode",
        "media_type": "episode",
        "tv_id": tv_id,
        "season": season,
        "episode_id": episode_id,
        "title": title,
        "tv_title": tv_title,
        "episode_title": episode_title,
        "poster": poster,
        "fanart": fanart
    }

def _collection_record_from_movie_stream(stream, movie_id, movie_title, year, poster, fanart):
    display_name = _stream_display_name(stream)
    return {
        "kind": "stream",
        "media_type": "movie",
        "movie_id": movie_id,
        "stream_id": stream.get("id"),
        "title": movie_title or display_name,
        "year": year,
        "poster": poster,
        "fanart": fanart,
        "stream_name": display_name,
        "size_gb": stream.get("sizeInGB")
    }

def _collection_record_from_episode_stream(stream, tv_id, season, episode_id, tv_title, episode_title, poster, fanart):
    display_name = _stream_display_name(stream)
    title = f"{tv_title} - {episode_title}" if tv_title else episode_title
    return {
        "kind": "stream",
        "media_type": "episode",
        "tv_id": tv_id,
        "season": season,
        "episode_id": episode_id,
        "stream_id": stream.get("id"),
        "title": title,
        "tv_title": tv_title,
        "episode_title": episode_title,
        "poster": poster,
        "fanart": fanart,
        "stream_name": display_name,
        "size_gb": stream.get("sizeInGB")
    }

def _collection_record_from_params(params):
    record = {
        key: params.get(key)
        for key in COLLECTION_RECORD_KEYS
        if params.get(key) not in (None, "")
    }
    item_id = params.get("item_id") or _collection_id(record)
    if item_id:
        record["id"] = item_id
    return item_id, record

def _collection_label(record):
    kind = record.get("kind")
    title = record.get("title") or record.get("stream_name") or "Media"
    year = record.get("year")

    if kind == "movie":
        return f"[Movie] {title} [COLOR FFAAAAAA][{year}][/COLOR]" if year else f"[Movie] {title}"
    if kind == "tv_show":
        return f"[TV] {title} [COLOR FFAAAAAA][{year}][/COLOR]" if year else f"[TV] {title}"
    if kind == "season":
        season_title = record.get("season_title") or f"Séria {record.get('season', '')}".strip()
        tv_title = record.get("tv_title")
        label = f"{tv_title} - {season_title}" if tv_title else title
        return f"[Season] {label}"
    if kind == "episode":
        return f"[Episode] {title}"
    if kind == "stream":
        stream_name = record.get("stream_name") or title
        if stream_name != title:
            return f"[Stream] {title} - {stream_name}"
        return f"[Stream] {stream_name}"
    return title

def _collection_plot(record):
    lines = []
    kind = record.get("kind")
    if kind:
        lines.append(f"Type: {kind.replace('_', ' ')}")
    if record.get("stream_name"):
        lines.append(f"Stream: {record.get('stream_name')}")
    if record.get("size_gb"):
        lines.append(f"Size: {record.get('size_gb')} GB")
    if record.get("tv_title"):
        lines.append(f"TV show: {record.get('tv_title')}")
    if record.get("season"):
        lines.append(f"Season: {record.get('season')}")
    if record.get("episode_title"):
        lines.append(f"Episode: {record.get('episode_title')}")
    if record.get("added_at"):
        lines.append(f"Added: {record.get('added_at').replace('T', ' ')}")
    return "\n".join(lines) or u"\u00A0"

def _collection_art(record):
    art = {}
    if record.get("poster"):
        art["poster"] = record.get("poster")
        art["thumb"] = record.get("poster")
    if record.get("fanart"):
        art["fanart"] = record.get("fanart")
    return art

def _collection_open_query(record):
    kind = record.get("kind")
    if kind == "movie":
        return {
            "action": "list_movie_versions",
            "movie_id": record.get("movie_id", ""),
            "title": record.get("title", ""),
            "year": record.get("year", ""),
            "poster": record.get("poster", ""),
            "fanart": record.get("fanart", "")
        }
    if kind == "tv_show":
        return {
            "action": "list_seasons",
            "tv_id": record.get("tv_id", "")
        }
    if kind == "season":
        return {
            "action": "list_episodes",
            "tv_id": record.get("tv_id", ""),
            "season": record.get("season", ""),
            "tv_title": record.get("tv_title", ""),
            "poster": record.get("poster", ""),
            "fanart": record.get("fanart", "")
        }
    if kind == "episode":
        return {
            "action": "show_streams",
            "tv_id": record.get("tv_id", ""),
            "season": record.get("season", ""),
            "episode_id": record.get("episode_id", ""),
            "tv_title": record.get("tv_title", ""),
            "poster": record.get("poster", ""),
            "fanart": record.get("fanart", "")
        }
    if kind == "stream":
        query = {
            "action": "play_movie_stream",
            "stream_id": record.get("stream_id", "")
        }
        for key in (
            "media_type",
            "movie_id",
            "tv_id",
            "season",
            "episode_id",
            "tv_title",
            "episode_title",
            "title",
            "year",
            "poster",
            "fanart",
            "stream_name"
        ):
            value = record.get(key)
            if value not in (None, ""):
                query[key] = value
        return query
    return {}

def _collection_is_folder(record):
    return record.get("kind") != "stream"

def show_media_collection(handle, collection):
    source_collection = collection
    if source_collection not in MEDIA_LIST_KEYS:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    title = _collection_title(source_collection)
    _prepare_directory(handle, title, "videos")
    try:
        xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_UNSORTED)
    except Exception:
        pass

    collections = _media_lists_snapshot()
    records = sorted(
        collections.get(source_collection, {}).values(),
        key=lambda record: record.get("added_at") or "",
        reverse=True
    )
    if records:
        clear_item = xbmcgui.ListItem(label=f"Clear {_collection_title(source_collection)}")
        clear_item.setInfo('video', {'plot': f"Remove all local {_collection_title(source_collection).lower()} entries."})
        clear_url = build_url({'action': 'clear_media_list', 'collection': source_collection})
        xbmcplugin.addDirectoryItem(handle, clear_url, clear_item, isFolder=False)
    elif not records:
        empty_item = xbmcgui.ListItem(label=f"{title} is empty")
        empty_item.setInfo('video', {'plot': u"\u00A0"})
        xbmcplugin.addDirectoryItem(handle, "", empty_item, isFolder=False)
        xbmcplugin.endOfDirectory(handle)
        return

    for record in records:
        item_id = record.get("id") or _collection_id(record)
        if not item_id:
            continue

        item = xbmcgui.ListItem(label=_collection_label(record))
        item.setInfo('video', {
            'title': record.get("title") or record.get("stream_name") or "Media",
            'plot': _collection_plot(record)
        })
        art = _collection_art(record)
        if art:
            item.setArt(art)

        if record.get("kind") == "stream":
            item.setProperty('IsPlayable', 'true')

        context_items = _collection_context_menu_items(record, collections)
        context_items.append((
            f"Clear {_collection_title(source_collection)}",
            f"RunPlugin({build_url({'action': 'clear_media_list', 'collection': source_collection})})"
        ))
        item.addContextMenuItems(context_items, True)

        open_query = _collection_open_query(record)
        url = build_url(open_query) if open_query else ""
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=_collection_is_folder(record))

    xbmcplugin.endOfDirectory(handle)

def show_favorites(handle):
    show_media_collection(handle, "favorites")

def add_media_list_item(collection, params):
    if collection not in MEDIA_LIST_KEYS:
        xbmcgui.Dialog().notification("Media List", "Unknown list", xbmcgui.NOTIFICATION_ERROR, 2000)
        return

    item_id, record = _collection_record_from_params(params or {})
    if not item_id:
        xbmcgui.Dialog().notification(_collection_title(collection), "Item cannot be saved", xbmcgui.NOTIFICATION_ERROR, 2000)
        return

    try:
        added = media_lists_db.upsert(collection, item_id, record)
    except Exception as ex:
        xbmc.log(f"[media_lists] Could not add item {item_id} to {collection}: {ex}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification(_collection_title(collection), "Could not save item", xbmcgui.NOTIFICATION_ERROR, 2500)
        return

    message = "Added" if added else "Updated"
    xbmcgui.Dialog().notification(_collection_title(collection), f"{message}: {_collection_label(record)}", xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin("Container.Refresh")

def remove_media_list_item(collection, item_id):
    if collection not in MEDIA_LIST_KEYS or not item_id:
        return

    try:
        removed = media_lists_db.remove(collection, item_id)
    except Exception as ex:
        xbmc.log(f"[media_lists] Could not remove item {item_id} from {collection}: {ex}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification(_collection_title(collection), "Could not remove item", xbmcgui.NOTIFICATION_ERROR, 2500)
        return

    if removed:
        xbmcgui.Dialog().notification(_collection_title(collection), "Item removed", xbmcgui.NOTIFICATION_INFO, 1500)
    xbmc.executebuiltin("Container.Refresh")

def clear_media_list(collection):
    if collection not in MEDIA_LIST_KEYS:
        return

    title = _collection_title(collection)
    confirm = xbmcgui.Dialog().yesno(title, f"All local {title.lower()} entries will be removed. Continue?", yeslabel="Yes", nolabel="No")
    if not confirm:
        return

    media_lists_db.clear(collection)
    xbmc.executebuiltin("Container.Refresh")

def _history_id(record):
    media_type = record.get("media_type")
    if media_type == "movie" and record.get("movie_id") not in (None, ""):
        return f"movie:{record.get('movie_id')}"
    if media_type == "episode" and all(record.get(key) not in (None, "") for key in ("tv_id", "season", "episode_id")):
        return f"episode:{record.get('tv_id')}:{record.get('season')}:{record.get('episode_id')}"
    return f"stream:{record.get('stream_id')}"

def _trim_watch_history(data):
    if len(data) <= MAX_WATCH_HISTORY_ITEMS:
        return

    ordered = sorted(
        data.items(),
        key=lambda item: item[1].get("last_played_at") or item[1].get("created_at") or ""
    )
    for history_id, _ in ordered[:len(data) - MAX_WATCH_HISTORY_ITEMS]:
        data.pop(history_id, None)

def _record_watch_history(stream_id, params):
    if not stream_id:
        return

    params = params or {}
    media_type = params.get("media_type") or "stream"
    stream_name = params.get("stream_name") or params.get("filename") or ""
    title = params.get("title") or stream_name or f"Stream {stream_id}"
    timestamp = now_iso()
    record = {
        "stream_id": stream_id,
        "media_type": media_type,
        "movie_id": params.get("movie_id"),
        "tv_id": params.get("tv_id"),
        "season": params.get("season"),
        "episode_id": params.get("episode_id"),
        "episode_number": params.get("episode_number"),
        "tv_title": params.get("tv_title"),
        "episode_title": params.get("episode_title"),
        "title": title,
        "year": params.get("year"),
        "poster": _media_art_url(params.get("poster")),
        "fanart": _media_art_url(params.get("fanart")),
        "stream_name": stream_name,
        "last_played_at": timestamp
    }
    history_id = _history_id(record)
    record["id"] = history_id

    def op(data):
        existing = data.get(history_id, {})
        record["created_at"] = existing.get("created_at") or timestamp
        record["play_count"] = _as_int(existing.get("play_count"), 0) + 1
        data[history_id] = {
            key: value for key, value in record.items()
            if value not in (None, "")
        }
        _trim_watch_history(data)

    try:
        watch_history_db.mutate(op)
    except Exception as ex:
        xbmc.log(f"[watch_history] Could not record stream {stream_id}: {ex}", xbmc.LOGWARNING)

def _history_label(record):
    title = record.get("title") or record.get("stream_name") or "Stream"
    year = record.get("year")
    if record.get("media_type") == "movie" and year:
        return f"{title} [COLOR FFAAAAAA][{year}][/COLOR]"
    if record.get("media_type") == "episode":
        return f"[TV] {title}"
    return title

def _history_plot(record):
    lines = []
    if record.get("stream_name"):
        lines.append(f"Stream: {record.get('stream_name')}")
    if record.get("last_played_at"):
        lines.append(f"Last played: {record.get('last_played_at').replace('T', ' ')}")
    if record.get("play_count"):
        lines.append(f"Play count: {record.get('play_count')}")
    return "\n".join(lines) or u"\u00A0"

def _history_watched_when(record, now=None):
    value = record.get("last_played_at") or record.get("created_at")
    if not value:
        return "Watched recently"
    try:
        watched = datetime.datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        if watched.tzinfo is not None:
            watched = watched.astimezone()
        current = now or datetime.datetime.now().astimezone()
        if current.tzinfo is not None and watched.tzinfo is None:
            watched = watched.replace(tzinfo=current.tzinfo)
        day_delta = current.date() - watched.date()
        clock = watched.strftime("%H:%M")
        if day_delta.days == 0:
            return f"Watched today at {clock}"
        if day_delta.days == 1:
            return f"Watched yesterday at {clock}"
        if 1 < day_delta.days < 7:
            return f"Watched {watched.strftime('%A')} at {clock}"
        return f"Watched {watched.strftime('%d %b %Y')} at {clock}"
    except (TypeError, ValueError, OverflowError):
        return "Watched recently"

def _history_progress(record):
    progress = record.get("progress_percent", record.get("progress"))
    if progress in (None, ""):
        position = record.get("position_seconds", record.get("resume_seconds"))
        duration = record.get("duration_seconds")
        try:
            if float(duration) > 0:
                progress = (float(position) / float(duration)) * 100
        except (TypeError, ValueError, ZeroDivisionError):
            progress = None
    try:
        return max(0, min(100, int(round(float(progress)))))
    except (TypeError, ValueError):
        return None

def _history_is_complete(record, progress=None):
    explicit = record.get("completed", record.get("watched"))
    if isinstance(explicit, str):
        explicit = explicit.strip().lower() in ("1", "true", "yes")
    if explicit is not None:
        return bool(explicit)
    return progress is not None and progress >= 90

def _history_play_query(record):
    query = {
        "action": "play_movie_stream",
        "stream_id": record.get("stream_id", "")
    }
    for key in (
        "media_type",
        "movie_id",
        "tv_id",
        "season",
        "episode_id",
        "episode_number",
        "tv_title",
        "episode_title",
        "title",
        "year",
        "poster",
        "fanart",
        "stream_name"
    ):
        value = record.get(key)
        if value not in (None, ""):
            query[key] = value
    return query

def _history_episode_navigation_context_menu_items(record):
    if record.get("media_type") != "episode":
        return []

    tv_id = record.get("tv_id")
    if tv_id in (None, ""):
        return []

    tv_show_url = build_url({
        'action': 'list_seasons',
        'tv_id': tv_id
    })
    items = [(
        tr("Prejsť na seriál"),
        f"Container.Update({tv_show_url})"
    )]

    season = record.get("season")
    if season not in (None, ""):
        season_url = build_url({
            'action': 'list_episodes',
            'tv_id': tv_id,
            'season': season,
            'tv_title': record.get('tv_title') or '',
            'poster': record.get('poster') or '',
            'fanart': record.get('fanart') or ''
        })
        items.append((
            tr("Prejsť na sériu"),
            f"Container.Update({season_url})"
        ))

    return items

def _modern_history_episode_actions(record):
    if record.get("media_type") != "episode":
        return []
    tv_id = record.get("tv_id")
    if tv_id in (None, ""):
        return []

    common = {
        "tv_id": tv_id,
        "tv_title": record.get("tv_title") or "",
        "poster": record.get("poster") or "",
        "fanart": record.get("fanart") or "",
    }
    actions = []
    season = record.get("season")
    if season not in (None, ""):
        next_query = dict(common)
        next_query.update({
            "action": "show_next_episode",
            "season": season,
            "episode_id": record.get("episode_id") or "",
            "episode_number": record.get("episode_number") or "",
        })
        actions.append({
            "label": tr("Play next episode"),
            "label2": tr("Open the next available episode"),
            "command": "browse",
            "target": build_url(next_query),
            "properties": {"App.Badge": "PLAY"},
        })

        season_query = dict(common)
        season_query.update({"action": "list_episodes", "season": season})
        actions.append({
            "label": tr("View this season"),
            "label2": tr("Choose another episode"),
            "command": "browse",
            "target": build_url(season_query),
            "properties": {"App.Badge": "EPISODES"},
        })
    actions.append({
        "label": tr("View series"),
        "label2": tr("Browse every season"),
        "command": "browse",
        "target": build_url({"action": "list_seasons", "tv_id": tv_id}),
        "properties": {"App.Badge": "SERIES"},
    })
    return actions

def _hero_excerpt(value, limit=360):
    text = " ".join(str(value or "").split())
    if len(text) <= limit:
        return text
    boundary = text.rfind(" ", 0, limit + 1)
    if boundary < int(limit * 0.65):
        boundary = limit
    return text[:boundary].rstrip(" ,.;:-") + "…"


def _home_model(
    label,
    label2,
    command,
    target,
    fallback_art,
    eyebrow,
    title,
    meta,
    description,
    poster="",
    fanart="",
    thumb=""
):
    tile_art = thumb or poster or fanart or fallback_art
    background = fanart or poster or fallback_art
    action_labels = {
        "home": tr("Explore").upper(),
        "navigate": tr("Open").upper(),
        "play": tr("PLAY"),
        "settings": tr("SETTINGS"),
        "detail": tr("Details").upper(),
    }
    return {
        "label": tr(label),
        "label2": tr(label2),
        "command": command,
        "target": target,
        "art": {
            "thumb": tile_art,
            "poster": poster or tile_art,
            "fanart": background
        },
        "properties": {
            "MediaHub.Eyebrow": tr(eyebrow),
            "MediaHub.Title": tr(title),
            "MediaHub.Meta": meta,
            "MediaHub.Description": tr(description),
            "MediaHub.HeroDescription": _hero_excerpt(tr(description)),
            "MediaHub.Action": action_labels.get(command, tr("Open").upper()),
            "MediaHub.Progress": "0"
        }
    }

def _modern_home_navigation(fallback_art, history_count, favorite_count, download_count):
    entries = (
        (
            "Home",
            f"{history_count} recent  •  {favorite_count} saved",
            "home",
            "MEDIA HUB",
            "Everything worth watching.",
            "Your personal streaming space",
            "Movies, series, favourites and downloads in one place."
        ),
        (
            "Movies",
            "Popular, new and top rated",
            "movies",
            "MOVIES",
            "A film for every night.",
            "New releases  •  Top rated  •  Popular",
            "Browse a poster-first catalogue without leaving the Media Hub app."
        ),
        (
            "TV Series",
            "Trending and recently aired",
            "tv",
            "TV SERIES",
            "Your next series is here.",
            "Trending  •  New episodes  •  Slovak",
            "Move through series and new episodes in the same cinematic interface."
        ),
        (
            "Downloads",
            f"{download_count} downloads",
            "downloads",
            "OFFLINE LIBRARY",
            "Downloads under control.",
            f"{download_count} downloads",
            "Check progress and manage offline titles without changing screens."
        ),
        (
            "Favourites",
            f"{favorite_count} saved",
            "favorites",
            "MY LIST",
            "Your favourites, always close.",
            f"{favorite_count} saved items",
            "Return to saved films, series, episodes and streams."
        ),
        (
            "Recently Viewed",
            f"{history_count} recent plays",
            "history",
            "RECENTLY VIEWED",
            "Continue where you left off.",
            f"{history_count} items in history",
            "Resume recent movies and episodes in one click."
        ),
        (
            "Settings",
            "Playback, API and downloads",
            "settings",
            "SETTINGS",
            "Media Hub, your way.",
            "Playback  •  API  •  Downloads",
            "Review the main preference areas before opening Kodi's settings panel."
        )
    )

    models = [
        _home_model(
            tr(label),
            label2,
            "page",
            "",
            fallback_art,
            tr(eyebrow),
            tr(title),
            meta,
            tr(description)
        )
        for (
            label,
            label2,
            page,
            eyebrow,
            title,
            meta,
            description
        ) in entries
    ]
    # Use the active skin's monochrome side-menu artwork so the rail reads like
    # a native TV application instead of a row of letter monograms.
    navigation_media = os.path.join(
        xbmcaddon.Addon().getAddonInfo("path"),
        "resources",
        "skins",
        "Default",
        "media",
    )
    icons = tuple(
        os.path.join(navigation_media, filename)
        for filename in (
            "nav-home.png",
            "nav-movies.png",
            "nav-tv.png",
            "nav-downloads.png",
            "nav-favorites.png",
            "nav-recent.png",
            "nav-settings.png",
        )
    )
    glyphs = ("H", "M", "T", "D", "F", "R", "S")
    for model, icon, glyph, entry in zip(models, icons, glyphs, entries):
        model["properties"]["MediaHub.NavIcon"] = icon
        model["properties"]["MediaHub.NavGlyph"] = glyph
        model["properties"]["App.Page"] = entry[2]
    return models

def _modern_home_quick_items(fallback_art):
    entries = (
        (
            "Populárne filmy",
            "Najsledovanejšie tituly",
            {"action": "menu_item_movies_popular", "filter_type": "all_time"},
            "TRENDY",
            "Najpopulárnejšie filmy práve teraz."
        ),
        (
            "Nové filmy",
            "Čerstvo pridané",
            {"action": "menu_item_movies_latest"},
            "NOVINKY",
            "Pozrite si najnovšie filmové prírastky."
        ),
        (
            "Populárne seriály",
            "Série, ktoré sa sledujú",
            {"action": "list_tv_shows_popular"},
            "TRENDY",
            "Objavte seriály, ktoré práve priťahujú pozornosť."
        ),
        (
            "Nové seriály",
            "Najnovšie série",
            {"action": "list_tv_shows_latest"},
            "NOVINKY",
            "Prejdite na nové seriály a čerstvé série."
        ),
        (
            "Objavovať",
            "Žánre, roky a hodnotenie",
            {"action": "show_discovery_filters", "media_type": "movie"},
            "OBJAVUJTE",
            "Vyberte si obsah pomocou inteligentných filtrov."
        ),
        (
            "Hľadať",
            "Filmy a seriály",
            {"action": "menu_item_search"},
            "HĽADAŤ",
            "Vyhľadajte konkrétny titul."
        )
    )
    return [
        _home_model(
            label,
            label2,
            "browse",
            build_url(query),
            fallback_art,
            eyebrow,
            label,
            label2,
            description
        )
        for label, label2, query, eyebrow, description in entries
    ]

def _modern_home_history_items(fallback_art, limit=10):
    try:
        snapshot = watch_history_db.list()
    except Exception as ex:
        xbmc.log(f"[modern_home] Could not read watch history: {ex}", xbmc.LOGWARNING)
        snapshot = {}

    records = sorted(
        (
            record
            for record in snapshot.values()
            if isinstance(record, dict)
        ) if isinstance(snapshot, dict) else (),
        key=lambda record: record.get("last_played_at") or record.get("created_at") or "",
        reverse=True
    )
    items = []
    for record in records:
        if not record.get("stream_id"):
            continue
        media_label = "Movie" if record.get("media_type") == "movie" else "Episode"
        year = _clean_query_value(record.get("year"))
        episode_meta = ""
        if record.get("media_type") == "episode":
            season = _as_int(record.get("season"), 0)
            episode = _episode_number(record)
            if season and episode:
                episode_meta = f"S{season:02d} E{episode:02d}"
            elif season:
                episode_meta = f"Season {season}"
        meta = "  •  ".join(
            value for value in (media_label, episode_meta, year) if value
        )
        title = record.get("title") or record.get("stream_name") or "Nedávno prehrané"
        progress = _history_progress(record)
        complete = _history_is_complete(record, progress)
        action_label = tr("Watch again") if complete else tr("Continue watching")
        watched_when = _history_watched_when(record)
        poster = _media_art_url(record.get("poster"))
        fanart = _media_art_url(record.get("fanart")) or poster
        thumb = (
            poster
            if record.get("media_type") == "episode"
            else fanart or poster
        )
        model = _home_model(
            title,
            action_label,
            "play",
            build_url(_history_play_query(record)),
            fallback_art,
            "NEDÁVNO PREHRANÉ",
            title,
            meta,
            _history_plot(record),
            poster,
            fanart,
            thumb
        )
        model["properties"].update({
            "App.Kind": "movie" if record.get("media_type") == "movie" else "tv",
            "App.KindLabel": media_label,
            "App.Year": year,
            "App.Rating": "",
            "App.HistoryMeta": meta,
            "App.WatchedWhen": watched_when,
            "App.WatchAction": action_label,
            "App.Progress": "" if progress is None else str(progress),
            "App.HasProgress": "true" if progress is not None and not complete else "false",
            "App.HistoryLinks": (
                "MENU  •  Series, season & next episode"
                if record.get("media_type") == "episode" and record.get("tv_id")
                else ""
            )
        })
        if record.get("media_type") == "episode":
            model["context_actions"] = [{
                "label": action_label,
                "label2": tr("Resume this episode") if not complete else tr("Replay this episode"),
                "command": "play",
                "target": build_url(_history_play_query(record)),
                "properties": {"App.Badge": "PLAY"},
            }]
            model["context_actions"].extend(
                _modern_history_episode_actions(record)
            )
        items.append(model)
        if limit is not None and len(items) >= limit:
            break
    return items

def _modern_home_favorite_items(fallback_art, limit=10):
    collections = _media_lists_snapshot()
    records = sorted(
        (
            record
            for record in collections.get("favorites", {}).values()
            if isinstance(record, dict)
        ),
        key=lambda record: record.get("added_at") or "",
        reverse=True
    )
    kind_labels = {
        "movie": "Film",
        "tv_show": "Seriál",
        "season": "Séria",
        "episode": "Epizóda",
        "stream": "Stream"
    }
    items = []
    for record in records:
        query = _collection_open_query(record)
        if not query:
            continue
        art = _collection_art(record)
        title = _collection_label(record)
        command = (
            "detail"
            if record.get("kind") in ("movie", "tv_show")
            else "play"
            if record.get("kind") == "stream"
            else "browse"
        )
        model = _home_model(
            title,
            kind_labels.get(record.get("kind"), "Médiá"),
            command,
            build_url(query),
            fallback_art,
            "OBĽÚBENÉ",
            record.get("title") or record.get("stream_name") or title,
            kind_labels.get(record.get("kind"), "Médiá"),
            _collection_plot(record),
            art.get("poster") or art.get("thumb") or "",
            art.get("fanart") or "",
            art.get("fanart") or art.get("thumb") or ""
        )
        model["properties"].update({
            "App.Kind": "tv" if record.get("kind") == "tv_show" else "movie",
            "App.KindLabel": kind_labels.get(record.get("kind"), "Media"),
            "App.Year": _clean_query_value(record.get("year")),
            "App.Rating": ""
        })
        items.append(model)
        if limit is not None and len(items) >= limit:
            break
    return items

def _modern_home_download_items(fallback_art, limit=6):
    try:
        snapshot = _list_downloads_normalized()
    except Exception as ex:
        xbmc.log(f"[modern_home] Could not read downloads: {ex}", xbmc.LOGWARNING)
        snapshot = {}

    records = [
        record for record in snapshot.values() if isinstance(record, dict)
    ]
    active = sorted(
        (record for record in records if record.get("status") in ACTIVE_DOWNLOAD_STATUSES),
        key=lambda record: (
            _queue_position(record),
            record.get("updated_at") or record.get("created_at") or "",
        ),
    )
    queued = sorted(
        (record for record in records if record.get("status") in QUEUE_STATUSES),
        key=lambda record: (
            _queue_position(record),
            record.get("created_at") or "",
        ),
    )
    history = sorted(
        (
            record for record in records
            if record.get("status") not in ACTIVE_DOWNLOAD_STATUSES + QUEUE_STATUSES
        ),
        key=lambda record: record.get("updated_at") or record.get("created_at") or "",
        reverse=True,
    )
    records = active + queued + history
    status_labels = {
        "queued": "Vo fronte",
        "paused": "Pozastavené",
        "waiting_retry": "Čaká na opakovanie",
        "downloading": "Sťahuje sa",
        "pausing": "Pozastavuje sa",
        "canceling": "Ruší sa",
        "repairing": "Opravuje sa",
        "finalizing": "Dokončuje sa",
        "complete": "Complete",
        "failed": "Failed",
        "canceled": "Canceled",
    }
    items = []
    visible_records = records if limit is None else records[:limit]
    for record in visible_records:
        status = record.get("status", "")
        progress = _as_int(record.get("progress"), 0)
        status_label = status_labels.get(status, status)
        meta = f"{status_label}  •  {progress}%"
        downloaded = _format_bytes(record.get("bytes_done"))
        total = _format_bytes(record.get("bytes_total"))
        description = f"Stiahnuté: {downloaded} / {total}"
        model = _home_model(
            record.get("filename") or "Sťahovanie",
            meta,
            "browse",
            build_url({"action": "show_download_actions", "id": record.get("id", "")}),
            fallback_art,
            "SŤAHOVANIE",
            record.get("filename") or "Sťahovanie",
            meta,
            description
        )
        model["properties"]["MediaHub.Progress"] = str(progress)
        model["properties"]["App.Status"] = status
        items.append(model)
    return items


def _modern_settings_items(fallback_art):
    entries = (
        (
            "Account & API",
            "Connection, credentials and service access",
            "Manage the backend address and API authentication."
        ),
        (
            "Playback",
            "Quality, subtitles and language",
            "Review preferred playback behaviour and subtitle options."
        ),
        (
            "Downloads",
            "Storage, queue and offline files",
            "Choose download storage and background transfer behaviour."
        ),
        (
            "TV filtering",
            "Animation and catalogue preferences",
            "Control which series are included in discovery screens."
        ),
        (
            "Interface",
            "Modern home and compatibility options",
            "Switch between the app shell and Kodi's classic directory interface."
        ),
        (
            "About",
            "Media Hub  •  Kodi addon",
            "Version, privacy and addon information."
        ),
    )
    models = [
        _home_model(
            tr(label),
            tr(label2),
            "browse",
            build_url({"action": "modern_settings", "section": section}),
            fallback_art,
            "SETTINGS",
            tr(label),
            tr(label2),
            tr(description),
        )
        for section, (label, label2, description) in zip(
            ("account", "playback", "downloads", "tv", "interface", "about"),
            entries,
        )
    ]
    return models


def _modern_genre_name_map(response):
    if isinstance(response, dict):
        entries = response.get("genres") or response.get("results") or []
    elif isinstance(response, (list, tuple)):
        entries = response
    else:
        entries = []

    names = {}
    for genre in entries:
        if not isinstance(genre, dict):
            continue
        genre_id = _as_int(genre.get("id", genre.get("Id")), 0)
        name = _clean_query_value(genre.get("name", genre.get("Name")))
        if genre_id > 0 and name:
            names[genre_id] = name
    return names


def _modern_genre_label(media, genre_names):
    names = []
    seen = set()

    for genre in media.get("genres") or []:
        if not isinstance(genre, dict):
            continue
        name = _clean_query_value(genre.get("name", genre.get("Name")))
        key = name.casefold()
        if name and key not in seen:
            names.append(name)
            seen.add(key)

    for genre_id in media.get("genre_ids") or []:
        normalized_id = _as_int(genre_id, 0)
        name = _clean_query_value((genre_names or {}).get(normalized_id))
        key = name.casefold()
        if name and key not in seen:
            names.append(name)
            seen.add(key)

    return ", ".join(names)


def _modern_movie_catalog_models(
    response,
    fallback_art,
    eyebrow="MOVIE",
    genre_names=None,
):
    results = response.get("results", []) if isinstance(response, dict) else []
    models = []
    for movie in results:
        if not isinstance(movie, dict):
            continue
        title = _movie_display_title(movie) or "Movie"
        year = _movie_release_year(movie)
        rating = _as_float(movie.get("vote_average"), 0.0)
        runtime = _as_int(movie.get("runtime"), 0)
        duration = f"{runtime} min" if runtime > 0 else ""
        genre_label = _modern_genre_label(movie, genre_names)
        meta = "  •  ".join(
            value for value in (
                year,
                duration,
                genre_label,
                f"★ {rating:.1f}" if rating else "",
            ) if value
        )
        poster = movie.get("poster_path", "")
        fanart = movie.get("backdrop_path", "") or poster
        model = _home_model(
            title,
            meta,
            "detail",
            _build_movie_versions_url(movie),
            fallback_art,
            eyebrow,
            title,
            meta,
            movie.get("overview", ""),
            poster,
            fanart,
            fanart,
        )
        model["properties"].update({
            "App.Kind": "movie",
            "App.KindLabel": genre_label,
            "App.Genres": genre_label,
            "App.Id": _clean_query_value(movie.get("id")),
            "App.Year": year,
            "App.Rating": f"{rating:.1f}" if rating else "",
            "App.Duration": duration,
        })
        models.append(model)
    return models


def _modern_tv_catalog_models(
    response,
    fallback_art,
    eyebrow="TV SERIES",
    genre_names=None,
):
    results = response.get("results", []) if isinstance(response, dict) else []
    results = _filter_tv_shows(results)
    models = []
    for show in results:
        if not isinstance(show, dict):
            continue
        title = show.get("name_with_original_name") or show.get("name") or "TV Series"
        year = _get_tv_year(show)
        rating = _as_float(show.get("vote_average"), 0.0)
        genre_label = _modern_genre_label(show, genre_names)
        meta = "  •  ".join(
            value for value in (
                year if year != "----" else "",
                genre_label,
                f"★ {rating:.1f}" if rating else "",
            ) if value
        )
        poster = _media_art_url(show.get("poster_path"))
        fanart = _media_art_url(show.get("backdrop_path")) or poster
        model = _home_model(
            title,
            meta,
            "detail",
            build_url({"action": "list_seasons", "tv_id": show.get("id", "")}),
            fallback_art,
            eyebrow,
            title,
            meta,
            show.get("overview", ""),
            poster,
            fanart,
            fanart,
        )
        model["properties"].update({
            "App.Kind": "tv",
            "App.KindLabel": genre_label,
            "App.Genres": genre_label,
            "App.Id": _clean_query_value(show.get("id")),
            "App.Year": year if year != "----" else "",
            "App.Rating": f"{rating:.1f}" if rating else "",
        })
        models.append(model)
    return models


def _load_modern_catalog(
    page,
    tab,
    fallback_art,
    movie_genre_names=None,
    tv_genre_names=None,
    page_number=1,
):
    if page == "movies":
        if tab == "latest":
            response = api.get_movies_latest(page_number)
            eyebrow = "NEW RELEASE"
        elif tab == "top":
            response = api.get_movies_toprated(page_number)
            eyebrow = "TOP RATED"
        else:
            response = api.get_movies_popular(page_number)
            eyebrow = "POPULAR MOVIE"
        return _modern_movie_catalog_models(
            response,
            fallback_art,
            eyebrow,
            movie_genre_names,
        )

    if page == "tv":
        if tab == "latest":
            response = api.get_tv_latest(page_number)
            eyebrow = "NEW SERIES"
        elif tab == "recent":
            response = api.get_tv_recently_aired(page_number, 30)
            eyebrow = "RECENTLY AIRED"
        elif tab == "slovak":
            response = api.get_tv_sk(page_number)
            eyebrow = "SLOVAK TV"
        else:
            response = api.get_tv_popular(page_number)
            eyebrow = "POPULAR SERIES"
        return _modern_tv_catalog_models(
            response,
            fallback_art,
            eyebrow,
            tv_genre_names,
        )
    return []


def _load_modern_search(
    query,
    fallback_art,
    movie_genre_names=None,
    tv_genre_names=None,
):
    with ThreadPoolExecutor(max_workers=2) as executor:
        movie_future = executor.submit(api.get_movies_search, query, 1)
        tv_future = executor.submit(api.get_tv_search, query, 1)
        movie_response = movie_future.result()
        tv_response = tv_future.result()
    movies = _modern_movie_catalog_models(
        movie_response,
        fallback_art,
        "SEARCH • MOVIE",
        movie_genre_names,
    )
    shows = _modern_tv_catalog_models(
        tv_response,
        fallback_art,
        "SEARCH • TV",
        tv_genre_names,
    )
    return movies + shows


def _modern_target_params(target):
    parsed = urllib.parse.urlparse(str(target or ""))
    return dict(urllib.parse.parse_qsl(parsed.query))


def _modern_browser_model(
    label, label2, command, target, fallback_art, description="",
    poster="", fanart="", badge="", hint="OK  •  Open", context_target=""
):
    model = _home_model(
        label, label2, command, target, fallback_art, "MEDIA HUB", label,
        label2, description, poster, fanart, poster or fanart
    )
    model["properties"].update({
        "App.Badge": badge,
        "App.Hint": hint,
        "App.ContextTarget": context_target,
    })
    return model


def _modern_browser_view(
    title, subtitle, items, fallback_art, eyebrow="MEDIA HUB",
    empty="Nothing to show yet.", fanart=""
):
    return {
        "title": tr(title),
        "subtitle": tr(subtitle),
        "eyebrow": tr(eyebrow),
        "empty": tr(empty),
        "fanart": fanart or fallback_art,
        "items": items,
    }


def _modern_next_page_model(params, total_pages, fallback_art):
    page = max(1, _as_int(params.get("page"), 1))
    total_pages = max(1, _as_int(total_pages, 1))
    if page >= total_pages:
        return None
    next_params = dict(params)
    next_params["page"] = page + 1
    return _modern_browser_model(
        "Next Page", "Page {0} of {1}".format(page + 1, total_pages),
        "browse", build_url(next_params), fallback_art,
        "Continue through the catalogue inside Media Hub.",
        badge="PAGE {0}".format(page + 1), hint="OK  •  Load more"
    )


def _modern_prompt_search(title):
    keyboard = xbmc.Keyboard("", title)
    keyboard.doModal()
    return (
        _clean_query_value(keyboard.getText())
        if keyboard.isConfirmed() else ""
    )


def _modern_root_browser(params, fallback_art):
    action = params.get("action")
    if action == "menu_item_search":
        entries = (
            ("Search Movies", "Search the film catalogue", "menu_item_movies_search"),
            ("Search TV Series", "Search every available series", "menu_item_tvshows_search"),
        )
        title, subtitle, eyebrow, media_type = "Search", "Choose a catalogue", "SEARCH", "movie"
    elif action == "menu_item_tvshows":
        entries = (
            ("Popular", "Trending TV series", "list_tv_shows_popular"),
            ("New Releases", "Recently added series", "list_tv_shows_latest"),
            ("Recently Aired", "New seasons and episodes", "list_tv_shows_recently_aired"),
            ("Slovak", "Slovak TV catalogue", "list_tv_shows_sk"),
            ("Discover", "Genres, years and ratings", "show_discovery_filters"),
            ("Search", "Find a TV series", "menu_item_tvshows_search"),
        )
        title, subtitle, eyebrow, media_type = "TV Series", "Browse every collection", "TV SERIES", "tv"
    else:
        entries = (
            ("Popular", "The most watched films", "menu_item_movies_popular"),
            ("New Releases", "Recently added movies", "menu_item_movies_latest"),
            ("Top Rated", "The highest-rated films", "menu_item_movies_toprated"),
            ("Discover", "Genres, years and ratings", "show_discovery_filters"),
            ("Search", "Find a movie", "menu_item_movies_search"),
        )
        title, subtitle, eyebrow, media_type = "Movies", "Browse every collection", "MOVIES", "movie"
    items = []
    for label, label2, target_action in entries:
        query = {"action": target_action}
        if target_action == "show_discovery_filters":
            query["media_type"] = media_type
        items.append(_modern_browser_model(
            label, label2, "browse", build_url(query), fallback_art,
            "Open {0} in the modern Media Hub browser.".format(label.lower()),
            badge="OPEN"
        ))
    return _modern_browser_view(title, subtitle, items, fallback_art, eyebrow)


def _modern_catalog_browser(params, fallback_art, genre_names):
    action = params.get("action", "")
    page = max(1, _as_int(params.get("page"), 1))
    media_type = "tv" if action.startswith("list_tv") or "tvshows" in action else "movie"
    query = params.get("search_query", "")
    if action in ("menu_item_movies_search", "menu_item_tvshows_search") and not query:
        query = _modern_prompt_search(
            "Search TV series" if media_type == "tv" else "Search movies"
        )
        if not query:
            return _modern_browser_view(
                "Search", "Search was cancelled", [], fallback_art, "SEARCH",
                "Use the search button in the side rail to try again."
            )
        params = dict(params)
        params.update({"search_query": query, "page": page})

    if action == "menu_item_movies_latest":
        response, title, eyebrow = api.get_movies_latest(page), "New Movies", "NEW RELEASES"
    elif action == "menu_item_movies_toprated":
        response, title, eyebrow = api.get_movies_toprated(page), "Top Rated Movies", "TOP RATED"
    elif action == "menu_item_movies_search":
        response, title, eyebrow = api.get_movies_search(query, page), "Movie Search", "SEARCH"
    elif action == "list_tv_shows_latest":
        response, title, eyebrow = api.get_tv_latest(page), "New TV Series", "NEW SERIES"
    elif action == "list_tv_shows_recently_aired":
        response = api.get_tv_recently_aired(page, max(1, _as_int(params.get("days"), 30)))
        title, eyebrow = "Recently Aired", "NEW EPISODES"
    elif action == "list_tv_shows_sk":
        response, title, eyebrow = api.get_tv_sk(page), "Slovak TV Series", "SLOVAK TV"
    elif action == "menu_item_tvshows_search":
        response, title, eyebrow = api.get_tv_search(query, page), "TV Search", "SEARCH"
    elif action == "list_tv_shows_popular":
        response, title, eyebrow = api.get_tv_popular(page), "Popular TV Series", "POPULAR"
    else:
        response, title, eyebrow = api.get_movies_popular(page), "Popular Movies", "POPULAR"
    models = (
        _modern_tv_catalog_models(response, fallback_art, eyebrow, genre_names("tv"))
        if media_type == "tv"
        else _modern_movie_catalog_models(response, fallback_art, eyebrow, genre_names("movie"))
    )
    total_pages = response.get("total_pages", 1) if isinstance(response, dict) else 1
    next_model = _modern_next_page_model(params, total_pages, fallback_art)
    if next_model:
        models.append(next_model)
    subtitle = "Page {0} of {1}".format(page, max(1, _as_int(total_pages, 1)))
    if query:
        subtitle = "Results for “{0}”  •  {1}".format(query, subtitle)
    return _modern_browser_view(
        title, subtitle, models, fallback_art, eyebrow,
        "No matching titles were found."
    )


def _modern_discovery_model(
    label,
    label2,
    command,
    target,
    fallback_art,
    *,
    selected=False,
    primary=False,
    key="",
    description="",
):
    model = _modern_browser_model(
        label,
        label2,
        command,
        target,
        fallback_art,
        description,
        badge="SELECTED" if selected else "",
        hint="OK  •  Select",
    )
    model["properties"].update({
        "App.Selected": "true" if selected else "false",
        "App.Primary": "true" if primary else "false",
        "App.FilterKey": key,
    })
    return model


def _discovery_option_target(media_type, state, section):
    return build_url(_discovery_query(
        "show_discovery_filters",
        media_type,
        state,
        section=section,
    ))


def _modern_discovery_genre_options(
    media_type,
    state,
    section,
    fallback_art,
    genre_name_map,
):
    selected_ids = _discovery_genre_ids(state)
    options = [
        _modern_discovery_model(
            "All genres",
            "Clear every genre selection",
            "browser_replace",
            _discovery_option_target(
                media_type,
                _discovery_state_with(
                    state,
                    genre_ids=None,
                    genre_names=None,
                ),
                section,
            ),
            fallback_art,
            selected=not selected_ids,
            key="all",
        )
    ]
    for genre_id, name in sorted(
        (genre_name_map or {}).items(),
        key=lambda item: _clean_query_value(item[1]).casefold(),
    ):
        genre_id = _as_int(genre_id, 0)
        name = _clean_query_value(name)
        if genre_id <= 0 or not name:
            continue
        toggled = list(selected_ids)
        if genre_id in toggled:
            toggled.remove(genre_id)
        else:
            toggled.append(genre_id)
        toggled_names = [
            _clean_query_value((genre_name_map or {}).get(value))
            for value in toggled
            if _clean_query_value((genre_name_map or {}).get(value))
        ]
        updated = _discovery_state_with(
            state,
            genre_ids=",".join(str(value) for value in toggled) or None,
            genre_names="|".join(toggled_names) or None,
        )
        options.append(_modern_discovery_model(
            name,
            "Included in results" if genre_id in selected_ids else "Include this genre",
            "browser_replace",
            _discovery_option_target(media_type, updated, section),
            fallback_art,
            selected=genre_id in selected_ids,
            key=str(genre_id),
        ))
    return options


def _modern_discovery_period_options(
    media_type,
    state,
    section,
    fallback_art,
):
    current_year = time.gmtime().tm_year
    presets = [
        ("Any time", None, None),
        ("This year", current_year, current_year),
        ("Last 3 years", current_year - 2, current_year),
        ("Last 5 years", current_year - 4, current_year),
        ("2020s", 2020, min(current_year + 1, 2029)),
        ("2010s", 2010, 2019),
        ("2000s", 2000, 2009),
        ("1990s", 1990, 1999),
        ("1980s", 1980, 1989),
    ]
    selected_from = _valid_discovery_year(state.get("year_from"))
    selected_to = _valid_discovery_year(state.get("year_to"))
    selected_exact = _valid_discovery_year(state.get("year"))
    options = []
    for label, year_from, year_to in presets:
        updated = _discovery_state_with(
            state,
            year=None,
            year_from=str(year_from) if year_from else None,
            year_to=str(year_to) if year_to else None,
        )
        selected = (
            not year_from and not year_to
            and not selected_from and not selected_to and not selected_exact
        ) or (
            year_from == selected_from and year_to == selected_to
        )
        value = (
            "No release-date limit"
            if year_from is None
            else "{0}–{1}".format(year_from, year_to)
        )
        options.append(_modern_discovery_model(
            label,
            value,
            "browser_replace",
            _discovery_option_target(media_type, updated, section),
            fallback_art,
            selected=selected,
            key=label,
        ))
    options.append(_modern_discovery_model(
        "Custom range…",
        _discovery_period_label(state),
        "action",
        build_url(_discovery_query(
            "configure_discovery_filter",
            media_type,
            state,
            filter="release_period",
            section=section,
        )),
        fallback_art,
        selected=bool(
            (selected_from or selected_to or selected_exact)
            and not any(
                (
                    selected_from == year_from
                    and selected_to == year_to
                )
                for _label, year_from, year_to in presets
                if year_from is not None
            )
        ),
        key="custom",
    ))
    return options


def _modern_discovery_rating_options(
    media_type,
    state,
    section,
    fallback_art,
):
    current = _as_float(state.get("minimum_rating"))
    choices = [("", "Any rating")] + [
        ("{0:.1f}".format(value / 2), "{0:.1f}+".format(value / 2))
        for value in range(12, 19)
    ]
    return [
        _modern_discovery_model(
            label,
            "No minimum" if not value else "TMDB user rating",
            "browser_replace",
            _discovery_option_target(
                media_type,
                _discovery_state_with(state, minimum_rating=value or None),
                section,
            ),
            fallback_art,
            selected=(
                current is None if not value
                else current == _as_float(value)
            ),
            key=value or "any",
        )
        for value, label in choices
    ]


def _modern_discovery_vote_options(
    media_type,
    state,
    section,
    fallback_art,
):
    current = max(0, _as_int(state.get("minimum_vote_count"), 0))
    choices = (
        (0, "Any count"),
        (25, "25+ ratings"),
        (100, "100+ ratings"),
        (250, "250+ ratings"),
        (500, "500+ ratings"),
        (1000, "1,000+ ratings"),
    )
    return [
        _modern_discovery_model(
            label,
            "Rating confidence",
            "browser_replace",
            _discovery_option_target(
                media_type,
                _discovery_state_with(
                    state,
                    minimum_vote_count=str(value),
                ),
                section,
            ),
            fallback_art,
            selected=current == value,
            key=str(value),
        )
        for value, label in choices
    ]


def _modern_discovery_sort_models(
    media_type,
    state,
    section,
    fallback_art,
):
    current = state.get("sort", "popularity.desc")
    return [
        _modern_discovery_model(
            label,
            "Result order",
            "browser_replace",
            _discovery_option_target(
                media_type,
                _discovery_state_with(state, sort=value),
                section,
            ),
            fallback_art,
            selected=current == value,
            key=value,
        )
        for value, label in _discovery_sort_options(media_type)
    ]


def _modern_discovery_chip_models(media_type, state, fallback_art):
    chips = []
    genre_names = _discovery_genre_names(state)
    genre_ids = _discovery_genre_ids(state)
    visible_genre_names = genre_names[:3]
    if len(genre_names) > 3:
        visible_genre_names = genre_names[:2] + [
            tr("+{0} more", len(genre_names) - 2)
        ]
    for index, name in enumerate(visible_genre_names):
        chips.append((name, "genre-{0}".format(index), "genre"))
    if not genre_names and genre_ids:
        chips.append(
            (
                _discovery_genre_label(state),
                "genres",
                "genre",
            )
        )

    if (
        _valid_discovery_year(state.get("year"))
        or _valid_discovery_year(state.get("year_from"))
        or _valid_discovery_year(state.get("year_to"))
    ):
        chips.append(
            (_discovery_period_label(state), "period", "release_period")
        )
    if state.get("minimum_rating"):
        chips.append(
            (
                "{0}+".format(state["minimum_rating"]),
                "rating",
                "minimum_rating",
            )
        )
    minimum_vote_count = max(
        0,
        _as_int(state.get("minimum_vote_count"), 0),
    )
    if minimum_vote_count:
        chips.append(
            (
                tr(
                    "{0}+ ratings",
                    "{0:,}".format(minimum_vote_count),
                ),
                "ratings-count",
                "minimum_vote_count",
            )
        )
    chips.append(
        (
            tr(_discovery_sort_label(state.get("sort"), media_type)),
            "sort",
            "sort",
        )
    )

    return [
        _modern_discovery_model(
            label,
            "",
            "edit_filters",
            _discovery_option_target(media_type, state, section),
            fallback_art,
            key=key,
        )
        for label, key, section in chips
    ]


def _modern_filter_studio_view(
    params,
    media_type,
    state,
    fallback_art,
    genre_names,
):
    section = params.get("section", "genre")
    if section not in DISCOVERY_SECTIONS:
        section = "genre"
    vote_count = max(0, _as_int(state.get("minimum_vote_count"), 0))
    groups = (
        (
            "genre",
            "Genres",
            (
                _discovery_genre_label(state)
                if _discovery_genre_ids(state)
                else "All"
            ),
            bool(_discovery_genre_ids(state)),
        ),
        (
            "release_period",
            "First aired" if media_type == "tv" else "Release period",
            (
                _discovery_period_label(state)
                if (
                    _valid_discovery_year(state.get("year"))
                    or _valid_discovery_year(state.get("year_from"))
                    or _valid_discovery_year(state.get("year_to"))
                )
                else "No limit"
            ),
            bool(
                _valid_discovery_year(state.get("year"))
                or _valid_discovery_year(state.get("year_from"))
                or _valid_discovery_year(state.get("year_to"))
            ),
        ),
        (
            "minimum_rating",
            "Minimum rating",
            (
                "{0}+".format(state["minimum_rating"])
                if state.get("minimum_rating")
                else "No minimum"
            ),
            bool(state.get("minimum_rating")),
        ),
        (
            "minimum_vote_count",
            "Ratings count",
            "{0}+".format(vote_count) if vote_count else "No minimum",
            vote_count > 0,
        ),
        (
            "sort",
            "Sort by",
            _discovery_sort_label(state.get("sort"), media_type),
            state.get("sort", "popularity.desc") != "popularity.desc",
        ),
    )
    group_models = []
    for key, label, value, has_value in groups:
        model = _modern_discovery_model(
            label,
            value,
            "browser_replace",
            _discovery_option_target(media_type, state, key),
            fallback_art,
            selected=section == key,
            key=key,
        )
        model["properties"]["App.HasValue"] = (
            "true" if has_value else "false"
        )
        group_models.append(model)

    if section == "genre":
        options = _modern_discovery_genre_options(
            media_type,
            state,
            section,
            fallback_art,
            genre_names(media_type),
        )
    elif section == "release_period":
        options = _modern_discovery_period_options(
            media_type,
            state,
            section,
            fallback_art,
        )
    elif section == "minimum_rating":
        options = _modern_discovery_rating_options(
            media_type,
            state,
            section,
            fallback_art,
        )
    elif section == "minimum_vote_count":
        options = _modern_discovery_vote_options(
            media_type,
            state,
            section,
            fallback_art,
        )
    else:
        options = _modern_discovery_sort_models(
            media_type,
            state,
            section,
            fallback_art,
        )

    clear_state = _discovery_state({})
    actions = [
        _modern_discovery_model(
            "Clear all",
            "Restore discovery defaults",
            "browser_replace",
            _discovery_option_target(media_type, clear_state, "genre"),
            fallback_art,
            key="clear",
        ),
        _modern_discovery_model(
            "Show results",
            _discovery_compact_summary(media_type, state),
            "apply_filters",
            build_url(_discovery_query(
                "list_discovery_results",
                media_type,
                state,
                page=1,
                section=section,
            )),
            fallback_art,
            primary=True,
            key="apply",
        ),
    ]
    view = _modern_browser_view(
        "Discover {0}".format("TV Series" if media_type == "tv" else "Movies"),
        "Build your perfect watchlist",
        [],
        fallback_art,
        "FILTER STUDIO",
    )
    view.update({
        "layout": "filter_studio",
        "media_type": media_type,
        "groups": group_models,
        "options": options,
        "actions": actions,
        "summary": _discovery_compact_summary(media_type, state),
        "active_count": _discovery_active_count(state),
        "section": section,
    })
    return view


def _modern_filter_results_view(
    params,
    media_type,
    state,
    fallback_art,
    genre_names,
):
    page = max(1, _as_int(params.get("page"), 1))
    request_kwargs = {
        "page": page,
        "genre_ids": _discovery_genre_ids(state),
        "year": _as_int(state.get("year"), 0) or None,
        "year_from": _as_int(state.get("year_from"), 0) or None,
        "year_to": _as_int(state.get("year_to"), 0) or None,
        "sort": state.get("sort", "popularity.desc"),
        "minimum_rating": _as_float(state.get("minimum_rating")),
        "minimum_vote_count": max(
            0,
            _as_int(state.get("minimum_vote_count"), 0),
        ),
    }
    response = (
        api.discover_tv(**request_kwargs)
        if media_type == "tv"
        else api.discover_movies(**request_kwargs)
    )
    result_models = (
        _modern_tv_catalog_models(
            response,
            fallback_art,
            "DISCOVERY • TV",
            genre_names("tv"),
        )
        if media_type == "tv"
        else _modern_movie_catalog_models(
            response,
            fallback_art,
            "DISCOVERY • MOVIE",
            genre_names("movie"),
        )
    )
    total_pages = (
        response.get("total_pages", 1)
        if isinstance(response, dict)
        else 1
    )
    normalized_total_pages = max(1, _as_int(total_pages, 1))
    pagination_actions = []
    if page > 1:
        previous_params = dict(params)
        previous_params["page"] = page - 1
        pagination_actions.append(_modern_browser_model(
            "Previous Page",
            tr("Page {0} of {1}", page - 1, normalized_total_pages),
            "browser_replace",
            build_url(previous_params),
            fallback_art,
            "Return to the previous discovery results.",
            badge="PAGE {0}".format(page - 1),
            hint="OK  •  Load page",
        ))
    if page < normalized_total_pages:
        next_params = dict(params)
        next_params["page"] = page + 1
        pagination_actions.append(_modern_browser_model(
            "Next Page",
            tr("Page {0} of {1}", page + 1, normalized_total_pages),
            "browser_replace",
            build_url(next_params),
            fallback_art,
            "Continue through these discovery results.",
            badge="PAGE {0}".format(page + 1),
            hint="OK  •  Load page",
        ))

    filter_target = _discovery_option_target(
        media_type,
        state,
        params.get("section", "genre"),
    )
    actions = [
        _modern_discovery_model(
            "Edit filters",
            "Return to the current Filter Studio selections",
            "edit_filters",
            filter_target,
            fallback_art,
            primary=True,
            key="edit",
        )
    ]
    total_results = (
        max(0, _as_int(response.get("total_results"), 0))
        if isinstance(response, dict)
        else 0
    )
    title = "{0} {1}".format(
        total_results,
        tr("TV Series" if media_type == "tv" else "Movies"),
    )
    view = _modern_browser_view(
        title,
        "Results match your filters",
        result_models,
        fallback_art,
        "FILTERED RESULTS",
        "No titles match these filters.",
    )
    view.update({
        "layout": "filter_results",
        "media_type": media_type,
        "result_actions": actions,
        "pagination_actions": pagination_actions,
        "chips": _modern_discovery_chip_models(
            media_type,
            state,
            fallback_art,
        ),
        "summary": _discovery_compact_summary(media_type, state),
        "page_label": tr("Page {0} of {1}",
            page,
            normalized_total_pages,
        ),
        "active_count": _discovery_active_count(state),
        "total_results": total_results,
    })
    return view


def _modern_discovery_browser(params, fallback_art, genre_names):
    media_type = "tv" if params.get("media_type") == "tv" else "movie"
    state = _discovery_state(params)
    if params.get("action") == "show_discovery_filters":
        return _modern_filter_studio_view(
            params,
            media_type,
            state,
            fallback_art,
            genre_names,
        )
    return _modern_filter_results_view(
        params,
        media_type,
        state,
        fallback_art,
        genre_names,
    )


def _modern_seasons_browser(params, fallback_art):
    tv_id = _as_int(params.get("tv_id"), 0)
    details = api.get_tv_details(tv_id)
    tv_title = details.get("name") or details.get("original_name") or "TV Series"
    poster = _media_art_url(details.get("poster_path"))
    fanart = _media_art_url(details.get("backdrop_path")) or poster or fallback_art
    items = []
    for season in details.get("seasons") or []:
        number = season.get("season_number")
        if number is None:
            continue
        name = season.get("name") or "Season {0}".format(number)
        year = _extract_year(season)
        season_poster = _media_art_url(season.get("poster_path")) or poster
        target = build_url({
            "action": "list_episodes", "tv_id": tv_id, "season": number,
            "tv_title": tv_title, "poster": season_poster, "fanart": fanart
        })
        count = season.get("episode_count")
        items.append(_modern_browser_model(
            name,
            "Season {0}{1}".format(number, "  •  {0}".format(year) if year else ""),
            "browse", target, fallback_art, season.get("overview", ""),
            season_poster, fanart,
            "{0} EPISODES".format(count) if count is not None else "OPEN",
            "OK  •  View episodes"
        ))
    return _modern_browser_view(
        tv_title, "{0} season{1}".format(len(items), "" if len(items) == 1 else "s"),
        items, fallback_art, "SEASONS", "No seasons are available.", fanart
    )


def _modern_episodes_browser(params, fallback_art):
    tv_id = _as_int(params.get("tv_id"), 0)
    season = _as_int(params.get("season"), 0)
    tv_title = params.get("tv_title") or "TV Series"
    poster = params.get("poster", "")
    fanart = params.get("fanart") or poster or fallback_art
    items = []
    for episode in api.get_episodes(tv_id, season) or []:
        episode_id = episode.get("id")
        if episode_id is None:
            continue
        title = _get_episode_title(episode)
        available = bool(episode.get("hasStreams") or episode.get("streams"))
        image = _media_art_url(
            episode.get("imageUrl") or episode.get("image_url")
        ) or poster
        target = build_url({
            "action": "show_streams", "tv_id": tv_id, "season": season,
            "episode_id": episode_id, "tv_title": tv_title,
            "poster": image, "fanart": fanart
        })
        air_date = episode.get("airDate") or episode.get("air_date")
        aired = _date_only(air_date) if air_date else ""
        rating = _as_float(
            episode.get("voteAverage", episode.get("vote_average")),
            0.0
        )
        runtime = _as_int(episode.get("runtime"), 0)
        metadata = "  •  ".join(
            value for value in (
                aired,
                f"{runtime} min" if runtime > 0 else "",
                f"★ {rating:.1f}" if rating else "",
            ) if value
        )
        items.append(_modern_browser_model(
            title,
            metadata,
            "browse" if available else "disabled",
            target if available else "", fallback_art,
            episode.get("description") or episode.get("overview", ""),
            image, fanart, "AVAILABLE" if available else "UNAVAILABLE",
            "OK  •  Choose stream" if available else "No stream available"
        ))
    return _modern_browser_view(
        "{0}  •  Season {1}".format(tv_title, season),
        "{0} episode{1}".format(len(items), "" if len(items) == 1 else "s"),
        items, fallback_art, "EPISODES",
        "No episodes are available for this season.", fanart
    )


def _modern_stream_models(streams, params, fallback_art, episode=None):
    is_episode = episode is not None
    title = params.get("tv_title") if is_episode else params.get("title")
    title = title or "Media Hub"
    poster = params.get("poster", "")
    fanart = params.get("fanart") or poster or fallback_art
    collections = _media_lists_snapshot()
    items = []
    for stream in streams or []:
        display_name = _stream_display_name(stream)
        size = stream.get("sizeInGB", "")
        play_query = {
            "action": "play_movie_stream",
            "stream_id": stream.get("id", ""),
            "media_type": "episode" if is_episode else "movie",
            "title": title,
            "poster": poster,
            "fanart": fanart,
            "stream_name": display_name,
        }
        if is_episode:
            episode_title = _get_episode_title(episode)
            play_query.update({
                "tv_id": params.get("tv_id", ""),
                "season": params.get("season", ""),
                "episode_id": params.get("episode_id", ""),
                "episode_number": _episode_number(episode),
                "tv_title": title,
                "episode_title": episode_title,
                "title": "{0} - {1}".format(title, episode_title),
            })
        else:
            play_query.update({
                "movie_id": params.get("movie_id", ""),
                "year": params.get("year", ""),
            })
        download_target = build_url({
            "action": "download_movie_stream",
            "stream_id": stream.get("id", ""),
            "filename": display_name,
        })
        if is_episode:
            collection_record = _collection_record_from_episode_stream(
                stream,
                params.get("tv_id", ""),
                params.get("season", ""),
                params.get("episode_id", ""),
                title,
                _get_episode_title(episode),
                poster,
                fanart,
            )
        else:
            collection_record = _collection_record_from_movie_stream(
                stream,
                params.get("movie_id", ""),
                title,
                params.get("year", ""),
                poster,
                fanart,
            )
        item_id = _collection_id(collection_record)
        is_favourite = item_id in collections.get("favorites", {})
        if is_favourite:
            favourite_label = "Remove from Favourites"
            favourite_query = {
                "action": "remove_media_list_item",
                "collection": "favorites",
                "item_id": item_id,
            }
        else:
            favourite_label = "Add to Favourites"
            favourite_query = _collection_action_query(
                "add_media_list_item",
                "favorites",
                collection_record,
                item_id,
            )

        model = _modern_browser_model(
            display_name,
            "{0} GB{1}".format(
                size,
                "  •  Bundled subtitles" if stream.get("hasBundledSubtitles") else ""
            ),
            "play", build_url(play_query), fallback_art, title, poster, fanart,
            "PLAY", "OK  •  Play    MENU  •  Actions", download_target
        )
        model["context_actions"] = [
            {
                "label": tr("Play"),
                "label2": tr("Start this stream now"),
                "command": "play",
                "target": build_url(play_query),
                "properties": {"App.Badge": "PLAY"},
            },
            {
                "label": tr("Download"),
                "label2": tr("Add this stream to the download queue"),
                "command": "action",
                "target": download_target,
                "properties": {"App.Badge": "QUEUE"},
            },
            {
                "label": tr(favourite_label),
                "label2": (
                    tr("Remove this exact stream from your saved items")
                    if is_favourite
                    else tr("Save this exact stream for quick access")
                ),
                "command": "action",
                "target": build_url(favourite_query),
                "properties": {
                    "App.Badge": "REMOVE" if is_favourite else "SAVE"
                },
            },
        ]
        items.append(model)
    return items


def _modern_streams_browser(params, fallback_art):
    tv_id = _as_int(params.get("tv_id"), 0)
    season = _as_int(params.get("season"), 0)
    episode_id = _as_int(params.get("episode_id"), 0)
    episode = next((
        item for item in (api.get_episodes(tv_id, season) or [])
        if _as_int(item.get("id"), -1) == episode_id
    ), None)
    if not episode:
        return _modern_browser_view(
            "Choose Stream", "Episode not found", [], fallback_art, "STREAMS"
        )
    items = _modern_stream_models(
        episode.get("streams", []), params, fallback_art, episode
    )
    return _modern_browser_view(
        _get_episode_title(episode),
        "{0}  •  Season {1}  •  {2} stream{3}".format(
            params.get("tv_title") or "TV Series", season, len(items),
            "" if len(items) == 1 else "s"
        ),
        items, fallback_art, "CHOOSE STREAM",
        "No streams are available for this episode.",
        params.get("fanart") or params.get("poster", "")
    )


def _modern_next_episode_browser(params, fallback_art):
    tv_id = _as_int(params.get("tv_id"), 0)
    season = _as_int(params.get("season"), 0)
    current_id = _as_int(params.get("episode_id"), -1)
    current_number = _as_int(params.get("episode_number"), 0)

    def ordered_episodes(season_number):
        episodes = [
            episode for episode in (api.get_episodes(tv_id, season_number) or [])
            if isinstance(episode, dict)
        ]
        return sorted(
            episodes,
            key=lambda episode: (
                _episode_number(episode, 1000000),
                _as_int(episode.get("id"), 1000000),
            ),
        )

    episodes = ordered_episodes(season)
    current_index = next((
        index for index, episode in enumerate(episodes)
        if _as_int(episode.get("id"), -2) == current_id
    ), None)
    candidates = (
        episodes[current_index + 1:]
        if current_index is not None
        else [
            episode for episode in episodes
            if _episode_number(episode) > current_number
        ]
    )
    next_episode = next(
        (
            episode for episode in candidates
            if episode.get("hasStreams") or episode.get("streams")
        ),
        None,
    )
    next_season = season

    if next_episode is None:
        details = api.get_tv_details(tv_id) or {}
        later_seasons = sorted({
            _as_int(item.get("season_number"), -1)
            for item in details.get("seasons") or []
            if isinstance(item, dict)
            and _as_int(item.get("season_number"), -1) > season
        })
        for season_number in later_seasons:
            later = ordered_episodes(season_number)
            next_episode = next(
                (
                    episode for episode in later
                    if episode.get("hasStreams") or episode.get("streams")
                ),
                None,
            )
            if next_episode is not None:
                next_season = season_number
                break

    tv_title = params.get("tv_title") or "TV Series"
    if next_episode is None:
        return _modern_browser_view(
            tv_title,
            "You are caught up",
            [],
            fallback_art,
            "NEXT EPISODE",
            "No later playable episode is available yet.",
            params.get("fanart") or params.get("poster", ""),
        )

    image = _media_art_url(
        next_episode.get("imageUrl") or next_episode.get("image_url")
    ) or params.get("poster", "")
    next_params = dict(params)
    next_params.update({
        "season": next_season,
        "episode_id": next_episode.get("id", ""),
        "episode_number": _episode_number(next_episode),
        "poster": image,
    })
    items = _modern_stream_models(
        next_episode.get("streams", []),
        next_params,
        fallback_art,
        next_episode,
    )
    episode_number = _episode_number(next_episode)
    return _modern_browser_view(
        _get_episode_title(next_episode),
        "{0}  •  S{1:02d} E{2:02d}  •  Choose stream".format(
            tv_title, next_season, episode_number
        ),
        items,
        fallback_art,
        "NEXT EPISODE",
        "The next episode has no playable streams.",
        params.get("fanart") or image,
    )


def _modern_movie_versions_browser(params, fallback_art):
    versions = api.get_movie_versions(params.get("movie_id", "")) or []
    items = _modern_stream_models(versions, params, fallback_art)
    title = params.get("title") or "Choose Version"
    return _modern_browser_view(
        title,
        "{0} version{1}  •  Choose playback quality".format(
            len(items), "" if len(items) == 1 else "s"
        ),
        items, fallback_art, "MOVIE VERSIONS",
        "No playable versions are available.",
        params.get("fanart") or params.get("poster", "")
    )


def _modern_download_actions_browser(params, fallback_art):
    data = _list_downloads_normalized()
    record = data.get(params.get("id"))
    if not isinstance(record, dict):
        return _modern_browser_view(
            "Download", "Download not found", [], fallback_art, "OFFLINE LIBRARY"
        )
    status = record.get("status", "")
    progress = _as_int(record.get("progress"), 0)
    items = []
    path = record.get("path", "")
    if status == "complete" and path and xbmcvfs.exists(path):
        items.append(_modern_browser_model(
            "Play Download", path, "play", path, fallback_art,
            "Play the completed local file.", badge="PLAY"
        ))
    for label, query in _download_action_queries(record, _queue_count(data)):
        items.append(_modern_browser_model(
            label, "Manage this offline item", "action", build_url(query),
            fallback_art, "Status: {0}  •  Progress: {1}%".format(status, progress),
            badge="ACTION"
        ))
    return _modern_browser_view(
        record.get("filename") or "Download",
        "{0}  •  {1}%  •  {2} / {3}".format(
            status.replace("_", " ").title(), progress,
            _format_bytes(record.get("bytes_done")),
            _format_bytes(record.get("bytes_total"))
        ),
        items, fallback_art, "DOWNLOAD ACTIONS",
        "No actions are currently available."
    )


def _modern_downloads_browser(fallback_art):
    items = _modern_home_download_items(fallback_art, limit=None)
    items.insert(0, _modern_browser_model(
        "Clear Download History", "Remove completed and canceled records",
        "action", build_url({"action": "clear_download_history"}), fallback_art,
        "Failed records and files are preserved.", badge="CLEAN UP"
    ))
    return _modern_browser_view(
        "Downloads", "Active transfers and offline history", items,
        fallback_art, "OFFLINE LIBRARY"
    )


def _modern_settings_browser(params, fallback_art):
    section = params.get("section", "about")
    addon = xbmcaddon.Addon()

    def setting_item(label, setting_id, kind, description):
        value = addon.getSetting(setting_id) or ""
        if kind == "bool":
            display = "On" if value.lower() == "true" else "Off"
        elif kind == "language":
            display = "Slovenčina" if language() == SLOVAK else "English"
        elif kind == "secret":
            display = "••••••••" if value else "Not configured"
        elif kind == "folder":
            display = value or "Not configured"
        else:
            display = value or "Default"
        return _modern_browser_model(
            label, display, "action",
            build_url({
                "action": "modern_setting", "setting": setting_id,
                "kind": kind, "section": section
            }),
            fallback_art, description,
            badge="TOGGLE" if kind == "bool" else "CHANGE"
        )

    if section == "account":
        title = "Account & API"
        items = [setting_item(
            "API Key", "api_key", "secret",
            "Authentication used for Media Hub API requests."
        )]
    elif section == "downloads":
        title = "Downloads"
        items = [
            setting_item("Download Folder", "download_path", "folder", "Where completed files are stored."),
            setting_item("Staging Folder", "download_staging_path", "folder", "Optional local staging for network destinations."),
            setting_item("Concurrent Downloads", "max_concurrent_downloads", "number", "Maximum simultaneous transfers."),
            setting_item("Retry Attempts", "download_retry_limit", "number", "Retries after a failed transfer."),
            setting_item("Speed Limit", "max_download_speed_kbps", "number", "KB/s; use 0 for unlimited."),
            setting_item("Streaming Speed Limit", "max_download_speed_streaming_kbps", "number", "KB/s while Kodi is playing media."),
        ]
    elif section == "tv":
        title = "TV Filtering"
        items = [setting_item(
            "Filter Animation", "filter_anime", "bool",
            "Hide likely anime titles from TV catalogue pages."
        )]
    elif section == "interface":
        title = "Interface"
        items = [
            setting_item(
                "Language", "ui_language", "language",
                "Choose the language used by the Media Hub interface."
            ),
            setting_item(
                "Modern Media Hub", "modern_home", "bool",
                "Use the cinematic application shell by default."
            ),
        ]
    elif section == "playback":
        title = "Playback"
        items = [_modern_browser_model(
            "Kodi Player", "Automatic stream and subtitle hand-off",
            "disabled", "", fallback_art,
            "Media Hub resolves your selection and hands it to Kodi's player.",
            badge="READY", hint="Managed automatically"
        )]
    else:
        title = "About"
        version = addon.getAddonInfo("version") or "0.8.0"
        items = [
            _modern_browser_model(
                "Media Hub", "Version {0}".format(version), "disabled", "",
                fallback_art, "A modern movie and TV experience for Kodi.",
                badge="KODI"
            ),
            _modern_browser_model(
                "Interface", "Custom 1080p remote-first shell", "disabled", "",
                fallback_art,
                "Every catalogue and management view shares one visual language.",
                badge="MODERN"
            ),
        ]
    return _modern_browser_view(
        title, "Media Hub preferences", items, fallback_art, "SETTINGS"
    )


def _modern_browser_loader(target, fallback_art, genre_names):
    params = _modern_target_params(target)
    action = params.get("action", "")
    if action in ("menu_item_movies", "menu_item_tvshows", "menu_item_search"):
        return _modern_root_browser(params, fallback_art)
    if action in (
        "menu_item_movies_latest", "menu_item_movies_popular",
        "menu_item_movies_toprated", "menu_item_movies_search",
        "list_tv_shows_latest", "list_tv_shows_recently_aired",
        "list_tv_shows_popular", "list_tv_shows_sk",
        "menu_item_tvshows_search"
    ):
        return _modern_catalog_browser(params, fallback_art, genre_names)
    if action in ("show_discovery_filters", "list_discovery_results"):
        return _modern_discovery_browser(params, fallback_art, genre_names)
    if action == "list_seasons":
        return _modern_seasons_browser(params, fallback_art)
    if action == "list_episodes":
        return _modern_episodes_browser(params, fallback_art)
    if action == "show_streams":
        return _modern_streams_browser(params, fallback_art)
    if action == "show_next_episode":
        return _modern_next_episode_browser(params, fallback_art)
    if action == "list_movie_versions":
        return _modern_movie_versions_browser(params, fallback_art)
    if action == "show_downloads_menu":
        return _modern_downloads_browser(fallback_art)
    if action == "show_download_actions":
        return _modern_download_actions_browser(params, fallback_art)
    if action == "show_favorites":
        return _modern_browser_view(
            "Favourites", "Movies, series and episodes saved for later",
            _modern_home_favorite_items(fallback_art, limit=None),
            fallback_art, "MY LIST"
        )
    if action == "show_watch_history":
        return _modern_browser_view(
            "Recently Viewed", "Continue where you left off",
            _modern_home_history_items(fallback_art, limit=None),
            fallback_art, "HISTORY"
        )
    if action == "modern_settings":
        return _modern_settings_browser(params, fallback_art)
    return _modern_browser_view(
        "Media Hub", "Compatibility destination", [], fallback_art,
        "MEDIA HUB", "No modern view is available for this destination."
    )


def _modern_setting_action(params):
    setting_id = params.get("setting", "")
    kind = params.get("kind", "text")
    if not setting_id:
        return
    addon = xbmcaddon.Addon()
    current = addon.getSetting(setting_id) or ""
    if kind == "language":
        options = [tr("English"), tr("Slovenčina")]
        selected = xbmcgui.Dialog().select(
            tr("Language"),
            options,
            preselect=1 if language() == SLOVAK else 0,
        )
        if selected in (0, 1):
            # Legacy Kodi enum settings persist their selected zero-based index.
            addon.setSetting(setting_id, str(selected))
        return
    if kind == "bool":
        addon.setSetting(setting_id, "false" if current.lower() == "true" else "true")
        return
    if kind == "folder":
        selected = xbmcgui.Dialog().browse(
            0, "Choose folder", "files", "", False, False, current
        )
        if selected:
            addon.setSetting(setting_id, selected)
        return
    keyboard = xbmc.Keyboard(current, "Change setting")
    keyboard.doModal()
    if not keyboard.isConfirmed():
        return
    value = _clean_query_value(keyboard.getText())
    if kind == "number" and value and not value.isdigit():
        xbmcgui.Dialog().notification(
            "Settings", "Enter a whole number.",
            xbmcgui.NOTIFICATION_ERROR, 2000
        )
        return
    addon.setSetting(setting_id, value)


def _modern_action_handler(target):
    params = _modern_target_params(target)
    action = params.get("action", "")
    if action == "configure_discovery_filter":
        media_type = "tv" if params.get("media_type") == "tv" else "movie"
        state = _prompt_discovery_filter(
            media_type, params.get("filter"), params
        )
        return (
            build_url(_discovery_query(
                "show_discovery_filters",
                media_type,
                state,
                section=params.get("section"),
            ))
            if state is not None else None
        )
    if action == "modern_setting":
        _modern_setting_action(params)
        return None
    handlers = {
        "move_download": lambda: move_download(params.get("id"), params.get("direction")),
        "pause_download": lambda: pause_download(params.get("id")),
        "resume_download": lambda: resume_download(params.get("id")),
        "cancel_download": lambda: cancel_download(params.get("id")),
        "retry_download": lambda: retry_download(params.get("id")),
        "verify_download": lambda: verify_download(params.get("id")),
        "repair_download": lambda: repair_download(params.get("id")),
        "clear_download_history": clear_download_history,
        "clear_watch_history": clear_watch_history,
        "remove_watch_history_item": lambda: remove_watch_history_item(params.get("id")),
        "clear_media_list": lambda: clear_media_list(params.get("collection")),
        "remove_media_list_item": lambda: remove_media_list_item(
            params.get("collection"), params.get("item_id")
        ),
        "add_media_list_item": lambda: add_media_list_item(
            params.get("collection"), params
        ),
        "download_movie_stream": lambda: download_movie_stream(
            params.get("stream_id"), params.get("filename", "download")
        ),
    }
    handler = handlers.get(action)
    if handler:
        handler()
    return None


def _handle_modern_home_result(result):
    if not isinstance(result, dict):
        return
    if result.get("command") == "navigate" and result.get("target"):
        xbmc.executebuiltin(f"Container.Update({result.get('target')})")
    elif result.get("command") == "quit":
        xbmc.executebuiltin("Quit")


def show_modern_home(
    handle,
    initial_target="",
    catalog_columns=6,
    catalog_rows=2,
    catalog_page_size=None,
):
    if not _addon_bool_setting("modern_home", True):
        show_main_menu(handle)
        return

    try:
        from . import app_home
    except Exception as ex:
        xbmc.log(f"[modern_home] Could not load custom window: {ex}", xbmc.LOGERROR)
        show_main_menu(handle)
        return

    try:
        fallback_art = get_addon_art_path()
        all_history_items = _modern_home_history_items(fallback_art, limit=None)
        all_favorite_items = _modern_home_favorite_items(fallback_art, limit=None)
        all_download_items = _modern_home_download_items(fallback_art, limit=None)
        history_items = all_history_items[:10]
        favorite_items = all_favorite_items[:10]
        download_items = all_download_items
        quick_items = _modern_home_quick_items(fallback_art)
        home_primary = history_items or favorite_items or quick_items
        home_secondary = (
            favorite_items
            if history_items and favorite_items
            else quick_items
        )
        navigation = _modern_home_navigation(
            fallback_art,
            len(all_history_items),
            len(all_favorite_items),
            len(all_download_items)
        )
        settings_items = _modern_settings_items(fallback_art)
    except Exception as ex:
        xbmc.log(f"[modern_home] Could not build home content: {ex}", xbmc.LOGERROR)
        show_main_menu(handle)
        return

    # Complete the plugin directory before opening the modal window so Kodi
    # does not leave its busy overlay above the custom interface.
    xbmcplugin.setPluginCategory(handle, "Media Hub")
    try:
        xbmcplugin.setContent(handle, "files")
    except Exception:
        pass
    classic_url = build_url({"action": "classic_home"})
    fallback_item = xbmcgui.ListItem(label="Media Hub – klasické zobrazenie")
    fallback_item.setArt({"thumb": fallback_art, "fanart": fallback_art})
    xbmcplugin.addDirectoryItem(handle, classic_url, fallback_item, isFolder=True)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)

    catalog_columns = max(1, _as_int(catalog_columns, 6))
    catalog_rows = max(1, _as_int(catalog_rows, 2))
    catalog_page_size = max(
        1,
        _as_int(catalog_page_size, catalog_columns * catalog_rows),
    )
    catalog_states = {}
    catalog_lock = threading.RLock()
    genre_cache = {"movie": None, "tv": None}

    def genre_names(media_type):
        if genre_cache[media_type] is None:
            try:
                response = (
                    api.get_tv_genres()
                    if media_type == "tv"
                    else api.get_movie_genres()
                )
                genre_cache[media_type] = _modern_genre_name_map(response)
            except Exception as ex:
                xbmc.log(
                    f"[modern_home] Could not load {media_type} genres: {ex}",
                    xbmc.LOGWARNING,
                )
                genre_cache[media_type] = {}
        return genre_cache[media_type]

    def catalog_page_loader(page, tab, page_number):
        page_number = max(1, _as_int(page_number, 1))
        key = (page, tab)
        with catalog_lock:
            state = catalog_states.setdefault(key, {
                "items": [],
                "batches": {},
                "source_page": 1,
                "emitted_items": 0,
                "exhausted": False,
                "lock": threading.RLock(),
            })
        with state["lock"]:
            if page_number in state["batches"]:
                return state["batches"][page_number]

            # Prime every category with two complete API pages. After that,
            # infinite scrolling continues in display-sized batches from the
            # third source page onward.
            start = state["emitted_items"]
            initial_load = page_number == 1
            end = None if initial_load else start + catalog_page_size
            while (
                (
                    state["source_page"] <= 2
                    if initial_load
                    else len(state["items"]) < end
                )
                and not state["exhausted"]
            ):
                source_items = _load_modern_catalog(
                    page,
                    tab,
                    fallback_art,
                    genre_names("movie") if page == "movies" else None,
                    genre_names("tv") if page == "tv" else None,
                    page_number=state["source_page"],
                )
                state["source_page"] += 1
                if not source_items:
                    state["exhausted"] = True
                    break
                state["items"].extend(source_items)

            batch = list(
                state["items"][start:]
                if initial_load
                else state["items"][start:end]
            )
            state["emitted_items"] += len(batch)
            state["batches"][page_number] = batch
            return batch

    def catalog_loader(page, tab):
        return catalog_page_loader(page, tab, 1)

    def search_loader(query):
        return _load_modern_search(
            query,
            fallback_art,
            genre_names("movie"),
            genre_names("tv"),
        )

    def home_loader():
        with ThreadPoolExecutor(max_workers=2) as executor:
            movie_future = executor.submit(catalog_loader, "movies", "popular")
            tv_future = executor.submit(catalog_loader, "tv", "popular")
            return movie_future.result()[:8], tv_future.result()[:8]

    def browser_loader(target):
        return _modern_browser_loader(
            target,
            fallback_art,
            genre_names,
        )

    def state_loader():
        return {
            "favorites": _modern_home_favorite_items(fallback_art, limit=None),
            "history": _modern_home_history_items(fallback_art, limit=10),
            "downloads": _modern_home_download_items(fallback_art, limit=None),
        }

    try:
        result = app_home.open_home(
            xbmcaddon.Addon().getAddonInfo("path"),
            navigation=navigation,
            home_primary=home_primary,
            home_secondary=home_secondary,
            favorite_items=favorite_items,
            history_items=history_items,
            download_items=download_items,
            settings_items=settings_items,
            fallback_art=fallback_art,
            logo_art=os.path.join(
                xbmcaddon.Addon().getAddonInfo("path"),
                "resources",
                "skins",
                "Default",
                "media",
                "rail-logo.png",
            ),
            catalog_loader=catalog_loader,
            catalog_page_loader=catalog_page_loader,
            catalog_columns=catalog_columns,
            search_loader=search_loader,
            home_loader=home_loader,
            browser_loader=browser_loader,
            discovery_targets={
                "movies": build_url({
                    "action": "show_discovery_filters",
                    "media_type": "movie",
                }),
                "tv": build_url({
                    "action": "show_discovery_filters",
                    "media_type": "tv",
                }),
            },
            action_handler=_modern_action_handler,
            play_handler=_play_modern_target,
            state_loader=state_loader,
            initial_target=initial_target,
        )
    except Exception as ex:
        xbmc.log(f"[modern_home] Custom window failed: {ex}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification(
            "Media Hub",
            "Moderné rozhranie sa nepodarilo otvoriť.",
            xbmcgui.NOTIFICATION_ERROR,
            3000
        )
        xbmc.executebuiltin(f"Container.Update({classic_url},replace)")
        return

    _handle_modern_home_result(result)

def show_main_menu(handle):

    _prepare_directory(handle, "Hlavné menu", "files")

    # Movies
    menuItemMovies = xbmcgui.ListItem(label="Filmy")
    menuItemMovies.setInfo('video', { 'plot': u"\u00A0" })
    _set_utility_fanart(menuItemMovies)
    urlMovies = build_url({'action': 'menu_item_movies'})
    xbmcplugin.addDirectoryItem(handle, urlMovies, menuItemMovies, isFolder=True)

    # TV Shows
    menuItemTvShows = xbmcgui.ListItem(label="Seriály")
    menuItemTvShows.setInfo('video', { 'plot': u"\u00A0" })
    _set_utility_fanart(menuItemTvShows)
    urlTvShows = build_url({'action': 'menu_item_tvshows'})
    xbmcplugin.addDirectoryItem(handle, urlTvShows, menuItemTvShows, isFolder=True)

    # Downloads
    menuItemDownloads = xbmcgui.ListItem(label="Sťahovanie")
    menuItemDownloads.setInfo('video', { 'plot': u"\u00A0" })
    _set_utility_fanart(menuItemDownloads)
    urlDownloads = build_url({'action': 'show_downloads_menu'})
    xbmcplugin.addDirectoryItem(handle, urlDownloads, menuItemDownloads, isFolder=True)

    # Watch History
    menuItemWatchHistory = xbmcgui.ListItem(label="História pozerania")
    menuItemWatchHistory.setInfo('video', { 'plot': u"\u00A0" })
    _set_utility_fanart(menuItemWatchHistory)
    urlWatchHistory = build_url({'action': 'show_watch_history'})
    xbmcplugin.addDirectoryItem(handle, urlWatchHistory, menuItemWatchHistory, isFolder=True)

    # Favorites
    menuItemFavorites = xbmcgui.ListItem(label="Obľúbené")
    menuItemFavorites.setInfo('video', { 'plot': u"\u00A0" })
    _set_utility_fanart(menuItemFavorites)
    urlFavorites = build_url({'action': 'show_favorites'})
    xbmcplugin.addDirectoryItem(handle, urlFavorites, menuItemFavorites, isFolder=True)

    xbmcplugin.endOfDirectory(handle)

def menu_item_search(handle):
    _prepare_directory(handle, "Hľadať", "files")

    movie_item = xbmcgui.ListItem(label="Hľadať filmy")
    movie_item.setInfo("video", {
        "plot": "Vyhľadať film podľa názvu a zobraziť dostupné verzie."
    })
    _set_utility_fanart(movie_item)
    xbmcplugin.addDirectoryItem(
        handle,
        build_url({"action": "menu_item_movies_search"}),
        movie_item,
        isFolder=True
    )

    tv_item = xbmcgui.ListItem(label="Hľadať seriály")
    tv_item.setInfo("video", {
        "plot": "Vyhľadať seriál podľa názvu a prejsť na série a epizódy."
    })
    _set_utility_fanart(tv_item)
    xbmcplugin.addDirectoryItem(
        handle,
        build_url({"action": "menu_item_tvshows_search"}),
        tv_item,
        isFolder=True
    )

    xbmcplugin.endOfDirectory(handle)

def show_watch_history(handle):
    _prepare_directory(handle, "História pozerania", "videos")
    try:
        xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_UNSORTED)
    except Exception:
        pass

    data = watch_history_db.list()
    records = sorted(
        data.values(),
        key=lambda record: record.get("last_played_at") or record.get("created_at") or "",
        reverse=True
    )

    if records:
        clear_item = xbmcgui.ListItem(label="Vymazať históriu pozerania")
        clear_item.setInfo('video', {'plot': 'Vymazať všetky lokálne záznamy histórie pozerania.'})
        clear_url = build_url({'action': 'clear_watch_history'})
        xbmcplugin.addDirectoryItem(handle, clear_url, clear_item, isFolder=False)
    else:
        empty_item = xbmcgui.ListItem(label="História je prázdna")
        empty_item.setInfo('video', {'plot': u"\u00A0"})
        xbmcplugin.addDirectoryItem(handle, "", empty_item, isFolder=False)
        xbmcplugin.endOfDirectory(handle)
        return

    for record in records:
        if not record.get("stream_id"):
            continue

        history_id = record.get("id") or _history_id(record)
        item = xbmcgui.ListItem(label=_history_label(record))
        item.setInfo('video', {
            'title': record.get("title") or record.get("stream_name") or "Stream",
            'plot': _history_plot(record)
        })
        art = {}
        if record.get("poster"):
            art['poster'] = record.get("poster")
            art['thumb'] = record.get("poster")
        if record.get("fanart"):
            art['fanart'] = record.get("fanart")
        if art:
            item.setArt(art)
        item.setProperty('IsPlayable', 'true')
        context_items = _history_episode_navigation_context_menu_items(record)
        context_items.extend([
            (tr("Odstrániť z histórie"), f"RunPlugin({build_url({'action': 'remove_watch_history_item', 'id': history_id})})"),
            (tr("Vymazať históriu pozerania"), f"RunPlugin({build_url({'action': 'clear_watch_history'})})")
        ])
        item.addContextMenuItems(context_items, True)

        url = build_url(_history_play_query(record))
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=False)

    xbmcplugin.endOfDirectory(handle)

def remove_watch_history_item(history_id):
    removed = watch_history_db.remove(history_id)
    if removed:
        xbmcgui.Dialog().notification("História pozerania", "Záznam odstránený", xbmcgui.NOTIFICATION_INFO, 1500)
    xbmc.executebuiltin("Container.Refresh")

def clear_watch_history():
    confirm = xbmcgui.Dialog().yesno("Vymazať históriu pozerania", "Všetky lokálne záznamy histórie pozerania budú odstránené. Pokračovať?", yeslabel="Áno", nolabel="Nie")
    if not confirm:
        return

    watch_history_db.clear_all()
    xbmc.executebuiltin("Container.Refresh")

def menu_item_movies(handle):

    _prepare_directory(handle, "Filmy", "files")

    # Latest Movies
    menuItemMoviesLatest = xbmcgui.ListItem(label="Nové ")
    menuItemMoviesLatest.setInfo('video', { 'plot': u"\u00A0" })
    _set_utility_fanart(menuItemMoviesLatest)
    urlMoviesLatest = build_url({'action': 'menu_item_movies_latest'})
    xbmcplugin.addDirectoryItem(handle, urlMoviesLatest, menuItemMoviesLatest, isFolder=True)

    # Popular Movies
    menuItemMoviesPopular = xbmcgui.ListItem(label="Populárne")
    menuItemMoviesPopular.setInfo('video', { 'plot': u"\u00A0" })
    _set_utility_fanart(menuItemMoviesPopular)
    urlMoviesPopular = build_url({'action': 'menu_item_movies_popular'})
    xbmcplugin.addDirectoryItem(handle, urlMoviesPopular, menuItemMoviesPopular, isFolder=True)

    # Top Rated Movies
    menuItemMoviesTopRated = xbmcgui.ListItem(label="Najlepšie Hodnotené")
    menuItemMoviesTopRated.setInfo('video', { 'plot': u"\u00A0" })
    _set_utility_fanart(menuItemMoviesTopRated)
    urlMoviesTopRated = build_url({'action': 'menu_item_movies_toprated'})
    xbmcplugin.addDirectoryItem(handle, urlMoviesTopRated, menuItemMoviesTopRated, isFolder=True)

    # Combined genre/year/sort/rating discovery
    menuItemMoviesDiscover = xbmcgui.ListItem(label="Prehliadať a filtrovať")
    menuItemMoviesDiscover.setInfo('video', { 'plot': "Žáner, rok, zoradenie a minimálne hodnotenie." })
    urlMoviesDiscover = build_url({'action': 'show_discovery_filters', 'media_type': 'movie'})
    xbmcplugin.addDirectoryItem(handle, urlMoviesDiscover, menuItemMoviesDiscover, isFolder=True)

    # Search
    menuItemMoviesSearch = xbmcgui.ListItem(label="Hľadať")
    menuItemMoviesSearch.setProperty('IsPlayable', 'false')
    menuItemMoviesSearch.setInfo('video', { 'plot': u"\u00A0" })
    _set_utility_fanart(menuItemMoviesSearch)
    urlMoviesSearch = build_url({'action': 'menu_item_movies_search'})
    xbmcplugin.addDirectoryItem(handle, urlMoviesSearch, menuItemMoviesSearch, isFolder=True)

    xbmcplugin.endOfDirectory(handle)

def menu_item_tvshows(handle):

    _prepare_directory(handle, "Seriály", "files")

    # Latest Tv Shows
    menuItemTvShowsLatest = xbmcgui.ListItem(label="Nové seriály")
    menuItemTvShowsLatest.setInfo('video', { 'plot': u"\u00A0" })
    _set_utility_fanart(menuItemTvShowsLatest)
    urlTvShowsLatest = build_url({'action': 'list_tv_shows_latest'})
    xbmcplugin.addDirectoryItem(handle, urlTvShowsLatest, menuItemTvShowsLatest, isFolder=True)

    # Recently aired seasons and episodes
    menuItemTvShowsRecentlyAired = xbmcgui.ListItem(label="Nové série a epizódy")
    menuItemTvShowsRecentlyAired.setInfo('video', { 'plot': u"\u00A0" })
    _set_utility_fanart(menuItemTvShowsRecentlyAired)
    urlTvShowsRecentlyAired = build_url({'action': 'list_tv_shows_recently_aired'})
    xbmcplugin.addDirectoryItem(handle, urlTvShowsRecentlyAired, menuItemTvShowsRecentlyAired, isFolder=True)

    # Popular Tv Shows
    menuItemTvShowsPopular = xbmcgui.ListItem(label="Populárne")
    menuItemTvShowsPopular.setInfo('video', { 'plot': u"\u00A0" })
    _set_utility_fanart(menuItemTvShowsPopular)
    urlTvShowsPopular = build_url({'action': 'list_tv_shows_popular'})
    xbmcplugin.addDirectoryItem(handle, urlTvShowsPopular, menuItemTvShowsPopular, isFolder=True)

    # Top Rated Tv Shows
    menuItemTvShowsSlovak = xbmcgui.ListItem(label="Slovenské")
    menuItemTvShowsSlovak.setInfo('video', { 'plot': u"\u00A0" })
    _set_utility_fanart(menuItemTvShowsSlovak)
    urlTvShowsSlovak = build_url({'action': 'list_tv_shows_sk'})
    xbmcplugin.addDirectoryItem(handle, urlTvShowsSlovak, menuItemTvShowsSlovak, isFolder=True)

    # Combined genre/year/sort/rating discovery
    menuItemTvDiscover = xbmcgui.ListItem(label="Prehliadať a filtrovať")
    menuItemTvDiscover.setInfo('video', { 'plot': "Žáner, rok prvého vysielania, zoradenie a minimálne hodnotenie." })
    urlTvDiscover = build_url({'action': 'show_discovery_filters', 'media_type': 'tv'})
    xbmcplugin.addDirectoryItem(handle, urlTvDiscover, menuItemTvDiscover, isFolder=True)

    # Search
    menuItemTvSearch = xbmcgui.ListItem(label="Hľadať")
    menuItemTvSearch.setProperty('IsPlayable', 'false')
    menuItemTvSearch.setInfo('video', { 'plot': u"\u00A0" })
    _set_utility_fanart(menuItemTvSearch)
    urlTvSearch = build_url({'action': 'menu_item_tvshows_search'})
    xbmcplugin.addDirectoryItem(handle, urlTvSearch, menuItemTvSearch, isFolder=True)

    xbmcplugin.endOfDirectory(handle)

def _discovery_sort_options(media_type):
    return DISCOVERY_SORTS

def _discovery_sort_label(sort_value, media_type="movie"):
    return dict(_discovery_sort_options(media_type)).get(sort_value, "Popular")


def _discovery_summary_parts(media_type, state):
    parts = []
    genre_names = _discovery_genre_names(state)
    genre_ids = _discovery_genre_ids(state)
    if genre_names:
        parts.append(" + ".join(genre_names))
    elif genre_ids:
        key = "{0} genre" if len(genre_ids) == 1 else "{0} genres"
        parts.append(
            tr(key, len(genre_ids))
        )
    if (
        _valid_discovery_year(state.get("year"))
        or _valid_discovery_year(state.get("year_from"))
        or _valid_discovery_year(state.get("year_to"))
    ):
        parts.append(_discovery_period_label(state))
    if state.get("minimum_rating"):
        parts.append("{0}+".format(state["minimum_rating"]))
    minimum_vote_count = max(
        0,
        _as_int(state.get("minimum_vote_count"), 0),
    )
    if minimum_vote_count:
        parts.append(
            tr("{0}+ ratings", "{0:,}".format(minimum_vote_count))
        )
    parts.append(
        tr(_discovery_sort_label(state.get("sort"), media_type))
    )
    return parts


def _discovery_compact_summary(media_type, state):
    return " • ".join(_discovery_summary_parts(media_type, state))


def _discovery_summary(media_type, state):
    prefix = tr("Movies" if media_type == "movie" else "TV Series")
    return "{0}: {1}".format(
        prefix,
        _discovery_compact_summary(media_type, state),
    )

def show_discovery_filters(handle, media_type):
    media_type = "tv" if media_type == "tv" else "movie"
    state = _discovery_state()
    _prepare_directory(handle, "Prehliadať a filtrovať", "files")

    _add_discovery_filter_item(
        handle,
        "Žánre: {0}".format(tr(_discovery_genre_label(state))),
        media_type,
        "genre",
        state
    )
    period_title = (
        "Obdobie prvého vysielania"
        if media_type == "tv"
        else "Obdobie vydania"
    )
    _add_discovery_filter_item(
        handle,
        "{0}: {1}".format(
            period_title,
            tr(_discovery_period_label(state)),
        ),
        media_type,
        "release_period",
        state,
    )
    _add_discovery_filter_item(
        handle,
        "Minimálne hodnotenie: {0}".format(
            (
                "{0}+".format(state["minimum_rating"])
                if state.get("minimum_rating")
                else "Bez minima"
            )
        ),
        media_type,
        "minimum_rating",
        state
    )
    _add_discovery_filter_item(
        handle,
        "Minimálny počet hodnotení: {0}".format(
            (
                "{0:,}+".format(
                    max(0, _as_int(state.get("minimum_vote_count"), 0))
                )
                if _as_int(state.get("minimum_vote_count"), 0) > 0
                else "Bez minima"
            )
        ),
        media_type,
        "minimum_vote_count",
        state
    )
    _add_discovery_filter_item(
        handle,
        "Zoradiť: {0}".format(
            tr(_discovery_sort_label(state.get("sort"), media_type))
        ),
        media_type,
        "sort",
        state
    )

    results_item = xbmcgui.ListItem(label="[B]Zobraziť výsledky[/B]")
    results_item.setInfo('video', {'plot': _discovery_summary(media_type, state)})
    results_url = build_url(_discovery_query("list_discovery_results", media_type, state, page=1))
    xbmcplugin.addDirectoryItem(handle, results_url, results_item, isFolder=True)

    clear_item = xbmcgui.ListItem(label="Vymazať filtre")
    clear_item.setInfo('video', {'plot': "Obnoviť predvolené filtrovanie podľa popularity."})
    clear_url = build_url(_discovery_query("show_discovery_filters", media_type))
    xbmcplugin.addDirectoryItem(handle, clear_url, clear_item, isFolder=True)
    xbmcplugin.endOfDirectory(handle)

def _genre_choices(media_type):
    response = api.get_tv_genres() if media_type == "tv" else api.get_movie_genres()
    if not isinstance(response, list):
        return []
    genres = []
    for genre in response:
        if not isinstance(genre, dict):
            continue
        genre_id = genre.get("id", genre.get("Id"))
        name = _clean_query_value(genre.get("name", genre.get("Name")))
        if _as_int(genre_id, 0) > 0 and name:
            genres.append((str(_as_int(genre_id)), name))
    return sorted(genres, key=lambda value: value[1].casefold())

def _prompt_discovery_filter(media_type, filter_name, params=None):
    media_type = "tv" if media_type == "tv" else "movie"
    state = _discovery_state(params)
    dialog = xbmcgui.Dialog()

    if filter_name == "genre":
        try:
            choices = _genre_choices(media_type)
        except Exception as ex:
            xbmc.log(f"[genres] Failed to load genre catalog: {ex}", xbmc.LOGERROR)
            dialog.ok("Žánre", "Nepodarilo sa načítať zoznam žánrov.")
            return None
        current_ids = {
            str(value)
            for value in _discovery_genre_ids(state)
        }
        preselect = [
            index
            for index, (genre_id, _name) in enumerate(choices)
            if genre_id in current_ids
        ]
        multiselect = getattr(dialog, "multiselect", None)
        if callable(multiselect):
            selected = multiselect(
                "Vyberte žánre",
                [label for _, label in choices],
                preselect=preselect,
            )
            if selected is None:
                return None
            selected_choices = [
                choices[index]
                for index in selected
                if 0 <= index < len(choices)
            ]
        else:
            single_choices = [("", "Všetky žánre")] + choices
            single_preselect = (
                preselect[0] + 1
                if preselect
                else 0
            )
            selected = dialog.select(
                "Vyberte žáner",
                [label for _, label in single_choices],
                preselect=single_preselect,
            )
            if selected < 0:
                return None
            selected_choices = (
                [single_choices[selected]]
                if single_choices[selected][0]
                else []
            )
        state = _discovery_state_with(
            state,
            genre_ids=(
                ",".join(value[0] for value in selected_choices)
                or None
            ),
            genre_names=(
                "|".join(value[1] for value in selected_choices)
                or None
            ),
        )
    elif filter_name == "year":
        current_year = time.gmtime().tm_year
        choices = [("", "Všetky roky")] + [
            (str(year), str(year))
            for year in range(current_year, DISCOVERY_MIN_YEAR - 1, -1)
        ]
        current = state.get("year", "")
        preselect = next(
            (
                index
                for index, (value, _label) in enumerate(choices)
                if value == current
            ),
            0,
        )
        selected = dialog.select(
            (
                "Rok prvého vysielania"
                if media_type == "tv"
                else "Rok vydania"
            ),
            [label for _, label in choices],
            preselect=preselect,
        )
        if selected < 0:
            return None
        selected_year = choices[selected][0]
        state = _discovery_state_with(
            state,
            year=selected_year or None,
            year_from=None,
            year_to=None,
        )
    elif filter_name == "release_period":
        current_year = time.gmtime().tm_year
        choose_custom_range = True
        if not _clean_query_value((params or {}).get("section")):
            presets = (
                ("Všetky obdobia", None, None),
                ("Tento rok", current_year, current_year),
                ("Posledné 3 roky", current_year - 2, current_year),
                ("Posledných 5 rokov", current_year - 4, current_year),
                ("Vlastný rozsah…", "custom", "custom"),
            )
            current_from = _valid_discovery_year(state.get("year_from"))
            current_to = _valid_discovery_year(state.get("year_to"))
            preselect = (
                4
                if state.get("year")
                else next(
                    (
                        index
                        for index, (
                            _label,
                            year_from,
                            year_to,
                        ) in enumerate(presets)
                        if (
                            year_from == current_from
                            and year_to == current_to
                        )
                    ),
                    4 if current_from or current_to else 0,
                )
            )
            selected = dialog.select(
                "Obdobie prvého vysielania"
                if media_type == "tv"
                else "Obdobie vydania",
                [label for label, _year_from, _year_to in presets],
                preselect=preselect,
            )
            if selected < 0:
                return None
            _label, preset_from, preset_to = presets[selected]
            choose_custom_range = preset_from == "custom"
            if not choose_custom_range:
                state = _discovery_state_with(
                    state,
                    year=None,
                    year_from=(
                        str(preset_from)
                        if preset_from is not None
                        else None
                    ),
                    year_to=(
                        str(preset_to)
                        if preset_to is not None
                        else None
                    ),
                )

        if not choose_custom_range:
            return state

        years = [
            year
            for year in range(current_year + 1, DISCOVERY_MIN_YEAR - 1, -1)
        ]
        current_from = (
            _valid_discovery_year(state.get("year_from"))
            or _valid_discovery_year(state.get("year"))
            or current_year
        )
        current_to = (
            _valid_discovery_year(state.get("year_to"))
            or _valid_discovery_year(state.get("year"))
            or current_year
        )
        from_preselect = (
            years.index(current_from)
            if current_from in years
            else years.index(current_year)
        )
        selected_from = dialog.select(
            "Od roku",
            [str(year) for year in years],
            preselect=from_preselect,
        )
        if selected_from < 0:
            return None
        year_from = years[selected_from]
        to_preselect = (
            years.index(current_to)
            if current_to in years
            else years.index(current_year)
        )
        selected_to = dialog.select(
            "Do roku",
            [str(year) for year in years],
            preselect=to_preselect,
        )
        if selected_to < 0:
            return None
        year_to = years[selected_to]
        if year_from > year_to:
            dialog.ok(
                "Obdobie",
                "Začiatočný rok nemôže byť neskôr ako koncový rok.",
            )
            return None
        state = _discovery_state_with(
            state,
            year=None,
            year_from=str(year_from),
            year_to=str(year_to),
        )
    elif filter_name == "sort":
        sort_options = _discovery_sort_options(media_type)
        current = state.get("sort", "popularity.desc")
        preselect = next((index for index, value in enumerate(sort_options) if value[0] == current), 0)
        selected = dialog.select("Zoradiť výsledky", [label for _, label in sort_options], preselect=preselect)
        if selected < 0:
            return None
        state["sort"] = sort_options[selected][0]
    elif filter_name == "minimum_rating":
        choices = [("", "Bez minima")] + [
            (f"{half_step / 2:.1f}", f"{half_step / 2:.1f}+")
            for half_step in range(1, 20)
        ]
        current = state.get("minimum_rating", "")
        preselect = next((index for index, value in enumerate(choices) if value[0] == current), 0)
        selected = dialog.select("Minimálne hodnotenie", [label for _, label in choices], preselect=preselect)
        if selected < 0:
            return None
        minimum_rating, _ = choices[selected]
        if minimum_rating:
            state["minimum_rating"] = minimum_rating
        else:
            state.pop("minimum_rating", None)
    elif filter_name == "minimum_vote_count":
        choices = (
            (0, "Bez minima"),
            (25, "25+"),
            (100, "100+"),
            (250, "250+"),
            (500, "500+"),
            (1000, "1 000+"),
        )
        current = max(
            0,
            _as_int(state.get("minimum_vote_count"), 0),
        )
        preselect = next(
            (
                index
                for index, (value, _label) in enumerate(choices)
                if value == current
            ),
            0,
        )
        selected = dialog.select(
            "Minimálny počet hodnotení",
            [label for _, label in choices],
            preselect=preselect,
        )
        if selected < 0:
            return None
        state["minimum_vote_count"] = str(choices[selected][0])
    else:
        return None

    return _discovery_state(state)


def configure_discovery_filter(media_type, filter_name, params=None):
    media_type = "tv" if media_type == "tv" else "movie"
    state = _prompt_discovery_filter(media_type, filter_name, params)
    if state is None:
        return

    _replace_discovery_container(media_type, state)

def _build_movie_item(movie, genre_name="", include_hearts=False, include_rating=False):
    year = _movie_release_year(movie) or "----"
    rating = _as_float(movie.get("vote_average"), 0.0)
    hearts = _format_vote_hearts(movie.get("vote_count")) if include_hearts else ""
    rating_label = f"[COLOR FFB8860B][{rating:.1f}][/COLOR]" if include_rating else ""
    label = " ".join(value for value in (
        _movie_display_title(movie),
        f"[COLOR FFAAAAAA][{year}][/COLOR]",
        hearts,
        rating_label
    ) if value)
    item = xbmcgui.ListItem(label=label)
    poster = movie.get('poster_path', '')
    fanart = movie.get('backdrop_path', '')
    item.setArt({
        'thumb': poster,
        'poster': poster,
        'fanart': fanart
    })
    info = {
        'title': movie.get('title') or _movie_display_title(movie),
        'originaltitle': movie.get('original_title', ''),
        'plot': movie.get('overview', ''),
        'rating': rating,
        'votes': _as_int(movie.get('vote_count'), 0),
        'premiered': movie.get('release_date', ''),
        'mediatype': 'movie'
    }
    numeric_year = _as_int(year, 0)
    if numeric_year:
        info['year'] = numeric_year
    if genre_name:
        info['genre'] = genre_name
    item.setInfo('video', info)
    return item

def _build_discovery_movie_item(movie, genre_name=""):
    return _build_movie_item(
        movie,
        genre_name=genre_name,
        include_rating=True
    )

def list_discovery_results(handle, media_type):
    media_type = "tv" if media_type == "tv" else "movie"
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    state = _discovery_state(params)
    page = max(1, _as_int(params.get("page"), 1))
    request_kwargs = {
        "page": page,
        "genre_ids": _discovery_genre_ids(state),
        "year": _as_int(state.get("year"), 0) or None,
        "year_from": _as_int(state.get("year_from"), 0) or None,
        "year_to": _as_int(state.get("year_to"), 0) or None,
        "sort": state.get("sort", "popularity.desc"),
        "minimum_rating": _as_float(state.get("minimum_rating")),
        "minimum_vote_count": max(
            0,
            _as_int(state.get("minimum_vote_count"), 0),
        ),
    }
    category = _discovery_summary(media_type, state)
    _prepare_directory(
        handle,
        category,
        "tvshows" if media_type == "tv" else "movies"
    )

    try:
        if media_type == "tv":
            response = api.discover_tv(**request_kwargs)
        else:
            response = api.discover_movies(**request_kwargs)
    except Exception as ex:
        xbmc.log(f"[discovery] Failed to load {media_type} results: {ex}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Prehliadanie", "Nepodarilo sa načítať výsledky.")
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    results = response.get("results", []) if isinstance(response, dict) else []
    total_pages = _as_int(response.get("total_pages"), 1) if isinstance(response, dict) else 1
    collections = _media_lists_snapshot()

    display_results = _filter_tv_shows(results) if media_type == "tv" else results
    if media_type == "tv":
        for show in display_results:
            item = _build_tv_show_item(
                show,
                include_vote_count=True,
                include_rating=True,
                genre_name=_discovery_genre_label(state),
            )
            _add_collection_context_menu(item, _collection_record_from_tv_show(show), collections)
            url = build_url({'action': 'list_seasons', 'tv_id': show['id']})
            xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
    else:
        for movie in display_results:
            item = _build_discovery_movie_item(
                movie,
                _discovery_genre_label(state),
            )
            _add_collection_context_menu(item, _collection_record_from_movie(movie), collections)
            xbmcplugin.addDirectoryItem(handle, _build_movie_versions_url(movie), item, isFolder=True)

    if not display_results:
        empty_item = xbmcgui.ListItem(label="Žiadne výsledky")
        empty_item.setInfo('video', {'plot': "Skúste zmeniť alebo vymazať filtre."})
        xbmcplugin.addDirectoryItem(handle, "", empty_item, isFolder=False)

    if page < total_pages:
        next_page = page + 1
        next_item = xbmcgui.ListItem(label=f"Ďalej na stranu {next_page}")
        next_url = build_url(_discovery_query(
            "list_discovery_results",
            media_type,
            state,
            page=next_page
        ))
        xbmcplugin.addDirectoryItem(handle, next_url, next_item, isFolder=True)

    xbmcplugin.endOfDirectory(handle, updateListing=False)

def menu_item_movies_latest(handle):
    _prepare_directory(handle, "Nové filmy", "movies")
    page = int(dict(urllib.parse.parse_qsl(sys.argv[2][1:])).get('page', 1))
    try:
        response = api.get_movies_latest(page)
    except Exception as ex:
        _catalog_load_failed(handle, "new movies", ex)
        return
    movies = response.get('results', [])
    total_pages = response.get('total_pages', 1)
    collections = _media_lists_snapshot()

    for movie in movies:
        item = _build_movie_item(movie, include_hearts=True)
        _add_collection_context_menu(item, _collection_record_from_movie(movie), collections)
        url = _build_movie_versions_url(movie)
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    if page < total_pages:
        nextPage = page + 1
        item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
        url = build_url({'action': 'menu_item_movies_latest', 'page': nextPage})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    xbmcplugin.endOfDirectory(handle, updateListing=False)

def menu_item_movies_popular(handle):
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    filter_type = params.get('filter_type')
    year = params.get('year')
    page = int(params.get('page', 1))
    
    # If no filter type, show submenu
    if not filter_type:
        _prepare_directory(handle, "Populárne", "files")
        
        # All Times
        item = xbmcgui.ListItem(label="Všetky roky")
        item.setInfo('video', { 'plot': u"\u00A0" })
        url = build_url({'action': 'menu_item_movies_popular', 'filter_type': 'all_time'})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
        
        # By Year
        item = xbmcgui.ListItem(label="Podľa Roku")
        item.setInfo('video', { 'plot': u"\u00A0" })
        url = build_url({'action': 'menu_item_movies_popular', 'filter_type': 'by_year'})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
        
        xbmcplugin.endOfDirectory(handle)
        return
    
    # If filter_type is 'by_year' but no year selected, show year selector
    if filter_type == 'by_year' and not year:
        _prepare_directory(handle, "Populárne – podľa roku", "files")
        
        import datetime
        current_year = datetime.datetime.now().year
        
        # Show years from current year back to 1940
        for yr in range(current_year, 1940, -1):
            item = xbmcgui.ListItem(label=str(yr))
            item.setInfo('video', { 'plot': u"\u00A0" })
            url = build_url({'action': 'menu_item_movies_popular', 'filter_type': 'by_year', 'year': yr})
            xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
        
        xbmcplugin.endOfDirectory(handle)
        return
    
    _prepare_directory(
        handle,
        f"Populárne filmy{f' – {year}' if year else ''}",
        "movies"
    )

    # Show movies based on filter
    try:
        if filter_type == 'all_time':
            response = api.get_movies_popular(page)
        elif filter_type == 'by_year' and year:
            response = api.get_movies_popular(page, year)
        else:
            response = api.get_movies_popular(page)
    except Exception as ex:
        _catalog_load_failed(handle, "popular movies", ex)
        return
    
    movies = response.get('results', [])
    total_pages = response.get('total_pages', 1)
    collections = _media_lists_snapshot()

    for movie in movies:
        item = _build_movie_item(movie, include_rating=True)
        _add_collection_context_menu(item, _collection_record_from_movie(movie), collections)
        url = _build_movie_versions_url(movie)
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    if page < total_pages:
        nextPage = page + 1
        extra_params = {'filter_type': filter_type}
        if year:
            extra_params['year'] = year
        item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
        url = build_url({'action': 'menu_item_movies_popular', 'page': nextPage, **extra_params})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    xbmcplugin.endOfDirectory(handle, updateListing=False)

def menu_item_movies_toprated(handle):
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    filter_type = params.get('filter_type')
    year = params.get('year')
    page = int(params.get('page', 1))
    
    # If no filter type, show submenu
    if not filter_type:
        _prepare_directory(handle, "Najlepšie hodnotené", "files")
        
        # All Times
        item = xbmcgui.ListItem(label="Všetky roky")
        item.setInfo('video', { 'plot': u"\u00A0" })
        url = build_url({'action': 'menu_item_movies_toprated', 'filter_type': 'all_time'})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
        
        # By Year
        item = xbmcgui.ListItem(label="Podľa Roku")
        item.setInfo('video', { 'plot': u"\u00A0" })
        url = build_url({'action': 'menu_item_movies_toprated', 'filter_type': 'by_year'})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
        
        xbmcplugin.endOfDirectory(handle)
        return
    
    # If filter_type is 'by_year' but no year selected, show year selector
    if filter_type == 'by_year' and not year:
        _prepare_directory(handle, "Najlepšie hodnotené – podľa roku", "files")
        
        import datetime
        current_year = datetime.datetime.now().year
        
        # Show years from current year back to 1990
        for yr in range(current_year, 1940, -1):
            item = xbmcgui.ListItem(label=str(yr))
            item.setInfo('video', { 'plot': u"\u00A0" })
            url = build_url({'action': 'menu_item_movies_toprated', 'filter_type': 'by_year', 'year': yr})
            xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
        
        xbmcplugin.endOfDirectory(handle)
        return
    
    _prepare_directory(
        handle,
        f"Najlepšie hodnotené{f' – {year}' if year else ''}",
        "movies"
    )

    # Show movies based on filter
    if filter_type == 'all_time':
        response = api.get_movies_toprated(page)
    elif filter_type == 'by_year' and year:
        response = api.get_movies_toprated(page, year)
    else:
        response = api.get_movies_toprated(page)
    
    movies = response.get('results', [])
    total_pages = response.get('total_pages', 1)
    collections = _media_lists_snapshot()

    for movie in movies:
        item = _build_movie_item(movie, include_rating=True)
        _add_collection_context_menu(item, _collection_record_from_movie(movie), collections)
        url = _build_movie_versions_url(movie)
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    if page < total_pages:
        nextPage = page + 1
        extra_params = {'filter_type': filter_type}
        if year:
            extra_params['year'] = year
        item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
        url = build_url({'action': 'menu_item_movies_toprated', 'page': nextPage, **extra_params})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    xbmcplugin.endOfDirectory(handle, updateListing=False)

def menu_item_movies_search(handle):
    _prepare_directory(handle, "Hľadať filmy", "movies")
    # Get parameters from URL
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    search_query = params.get('search_query')
    page = int(params.get('page', 1))
    
    # Only show keyboard if no search_query (initial search)
    if not search_query:
        keyboard = xbmc.Keyboard('', 'Hľadať Filmy')
        keyboard.doModal()
        if keyboard.isConfirmed():
            search_query = keyboard.getText()
        else:
            xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)
            return
    
    if search_query:
        response = api.get_movies_search(search_query, page)
        movies = response.get('results', [])
        total_pages = response.get('total_pages', 1)
        collections = _media_lists_snapshot()

        for movie in movies:
            item = _build_movie_item(movie, include_hearts=True)
            _add_collection_context_menu(item, _collection_record_from_movie(movie), collections)
            url = _build_movie_versions_url(movie)
            xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

        if page < total_pages:
            nextPage = page + 1
            item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
            url = build_url({'action': 'menu_item_movies_search', 'page': nextPage, 'search_query': search_query})
            xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

        xbmcplugin.endOfDirectory(handle, updateListing=False)




    # itemTvSeriesLatest = xbmcgui.ListItem(label="Seriály - Nové")
    # url = build_url({'action': 'list_tv_shows_latest'})
    # xbmcplugin.addDirectoryItem(handle, url, itemTvSeriesLatest, isFolder=True)

    # itemTvSeriesPopular = xbmcgui.ListItem(label="Seriály - Populárne")
    # url = build_url({'action': 'list_tv_shows_popular'})
    # xbmcplugin.addDirectoryItem(handle, url, itemTvSeriesPopular, isFolder=True)

    # itemTvSeriesSk = xbmcgui.ListItem(label="Seriály - SK")
    # url = build_url({'action': 'list_tv_shows_sk'})
    # xbmcplugin.addDirectoryItem(handle, url, itemTvSeriesSk, isFolder=True)

def _get_tv_year(show):
    year = show.get("first_air_date_year")
    if year:
        return str(year)

    first_air_date = show.get("first_air_date") or ""
    return first_air_date[:4] if first_air_date else "----"

def _extract_year(item):
    for key in ("year", "first_air_date_year"):
        value = item.get(key)
        if value not in (None, ""):
            return str(value)

    for key in ("air_date", "first_air_date", "release_date"):
        value = item.get(key) or ""
        if len(value) >= 4:
            return value[:4]

    return "----"

def _get_episode_title(ep):
    return ep.get("title") or ep.get("name") or f"Episode {ep.get('episode_number', '?')}"

def _format_vote_hearts(vote_count):
    if vote_count is None:
        vote_count = 0

    if vote_count < 200:
        filled_hearts = 0
    elif vote_count < 500:
        filled_hearts = 1
    elif vote_count <= 1000:
        filled_hearts = 2
    else:
        filled_hearts = 3

    hearts = []
    for index in range(3):
        if index < filled_hearts:
            # use a softer golden tone instead of bright yellow
            hearts.append("[COLOR FFB8860B]★[/COLOR]")
        else:
            # slightly darker grey for empty stars
            hearts.append("[COLOR FF909090]☆[/COLOR]")
    return "".join(hearts)

def _date_only(value):
    value = _clean_query_value(value)
    if len(value) >= 10:
        return value[:10]
    return value

def _format_episode_ref(episode):
    if not isinstance(episode, dict):
        return ""

    season_number = episode.get("season_number")
    episode_number = episode.get("episode_number")
    if season_number in (None, "") or episode_number in (None, ""):
        return ""

    try:
        return f"S{int(season_number):02d}E{int(episode_number):02d}"
    except (TypeError, ValueError):
        return ""

def _recent_tv_activity_label(show):
    episode = show.get("last_episode_to_air") or {}
    episode_ref = _format_episode_ref(episode)
    air_date = _date_only(episode.get("air_date") or show.get("last_air_date"))

    if episode_ref and air_date:
        return f"{episode_ref} {air_date}"
    if episode_ref:
        return episode_ref
    return air_date

def _recent_tv_activity_plot(show):
    episode = show.get("last_episode_to_air") or {}
    episode_ref = _format_episode_ref(episode)
    episode_name = _clean_query_value(episode.get("name"))
    air_date = _date_only(episode.get("air_date") or show.get("last_air_date"))
    lines = []

    if episode_ref:
        title = f"Najnovšia epizóda: {episode_ref}"
        if episode_name:
            title = f"{title} - {episode_name}"
        lines.append(title)
    if air_date:
        lines.append(f"Dátum odvysielania: {air_date}")

    return "\n".join(lines)

def _build_tv_show_item(
    show,
    include_vote_count=False,
    include_hearts=True,
    include_recent_activity=False,
    include_rating=False,
    genre_name=""
):
    year = _get_tv_year(show)
    display_title = show.get("name_with_original_name") or show.get("name") or ""
    vote_count = show.get("vote_count")
    hearts = _format_vote_hearts(vote_count) if include_hearts else ""
    recent_activity = ""
    if include_recent_activity:
        recent_activity_label = _recent_tv_activity_label(show)
        if recent_activity_label:
            recent_activity = f" [COLOR FF00C8FF][{recent_activity_label}][/COLOR]"
    rating = _as_float(show.get("vote_average"), 0.0)
    rating_label = f" [COLOR FFB8860B][{rating:.1f}][/COLOR]" if include_rating else ""

    item = xbmcgui.ListItem(
        label=f"{display_title} [COLOR FFAAAAAA][{year}][/COLOR] {hearts}{rating_label}{recent_activity}".strip()
    )
    plot = show.get('overview', '')
    if include_recent_activity:
        activity_plot = _recent_tv_activity_plot(show)
        if activity_plot and plot:
            plot = f"{activity_plot}\n\n{plot}"
        elif activity_plot:
            plot = activity_plot

    poster = _media_art_url(show.get('poster_path'))
    fanart = _media_art_url(show.get('backdrop_path')) or poster
    item.setArt({
        'thumb': poster,
        'poster': poster,
        'fanart': fanart
    })
    info = {
        'title': show.get('name') or display_title,
        'originaltitle': show.get('original_name', ''),
        'plot': plot,
        'rating': rating,
        'votes': _as_int(vote_count, 0),
        'premiered': show.get('first_air_date', ''),
        'mediatype': 'tvshow'
    }
    numeric_year = _as_int(year, 0)
    if numeric_year:
        info['year'] = numeric_year
    if genre_name:
        info['genre'] = genre_name
    item.setInfo('video', info)
    return item

def menu_item_tvshows_search(handle):
    _prepare_directory(handle, "Hľadať seriály", "tvshows")
    # Get parameters from URL
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    search_query = params.get('search_query')
    page = int(params.get('page', 1))
    
    # Only show keyboard if no search_query (initial search)
    if not search_query:
        keyboard = xbmc.Keyboard('', 'Hľadať Seriály')
        keyboard.doModal()
        if keyboard.isConfirmed():
            search_query = keyboard.getText()
        else:
            xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)
            return
    
    if search_query:
        response = api.get_tv_search(search_query, page)
        shows = _filter_tv_shows(response.get('results', []))
        total_pages = response.get('total_pages', 1)
        collections = _media_lists_snapshot()

        for show in shows:
            item = _build_tv_show_item(show, include_vote_count=True)
            _add_collection_context_menu(item, _collection_record_from_tv_show(show), collections)
            url = build_url({'action': 'list_seasons', 'tv_id': show['id']})
            xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

        if page < total_pages:
            nextPage = page + 1
            item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
            url = build_url({'action': 'menu_item_tvshows_search', 'page': nextPage, 'search_query': search_query})
            xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

        xbmcplugin.endOfDirectory(handle, updateListing=False)

def list_tv_shows_latest(handle):
    _prepare_directory(handle, "Nové seriály", "tvshows")
    page = int(dict(urllib.parse.parse_qsl(sys.argv[2][1:])).get('page', 1))
    try:
        response = api.get_tv_latest(page)
    except Exception as ex:
        _catalog_load_failed(handle, "new TV shows", ex)
        return
    shows = _filter_tv_shows(response.get('results', []))
    total_pages = response.get('total_pages', 1)
    collections = _media_lists_snapshot()

    for show in shows:
        item = _build_tv_show_item(show, include_vote_count=True)
        _add_collection_context_menu(item, _collection_record_from_tv_show(show), collections)
        url = build_url({'action': 'list_seasons', 'tv_id': show['id']})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    # Add "Next Page" if more pages are available
    if page < total_pages:
        nextPage = page + 1
        item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
        url = build_url({'action': 'list_tv_shows_latest', 'page': page + 1})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    # Tell Kodi this is a new folder level (updateListing=False)
    xbmcplugin.endOfDirectory(handle, updateListing=False)

def list_tv_shows_recently_aired(handle):
    _prepare_directory(handle, "Nové série a epizódy", "tvshows")
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    page = _as_int(params.get('page'), 1)
    days = _as_int(params.get('days'), 30)
    if page < 1:
        page = 1
    if days < 1:
        days = 30

    response = api.get_tv_recently_aired(page, days)
    shows = _filter_tv_shows(response.get('results', []))
    total_pages = response.get('total_pages', 1)
    collections = _media_lists_snapshot()

    for show in shows:
        item = _build_tv_show_item(show, include_vote_count=True, include_recent_activity=True)
        _add_collection_context_menu(item, _collection_record_from_tv_show(show), collections)
        url = build_url({'action': 'list_seasons', 'tv_id': show['id']})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    if page < total_pages:
        nextPage = page + 1
        item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
        url = build_url({'action': 'list_tv_shows_recently_aired', 'page': nextPage, 'days': days})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    xbmcplugin.endOfDirectory(handle, updateListing=False)

def list_tv_shows_popular(handle):
    _prepare_directory(handle, "Populárne seriály", "tvshows")
    page = int(dict(urllib.parse.parse_qsl(sys.argv[2][1:])).get('page', 1))
    try:
        response = api.get_tv_popular(page)
    except Exception as ex:
        _catalog_load_failed(handle, "popular TV shows", ex)
        return
    shows = _filter_tv_shows(response.get('results', []))
    total_pages = response.get('total_pages', 1)
    collections = _media_lists_snapshot()

    for show in shows:
        item = _build_tv_show_item(show, include_hearts=False)
        _add_collection_context_menu(item, _collection_record_from_tv_show(show), collections)
        url = build_url({'action': 'list_seasons', 'tv_id': show['id']})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    # Add "Next Page" if more pages are available
    if page < total_pages:
        nextPage = page + 1
        item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
        url = build_url({'action': 'list_tv_shows_popular', 'page': page + 1})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    # Tell Kodi this is a new folder level (updateListing=False)
    xbmcplugin.endOfDirectory(handle, updateListing=False)

def list_tv_shows_sk(handle):
    _prepare_directory(handle, "Slovenské seriály", "tvshows")
    page = int(dict(urllib.parse.parse_qsl(sys.argv[2][1:])).get('page', 1))
    response = api.get_tv_sk(page)
    shows = _filter_tv_shows(response.get('results', []))
    total_pages = response.get('total_pages', 1)
    collections = _media_lists_snapshot()

    for show in shows:
        item = _build_tv_show_item(show, include_hearts=False)
        _add_collection_context_menu(item, _collection_record_from_tv_show(show), collections)
        url = build_url({'action': 'list_seasons', 'tv_id': show['id']})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    # Add "Next Page" if more pages are available
    if page < total_pages:
        nextPage = page + 1
        item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
        url = build_url({'action': 'list_tv_shows_sk', 'page': page + 1})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    # Tell Kodi this is a new folder level (updateListing=False)
    xbmcplugin.endOfDirectory(handle, updateListing=False)

def list_seasons(handle, tv_id):
    _prepare_directory(handle, "Série", "seasons")
    try:
        details = api.get_tv_details(tv_id)
    except Exception as ex:
        xbmc.log(f"[list_seasons] Failed to load TV details for tv_id={tv_id}: {ex}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("TV Show", "Could not load seasons.")
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    tv_title = details.get('name') or details.get('original_name') or f"TV {tv_id}"
    _prepare_directory(handle, tv_title, "seasons")
    poster = details.get('poster_path', '')
    fanart = details.get('backdrop_path') or poster
    collections = _media_lists_snapshot()

    for season in details.get('seasons', []):
        season_number = season.get('season_number')
        if season_number is None:
            xbmc.log(
                f"[list_seasons] Skipping season without season_number for tv_id={tv_id}: keys={sorted(season.keys())}",
                xbmc.LOGWARNING
            )
            continue

        seasonName = season.get('name') or f"Séria {season_number}"
        season_year = _extract_year(season)
        season_poster = season.get('poster_path') or poster
        season_fanart = fanart or season_poster
        label = f"{seasonName} [{season_year}]"
        item = xbmcgui.ListItem(label=label)
        item.setInfo('video', {
            'title': seasonName,
            'plot': season.get('overview', ''),
            'tagline': season.get('tagline', ''),
            'season': season_number,
            'tvshowtitle': tv_title,
            'mediatype': 'season'
        })
        item.setArt({
            'thumb': season_poster,
            'poster': season_poster,
            'fanart': season_fanart
        })
        _add_collection_context_menu(
            item,
            _collection_record_from_season(tv_id, tv_title, season_number, seasonName, season_year, season_poster, season_fanart),
            collections
        )
        url = build_url({
            'action': 'list_episodes',
            'tv_id': tv_id,
            'season': season_number,
            'tv_title': tv_title,
            'poster': poster,
            'fanart': fanart
        })
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
    xbmcplugin.endOfDirectory(handle)

def list_episodes(handle, tv_id, season, tv_title="", poster="", fanart=""):
    category = f"{tv_title} • Séria {season}" if tv_title else f"Séria {season}"
    _prepare_directory(handle, category, "episodes")
    try:
        episodes = api.get_episodes(tv_id, season)
    except Exception as ex:
        xbmc.log(f"[list_episodes] Failed to load episodes for tv_id={tv_id} season={season}: {ex}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("TV Show", "Could not load episodes.")
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    collections = _media_lists_snapshot()
    for ep in episodes:
        episode_id = ep.get('id')
        if episode_id is None:
            xbmc.log(
                f"[list_episodes] Skipping episode without id for tv_id={tv_id} season={season}: keys={sorted(ep.keys())}",
                xbmc.LOGWARNING
            )
            continue

        title = _get_episode_title(ep)
        label = title
        if not ep.get('hasStreams'):
            label = f"[COLOR 80FF0000][B][X][/B][/COLOR] [COLOR FFAAAAAA]{label}[/COLOR]"
        item = xbmcgui.ListItem(label=label)
        item.setInfo('video', {
            'title': title,
            'plot': ep.get('description') or ep.get('overview', ''),
            'season': season,
            'episode': _episode_number(ep),
            'aired': ep.get('air_date', ''),
            'tvshowtitle': tv_title,
            'mediatype': 'episode'
        })
        episode_image = _media_art_url(
            ep.get('imageUrl') or ep.get('image_url')
        )
        episode_poster = episode_image or _media_art_url(poster)
        episode_fanart = _media_art_url(fanart) or episode_image or episode_poster
        item.setArt({
            'thumb': episode_poster,
            'poster': episode_poster,
            'fanart': episode_fanart
        })
        _add_collection_context_menu(
            item,
            _collection_record_from_episode(tv_id, season, episode_id, tv_title, title, episode_poster, episode_fanart),
            collections
        )
        url = build_url({
            'action': 'show_streams',
            'tv_id': tv_id,
            'season': season,
            'episode_id': episode_id,
            'episode_number': _episode_number(ep),
            'tv_title': tv_title,
            'poster': episode_poster,
            'fanart': episode_fanart
        })
        has_streams = bool(ep.get('hasStreams') or ep.get('streams'))
        xbmcplugin.addDirectoryItem(
            handle,
            url if has_streams else "",
            item,
            isFolder=has_streams
        )
    xbmcplugin.endOfDirectory(handle)

def show_streams_popup(handle, tv_id, season, episode_id, tv_title="", poster="", fanart=""):
    _prepare_directory(handle, "Vybrať stream", "videos")
    episodes = api.get_episodes(tv_id, season)
    episode = next((ep for ep in episodes if ep['id'] == int(episode_id)), None)
    if not episode:
        xbmcgui.Dialog().notification("Streams", "Episode not found.", xbmcgui.NOTIFICATION_ERROR, 2500)
        xbmcplugin.endOfDirectory(handle)
        return

    streams = episode.get('streams', [])
    if not streams:
        xbmcgui.Dialog().notification("Streams", "No streams available for this episode.", xbmcgui.NOTIFICATION_INFO, 2500)
        xbmcplugin.endOfDirectory(handle)
        return

    collections = _media_lists_snapshot()
    for stream in streams:
        display_name = _stream_display_name(stream)
        episode_title = _get_episode_title(episode)
        history_title = f"{tv_title} - {episode_title}" if tv_title else episode_title
        stream_poster = poster or episode.get('imageUrl', '')
        stream_fanart = fanart or episode.get('imageUrl', '')
        label = f"[COLOR FF00C8FF][{stream['sizeInGB']} GB][/COLOR] {display_name}"
        item = xbmcgui.ListItem(label=label)
        item.setInfo('video', {
            'title': display_name,
            'plot': f"{history_title}\n\nVeľkosť: {stream['sizeInGB']} GB",
            'season': season,
            'episode': _episode_number(episode),
            'tvshowtitle': tv_title,
            'mediatype': 'episode'
        })
        item.setArt({
            'thumb': stream_poster,
            'poster': stream_poster,
            'fanart': stream_fanart
        })
        item.setProperty('IsPlayable', 'true')
        url = build_url({
            'action': 'play_movie_stream',
            'stream_id': stream['id'],
            'media_type': 'episode',
            'tv_id': tv_id,
            'season': season,
            'episode_id': episode_id,
            'episode_number': _episode_number(episode),
            'tv_title': tv_title,
            'episode_title': episode_title,
            'title': history_title,
            'poster': stream_poster,
            'fanart': stream_fanart,
            'stream_name': display_name
        })
        _add_collection_context_menu(
            item,
            _collection_record_from_episode_stream(stream, tv_id, season, episode_id, tv_title, episode_title, stream_poster, stream_fanart),
            collections,
            [("Stiahnuť", f"RunPlugin({build_url({'action': 'download_movie_stream', 'stream_id': stream['id'], 'filename': display_name})})")]
        )
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=False)

    xbmcplugin.endOfDirectory(handle)

def list_movie_versions(handle, movie_id, movie_title="", year="", poster="", fanart=""):
    _prepare_directory(handle, movie_title or "Vybrať verziu", "videos")
    versions = api.get_movie_versions(movie_id)
    collections = _media_lists_snapshot()
    for version in versions:
        display_name = _stream_display_name(version)
        has_bundled_subtitles = version.get('hasBundledSubtitles', "")
        subtitles_label = " [COLOR FF00FF00][Titulky][/COLOR]" if has_bundled_subtitles else ""
        label = f"[COLOR FF00C8FF][{version['sizeInGB']} GB][/COLOR]{subtitles_label} {display_name}"
        item = xbmcgui.ListItem(label=label)
        item.setInfo('video', {
            'title': display_name,
            'plot': f"{movie_title or display_name}\n\nVeľkosť: {version['sizeInGB']} GB",
            'year': _as_int(year, 0),
            'mediatype': 'movie'
        })
        item.setArt({
            'thumb': poster,
            'poster': poster,
            'fanart': fanart or poster
        })
        item.setProperty('IsPlayable', 'true')
        url = build_url({
            'action': 'play_movie_stream',
            'stream_id': version['id'],
            'media_type': 'movie',
            'movie_id': movie_id,
            'title': movie_title or display_name,
            'year': year,
            'poster': poster,
            'fanart': fanart,
            'stream_name': display_name
        })
        _add_collection_context_menu(
            item,
            _collection_record_from_movie_stream(version, movie_id, movie_title, year, poster, fanart),
            collections,
            [("Stiahnuť", f"RunPlugin({build_url({'action': 'download_movie_stream', 'stream_id': version['id'], 'filename': display_name})})")]
        )
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=False)
    xbmcplugin.endOfDirectory(handle)

def _resolve_playback(stream_id, params=None):
    try:
        streamUrl = api.get_streams(stream_id)
    except api.ApiError as e:
        xbmc.log(f"[play_movie_stream] HTTP {e.status_code} for stream {stream_id}: {e.message}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Stream error", e.message)
        return None
    except URLError as e:
        xbmc.log(f"[play_movie_stream] URL error for stream {stream_id}: {e.reason}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Stream error", "Network issue while resolving stream.")
        return None
    except Exception as e:
        xbmc.log(f"[play_movie_stream] Unexpected error for stream {stream_id}: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Stream error", "Could not resolve stream.")
        return None

    if not streamUrl:
        return None

    _record_watch_history(stream_id, params)
    params = params or {}
    title = params.get("title") or params.get("stream_name") or "Media Hub"
    item = xbmcgui.ListItem(label=title, path=streamUrl)
    item.setInfo("video", {
        "title": title,
        "year": _as_int(params.get("year"), 0),
        "season": _as_int(params.get("season"), 0),
        "mediatype": "episode" if params.get("media_type") == "episode" else "movie"
    })
    item.setArt({
        "thumb": params.get("poster", ""),
        "poster": params.get("poster", ""),
        "fanart": params.get("fanart", "") or params.get("poster", "")
    })
    item.setProperty("IsPlayable", "true")
    return streamUrl, item


def _play_modern_target(target):
    params = _modern_target_params(target)
    if params.get("action") != "play_movie_stream":
        return False
    resolved = _resolve_playback(params.get("stream_id"), params)
    if not resolved:
        return None
    stream_url, item = resolved
    xbmc.Player().play(stream_url, item)
    return True


def play_movie_stream(handle, stream_id, params=None):
    resolved = _resolve_playback(stream_id, params)
    if resolved:
        _stream_url, item = resolved
        xbmcplugin.setResolvedUrl(handle, True, listitem=item)
    else:
        xbmcplugin.setResolvedUrl(handle, False, listitem=xbmcgui.ListItem())

def download_movie_stream(stream_id, filename):
    # Queue only stable stream metadata. Signed URLs are deliberately obtained
    # by the worker immediately before each attempt and are never persisted.
    safe_filename = _safe_download_filename(filename)

    addon = xbmcaddon.Addon()
    default_dir = addon.getSetting("download_path") or ""
    save_dir = default_dir

    if not save_dir:
        save_dir = xbmcgui.Dialog().browse(0, "Choose save directory", "files", "", False, False, "")
        if not save_dir:
            return

    if not xbmcvfs.exists(save_dir):
        xbmcvfs.mkdirs(save_dir)

    # VFS paths (content://, smb://, storage://) can report missing; don't block on exists.
    if not xbmcvfs.exists(save_dir) and not _is_vfs_path(save_dir):
        xbmcgui.Dialog().ok("Download", "Download folder is not accessible.")
        return

    filepath = _join_path(save_dir, safe_filename)
    download_id = str(uuid.uuid4())
    created_at = now_iso()
    record = {
        "id": download_id,
        "stream_id": stream_id,
        "filename": safe_filename,
        "path": filepath,
        "status": "queued",
        "progress": 0,
        "bytes_total": None,
        "bytes_done": 0,
        "attempts": 0,
        "created_at": created_at,
        "updated_at": created_at
    }

    try:
        inserted = db.add_with_unique_path(record)
    except Exception as ex:
        xbmc.log(f"[download_movie_stream] Could not queue stream {stream_id}: {ex}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Download", "Could not add the download to the queue.")
        return

    xbmcgui.Dialog().notification(
        "Queued",
        inserted.get("filename", safe_filename),
        xbmcgui.NOTIFICATION_INFO,
        2500
    )

def show_downloads_menu(handle):
    _prepare_directory(handle, "Sťahovanie", "videos")
    try:
        xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_UNSORTED)
    except Exception:
        pass

    addon = xbmcaddon.Addon()
    max_attempts = max(1, int(addon.getSetting("download_retry_limit") or 0) + 1)
    data = _list_downloads_normalized()
    queue_total = _queue_count(data)

    clear_item = xbmcgui.ListItem(label="Vymazať históriu sťahovania")
    clear_item.setInfo('video', {
        'plot': 'Vymazať dokončené a zrušené záznamy bez .part súborov '
                '(zlyhané záznamy a súbory zostanú zachované).'
    })
    clear_url = build_url({'action': 'clear_download_history'})
    xbmcplugin.addDirectoryItem(handle, clear_url, clear_item, isFolder=False)

    downloading_items = sorted(
        [item for item in data.values() if item.get("status") in ACTIVE_DOWNLOAD_STATUSES],
        key=lambda x: (_queue_position(x), x.get("updated_at") or "", x.get("created_at") or "")
    )
    queued_items = sorted(
        [item for item in data.values() if item.get("status") in QUEUE_STATUSES],
        key=lambda x: (_queue_position(x), x.get("created_at") or "", x.get("id") or "")
    )
    history_items = sorted(
        [item for item in data.values() if item.get("status") not in ACTIVE_DOWNLOAD_STATUSES + QUEUE_STATUSES],
        key=lambda x: x.get("updated_at") or x.get("created_at") or "",
        reverse=True
    )
    items = downloading_items + queued_items + history_items

    for it in items:
        download_id = it.get("id")
        status = it.get("status", "?")
        progress = it.get("progress", 0) or 0
        filename = it.get("filename", "Unknown")
        path = it.get("path", "")
        attempts = it.get("attempts", 0) or 0
        error = it.get("error")
        position = _as_int(it.get("queue_position"), 0)
        bytes_done = it.get("bytes_done")
        bytes_total = it.get("bytes_total")

        if status == "downloading":
            label = f"[Now {progress}%] {filename}"
        elif status == "pausing":
            label = f"[Pausing {progress}%] {filename}"
        elif status == "canceling":
            label = f"[Canceling {progress}%] {filename}"
        elif status == "repairing":
            label = f"[Repairing] {filename}"
        elif status == "finalizing":
            label = f"[Finalizing] {filename}"
        elif status == "queued":
            label = f"#{position} [Queued] {filename}"
        elif status == "paused":
            label = f"#{position} [Paused {progress}%] {filename}"
        elif status == "waiting_retry":
            label = f"#{position} [Waiting to retry {progress}%] {filename}"
        elif status == "complete":
            label = f"[[COLOR FF90EE90]Complete[/COLOR]] {filename}"
        elif status == "failed":
            label = f"[[COLOR FFFF9090]Failed[/COLOR]] {filename}"
        elif status == "canceled":
            label = f"[Canceled] {filename}"
        else:
            label = f"[{status}] {filename}"

        li = xbmcgui.ListItem(label=label)
        plot_lines = [
            f"Status: {status}",
            f"Progress: {progress}%",
            f"Attempts: {attempts}/{max_attempts}"
        ]
        if status in QUEUE_STATUSES and position:
            plot_lines.append(f"Queue position: {position}/{queue_total}")
        elif status in ACTIVE_DOWNLOAD_STATUSES:
            plot_lines.append("Queue position: downloading now")
        if bytes_total:
            plot_lines.append(f"Downloaded: {_format_bytes(bytes_done)} / {_format_bytes(bytes_total)}")
        elif bytes_done:
            plot_lines.append(f"Downloaded: {_format_bytes(bytes_done)}")
        if path:
            plot_lines.append(f"Path: {path}")
        if error:
            plot_lines.append(f"Error: {error}")
        if status == "waiting_retry" and it.get("next_attempt_at"):
            plot_lines.append(f"Next retry: {it.get('next_attempt_at')}")
        li.setInfo('video', {'plot': "\n".join(plot_lines)})

        actions = _download_action_queries(it, queue_total)
        if actions:
            li.addContextMenuItems([
                (label, f"RunPlugin({build_url(query)})")
                for label, query in actions
            ])

        url = ""
        if status == "complete" and path and xbmcvfs.exists(path):
            url = path
            li.setProperty("IsPlayable", "true")
        elif actions:
            url = build_url({'action': 'show_download_actions', 'id': download_id})

        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=False)

    xbmcplugin.endOfDirectory(handle)

def _refresh_downloads_container():
    xbmc.executebuiltin("Container.Refresh")

def _part_path(record):
    staging_path = record.get("staging_path")
    if staging_path:
        return staging_path
    path = record.get("path")
    return f"{path}.part" if path else ""

def _part_size(record):
    part = _part_path(record)
    if not part:
        return 0
    try:
        if not xbmcvfs.exists(part):
            return 0
        return xbmcvfs.Stat(part).st_size()
    except Exception:
        return 0


def _part_exists(record):
    part = _part_path(record)
    if not part:
        return False
    try:
        return bool(xbmcvfs.exists(part))
    except Exception:
        return False


def _delete_part_file(record):
    part = _part_path(record)
    if not part:
        return True
    try:
        if not xbmcvfs.exists(part):
            return True
        deleted = xbmcvfs.delete(part)
        return bool(deleted) or not xbmcvfs.exists(part)
    except Exception:
        return False


def _finalization_marker_bytes(reservation_token):
    try:
        token = str(uuid.UUID(str(reservation_token)))
    except (TypeError, ValueError, AttributeError):
        return None
    return FINALIZATION_MARKER_PREFIX + token.encode("ascii") + b"\n"


def _delete_owned_finalization_marker(record):
    marker = _finalization_marker_bytes(
        record.get("finalization_reservation_token")
    )
    path = record.get("path")
    if marker is None or not path:
        return True
    try:
        local = str(xbmcvfs.translatePath(path) or "")
    except Exception:
        local = str(path)
    if not local or _is_vfs_path(local):
        return True
    if not os.path.lexists(local):
        return True

    flags = os.O_RDONLY | getattr(os, "O_BINARY", 0)
    flags |= getattr(os, "O_NOFOLLOW", 0)
    descriptor = None
    try:
        descriptor = os.open(local, flags)
        file_stat = os.fstat(descriptor)
        if not stat.S_ISREG(file_stat.st_mode) or file_stat.st_size != len(marker):
            return False
        content = b""
        while len(content) <= len(marker):
            chunk = os.read(descriptor, len(marker) + 1 - len(content))
            if not chunk:
                break
            content += chunk
        if content != marker:
            return False
    except OSError:
        return False
    finally:
        if descriptor is not None:
            try:
                os.close(descriptor)
            except OSError:
                pass

    try:
        os.unlink(local)
        return not os.path.lexists(local)
    except OSError:
        return False

def _progress_from_part(record, default=0):
    part_size = _part_size(record)
    total = _as_int(record.get("bytes_total"), 0)
    if part_size > 0 and total > 0:
        return part_size, int(100 * part_size / total)
    return part_size, default if part_size > 0 else 0

def _run_download_action(query):
    action = query.get("action")
    download_id = query.get("id")

    if action == "move_download":
        move_download(download_id, query.get("direction"))
    elif action == "pause_download":
        pause_download(download_id)
    elif action == "resume_download":
        resume_download(download_id)
    elif action == "cancel_download":
        cancel_download(download_id)
    elif action == "retry_download":
        retry_download(download_id)
    elif action == "verify_download":
        verify_download(download_id)
    elif action == "repair_download":
        repair_download(download_id)

def show_download_actions(download_id):
    data = _list_downloads_normalized()
    record = data.get(download_id)
    if not record:
        xbmcgui.Dialog().notification("Downloads", "Download not found", xbmcgui.NOTIFICATION_ERROR, 2000)
        return

    actions = _download_action_queries(record, _queue_count(data))
    if not actions:
        xbmcgui.Dialog().notification("Downloads", "No actions available", xbmcgui.NOTIFICATION_INFO, 2000)
        return

    choice = xbmcgui.Dialog().select(record.get("filename", "Download"), [label for label, _ in actions])
    if choice < 0:
        return

    _run_download_action(actions[choice][1])

def move_download(download_id, direction):
    if direction not in ("up", "down", "top", "bottom"):
        return

    def op(data):
        _normalize_queue_positions(data)
        items = [
            (item_id, record)
            for item_id, record in data.items()
            if record.get("status") in QUEUE_STATUSES
        ]
        items.sort(key=lambda item: (_queue_position(item[1]), item[1].get("created_at") or "", item[0]))

        index = next((i for i, (item_id, _) in enumerate(items) if item_id == download_id), None)
        if index is None:
            return None

        item = items.pop(index)
        if direction == "up":
            target = max(0, index - 1)
        elif direction == "down":
            target = min(len(items), index + 1)
        elif direction == "top":
            target = 0
        else:
            target = len(items)

        items.insert(target, item)
        updated_at = now_iso()
        for position, (_, record) in enumerate(items, start=1):
            record["queue_position"] = position
            record["updated_at"] = updated_at

        return item[1].get("filename", "Download")

    filename = db.mutate(op)
    if filename:
        xbmcgui.Dialog().notification("Downloads", f"Reordered {filename}", xbmcgui.NOTIFICATION_INFO, 1500)
    _refresh_downloads_container()

def pause_download(download_id):
    updated = None
    for _ in range(2):
        record = db.list().get(download_id)
        if not record:
            break
        status = record.get("status")
        target = {
            "queued": "paused",
            "waiting_retry": "paused",
            "downloading": "pausing"
        }.get(status)
        if not target:
            break
        updated = db.transition(download_id, status, {
            "status": target,
            "error": None,
            "error_code": None,
            "updated_at": now_iso()
        }, expected_revision=record.get("revision"))
        if updated:
            break

    if updated:
        title = "Pause requested" if updated.get("status") == "pausing" else "Paused"
        xbmcgui.Dialog().notification(title, updated.get("filename", "Download"), xbmcgui.NOTIFICATION_INFO, 2000)
    _refresh_downloads_container()

def resume_download(download_id):
    record = db.list().get(download_id)
    if not record or record.get("status") != "paused":
        _refresh_downloads_container()
        return
    updated = db.transition(download_id, "paused", {
        "status": "queued",
        "error": None,
        "error_code": None,
        "next_attempt_at": None,
        "owner_token": None,
        "updated_at": now_iso()
    }, expected_revision=record.get("revision"))
    if updated:
        xbmcgui.Dialog().notification("Queued", updated.get("filename", "Download"), xbmcgui.NOTIFICATION_INFO, 2000)
    _refresh_downloads_container()

def retry_download(download_id):
    record = db.list().get(download_id)
    if not record or record.get("status") not in ("failed", "canceled"):
        _refresh_downloads_container()
        return
    if record.get("error_code") == VERIFICATION_ERROR_CODE:
        repair_download(download_id)
        return

    bytes_done, progress = _progress_from_part(record, record.get("progress", 0) or 0)
    updated = db.transition(download_id, record.get("status"), {
        "status": "queued",
        "queue_position": _next_queue_position(db.list()),
        "error": None,
        "error_code": None,
        "attempts": 0,
        "next_attempt_at": None,
        "owner_token": None,
        "bytes_done": bytes_done,
        "progress": progress,
        "updated_at": now_iso()
    }, expected_revision=record.get("revision"))
    if updated:
        xbmcgui.Dialog().notification("Queued", updated.get("filename", "Download"), xbmcgui.NOTIFICATION_INFO, 2000)
    _refresh_downloads_container()

def cancel_download(download_id):
    record = db.list().get(download_id)
    if not record:
        _refresh_downloads_container()
        return

    initial_status = record.get("status")
    cancellable_statuses = (
        "queued",
        "waiting_retry",
        "paused",
        "failed",
        "downloading",
        "pausing"
    )
    if initial_status not in cancellable_statuses:
        _refresh_downloads_container()
        return

    part_size = _part_size(record)
    if _part_exists(record):
        partial_message = f"Partial data ({_format_bytes(part_size)}) will be deleted."
    else:
        partial_message = "There is no partial file to keep."
    if not xbmcgui.Dialog().yesno(
        "Cancel download",
        f"Cancel {record.get('filename', 'this download')}?\n\n{partial_message}",
        yeslabel="Cancel download",
        nolabel="Keep downloading"
    ):
        return

    cleanup_token = None
    updated = None
    was_active = False
    for _ in range(4):
        current = db.list().get(download_id)
        if not current:
            break
        status = current.get("status")
        if status == "canceling":
            updated = current
            was_active = bool(current.get("owner_token"))
            break
        if status not in cancellable_statuses:
            break

        was_active = status in ("downloading", "pausing")
        patch = {
            "status": "canceling",
            "queue_position": None,
            "next_attempt_at": None,
            "updated_at": now_iso()
        }
        if not was_active:
            cleanup_token = str(uuid.uuid4())
            patch.update({
                "owner_token": cleanup_token,
                "owner_worker_id": "ui-cleanup",
                "owner_heartbeat_at": now_iso(),
                "attempt_id": cleanup_token
            })
        updated = db.transition(
            download_id,
            status,
            patch,
            expected_revision=current.get("revision")
        )
        if updated:
            break

    if not updated:
        _refresh_downloads_container()
        return
    if was_active or cleanup_token is None:
        xbmcgui.Dialog().notification(
            "Cancel requested",
            updated.get("filename", "Download"),
            xbmcgui.NOTIFICATION_INFO,
            2000
        )
        _refresh_downloads_container()
        return

    partial_removed = _delete_part_file(updated)
    marker_removed = _delete_owned_finalization_marker(updated)
    finalization_path = updated.get("finalization_path")
    upload_removed = True
    if finalization_path:
        try:
            upload_removed = (
                not xbmcvfs.exists(finalization_path)
                or bool(xbmcvfs.delete(finalization_path))
                or not xbmcvfs.exists(finalization_path)
            )
        except Exception:
            upload_removed = False
    removed = partial_removed and upload_removed and marker_removed
    verification_error = updated.get("error_code") == VERIFICATION_ERROR_CODE
    finalized = db.update_owned(
        download_id,
        cleanup_token,
        {
            "status": "canceled",
            "bytes_done": 0 if removed else _part_size(updated),
            "progress": 0 if removed else updated.get("progress", 0),
            "owner_token": None,
            "owner_worker_id": None,
            "owner_heartbeat_at": None,
            "attempt_id": None,
            "error": (
                updated.get("error")
                if verification_error
                else None if removed else "Canceled, but some partial data could not be deleted."
            ),
            "error_code": (
                VERIFICATION_ERROR_CODE
                if verification_error
                else None if removed else "storage"
            ),
            "cleanup_pending": not removed,
            "finalization_path": None if upload_removed else finalization_path,
            "finalization_reservation_token": (
                None
                if marker_removed
                else updated.get("finalization_reservation_token")
            ),
            "updated_at": now_iso()
        },
        expected_statuses=("canceling",)
    )
    if finalized and removed:
        xbmcgui.Dialog().notification("Canceled", "Download canceled", xbmcgui.NOTIFICATION_INFO, 2000)
    elif finalized:
        xbmcgui.Dialog().ok(
            "Download canceled",
            "Canceled, but some partial data could not be deleted. The history record was kept for cleanup."
        )
    _refresh_downloads_container()


def _final_file_size(record):
    path = record.get("path")
    if not path:
        return None
    try:
        return int(xbmcvfs.Stat(path).st_size())
    except Exception:
        return None


def _authoritative_download_metadata(record, dialog_title):
    stream_id = record.get("stream_id")
    if not stream_id:
        xbmcgui.Dialog().ok(
            dialog_title,
            "This legacy record has no stream ID, so its expected size cannot be refreshed safely."
        )
        return None
    try:
        ticket = api.get_download_metadata(stream_id)
    except Exception as ex:
        xbmc.log(
            f"[downloads] Could not refresh verification metadata for {stream_id}: {ex}",
            xbmc.LOGERROR
        )
        xbmcgui.Dialog().ok(
            dialog_title,
            "Could not retrieve authoritative file metadata. Check the connection and try again."
        )
        return None
    return ticket


def _recognized_hash(value):
    if not isinstance(value, str) or not value.strip():
        return None
    text = value.strip().lower()
    if ":" in text:
        algorithm, digest = text.split(":", 1)
        algorithm = algorithm.replace("-", "")
    elif len(text) == 64:
        algorithm, digest = "sha256", text
    elif len(text) == 32:
        algorithm, digest = "md5", text
    else:
        return None
    if algorithm not in hashlib.algorithms_available:
        return None
    if not digest or any(character not in "0123456789abcdef" for character in digest):
        return None
    return algorithm, digest


def _file_hash(path, algorithm, heartbeat=None):
    digest = hashlib.new(algorithm)
    handle = None
    try:
        handle = xbmcvfs.File(path, "r")
        while True:
            if heartbeat:
                heartbeat()
            chunk = handle.read(1024 * 1024)
            if not chunk:
                break
            digest.update(bytes(chunk))
        return digest.hexdigest()
    except _RepairOwnershipLost:
        raise
    except Exception as ex:
        xbmc.log(f"[downloads] Could not hash {path}: {ex}", xbmc.LOGERROR)
        return None
    finally:
        if handle is not None:
            try:
                handle.close()
            except Exception:
                pass


def _file_matches_hash(path, expected_hash, heartbeat=None):
    specification = _recognized_hash(expected_hash)
    if not specification:
        return True
    algorithm, expected = specification
    actual = _file_hash(path, algorithm, heartbeat)
    return actual is not None and actual.lower() == expected.lower()


def _verification_failure(download_id, expected_status, record, message, actual_size=None):
    total = _as_int(record.get("bytes_total"), 0)
    actual = max(0, _as_int(actual_size, 0))
    progress = min(100, int(100 * actual / total)) if total > 0 else 0
    return db.transition(download_id, expected_status, {
        "status": "failed",
        "queue_position": None,
        "error": message,
        "error_code": VERIFICATION_ERROR_CODE,
        "bytes_done": actual,
        "bytes_total": total if total >= 0 else None,
        "expected_hash": record.get("expected_hash"),
        "progress": progress,
        "owner_token": None,
        "updated_at": now_iso()
    }, expected_revision=record.get("revision"))


def verify_download(download_id):
    record = db.list().get(download_id)
    if not record or record.get("status") != "complete":
        _refresh_downloads_container()
        return

    ticket = _authoritative_download_metadata(record, "Verify download")
    if not ticket:
        _refresh_downloads_container()
        return

    expected = _as_int(ticket.get("size_bytes"), -1)
    expected_hash = ticket.get("hash")
    record = dict(record)
    record["bytes_total"] = expected
    record["expected_hash"] = expected_hash
    actual = _final_file_size(record)
    if actual is None:
        message = "Verification failed: the downloaded file is missing. Choose Repair to download it again."
        updated = _verification_failure(download_id, "complete", record, message)
    elif expected < 0:
        message = "Verification failed: the expected file size is unavailable. Choose Repair to download it again."
        updated = _verification_failure(download_id, "complete", record, message, actual)
    elif actual != expected:
        message = (
            f"Verification failed: file is {_format_bytes(actual)}, expected {_format_bytes(expected)}. "
            "Choose Repair to resume or download it again."
        )
        updated = _verification_failure(download_id, "complete", record, message, actual)
    elif not _file_matches_hash(record.get("path"), expected_hash):
        message = "Verification failed: the file hash does not match the authoritative download metadata. Choose Repair to download it again."
        updated = _verification_failure(download_id, "complete", record, message, actual)
    else:
        updated = db.transition(download_id, "complete", {
            "verified_at": now_iso(),
            "error": None,
            "error_code": None,
            "bytes_done": actual,
            "bytes_total": expected,
            "expected_hash": expected_hash,
            "progress": 100,
            "owner_token": None,
            "updated_at": now_iso()
        }, expected_revision=record.get("revision"))
        if updated:
            xbmcgui.Dialog().notification("Verified", updated.get("filename", "Download"), xbmcgui.NOTIFICATION_INFO, 2500)

    if updated and updated.get("status") == "failed":
        xbmcgui.Dialog().ok("Download verification", updated.get("error"))
    _refresh_downloads_container()


def _move_without_overwrite(source, target):
    try:
        if not source or not target or xbmcvfs.exists(target) or not xbmcvfs.exists(source):
            return False
        if _is_vfs_path(source) or _is_vfs_path(target):
            moved = xbmcvfs.rename(source, target)
        else:
            os.rename(source, target)
            moved = True
        return bool(moved) and xbmcvfs.exists(target) and not xbmcvfs.exists(source)
    except Exception as ex:
        xbmc.log(f"[downloads] Could not move {source} to {target}: {ex}", xbmc.LOGERROR)
        return False


def _requires_local_staging(path):
    raw = str(path or "").replace("/", "\\")
    if raw.startswith("\\\\") or _is_vfs_path(str(path or "")):
        return True
    try:
        translated = str(xbmcvfs.translatePath(path) or "").replace("/", "\\")
        return translated.startswith("\\\\") or _is_vfs_path(translated)
    except Exception:
        return True


def _repair_staging_path(download_id):
    addon = xbmcaddon.Addon()
    configured = addon.getSetting("download_staging_path") or ""
    if configured and not _requires_local_staging(configured):
        root = xbmcvfs.translatePath(configured)
        staging_dir = os.path.join(root, ".mediahub-staging")
    else:
        profile = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
        staging_dir = os.path.join(profile, "download_staging")
    os.makedirs(staging_dir, exist_ok=True)
    safe_id = "".join(
        character if character.isalnum() or character in "_.-" else "_"
        for character in str(download_id)
    )
    return os.path.join(staging_dir, f"{safe_id}.part")


def _copy_vfs_to_local_and_remove(
    source,
    target,
    expected_size,
    heartbeat=None,
    final_control=None
):
    if xbmcvfs.exists(target):
        return False
    source_handle = None
    created = False
    try:
        os.makedirs(os.path.dirname(target), exist_ok=True)
        source_handle = xbmcvfs.File(source, "r")
        with open(target, "xb") as target_handle:
            created = True
            copied = 0
            while True:
                if heartbeat:
                    heartbeat()
                chunk = source_handle.read(1024 * 1024)
                if not chunk:
                    break
                view = memoryview(bytes(chunk))
                written = 0
                while written < len(view):
                    count = target_handle.write(view[written:])
                    if not count:
                        return False
                    written += count
                copied += len(view)
            target_handle.flush()
            os.fsync(target_handle.fileno())
        if copied != expected_size or os.path.getsize(target) != expected_size:
            return False
        if final_control:
            final_control()
        if not xbmcvfs.delete(source) and xbmcvfs.exists(source):
            return False
        return True
    except _RepairOwnershipLost:
        raise
    except Exception as ex:
        xbmc.log(f"[downloads] Could not stage repair data: {ex}", xbmc.LOGERROR)
        return False
    finally:
        if source_handle is not None:
            try:
                source_handle.close()
            except Exception:
                pass
        if created and xbmcvfs.exists(source):
            try:
                os.remove(target)
            except OSError:
                pass


def repair_download(download_id):
    record = db.list().get(download_id)
    if not record:
        _refresh_downloads_container()
        return

    status = record.get("status")
    if status != "complete" and not (
        status in ("failed", "canceled") and record.get("error_code") == VERIFICATION_ERROR_CODE
    ):
        _refresh_downloads_container()
        return

    ticket = _authoritative_download_metadata(record, "Repair download")
    if not ticket:
        _refresh_downloads_container()
        return
    expected = _as_int(ticket.get("size_bytes"), -1)
    expected_hash = ticket.get("hash")
    if expected <= 0:
        xbmcgui.Dialog().ok("Repair download", "The server returned an invalid expected file size.")
        return

    repair_token = str(uuid.uuid4())
    staging_path = record.get("staging_path")
    if _requires_local_staging(record.get("path")) and not staging_path:
        try:
            staging_path = _repair_staging_path(download_id)
        except Exception as ex:
            xbmc.log(f"[downloads] Could not prepare repair staging: {ex}", xbmc.LOGERROR)
            xbmcgui.Dialog().ok("Repair download", "Could not prepare the local staging folder.")
            return

    claimed = db.transition(download_id, status, {
        "status": "repairing",
        "repair_from_status": status,
        "owner_token": repair_token,
        "owner_worker_id": "ui-repair",
        "owner_heartbeat_at": now_iso(),
        "attempt_id": repair_token,
        "bytes_total": expected,
        "expected_hash": expected_hash,
        "staging_path": staging_path,
        "updated_at": now_iso()
    }, expected_revision=record.get("revision"))
    if not claimed:
        _refresh_downloads_container()
        return

    record = claimed
    last_control_check = [0.0]
    last_heartbeat = [0.0]

    def repair_heartbeat(force=False):
        current = time.monotonic()
        if not force and current - last_control_check[0] < 0.5:
            return
        current_record = db.list().get(download_id)
        if (
            not current_record
            or current_record.get("status") != "repairing"
            or current_record.get("owner_token") != repair_token
        ):
            raise _RepairOwnershipLost("Repair ownership changed")
        last_control_check[0] = current
        if not force and current - last_heartbeat[0] < 5.0:
            return
        if not db.update_owned(
            download_id,
            repair_token,
            {"owner_heartbeat_at": now_iso(), "updated_at": now_iso()},
            expected_statuses=("repairing",)
        ):
            raise _RepairOwnershipLost("Repair ownership changed")
        last_heartbeat[0] = current

    part = _part_path(record)
    actual = _final_file_size(record)
    part_exists = _part_exists(record)
    message = None
    queue_repair = False

    try:
        if actual is not None and actual == expected:
            hash_matches = _file_matches_hash(
                record.get("path"),
                expected_hash,
                repair_heartbeat
            )
            # The hash callback is throttled; force one final CAS immediately
            # before either completing or quarantining the file.
            repair_heartbeat(force=True)
            if hash_matches:
                updated = db.update_owned(download_id, repair_token, {
                    "status": "complete",
                    "verified_at": now_iso(),
                    "error": None,
                    "error_code": None,
                    "bytes_done": actual,
                    "progress": 100,
                    "owner_token": None,
                    "owner_worker_id": None,
                    "owner_heartbeat_at": None,
                    "attempt_id": None,
                    "repair_from_status": None,
                    "updated_at": now_iso()
                }, expected_statuses=("repairing",))
                if updated:
                    xbmcgui.Dialog().notification(
                        "Verified",
                        "The file is already complete.",
                        xbmcgui.NOTIFICATION_INFO,
                        2500
                    )
                _refresh_downloads_container()
                return

        if actual is not None and actual > expected:
            message = "Repair stopped because the existing file is larger than the authoritative size. It was left untouched."
        elif actual is not None and actual == expected:
            quarantine = f"{record.get('path')}.corrupt-{str(download_id)[:8]}"
            repair_heartbeat(force=True)
            if _move_without_overwrite(record.get("path"), quarantine):
                queue_repair = True
                record["quarantine_path"] = quarantine
            else:
                message = "The file has the expected size but failed its hash check and could not be quarantined."
        elif actual is not None:
            if part_exists:
                message = "Repair stopped because a partial file already exists. Neither file was overwritten."
            elif _requires_local_staging(record.get("path")):
                if _copy_vfs_to_local_and_remove(
                    record.get("path"),
                    part,
                    actual,
                    repair_heartbeat,
                    lambda: repair_heartbeat(force=True)
                ):
                    queue_repair = True
                else:
                    message = "Repair could not move the incomplete network file into local staging."
            else:
                repair_heartbeat(force=True)
                if _move_without_overwrite(record.get("path"), part):
                    queue_repair = True
                else:
                    message = "Repair could not move the incomplete file to the partial download."
        else:
            queue_repair = True
    except _RepairOwnershipLost:
        _refresh_downloads_container()
        return

    if queue_repair:
        part_size = _part_size(record)
        progress = min(100, int(100 * part_size / expected)) if expected > 0 else 0
        updated = db.update_owned(download_id, repair_token, {
            "status": "queued",
            "queue_position": _next_queue_position(db.list()),
            "error": None,
            "error_code": None,
            "attempts": 0,
            "next_attempt_at": None,
            "owner_token": None,
            "owner_worker_id": None,
            "owner_heartbeat_at": None,
            "attempt_id": None,
            "repair_from_status": None,
            "bytes_done": part_size,
            "progress": progress,
            "quarantine_path": record.get("quarantine_path"),
            "updated_at": now_iso()
        }, expected_statuses=("repairing",))
        if updated:
            xbmcgui.Dialog().notification("Repair queued", record.get("filename", "Download"), xbmcgui.NOTIFICATION_INFO, 2500)
    else:
        db.update_owned(download_id, repair_token, {
            "status": "failed",
            "queue_position": None,
            "error": message,
            "error_code": VERIFICATION_ERROR_CODE,
            "owner_token": None,
            "owner_worker_id": None,
            "owner_heartbeat_at": None,
            "attempt_id": None,
            "repair_from_status": None,
            "updated_at": now_iso()
        }, expected_statuses=("repairing",))
        xbmcgui.Dialog().ok("Repair download", message)
    _refresh_downloads_container()

def clear_download_history():
    confirm = xbmcgui.Dialog().yesno(
        "Vymazať históriu sťahovania",
        "Odstránia sa iba dokončené a zrušené záznamy bez .part súboru. "
        "Zlyhané záznamy a všetky čiastočné sťahovania zostanú zachované. Stiahnuté súbory sa neodstránia. Pokračovať?",
        yeslabel="Áno",
        nolabel="Nie"
    )
    if not confirm:
        return

    snapshot = db.list()
    removable = {}
    for download_id, record in snapshot.items():
        if record.get("status") not in ("complete", "canceled"):
            continue
        if record.get("cleanup_pending") or _part_exists(record):
            continue
        finalization_path = record.get("finalization_path")
        if finalization_path:
            try:
                if xbmcvfs.exists(finalization_path):
                    continue
            except Exception:
                continue
        removable[download_id] = record.get("revision")

    def op(data):
        removable_ids = []
        for download_id, expected_revision in removable.items():
            current = data.get(download_id)
            if not current or current.get("status") not in ("complete", "canceled"):
                continue
            if current.get("revision") != expected_revision:
                continue
            del data[download_id]
            removable_ids.append(download_id)
        _normalize_queue_positions(data)
        return len(removable_ids)

    removed = db.mutate(op)
    xbmcgui.Dialog().notification("Downloads", f"Removed {removed} history record(s)", xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin("Container.Refresh")
