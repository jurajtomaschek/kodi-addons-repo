from resources.lib.downloads_worker import DownloadsWorker

if __name__ == "__main__":
    DownloadsWorker().run()
