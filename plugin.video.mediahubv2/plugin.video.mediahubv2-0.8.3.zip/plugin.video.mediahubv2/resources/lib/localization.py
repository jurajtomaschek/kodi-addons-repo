"""Small, explicit UI localization layer for Media Hub.

The selected language is intentionally independent from Kodi's global language,
so every household can choose the add-on language in Media Hub settings.
"""

try:
    import xbmcaddon
except ImportError:  # Allows non-Kodi tooling and unit tests to import the UI.
    xbmcaddon = None


ENGLISH = "en"
SLOVAK = "sk"

_SK = {
    "Home": "Domov",
    "Everything worth watching, all in one place": "Všetko, čo sa oplatí pozerať, na jednom mieste",
    "Movies": "Filmy",
    "Popular titles, new releases and top rated films": "Populárne tituly, novinky a najlepšie hodnotené filmy",
    "TV Series": "Seriály",
    "Trending series and recently aired episodes": "Trendové seriály a nedávno odvysielané epizódy",
    "Downloads": "Sťahovanie",
    "Your offline library and active transfers": "Vaša offline knižnica a aktívne prenosy",
    "Favourites": "Obľúbené",
    "Movies and series saved for later": "Filmy a seriály uložené na neskôr",
    "Recently Viewed": "Nedávno pozerané",
    "Continue where you left off": "Pokračujte tam, kde ste skončili",
    "Settings": "Nastavenia",
    "Playback, downloads and account preferences": "Prehrávanie, sťahovanie a nastavenia účtu",
    "Search": "Hľadať",
    "Find movies and TV series": "Nájdite filmy a seriály",
    "Browse": "Prehliadať",
    "Explore Media Hub": "Objavujte Media Hub",
    "Continue Watching": "Pokračovať v pozeraní",
    "Continue watching": "Pokračovať v pozeraní",
    "Watch again": "Pozrieť znova",
    "Featured": "Odporúčané",
    "My List": "Môj zoznam",
    "Discover": "Objavovať",
    "Trending Now": "Práve populárne",
    "Popular TV Series": "Populárne seriály",
    "Popular": "Populárne",
    "New Releases": "Novinky",
    "Top Rated": "Najlepšie hodnotené",
    "Recently Aired": "Nedávno odvysielané",
    "Slovak": "Slovenské",
    "Trending now": "Práve populárne",
    "Just added": "Práve pridané",
    "Best reviewed": "Najlepšie hodnotené",
    "Recently shown": "Nedávno odvysielané",
    "Slovak productions": "Slovenská tvorba",
    "Search movies and TV series": "Hľadať filmy a seriály",
    "Results for “{0}”": "Výsledky pre „{0}“",
    "Content could not be loaded.": "Obsah sa nepodarilo načítať.",
    "This screen could not be loaded.": "Túto obrazovku sa nepodarilo načítať.",
    "Nothing to show yet.": "Zatiaľ tu nie je čo zobraziť.",
    "No titles to show": "Žiadne tituly na zobrazenie",
    "Try another tab, search, or check the API connection.": "Skúste inú kartu, vyhľadávanie alebo skontrolujte pripojenie API.",
    "Open addon settings": "Otvoriť nastavenia doplnku",
    "Media Hub interface": "Rozhranie Media Hub",
    "Modern": "Moderné",
    "Nothing here yet": "Zatiaľ tu nič nie je",
    "SUMMARY": "SÚHRN",
    "SEARCH": "HĽADAŤ",
    "LOADING": "NAČÍTAVA SA",
    "STREAM OPTIONS": "MOŽNOSTI STREAMU",
    "OK  Select     BACK  Close": "OK  Vybrať     SPÄŤ  Zavrieť",
    "SEASONS": "SÉRIE",
    "PLAY": "PREHRAŤ",
    "BACK": "SPÄŤ",
    "Download": "Stiahnuť",
    "Add this stream to the download queue": "Pridať tento stream do frontu sťahovania",
    "Actions": "Akcie",
    "MOVIES": "FILMY",
    "TV SERIES": "SERIÁLY",
    "OFFLINE LIBRARY": "OFFLINE KNIŽNICA",
    "MY LIST": "MÔJ ZOZNAM",
    "RECENTLY VIEWED": "NEDÁVNO POZERANÉ",
    "SETTINGS": "NASTAVENIA",
    "A film for every night.": "Film na každý večer.",
    "Your next series is here.": "Váš ďalší seriál je tu.",
    "Downloads under control.": "Sťahovanie pod kontrolou.",
    "Your favourites, always close.": "Vaše obľúbené tituly vždy poruke.",
    "Continue where you left off.": "Pokračujte tam, kde ste skončili.",
    "Media Hub, your way.": "Media Hub podľa vás.",
    "Account & API": "Účet a API",
    "Playback": "Prehrávanie",
    "TV filtering": "Filtrovanie seriálov",
    "Interface": "Rozhranie",
    "About": "O doplnku",
    "Connection, credentials and service access": "Pripojenie, prihlasovacie údaje a prístup k službe",
    "Quality, subtitles and language": "Kvalita, titulky a jazyk",
    "Storage, queue and offline files": "Úložisko, front a offline súbory",
    "Animation and catalogue preferences": "Nastavenia animácie a katalógu",
    "Modern home and compatibility options": "Moderná domovská obrazovka a kompatibilita",
    "Language": "Jazyk",
    "English": "Angličtina",
    "Slovenčina": "Slovenčina",
    "Choose the language used by the Media Hub interface.": "Vyberte jazyk rozhrania Media Hub.",
    "Modern Media Hub": "Moderný Media Hub",
    "Use the cinematic application shell by default.": "Predvolene používať filmové aplikačné rozhranie.",
    "On": "Zapnuté",
    "Off": "Vypnuté",
    "Play": "Prehrať",
    "Play next episode": "Prehrať ďalšiu epizódu",
    "Open the next available episode": "Otvoriť ďalšiu dostupnú epizódu",
    "View this season": "Zobraziť túto sériu",
    "Choose another episode": "Vybrať inú epizódu",
    "View series": "Zobraziť seriál",
    "Browse every season": "Prehliadať všetky série",
    "Resume this episode": "Pokračovať v tejto epizóde",
    "Replay this episode": "Prehrať túto epizódu znova",
    "Start this stream now": "Spustiť tento stream",
    "Add to Favourites": "Pridať medzi obľúbené",
    "Remove from Favourites": "Odstrániť z obľúbených",
    "Add to Media Hub Favorites": "Pridať medzi obľúbené v Media Hub",
    "Remove from Media Hub Favorites": "Odstrániť z obľúbených v Media Hub",
    "Remove this exact stream from your saved items": "Odstrániť tento stream z uložených položiek",
    "Save this exact stream for quick access": "Uložiť tento stream pre rýchly prístup",
    "Move up": "Posunúť vyššie",
    "Move to top": "Presunúť navrch",
    "Move down": "Posunúť nižšie",
    "Move to bottom": "Presunúť naspodok",
    "Pause": "Pozastaviť",
    "Resume": "Pokračovať",
    "Cancel": "Zrušiť",
    "Retry": "Skúsiť znova",
    "Verify": "Overiť",
    "Repair": "Opraviť",
    "QUEUE": "FRONT",
    "REMOVE": "ODSTRÁNIŤ",
    "SAVE": "ULOŽIŤ",
    "EPISODES": "EPIZÓDY",
    "SERIES": "SERIÁL",
    "Go to series": "Prejsť na seriál",
    "Go to season": "Prejsť na sériu",
    "Remove from history": "Odstrániť z histórie",
    "Clear watch history": "Vymazať históriu pozerania",
    "Explore": "Preskúmať",
    "Open": "Otvoriť",
    "Details": "Podrobnosti",
}

_EN = {translated: english for english, translated in _SK.items()}


def language():
    global xbmcaddon
    if xbmcaddon is None:
        try:
            import importlib
            xbmcaddon = importlib.import_module("xbmcaddon")
        except ImportError:
            return ENGLISH
    try:
        value = (xbmcaddon.Addon().getSetting("ui_language") or ENGLISH).lower()
    except Exception:
        return ENGLISH
    return SLOVAK if value in (SLOVAK, "1", "slovak") else ENGLISH


def tr(text, *args):
    translated = _SK.get(text, text) if language() == SLOVAK else _EN.get(text, text)
    return translated.format(*args) if args else translated
