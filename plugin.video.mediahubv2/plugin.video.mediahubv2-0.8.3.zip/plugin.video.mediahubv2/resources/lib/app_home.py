"""Controller for the fullscreen Media Hub application shell."""

import threading
import xbmc
import xbmcgui
try:
    from .localization import tr
except ImportError:  # Direct module loading used by the lightweight test harness.
    from resources.lib.localization import tr


XML_FILENAME = "MediaHubHome.xml"
ADDON_ID = "plugin.video.mediahub"

NAV = 100
SEARCH = 200
TABS = 210
HOME_PRIMARY = 300
HOME_SECONDARY = 310
CATALOG = 400
HISTORY = 420
BROWSER = 430
DOWNLOADS = 500
SETTINGS = 510
DETAIL_ACTIONS = 600
CONTEXT_MENU = 700

# Compatibility names used by older tests and callers.
QUICK = HOME_PRIMARY
FAVORITES = HOME_SECONDARY

_BACK_ACTIONS = frozenset((9, 10, 92, 110))
DOWNLOAD_REFRESH_INTERVAL_SECONDS = 1.0
_CONTROL_NAMES = {
    NAV: "navigation",
    TABS: "tabs",
    HOME_PRIMARY: "home primary",
    HOME_SECONDARY: "home secondary",
    CATALOG: "catalog",
    HISTORY: "history",
    BROWSER: "browser",
    DOWNLOADS: "downloads",
    SETTINGS: "settings",
    DETAIL_ACTIONS: "detail actions",
    CONTEXT_MENU: "context menu",
}

_PAGE_TITLES = {
    "home": ("Home", "Everything worth watching, all in one place"),
    "movies": ("Movies", "Popular titles, new releases and top rated films"),
    "tv": ("TV Series", "Trending series and recently aired episodes"),
    "downloads": ("Downloads", "Your offline library and active transfers"),
    "favorites": ("Favourites", "Movies and series saved for later"),
    "history": ("Recently Viewed", "Continue where you left off"),
    "settings": ("Settings", "Playback, downloads and account preferences"),
    "search": ("Search", "Find movies and TV series"),
    "browse": ("Browse", "Explore Media Hub"),
}


def _log(message, level=None):
    if level is None:
        level = xbmc.LOGDEBUG
    try:
        xbmc.log("[Media Hub app] {0}".format(message), level)
    except Exception:
        pass


def _models(value):
    if value is None:
        return []
    try:
        values = list(value)
    except TypeError:
        return []
    return [model for model in values if isinstance(model, dict)]


def _text(value):
    if value is None:
        return ""
    if isinstance(value, bool):
        return "true" if value else "false"
    return str(value)


def _model_property(model, key, default=""):
    properties = model.get("properties")
    if not isinstance(properties, dict):
        return _text(default)
    return _text(properties.get(key, default))


class MediaHubHomeDialog(xbmcgui.WindowXML):
    """Single-window, remote-first interface for every primary addon page."""

    def __init__(self, *args, **kwargs):
        self.navigation = _models(kwargs.pop("navigation", None))
        self.home_primary = _models(
            kwargs.pop("home_primary", kwargs.pop("quick_items", None))
        )
        secondary_items = kwargs.pop("home_secondary", None)
        favorite_items = kwargs.pop("favorite_items", None)
        self.home_secondary = _models(
            secondary_items if secondary_items is not None else favorite_items
        )
        self.favorite_items = _models(
            favorite_items if favorite_items is not None else self.home_secondary
        )
        self.history_items = _models(kwargs.pop("history_items", None))
        self.download_items = _models(kwargs.pop("download_items", None))
        self.settings_items = _models(kwargs.pop("settings_items", None))
        self.fallback_art = _text(kwargs.pop("fallback_art", ""))
        self.logo_art = _text(kwargs.pop("logo_art", ""))
        self.initial_page = _text(kwargs.pop("initial_page", "home")) or "home"
        self.catalog_loader = kwargs.pop("catalog_loader", None)
        self.catalog_page_loader = kwargs.pop("catalog_page_loader", None)
        self.catalog_columns = max(1, int(kwargs.pop("catalog_columns", 6)))
        self.search_loader = kwargs.pop("search_loader", None)
        self.home_loader = kwargs.pop("home_loader", None)
        self.browser_loader = kwargs.pop("browser_loader", None)
        self.action_handler = kwargs.pop("action_handler", None)
        self.play_handler = kwargs.pop("play_handler", None)
        self.state_loader = kwargs.pop("state_loader", None)
        self.initial_target = _text(kwargs.pop("initial_target", ""))
        self.result = None

        self._page = ""
        self._previous_page = "home"
        self._catalog_cache = {}
        self._catalog_pages = {}
        self._catalog_exhausted = set()
        self._catalog_page_loading = False
        self._tabs = []
        self._catalog_items = []
        self._browser_items = []
        self._browser_targets = []
        self._browser_origin = "home"
        self._browser_view = {}
        self._browser_return_state = None
        self._context_items = []
        self._context_open = False
        self._context_origin_control = None
        self._nav_index = {}
        self._nav_position = None
        self._tab_position = None
        self._initialized = False
        self._reactivation_state = None
        self._downloads_refresh_stop = threading.Event()
        self._downloads_refresh_thread = None

        self._items_by_control = {
            NAV: self.navigation,
            TABS: self._tabs,
            HOME_PRIMARY: self.home_primary,
            HOME_SECONDARY: self.home_secondary,
            CATALOG: self._catalog_items,
            HISTORY: self.history_items,
            BROWSER: self._browser_items,
            DOWNLOADS: self.download_items,
            SETTINGS: self.settings_items,
            DETAIL_ACTIONS: [],
            CONTEXT_MENU: self._context_items,
        }

    def onInit(self):
        try:
            self.setProperty("App.FallbackArt", self.fallback_art)
            self.setProperty("App.Logo", self.logo_art)
            self.setProperty(
                "App.HomePrimaryTitle",
                tr("Continue Watching") if self.history_items else tr("Featured"),
            )
            self.setProperty(
                "App.HomeSecondaryTitle",
                tr("My List") if self.home_secondary else tr("Discover"),
            )
            self.setProperty(
                "App.HasHomeSecondary",
                "true" if self.home_secondary else "false",
            )
            if not self._initialized:
                self.setProperty(
                    "App.HomeReady",
                    "false" if callable(self.home_loader) else "true",
                )
            self.setProperty("App.ContextOpen", "false")
            self.setProperty("App.Loading", "false")
            for name, text in {
                "SearchLabel": "SEARCH",
                "LoadingLabel": "LOADING",
                "StreamOptionsLabel": "STREAM OPTIONS",
                "ContextHelp": "OK  Select     BACK  Close",
                "EmptyTitle": "No titles to show",
                "EmptyHint": "Try another tab, search, or check the API connection.",
                "OpenSettingsLabel": "Open addon settings",
                "InterfaceLabel": "Media Hub interface",
                "ModernLabel": "Modern",
                "NothingHereLabel": "Nothing here yet",
                "SummaryLabel": "SUMMARY",
            }.items():
                self.setProperty("App." + name, tr(text))
        except Exception as exc:
            _log("Could not initialize window properties: {0}".format(exc), xbmc.LOGERROR)

        self._nav_index = {
            _model_property(model, "App.Page"): index
            for index, model in enumerate(self.navigation)
            if _model_property(model, "App.Page")
        }
        for control_id in (
            NAV,
            HOME_PRIMARY,
            HOME_SECONDARY,
            HISTORY,
            DOWNLOADS,
            SETTINGS,
        ):
            self._populate_control(control_id, self._items_by_control[control_id])

        if self._initialized:
            self._restore_reactivated_window()
            return
        self._initialized = True
        self._show_page(self.initial_page, load=True)
        if self.initial_target:
            self._open_browser(self.initial_target)
        if callable(self.home_loader):
            threading.Thread(
                target=self._load_home_background,
                name="MediaHubHomeLoader",
                daemon=True,
            ).start()
        if callable(self.state_loader):
            self._downloads_refresh_thread = threading.Thread(
                target=self._refresh_downloads_background,
                name="MediaHubDownloadsRefresher",
                daemon=True,
            )
            self._downloads_refresh_thread.start()

    def close(self):
        self._downloads_refresh_stop.set()
        return super().close()

    def onClick(self, control_id):
        try:
            if control_id == CONTEXT_MENU:
                model = self._selected_model(CONTEXT_MENU)
                if model is not None:
                    self._close_context_menu(restore_focus=True)
                    self._activate(model)
                return

            if control_id == SEARCH:
                self._show_search()
                return

            model = self._selected_model(control_id)
            if model is None:
                return

            if control_id == NAV:
                page = _model_property(model, "App.Page", "home")
                self._show_page(page, load=True)
            elif control_id == TABS:
                tab = _model_property(model, "App.Tab")
                self._load_catalog(self._page, tab, force=False)
            elif control_id == DETAIL_ACTIONS:
                self._activate_detail_action(model)
            else:
                self._activate(model)
        except Exception as exc:
            _log(
                "Click handling failed for control {0}: {1}".format(control_id, exc),
                xbmc.LOGERROR,
            )

    def onFocus(self, control_id):
        if control_id == TABS:
            self._remember_tab_position()
            return
        if control_id != NAV:
            return
        page = self._previous_page if self._page == "detail" else self._page
        self._select_navigation(page)
        self._remember_navigation_position()

    def onAction(self, action):
        try:
            action_id = action.getId()
        except (AttributeError, TypeError):
            try:
                action_id = int(action)
            except (TypeError, ValueError):
                return

        if self._context_open:
            if action_id in _BACK_ACTIONS or action_id in (101, 117):
                self._close_context_menu()
            return
        if action_id in (101, 117):
            self._open_context_menu()
            return
        if action_id not in _BACK_ACTIONS:
            self._sync_navigation_selection()
            self._sync_tab_selection()
            if action_id == 4:
                self._load_next_catalog_page_if_needed()
            return
        if self._page == "browse":
            self._close_browser_level()
            return
        if self._page == "detail":
            self._show_page(self._previous_page, load=False)
            return

        if self._page != "home":
            self._show_page("home", load=False)
            return

        # Keep the application shell open at its root. In particular, do not
        # close the window here: repeated/queued Back actions would otherwise
        # continue through Kodi's navigation stack and leave the add-on.
        self._focus_home_content()

    def _show_page(self, page, load=True, focus=True):
        if page not in _PAGE_TITLES and page != "detail":
            page = "home"
        if page != "detail":
            self._previous_page = page
        self._page = page
        self.setProperty("App.Page", page)

        title, subtitle = _PAGE_TITLES.get(page, ("", ""))
        title, subtitle = tr(title), tr(subtitle)
        if page in ("movies", "tv"):
            title = title.upper()
        self.setProperty("App.PageTitle", title)
        self.setProperty("App.PageSubtitle", subtitle)
        self._select_navigation(page)

        if page in ("movies", "tv"):
            self._set_tabs(page)
            selected_tab = _model_property(self._tabs[0], "App.Tab") if self._tabs else ""
            if load:
                self._load_catalog(page, selected_tab, force=False, focus=focus)
            if focus:
                self._focus(CATALOG if self._catalog_items else TABS)
        elif page == "favorites":
            self._set_catalog(self.favorite_items)
            if focus:
                self._focus(CATALOG if self._catalog_items else NAV)
        elif page == "history":
            if focus:
                self._focus(HISTORY if self.history_items else NAV)
        elif page == "downloads":
            if focus:
                self._focus(DOWNLOADS if self.download_items else NAV)
        elif page == "settings":
            if focus:
                self._focus(SETTINGS if self.settings_items else NAV)
        elif page == "search":
            if focus:
                self._focus(CATALOG if self._catalog_items else SEARCH)
        elif page == "browse":
            self._restore_browser_state()
            if focus:
                self._focus(BROWSER if self._browser_items else NAV)
        elif page == "home" and focus:
            self._focus(
                HOME_PRIMARY
                if self.home_primary
                else HOME_SECONDARY
                if self.home_secondary
                else NAV
            )

    def _set_tabs(self, page):
        labels = (
            (
                (
                    tr("Popular"),
                    "popular",
                    "Trending now",
                    "category-popular.png",
                ),
                (
                    tr("New Releases"),
                    "latest",
                    "Just added",
                    "category-latest.png",
                ),
                (
                    tr("Top Rated"),
                    "top",
                    "Best reviewed",
                    "category-top-rated.png",
                ),
            )
            if page == "movies"
            else (
                (
                    tr("Popular"),
                    "popular",
                    "Trending now",
                    "category-popular.png",
                ),
                (
                    tr("New Releases"),
                    "latest",
                    "Just added",
                    "category-latest.png",
                ),
                (
                    tr("Recently Aired"),
                    "recent",
                    "Recently shown",
                    "category-recent.png",
                ),
                (
                    tr("Slovak"),
                    "slovak",
                    "Slovak productions",
                    "category-slovak.png",
                ),
            )
        )
        self._tabs[:] = [
            {
                "label": label.upper(),
                "command": "tab",
                "properties": {
                    "App.Tab": value,
                    "App.Hint": hint,
                    "App.Icon": icon,
                },
            }
            for label, value, hint, icon in labels
        ]
        active_tab = (
            _model_property(self._tabs[0], "App.Tab") if self._tabs else ""
        )
        self.setProperty("App.ActiveTab", active_tab)
        self._populate_control(TABS, self._tabs)

    def _load_catalog(self, page, tab, force=False, query="", focus=True):
        if page in ("movies", "tv") and tab:
            self.setProperty("App.ActiveTab", tab)
        cache_key = (page, tab, query)
        if not force and cache_key in self._catalog_cache:
            self._set_catalog(self._catalog_cache[cache_key])
            if focus:
                self._focus(CATALOG if self._catalog_items else TABS)
            return

        loader = self.search_loader if page == "search" else self.catalog_loader
        if not callable(loader):
            self._set_catalog([])
            return

        self.setProperty("App.Loading", "true")
        try:
            if page == "search":
                models = loader(query)
            else:
                models = loader(page, tab)
            models = _models(models)
            self._catalog_cache[cache_key] = models
            self._catalog_pages[cache_key] = 1
            self._catalog_exhausted.discard(cache_key)
            self._set_catalog(models)
        except Exception as exc:
            _log("Could not load {0}/{1}: {2}".format(page, tab, exc), xbmc.LOGERROR)
            self._set_catalog([])
            try:
                xbmcgui.Dialog().notification(
                    "Media Hub",
                    tr("Content could not be loaded."),
                    xbmcgui.NOTIFICATION_ERROR,
                    2500,
                )
            except Exception:
                pass
        finally:
            self.setProperty("App.Loading", "false")

        if focus:
            self._focus(CATALOG if self._catalog_items else TABS)

    def _load_next_catalog_page_if_needed(self):
        if (
            self._page not in ("movies", "tv")
            or not callable(self.catalog_page_loader)
            or self._catalog_page_loading
            or not self._catalog_items
        ):
            return
        try:
            control = self.getControl(CATALOG)
            position = int(control.getSelectedPosition())
        except Exception:
            return
        # Kodi calls onAction before the panel applies the Down movement. The
        # poster panel is six columns wide, so anticipate entry into the final
        # row and fetch while the penultimate row is focused. Waiting until the
        # reported position is already in the final row is unreliable because
        # some Kodi versions stop dispatching Down at the panel boundary.
        if position < max(
            0, len(self._catalog_items) - (self.catalog_columns * 2 + 1)
        ):
            return

        tab = (
            _model_property(self._tabs[self._tab_position], "App.Tab")
            if self._tab_position is not None
            and 0 <= self._tab_position < len(self._tabs)
            else _model_property(self._tabs[0], "App.Tab") if self._tabs else ""
        )
        cache_key = (self._page, tab, "")
        if cache_key in self._catalog_exhausted:
            return
        next_page = self._catalog_pages.get(cache_key, 1) + 1
        self._catalog_page_loading = True
        self.setProperty("App.Loading", "true")
        try:
            models = _models(self.catalog_page_loader(self._page, tab, next_page))
            if not models:
                self._catalog_exhausted.add(cache_key)
                return
            existing_ids = {
                (_model_property(model, "App.Kind"), _model_property(model, "App.Id"))
                for model in self._catalog_items
                if _model_property(model, "App.Id")
            }
            additions = [
                model for model in models
                if not _model_property(model, "App.Id")
                or (
                    _model_property(model, "App.Kind"),
                    _model_property(model, "App.Id"),
                ) not in existing_ids
            ]
            self._catalog_pages[cache_key] = next_page
            if not additions:
                self._catalog_exhausted.add(cache_key)
                return
            combined = list(self._catalog_items) + additions
            self._catalog_cache[cache_key] = combined
            self._set_catalog(combined)
            try:
                self.getControl(CATALOG).selectItem(position)
            except Exception:
                pass
        except Exception as exc:
            _log(
                "Could not load catalog page {0}: {1}".format(next_page, exc),
                xbmc.LOGERROR,
            )
        finally:
            self.setProperty("App.Loading", "false")
            self._catalog_page_loading = False

    def _show_search(self):
        try:
            keyboard = xbmc.Keyboard("", tr("Search movies and TV series"))
            keyboard.doModal()
            if not keyboard.isConfirmed():
                return
            query = _text(keyboard.getText()).strip()
        except Exception as exc:
            _log("Could not open search keyboard: {0}".format(exc), xbmc.LOGERROR)
            return
        if not query:
            return

        self._page = "search"
        self.setProperty("App.Page", "search")
        self.setProperty("App.PageTitle", tr("Search"))
        self.setProperty("App.PageSubtitle", tr("Results for “{0}”", query))
        self._select_navigation("")
        self._load_catalog("search", "results", force=True, query=query)

    def _load_home_background(self):
        try:
            loaded = self.home_loader()
            if not isinstance(loaded, (list, tuple)) or len(loaded) != 2:
                return
            primary, secondary = (_models(loaded[0]), _models(loaded[1]))
            if primary:
                self.home_primary[:] = primary
                self._populate_control(HOME_PRIMARY, self.home_primary)
                self.setProperty("App.HomePrimaryTitle", tr("Trending Now"))
            if secondary:
                self.home_secondary[:] = secondary
                self._populate_control(HOME_SECONDARY, self.home_secondary)
                self.setProperty("App.HomeSecondaryTitle", tr("Popular TV Series"))
                self.setProperty("App.HasHomeSecondary", "true")
        except Exception as exc:
            _log("Could not refresh home artwork: {0}".format(exc), xbmc.LOGWARNING)
        finally:
            # The initially supplied history/favourites shelves are a fallback,
            # not an intermediate home-page render. Reveal the page only after
            # the online shelves have either replaced them or failed to load.
            self.setProperty("App.HomeReady", "true")

    def _refresh_downloads_background(self):
        while not self._downloads_refresh_stop.wait(
            DOWNLOAD_REFRESH_INTERVAL_SECONDS
        ):
            if self._page != "downloads":
                continue
            self._refresh_state(downloads_only=True)

    def _set_catalog(self, models):
        self._catalog_items[:] = _models(models)
        self._populate_control(CATALOG, self._catalog_items)
        self.setProperty("App.HasCatalog", "true" if self._catalog_items else "false")

    def _show_detail(self, model):
        if self._page == "browse":
            self._browser_return_state = {
                "targets": list(self._browser_targets),
                "view": dict(self._browser_view),
                "items": list(self._browser_items),
            }
        elif self._page != "detail":
            self._browser_return_state = None
        self._previous_page = self._page if self._page != "detail" else self._previous_page
        self._page = "detail"
        self.setProperty("App.Page", "detail")

        properties = model.get("properties") if isinstance(model.get("properties"), dict) else {}
        detail_values = {
            "App.Detail.Title": properties.get("MediaHub.Title") or model.get("label"),
            "App.Detail.Eyebrow": properties.get("MediaHub.Eyebrow") or "MEDIA HUB",
            "App.Detail.Meta": properties.get("MediaHub.Meta") or model.get("label2"),
            "App.Detail.Description": properties.get("MediaHub.Description"),
            "App.Detail.HeroDescription": (
                properties.get("MediaHub.HeroDescription")
                or properties.get("MediaHub.Description")
            ),
            "App.Detail.Year": properties.get("App.Year") or "—",
            "App.Detail.Rating": properties.get("App.Rating") or "—",
            "App.Detail.Kind": properties.get("App.KindLabel") or "Media",
            "App.Detail.Fanart": (model.get("art") or {}).get("fanart", ""),
            "App.Detail.Poster": (model.get("art") or {}).get("poster", ""),
        }
        for key, value in detail_values.items():
            self.setProperty(key, _text(value))

        target = _text(model.get("target"))
        primary_label = tr("SEASONS") if properties.get("App.Kind") == "tv" else tr("PLAY")
        actions = [
            {
                "label": primary_label,
                "command": "browse" if callable(self.browser_loader) else "navigate",
                "target": target,
                "properties": {"App.ActionGlyph": "▶"},
            },
            {
                "label": tr("BACK"),
                "command": "back_detail",
                "target": "",
                "properties": {"App.ActionGlyph": "←"},
            },
        ]
        self._items_by_control[DETAIL_ACTIONS] = actions
        self._populate_control(DETAIL_ACTIONS, actions)

        self._focus(DETAIL_ACTIONS)

    def _activate_detail_action(self, model):
        command = _text(model.get("command")).strip().lower()
        if command == "back_detail":
            self._show_page(self._previous_page, load=False)
        else:
            self._activate(model)

    def _activate(self, model):
        command = _text(model.get("command")).strip().lower()
        target = _text(model.get("target")).strip()

        if command == "page":
            self._show_page(_model_property(model, "App.Page", "home"), load=True)
        elif command == "detail":
            self._show_detail(model)
        elif command == "browse":
            self._open_browser(target)
        elif command == "navigate":
            if target:
                self.result = {"command": "navigate", "target": target}
                self.close()
        elif command == "play":
            if target:
                handled = False
                if callable(self.play_handler):
                    reactivation_state = self._capture_reactivation_state()
                    self.setProperty("App.Loading", "true")
                    try:
                        outcome = self.play_handler(target)
                        handled = outcome is not False
                        if outcome is True:
                            self._reactivation_state = reactivation_state
                            self._refresh_state()
                    except Exception as exc:
                        _log(
                            "Direct playback failed for {0}: {1}".format(
                                target, exc
                            ),
                            xbmc.LOGERROR,
                        )
                    finally:
                        self.setProperty("App.Loading", "false")
                if not handled:
                    xbmc.executebuiltin("PlayMedia({0})".format(target))
        elif command == "builtin":
            if target:
                xbmc.executebuiltin(target)
        elif command == "action":
            self._run_action(target)
        elif command == "run":
            if target:
                xbmc.executebuiltin("RunPlugin({0})".format(target))
        elif command == "settings":
            xbmc.executebuiltin("Addon.OpenSettings({0})".format(ADDON_ID))
        elif command == "back_detail":
            self._show_page(self._previous_page, load=False)
        else:
            _log("Ignored unsupported app command: {0}".format(command), xbmc.LOGWARNING)

    def _open_browser(self, target, replace=False):
        target = _text(target).strip()
        if not target or not callable(self.browser_loader):
            return

        self.setProperty("App.Loading", "true")
        try:
            view = self.browser_loader(target)
        except Exception as exc:
            _log("Could not load browser target {0}: {1}".format(target, exc), xbmc.LOGERROR)
            try:
                xbmcgui.Dialog().notification(
                    "Media Hub",
                    tr("This screen could not be loaded."),
                    xbmcgui.NOTIFICATION_ERROR,
                    2500,
                )
            except Exception:
                pass
            return
        finally:
            self.setProperty("App.Loading", "false")

        if not isinstance(view, dict):
            return
        if self._page != "browse":
            self._browser_origin = self._page
            self._browser_targets = []
        if replace and self._browser_targets:
            self._browser_targets[-1] = target
        elif not self._browser_targets or self._browser_targets[-1] != target:
            self._browser_targets.append(target)

        self._page = "browse"
        self.setProperty("App.Page", "browse")
        self.setProperty("App.BrowserTitle", _text(view.get("title", tr("Browse"))))
        self.setProperty("App.BrowserSubtitle", _text(view.get("subtitle", "")))
        self.setProperty("App.BrowserEyebrow", _text(view.get("eyebrow", "MEDIA HUB")))
        self.setProperty("App.BrowserEmpty", _text(view.get("empty", tr("Nothing to show yet."))))
        self.setProperty("App.BrowserArt", _text(view.get("fanart", self.fallback_art)))
        self.setProperty(
            "App.BrowserDepth",
            "{0:02d}".format(max(1, len(self._browser_targets))),
        )
        self._browser_view = dict(view)
        self._browser_items[:] = _models(view.get("items"))
        self._populate_control(BROWSER, self._browser_items)
        self.setProperty("App.HasBrowser", "true" if self._browser_items else "false")
        self._focus(BROWSER if self._browser_items else NAV)

    def _restore_browser_state(self):
        state = self._browser_return_state
        if not isinstance(state, dict):
            return
        view = state.get("view")
        if not isinstance(view, dict):
            return
        self._browser_targets = list(state.get("targets") or [])
        self._browser_view = dict(view)
        self._browser_items[:] = _models(state.get("items"))
        self.setProperty("App.BrowserTitle", _text(view.get("title", "Browse")))
        self.setProperty("App.BrowserSubtitle", _text(view.get("subtitle", "")))
        self.setProperty("App.BrowserEyebrow", _text(view.get("eyebrow", "MEDIA HUB")))
        self.setProperty("App.BrowserEmpty", _text(view.get("empty", "Nothing to show yet.")))
        self.setProperty("App.BrowserArt", _text(view.get("fanart", self.fallback_art)))
        self.setProperty(
            "App.BrowserDepth",
            "{0:02d}".format(max(1, len(self._browser_targets))),
        )
        self._populate_control(BROWSER, self._browser_items)
        self.setProperty("App.HasBrowser", "true" if self._browser_items else "false")
        self._browser_return_state = None

    def _reload_browser(self, target=None):
        if target:
            self._open_browser(target, replace=True)
        elif self._browser_targets:
            self._open_browser(self._browser_targets[-1], replace=True)

    def _close_browser_level(self):
        if len(self._browser_targets) > 1:
            self._browser_targets.pop()
            target = self._browser_targets.pop()
            self._open_browser(target)
            return
        self._browser_targets = []
        origin = self._browser_origin
        if origin == "browse":
            origin = "home"
        self._show_page(origin, load=False)

    def _run_action(self, target):
        if not target or not callable(self.action_handler):
            return
        try:
            next_target = self.action_handler(target)
        except Exception as exc:
            _log("Action failed for {0}: {1}".format(target, exc), xbmc.LOGERROR)
            return
        self._refresh_state()
        self._reload_browser(_text(next_target).strip() if next_target else None)

    def _refresh_state(self, downloads_only=False):
        if not callable(self.state_loader):
            return
        try:
            state = self.state_loader()
        except Exception as exc:
            _log("Could not refresh app state: {0}".format(exc), xbmc.LOGWARNING)
            return
        if not isinstance(state, dict):
            return

        if not downloads_only:
            favourites = state.get("favorites")
            if favourites is not None:
                self.favorite_items[:] = _models(favourites)
                if self._page == "favorites":
                    self._set_catalog(self.favorite_items)
            history = state.get("history")
            if history is not None:
                self.history_items[:] = _models(history)
                self._populate_control(HISTORY, self.history_items)
        downloads = state.get("downloads")
        if downloads is not None:
            selection = self._control_selection(DOWNLOADS)
            self.download_items[:] = _models(downloads)
            self._populate_control(DOWNLOADS, self.download_items)
            self._restore_control_selection(DOWNLOADS, selection)

    def _control_selection(self, control_id):
        models = self._items_by_control.get(control_id)
        if models is None:
            return {}
        try:
            position = int(self.getControl(control_id).getSelectedPosition())
        except Exception:
            position = 0
        selected = models[position] if 0 <= position < len(models) else None
        return {
            "position": position,
            "target": _text(selected.get("target")) if selected else "",
            "command": _text(selected.get("command")) if selected else "",
            "label": _text(selected.get("label")) if selected else "",
        }

    def _open_context_menu(self):
        try:
            control_id = int(self.getFocusId())
        except Exception:
            return
        model = self._selected_model(control_id)
        if model is None:
            return
        actions = _models(model.get("context_actions"))
        if not actions:
            target = _model_property(model, "App.ContextTarget")
            if target:
                actions = [{
                    "label": tr("Download"),
                    "label2": tr("Add this stream to the download queue"),
                    "command": "action",
                    "target": target,
                    "properties": {"App.Badge": "QUEUE"},
                }]
        if not actions:
            return

        self._context_items[:] = actions
        self._populate_control(CONTEXT_MENU, self._context_items)
        self._context_origin_control = control_id
        self._context_open = True
        self.setProperty("App.ContextTitle", _text(model.get("label", tr("Actions"))))
        self.setProperty("App.ContextSubtitle", _text(model.get("label2", "")))
        self.setProperty("App.ContextOpen", "true")
        self._focus(CONTEXT_MENU)

    def _close_context_menu(self, restore_focus=True):
        if not self._context_open:
            return
        origin = self._context_origin_control
        self._context_open = False
        self._context_origin_control = None
        self.setProperty("App.ContextOpen", "false")
        if restore_focus and origin is not None:
            self._focus(origin)

    def _populate_control(self, control_id, models):
        try:
            control = self.getControl(control_id)
            reset = getattr(control, "reset", None)
            if callable(reset):
                reset()
            items = [self._list_item(model) for model in models]
            add_items = getattr(control, "addItems", None)
            if callable(add_items):
                add_items(items)
            else:
                add_item = getattr(control, "addItem")
                for item in items:
                    add_item(item)
        except Exception as exc:
            _log(
                "Could not populate {0} ({1}): {2}".format(
                    _CONTROL_NAMES.get(control_id, control_id),
                    control_id,
                    exc,
                ),
                xbmc.LOGERROR,
            )

    @staticmethod
    def _list_item(model):
        item = xbmcgui.ListItem(
            label=tr(_text(model.get("label"))),
            label2=tr(_text(model.get("label2"))),
        )
        art = model.get("art")
        if isinstance(art, dict):
            normalized_art = {
                _text(key): _text(value) for key, value in art.items()
            }
            item.setArt(normalized_art)
            # WindowXML list/panel controls do not expose ListItem.Art
            # consistently across Kodi versions. Mirror artwork as ordinary
            # properties, which custom skin controls reliably resolve.
            item.setProperty(
                "MediaHub.Thumb", normalized_art.get("thumb", "")
            )
            item.setProperty(
                "MediaHub.Poster", normalized_art.get("poster", "")
            )
            item.setProperty(
                "MediaHub.Fanart", normalized_art.get("fanart", "")
            )
        properties = model.get("properties")
        if isinstance(properties, dict):
            for key, value in properties.items():
                text_key = _text(key)
                text_value = _text(value)
                if text_key in ("App.Badge", "App.Hint"):
                    text_value = tr(text_value)
                item.setProperty(text_key, text_value)
        return item

    def _selected_model(self, control_id):
        models = self._items_by_control.get(control_id)
        if models is None:
            return None
        try:
            position = int(self.getControl(control_id).getSelectedPosition())
        except Exception:
            return None
        return models[position] if 0 <= position < len(models) else None

    def _capture_reactivation_state(self):
        selections = {}
        for control_id, models in self._items_by_control.items():
            if control_id == CONTEXT_MENU:
                continue
            try:
                position = int(self.getControl(control_id).getSelectedPosition())
            except Exception:
                continue
            selected = models[position] if 0 <= position < len(models) else None
            selections[control_id] = {
                "position": position,
                "target": _text(selected.get("target")) if selected else "",
                "command": _text(selected.get("command")) if selected else "",
                "label": _text(selected.get("label")) if selected else "",
            }
        try:
            focus_id = int(self.getFocusId())
        except Exception:
            focus_id = BROWSER if self._page == "browse" else NAV
        return {
            "page": self._page,
            "previous_page": self._previous_page,
            "focus_id": focus_id,
            "selections": selections,
        }

    def _restore_reactivated_window(self):
        state = self._reactivation_state
        if not isinstance(state, dict):
            state = {
                "page": self._page or self.initial_page,
                "previous_page": self._previous_page,
                "selections": {},
            }

        page = _text(state.get("page", self._page or self.initial_page)) or "home"
        self._page = page
        self._previous_page = (
            _text(state.get("previous_page", self._previous_page))
            or self._previous_page
        )
        self.setProperty("App.Page", page)
        title, subtitle = _PAGE_TITLES.get(page, ("", ""))
        title, subtitle = tr(title), tr(subtitle)
        if page in ("movies", "tv"):
            title = title.upper()
        self.setProperty("App.PageTitle", title)
        self.setProperty("App.PageSubtitle", subtitle)
        self._select_navigation(
            self._previous_page if page == "detail" else page
        )

        if page in ("movies", "tv"):
            self._populate_control(TABS, self._tabs)
            self._set_catalog(self._catalog_items)
        elif page in ("favorites", "search"):
            self._set_catalog(self._catalog_items)
        elif page == "browse":
            view = self._browser_view
            self.setProperty("App.BrowserTitle", _text(view.get("title", "Browse")))
            self.setProperty("App.BrowserSubtitle", _text(view.get("subtitle", "")))
            self.setProperty(
                "App.BrowserEyebrow",
                _text(view.get("eyebrow", "MEDIA HUB")),
            )
            self.setProperty(
                "App.BrowserEmpty",
                _text(view.get("empty", "Nothing to show yet.")),
            )
            self.setProperty(
                "App.BrowserArt",
                _text(view.get("fanart", self.fallback_art)),
            )
            self.setProperty(
                "App.BrowserDepth",
                "{0:02d}".format(max(1, len(self._browser_targets))),
            )
            self._populate_control(BROWSER, self._browser_items)
            self.setProperty(
                "App.HasBrowser",
                "true" if self._browser_items else "false",
            )
        elif page == "detail":
            self._populate_control(
                DETAIL_ACTIONS,
                self._items_by_control[DETAIL_ACTIONS],
            )

        selections = state.get("selections")
        if isinstance(selections, dict):
            for control_id, selection in selections.items():
                self._restore_control_selection(control_id, selection)

        try:
            focus_id = int(state.get("focus_id"))
        except (TypeError, ValueError):
            focus_id = BROWSER if page == "browse" else NAV
        self._focus(focus_id)
        self._reactivation_state = None

    def _restore_control_selection(self, control_id, selection):
        if not isinstance(selection, dict):
            return
        try:
            control_id = int(control_id)
        except (TypeError, ValueError):
            return
        models = self._items_by_control.get(control_id)
        if not models:
            return

        target = _text(selection.get("target"))
        command = _text(selection.get("command"))
        label = _text(selection.get("label"))
        matched = None
        for index, model in enumerate(models):
            if target and _text(model.get("target")) == target:
                matched = index
                break
            if (
                not target
                and command
                and _text(model.get("command")) == command
                and _text(model.get("label")) == label
            ):
                matched = index
                break
        if matched is None:
            try:
                matched = int(selection.get("position", 0))
            except (TypeError, ValueError):
                matched = 0
            matched = min(max(0, matched), len(models) - 1)
        try:
            self.getControl(control_id).selectItem(matched)
        except Exception:
            pass

    def _select_navigation(self, page):
        index = self._nav_index.get(page)
        if index is None:
            return
        try:
            self.getControl(NAV).selectItem(index)
            self._nav_position = index
        except Exception:
            pass

    def _remember_navigation_position(self):
        try:
            self._nav_position = int(
                self.getControl(NAV).getSelectedPosition()
            )
        except Exception:
            self._nav_position = None

    def _remember_tab_position(self):
        try:
            self._tab_position = int(
                self.getControl(TABS).getSelectedPosition()
            )
        except Exception:
            self._tab_position = None

    def _sync_navigation_selection(self):
        try:
            if int(self.getFocusId()) != NAV:
                return
            position = int(self.getControl(NAV).getSelectedPosition())
        except Exception:
            return

        if position == self._nav_position:
            return
        self._nav_position = position
        if not 0 <= position < len(self.navigation):
            return

        page = _model_property(self.navigation[position], "App.Page", "home")
        if page != self._page:
            self._show_page(page, load=True, focus=False)

    def _sync_tab_selection(self):
        if self._page not in ("movies", "tv"):
            return
        try:
            if int(self.getFocusId()) != TABS:
                return
            position = int(self.getControl(TABS).getSelectedPosition())
        except Exception:
            return

        if position == self._tab_position:
            return
        self._tab_position = position
        if not 0 <= position < len(self._tabs):
            return

        tab = _model_property(self._tabs[position], "App.Tab")
        if tab:
            self._load_catalog(
                self._page,
                tab,
                force=False,
                focus=False,
            )

    def _focus(self, control_id):
        try:
            self.setFocusId(control_id)
        except Exception as exc:
            _log("Could not focus control {0}: {1}".format(control_id, exc), xbmc.LOGERROR)

    def _focus_home_content(self):
        self._show_page("home", load=False)


def open_home(addon_path, **kwargs):
    """Open the unified Media Hub application and return its exit command."""
    dialog = None
    abort_monitor = None
    try:
        dialog = MediaHubHomeDialog(
            XML_FILENAME,
            addon_path,
            "Default",
            "1080i",
            **kwargs
        )

        class _HomeAbortMonitor(xbmc.Monitor):
            def __init__(self, window):
                super().__init__()
                self.window = window

            def onAbortRequested(self):
                window = self.window
                if window is not None:
                    window.close()

        abort_monitor = _HomeAbortMonitor(dialog)
        dialog.doModal()
        return dialog.result
    except Exception as exc:
        _log("Could not open the app window: {0}".format(exc), xbmc.LOGERROR)
        raise
    finally:
        if abort_monitor is not None:
            abort_monitor.window = None
        if dialog is not None:
            # Kodi can dismiss a modal window as part of global shutdown
            # without taking the normal WindowXML.close path.
            dialog._downloads_refresh_stop.set()
            del dialog
