"""Optional search entries for finales released as two separate episodes."""
import re
from statistics import median


def _positive_int(value):
    try:
        number = int(value)
    except (TypeError, ValueError, OverflowError):
        return 0
    return number if number > 0 else 0


def episode_number(episode):
    for key in ("episode_number", "episodeNumber", "episode"):
        number = _positive_int(episode.get(key))
        if number:
            return number
    title = str(episode.get("title") or episode.get("name") or "")
    match = re.search(r"\bS\d{1,3}\s*E(\d{1,3})\b", title, re.IGNORECASE)
    if not match:
        match = re.search(r"\b\d{1,3}x(\d{1,3})\b", title, re.IGNORECASE)
    return _positive_int(match.group(1)) if match else 0


def with_split_finale(episodes, season):
    """Append a speculative Part 2 without changing TMDB's combined entry.

    Require three known earlier runtimes and a finale at least 1.75 times
    their median. No stream search or extra metadata request occurs here.
    """
    if not isinstance(episodes, list) or not _positive_int(season):
        return episodes
    if any(isinstance(row, dict) and row.get("split_finale_part") for row in episodes):
        return episodes
    numbered = [(episode_number(row), row) for row in episodes if isinstance(row, dict)]
    if not numbered or any(not number for number, _row in numbered):
        return episodes
    last_number, finale = max(numbered, key=lambda entry: entry[0])
    runtime = _positive_int(finale.get("runtime"))
    finale_id = _positive_int(finale.get("id"))
    earlier_runtimes = [
        _positive_int(row.get("runtime"))
        for number, row in numbered if number < last_number
        and _positive_int(row.get("runtime"))
    ]
    if not runtime or not finale_id or len(earlier_runtimes) < 3:
        return episodes
    if runtime < median(earlier_runtimes) * 1.75:
        return episodes

    name = str(finale.get("title") or finale.get("name") or "")
    name = re.sub(r"^\s*(?:S\d{1,3}\s*E\d{1,3}|\d{1,3}x\d{1,3})\s*[-–—:·]?\s*",
                  "", name, flags=re.IGNORECASE)
    name = re.sub(r"\s*[-–—:]?\s*\(?\bPart\s*1\)?\s*$|\s*\(1\)\s*$",
                  "", name, flags=re.IGNORECASE).strip()
    extra = dict(finale)
    # Negative IDs are local identities, never TMDB episode IDs. This keeps
    # history/favourites distinct and subtitles use the series + S/E instead.
    extra.update({
        "id": -finale_id,
        "episode_number": last_number + 1,
        "title": "S{0:02d}E{1} - {2} - Part 2".format(int(season), last_number + 1, name),
        "name": "{0} - Part 2".format(name),
        "runtime": max(1, (runtime + 1) // 2),
        "split_finale_part": 2,
    })
    # Combined-episode streams must never be reused for the second part.
    # Omitting this key lets legacy callers fetch streams when selected.
    extra.pop("streams", None)
    extra.pop("hasStreams", None)
    for key in ("episodeNumber", "episode"):
        if key in extra:
            extra[key] = last_number + 1
    return episodes + [extra]
