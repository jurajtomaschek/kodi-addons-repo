import json
import os
import time
import uuid
import xbmcaddon
import xbmcvfs


class WatchHistoryDb:
    def __init__(self, filename="watch_history.json"):
        addon = xbmcaddon.Addon()
        self._dir = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
        if not xbmcvfs.exists(self._dir):
            xbmcvfs.mkdirs(self._dir)

        self._path = os.path.join(self._dir, filename)
        self._lock_path = os.path.join(self._dir, ".watch_history.lock")

    def list(self) -> dict:
        return self._with_lock(self._load_unlocked)

    def mutate(self, fn):
        def op():
            data = self._load_unlocked()
            result = fn(data)
            self._atomic_write_unlocked(data)
            return result
        return self._with_lock(op)

    def remove(self, history_id: str):
        def op():
            data = self._load_unlocked()
            removed = data.pop(history_id, None)
            self._atomic_write_unlocked(data)
            return removed
        return self._with_lock(op)

    def clear_all(self):
        def op():
            self._atomic_write_unlocked({})
            return None
        return self._with_lock(op)

    def _with_lock(self, fn, timeout_sec=10.0, poll_sec=0.05):
        start = time.time()
        token = "{0}:{1}".format(os.getpid(), uuid.uuid4().hex)
        while True:
            try:
                descriptor = os.open(
                    self._lock_path,
                    os.O_CREAT | os.O_EXCL | os.O_WRONLY,
                )
                try:
                    os.write(descriptor, token.encode("ascii"))
                    os.fsync(descriptor)
                finally:
                    os.close(descriptor)
                break
            except FileExistsError:
                self._remove_stale_lock(max(timeout_sec * 3.0, 30.0))
            except OSError:
                # Addon profile paths are normally local after translatePath.
                # If the platform cannot create an exclusive lock file, wait
                # and retry rather than pretending a shared lock was acquired.
                pass
            if time.time() - start >= timeout_sec:
                raise TimeoutError("Could not acquire watch history lock in time")
            time.sleep(poll_sec)

        try:
            return fn()
        finally:
            self._release_lock(token)

    def _remove_stale_lock(self, stale_after_sec):
        try:
            age = time.time() - os.path.getmtime(self._lock_path)
            if age > stale_after_sec:
                os.remove(self._lock_path)
        except (FileNotFoundError, OSError):
            pass

    def _release_lock(self, token):
        try:
            with open(self._lock_path, "r", encoding="ascii") as lock_file:
                owner = lock_file.read()
            if owner == token:
                os.remove(self._lock_path)
        except (FileNotFoundError, OSError, UnicodeError):
            pass

    def _load_unlocked(self) -> dict:
        if not xbmcvfs.exists(self._path):
            return {}
        try:
            f = xbmcvfs.File(self._path, "r")
            raw = f.read()
            f.close()
            return json.loads(raw) if raw else {}
        except Exception:
            return {}

    def _atomic_write_unlocked(self, data: dict):
        payload = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
        if "://" not in self._path:
            tmp = "{0}.tmp.{1}.{2}".format(
                self._path,
                os.getpid(),
                uuid.uuid4().hex,
            )
            try:
                with open(tmp, "w", encoding="utf-8", newline="") as file_handle:
                    file_handle.write(payload)
                    file_handle.flush()
                    os.fsync(file_handle.fileno())
                os.replace(tmp, self._path)
                return
            finally:
                try:
                    if os.path.exists(tmp):
                        os.remove(tmp)
                except OSError:
                    pass

        tmp = self._path + ".tmp"
        f = xbmcvfs.File(tmp, "w")
        f.write(payload)
        f.close()

        if xbmcvfs.exists(self._path):
            xbmcvfs.delete(self._path)
        xbmcvfs.rename(tmp, self._path)
