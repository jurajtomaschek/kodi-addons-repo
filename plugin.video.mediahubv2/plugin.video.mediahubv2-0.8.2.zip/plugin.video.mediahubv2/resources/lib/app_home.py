"""Controller for the fullscreen Media Hub application shell."""

import threading
import xbmc
import xbmcgui


XML_FILENAME = "MediaHubHome.xml"
ADDON_ID = "plugin.video.mediahubv2"

NAV = 100
SEARCH = 200
TABS = 210
HOME_PRIMARY = 300
HOME_SECONDARY = 310
CATALOG = 400
HISTORY = 420
BROWSER = 430
DOWNLOADS = 500
SETTINGS = 510
DETAIL_ACTIONS = 600
DETAIL_MORE = 610
CONTEXT_MENU = 700

# Compatibility names used by older tests and callers.
QUICK = HOME_PRIMARY
FAVORITES = HOME_SECONDARY

_BACK_ACTIONS = frozenset((9, 10, 92, 110))
_CONTROL_NAMES = {
    NAV: "navigation",
    TABS: "tabs",
    HOME_PRIMARY: "home primary",
    HOME_SECONDARY: "home secondary",
    CATALOG: "catalog",
    HISTORY: "history",
    BROWSER: "browser",
    DOWNLOADS: "downloads",
    SETTINGS: "settings",
    DETAIL_ACTIONS: "detail actions",
    DETAIL_MORE: "more like this",
    CONTEXT_MENU: "context menu",
}

_PAGE_TITLES = {
    "home": ("Home", "Everything worth watching, all in one place"),
    "movies": ("Movies", "Popular titles, new releases and top rated films"),
    "tv": ("TV Series", "Trending series and recently aired episodes"),
    "downloads": ("Downloads", "Your offline library and active transfers"),
    "favorites": ("Favourites", "Movies and series saved for later"),
    "history": ("Recently Viewed", "Continue where you left off"),
    "settings": ("Settings", "Playback, downloads and account preferences"),
    "search": ("Search", "Find movies and TV series"),
    "browse": ("Browse", "Explore Media Hub"),
}


def _log(message, level=None):
    if level is None:
        level = xbmc.LOGDEBUG
    try:
        xbmc.log("[Media Hub app] {0}".format(message), level)
    except Exception:
        pass


def _models(value):
    if value is None:
        return []
    try:
        values = list(value)
    except TypeError:
        return []
    return [model for model in values if isinstance(model, dict)]


def _text(value):
    if value is None:
        return ""
    if isinstance(value, bool):
        return "true" if value else "false"
    return str(value)


def _model_property(model, key, default=""):
    properties = model.get("properties")
    if not isinstance(properties, dict):
        return _text(default)
    return _text(properties.get(key, default))


class MediaHubHomeDialog(xbmcgui.WindowXML):
    """Single-window, remote-first interface for every primary addon page."""

    def __init__(self, *args, **kwargs):
        self.navigation = _models(kwargs.pop("navigation", None))
        self.home_primary = _models(
            kwargs.pop("home_primary", kwargs.pop("quick_items", None))
        )
        secondary_items = kwargs.pop("home_secondary", None)
        favorite_items = kwargs.pop("favorite_items", None)
        self.home_secondary = _models(
            secondary_items if secondary_items is not None else favorite_items
        )
        self.favorite_items = _models(
            favorite_items if favorite_items is not None else self.home_secondary
        )
        self.history_items = _models(kwargs.pop("history_items", None))
        self.download_items = _models(kwargs.pop("download_items", None))
        self.settings_items = _models(kwargs.pop("settings_items", None))
        self.fallback_art = _text(kwargs.pop("fallback_art", ""))
        self.logo_art = _text(kwargs.pop("logo_art", ""))
        self.initial_page = _text(kwargs.pop("initial_page", "home")) or "home"
        self.catalog_loader = kwargs.pop("catalog_loader", None)
        self.search_loader = kwargs.pop("search_loader", None)
        self.home_loader = kwargs.pop("home_loader", None)
        self.browser_loader = kwargs.pop("browser_loader", None)
        self.action_handler = kwargs.pop("action_handler", None)
        self.play_handler = kwargs.pop("play_handler", None)
        self.state_loader = kwargs.pop("state_loader", None)
        self.initial_target = _text(kwargs.pop("initial_target", ""))
        self.result = None

        self._page = ""
        self._previous_page = "home"
        self._catalog_cache = {}
        self._tabs = []
        self._catalog_items = []
        self._detail_more = []
        self._browser_items = []
        self._browser_targets = []
        self._browser_origin = "home"
        self._browser_view = {}
        self._browser_return_state = None
        self._context_items = []
        self._context_open = False
        self._context_origin_control = None
        self._nav_index = {}
        self._nav_position = None
        self._tab_position = None
        self._initialized = False
        self._reactivation_state = None

        self._items_by_control = {
            NAV: self.navigation,
            TABS: self._tabs,
            HOME_PRIMARY: self.home_primary,
            HOME_SECONDARY: self.home_secondary,
            CATALOG: self._catalog_items,
            HISTORY: self.history_items,
            BROWSER: self._browser_items,
            DOWNLOADS: self.download_items,
            SETTINGS: self.settings_items,
            DETAIL_ACTIONS: [],
            DETAIL_MORE: self._detail_more,
            CONTEXT_MENU: self._context_items,
        }

    def onInit(self):
        try:
            self.setProperty("App.FallbackArt", self.fallback_art)
            self.setProperty("App.Logo", self.logo_art)
            self.setProperty(
                "App.HomePrimaryTitle",
                "Continue Watching" if self.history_items else "Featured",
            )
            self.setProperty(
                "App.HomeSecondaryTitle",
                "My List" if self.home_secondary else "Discover",
            )
            self.setProperty(
                "App.HasHomeSecondary",
                "true" if self.home_secondary else "false",
            )
            self.setProperty("App.ContextOpen", "false")
            self.setProperty("App.Loading", "false")
        except Exception as exc:
            _log("Could not initialize window properties: {0}".format(exc), xbmc.LOGERROR)

        self._nav_index = {
            _model_property(model, "App.Page"): index
            for index, model in enumerate(self.navigation)
            if _model_property(model, "App.Page")
        }
        for control_id in (
            NAV,
            HOME_PRIMARY,
            HOME_SECONDARY,
            HISTORY,
            DOWNLOADS,
            SETTINGS,
        ):
            self._populate_control(control_id, self._items_by_control[control_id])

        if self._initialized:
            self._restore_reactivated_window()
            return
        self._initialized = True
        self._show_page(self.initial_page, load=True)
        if self.initial_target:
            self._open_browser(self.initial_target)
        if callable(self.home_loader):
            threading.Thread(
                target=self._load_home_background,
                name="MediaHubHomeLoader",
                daemon=True,
            ).start()

    def onClick(self, control_id):
        try:
            if control_id == CONTEXT_MENU:
                model = self._selected_model(CONTEXT_MENU)
                if model is not None:
                    self._close_context_menu(restore_focus=True)
                    self._activate(model)
                return

            if control_id == SEARCH:
                self._show_search()
                return

            model = self._selected_model(control_id)
            if model is None:
                return

            if control_id == NAV:
                page = _model_property(model, "App.Page", "home")
                self._show_page(page, load=True)
            elif control_id == TABS:
                tab = _model_property(model, "App.Tab")
                self._load_catalog(self._page, tab, force=False)
            elif control_id == DETAIL_ACTIONS:
                self._activate_detail_action(model)
            else:
                self._activate(model)
        except Exception as exc:
            _log(
                "Click handling failed for control {0}: {1}".format(control_id, exc),
                xbmc.LOGERROR,
            )

    def onFocus(self, control_id):
        if control_id == TABS:
            self._remember_tab_position()
            return
        if control_id != NAV:
            return
        page = self._previous_page if self._page == "detail" else self._page
        self._select_navigation(page)
        self._remember_navigation_position()

    def onAction(self, action):
        try:
            action_id = action.getId()
        except (AttributeError, TypeError):
            try:
                action_id = int(action)
            except (TypeError, ValueError):
                return

        if self._context_open:
            if action_id in _BACK_ACTIONS or action_id in (101, 117):
                self._close_context_menu()
            return
        if action_id in (101, 117):
            self._open_context_menu()
            return
        if action_id not in _BACK_ACTIONS:
            self._sync_navigation_selection()
            self._sync_tab_selection()
            return
        if self._page == "browse":
            self._close_browser_level()
            return
        if self._page == "detail":
            self._show_page(self._previous_page, load=False)
            return

        self.result = {"command": "back"}
        try:
            self.close()
        except Exception as exc:
            _log("Could not close the app window: {0}".format(exc), xbmc.LOGERROR)

    def _show_page(self, page, load=True, focus=True):
        if page not in _PAGE_TITLES and page != "detail":
            page = "home"
        if page != "detail":
            self._previous_page = page
        self._page = page
        self.setProperty("App.Page", page)

        title, subtitle = _PAGE_TITLES.get(page, ("", ""))
        self.setProperty("App.PageTitle", title)
        self.setProperty("App.PageSubtitle", subtitle)
        self._select_navigation(page)

        if page in ("movies", "tv"):
            self._set_tabs(page)
            selected_tab = _model_property(self._tabs[0], "App.Tab") if self._tabs else ""
            if load:
                self._load_catalog(page, selected_tab, force=False, focus=focus)
            if focus:
                self._focus(CATALOG if self._catalog_items else TABS)
        elif page == "favorites":
            self._set_catalog(self.favorite_items)
            if focus:
                self._focus(CATALOG if self._catalog_items else NAV)
        elif page == "history":
            if focus:
                self._focus(HISTORY if self.history_items else NAV)
        elif page == "downloads":
            if focus:
                self._focus(DOWNLOADS if self.download_items else NAV)
        elif page == "settings":
            if focus:
                self._focus(SETTINGS if self.settings_items else NAV)
        elif page == "search":
            if focus:
                self._focus(CATALOG if self._catalog_items else SEARCH)
        elif page == "browse":
            self._restore_browser_state()
            if focus:
                self._focus(BROWSER if self._browser_items else NAV)
        elif page == "home" and focus:
            self._focus(
                HOME_PRIMARY
                if self.home_primary
                else HOME_SECONDARY
                if self.home_secondary
                else NAV
            )

    def _set_tabs(self, page):
        labels = (
            (("Popular", "popular"), ("New Releases", "latest"), ("Top Rated", "top"))
            if page == "movies"
            else (
                ("Popular", "popular"),
                ("New Releases", "latest"),
                ("Recently Aired", "recent"),
                ("Slovak", "slovak"),
            )
        )
        self._tabs[:] = [
            {
                "label": label,
                "command": "tab",
                "properties": {"App.Tab": value},
            }
            for label, value in labels
        ]
        self._populate_control(TABS, self._tabs)

    def _load_catalog(self, page, tab, force=False, query="", focus=True):
        cache_key = (page, tab, query)
        if not force and cache_key in self._catalog_cache:
            self._set_catalog(self._catalog_cache[cache_key])
            if focus:
                self._focus(CATALOG if self._catalog_items else TABS)
            return

        loader = self.search_loader if page == "search" else self.catalog_loader
        if not callable(loader):
            self._set_catalog([])
            return

        self.setProperty("App.Loading", "true")
        try:
            if page == "search":
                models = loader(query)
            else:
                models = loader(page, tab)
            models = _models(models)
            self._catalog_cache[cache_key] = models
            self._set_catalog(models)
        except Exception as exc:
            _log("Could not load {0}/{1}: {2}".format(page, tab, exc), xbmc.LOGERROR)
            self._set_catalog([])
            try:
                xbmcgui.Dialog().notification(
                    "Media Hub",
                    "Content could not be loaded.",
                    xbmcgui.NOTIFICATION_ERROR,
                    2500,
                )
            except Exception:
                pass
        finally:
            self.setProperty("App.Loading", "false")

        if focus:
            self._focus(CATALOG if self._catalog_items else TABS)

    def _show_search(self):
        try:
            keyboard = xbmc.Keyboard("", "Search movies and TV series")
            keyboard.doModal()
            if not keyboard.isConfirmed():
                return
            query = _text(keyboard.getText()).strip()
        except Exception as exc:
            _log("Could not open search keyboard: {0}".format(exc), xbmc.LOGERROR)
            return
        if not query:
            return

        self._page = "search"
        self.setProperty("App.Page", "search")
        self.setProperty("App.PageTitle", "Search")
        self.setProperty("App.PageSubtitle", "Results for “{0}”".format(query))
        self._select_navigation("")
        self._load_catalog("search", "results", force=True, query=query)

    def _load_home_background(self):
        try:
            loaded = self.home_loader()
            if not isinstance(loaded, (list, tuple)) or len(loaded) != 2:
                return
            primary, secondary = (_models(loaded[0]), _models(loaded[1]))
            if primary:
                self.home_primary[:] = primary
                self._populate_control(HOME_PRIMARY, self.home_primary)
                self.setProperty("App.HomePrimaryTitle", "Trending Now")
            if secondary:
                self.home_secondary[:] = secondary
                self._populate_control(HOME_SECONDARY, self.home_secondary)
                self.setProperty("App.HomeSecondaryTitle", "Popular TV Series")
                self.setProperty("App.HasHomeSecondary", "true")
        except Exception as exc:
            _log("Could not refresh home artwork: {0}".format(exc), xbmc.LOGWARNING)

    def _set_catalog(self, models):
        self._catalog_items[:] = _models(models)
        self._populate_control(CATALOG, self._catalog_items)
        self.setProperty("App.HasCatalog", "true" if self._catalog_items else "false")

    def _show_detail(self, model):
        if self._page == "browse":
            self._browser_return_state = {
                "targets": list(self._browser_targets),
                "view": dict(self._browser_view),
                "items": list(self._browser_items),
            }
        elif self._page != "detail":
            self._browser_return_state = None
        self._previous_page = self._page if self._page != "detail" else self._previous_page
        self._page = "detail"
        self.setProperty("App.Page", "detail")

        properties = model.get("properties") if isinstance(model.get("properties"), dict) else {}
        detail_values = {
            "App.Detail.Title": properties.get("MediaHub.Title") or model.get("label"),
            "App.Detail.Eyebrow": properties.get("MediaHub.Eyebrow") or "MEDIA HUB",
            "App.Detail.Meta": properties.get("MediaHub.Meta") or model.get("label2"),
            "App.Detail.Description": properties.get("MediaHub.Description"),
            "App.Detail.HeroDescription": (
                properties.get("MediaHub.HeroDescription")
                or properties.get("MediaHub.Description")
            ),
            "App.Detail.Year": properties.get("App.Year") or "—",
            "App.Detail.Rating": properties.get("App.Rating") or "—",
            "App.Detail.Kind": properties.get("App.KindLabel") or "Media",
            "App.Detail.Fanart": (model.get("art") or {}).get("fanart", ""),
            "App.Detail.Poster": (model.get("art") or {}).get("poster", ""),
        }
        for key, value in detail_values.items():
            self.setProperty(key, _text(value))

        target = _text(model.get("target"))
        primary_label = "SEASONS" if properties.get("App.Kind") == "tv" else "PLAY"
        actions = [
            {
                "label": primary_label,
                "command": "browse" if callable(self.browser_loader) else "navigate",
                "target": target,
                "properties": {"App.ActionGlyph": "▶"},
            },
            {
                "label": "BACK",
                "command": "back_detail",
                "target": "",
                "properties": {"App.ActionGlyph": "←"},
            },
        ]
        self._items_by_control[DETAIL_ACTIONS] = actions
        self._populate_control(DETAIL_ACTIONS, actions)

        self._detail_more[:] = [
            candidate
            for candidate in self._catalog_items
            if candidate is not model
        ][:6]
        self._populate_control(DETAIL_MORE, self._detail_more)
        self.setProperty("App.HasMore", "true" if self._detail_more else "false")
        self._focus(DETAIL_ACTIONS)

    def _activate_detail_action(self, model):
        command = _text(model.get("command")).strip().lower()
        if command == "back_detail":
            self._show_page(self._previous_page, load=False)
        else:
            self._activate(model)

    def _activate(self, model):
        command = _text(model.get("command")).strip().lower()
        target = _text(model.get("target")).strip()

        if command == "page":
            self._show_page(_model_property(model, "App.Page", "home"), load=True)
        elif command == "detail":
            self._show_detail(model)
        elif command == "browse":
            self._open_browser(target)
        elif command == "navigate":
            if target:
                self.result = {"command": "navigate", "target": target}
                self.close()
        elif command == "play":
            if target:
                handled = False
                if callable(self.play_handler):
                    reactivation_state = self._capture_reactivation_state()
                    self.setProperty("App.Loading", "true")
                    try:
                        outcome = self.play_handler(target)
                        handled = outcome is not False
                        if outcome is True:
                            self._reactivation_state = reactivation_state
                            self._refresh_state()
                    except Exception as exc:
                        _log(
                            "Direct playback failed for {0}: {1}".format(
                                target, exc
                            ),
                            xbmc.LOGERROR,
                        )
                    finally:
                        self.setProperty("App.Loading", "false")
                if not handled:
                    xbmc.executebuiltin("PlayMedia({0})".format(target))
        elif command == "builtin":
            if target:
                xbmc.executebuiltin(target)
        elif command == "action":
            self._run_action(target)
        elif command == "run":
            if target:
                xbmc.executebuiltin("RunPlugin({0})".format(target))
        elif command == "settings":
            xbmc.executebuiltin("Addon.OpenSettings({0})".format(ADDON_ID))
        elif command == "back_detail":
            self._show_page(self._previous_page, load=False)
        else:
            _log("Ignored unsupported app command: {0}".format(command), xbmc.LOGWARNING)

    def _open_browser(self, target, replace=False):
        target = _text(target).strip()
        if not target or not callable(self.browser_loader):
            return

        self.setProperty("App.Loading", "true")
        try:
            view = self.browser_loader(target)
        except Exception as exc:
            _log("Could not load browser target {0}: {1}".format(target, exc), xbmc.LOGERROR)
            try:
                xbmcgui.Dialog().notification(
                    "Media Hub",
                    "This screen could not be loaded.",
                    xbmcgui.NOTIFICATION_ERROR,
                    2500,
                )
            except Exception:
                pass
            return
        finally:
            self.setProperty("App.Loading", "false")

        if not isinstance(view, dict):
            return
        if self._page != "browse":
            self._browser_origin = self._page
            self._browser_targets = []
        if replace and self._browser_targets:
            self._browser_targets[-1] = target
        elif not self._browser_targets or self._browser_targets[-1] != target:
            self._browser_targets.append(target)

        self._page = "browse"
        self.setProperty("App.Page", "browse")
        self.setProperty("App.BrowserTitle", _text(view.get("title", "Browse")))
        self.setProperty("App.BrowserSubtitle", _text(view.get("subtitle", "")))
        self.setProperty("App.BrowserEyebrow", _text(view.get("eyebrow", "MEDIA HUB")))
        self.setProperty("App.BrowserEmpty", _text(view.get("empty", "Nothing to show yet.")))
        self.setProperty("App.BrowserArt", _text(view.get("fanart", self.fallback_art)))
        self.setProperty(
            "App.BrowserDepth",
            "{0:02d}".format(max(1, len(self._browser_targets))),
        )
        self._browser_view = dict(view)
        self._browser_items[:] = _models(view.get("items"))
        self._populate_control(BROWSER, self._browser_items)
        self.setProperty("App.HasBrowser", "true" if self._browser_items else "false")
        self._focus(BROWSER if self._browser_items else NAV)

    def _restore_browser_state(self):
        state = self._browser_return_state
        if not isinstance(state, dict):
            return
        view = state.get("view")
        if not isinstance(view, dict):
            return
        self._browser_targets = list(state.get("targets") or [])
        self._browser_view = dict(view)
        self._browser_items[:] = _models(state.get("items"))
        self.setProperty("App.BrowserTitle", _text(view.get("title", "Browse")))
        self.setProperty("App.BrowserSubtitle", _text(view.get("subtitle", "")))
        self.setProperty("App.BrowserEyebrow", _text(view.get("eyebrow", "MEDIA HUB")))
        self.setProperty("App.BrowserEmpty", _text(view.get("empty", "Nothing to show yet.")))
        self.setProperty("App.BrowserArt", _text(view.get("fanart", self.fallback_art)))
        self.setProperty(
            "App.BrowserDepth",
            "{0:02d}".format(max(1, len(self._browser_targets))),
        )
        self._populate_control(BROWSER, self._browser_items)
        self.setProperty("App.HasBrowser", "true" if self._browser_items else "false")
        self._browser_return_state = None

    def _reload_browser(self, target=None):
        if target:
            self._open_browser(target, replace=True)
        elif self._browser_targets:
            self._open_browser(self._browser_targets[-1], replace=True)

    def _close_browser_level(self):
        if len(self._browser_targets) > 1:
            self._browser_targets.pop()
            target = self._browser_targets.pop()
            self._open_browser(target)
            return
        self._browser_targets = []
        origin = self._browser_origin
        if origin == "browse":
            origin = "home"
        self._show_page(origin, load=False)

    def _run_action(self, target):
        if not target or not callable(self.action_handler):
            return
        try:
            next_target = self.action_handler(target)
        except Exception as exc:
            _log("Action failed for {0}: {1}".format(target, exc), xbmc.LOGERROR)
            return
        self._refresh_state()
        self._reload_browser(_text(next_target).strip() if next_target else None)

    def _refresh_state(self):
        if not callable(self.state_loader):
            return
        try:
            state = self.state_loader()
        except Exception as exc:
            _log("Could not refresh app state: {0}".format(exc), xbmc.LOGWARNING)
            return
        if not isinstance(state, dict):
            return

        favourites = state.get("favorites")
        if favourites is not None:
            self.favorite_items[:] = _models(favourites)
            if self._page == "favorites":
                self._set_catalog(self.favorite_items)
        history = state.get("history")
        if history is not None:
            self.history_items[:] = _models(history)
            self._populate_control(HISTORY, self.history_items)
        downloads = state.get("downloads")
        if downloads is not None:
            self.download_items[:] = _models(downloads)
            self._populate_control(DOWNLOADS, self.download_items)

    def _open_context_menu(self):
        try:
            control_id = int(self.getFocusId())
        except Exception:
            return
        model = self._selected_model(control_id)
        if model is None:
            return
        actions = _models(model.get("context_actions"))
        if not actions:
            target = _model_property(model, "App.ContextTarget")
            if target:
                actions = [{
                    "label": "Download",
                    "label2": "Add this stream to the download queue",
                    "command": "action",
                    "target": target,
                    "properties": {"App.Badge": "QUEUE"},
                }]
        if not actions:
            return

        self._context_items[:] = actions
        self._populate_control(CONTEXT_MENU, self._context_items)
        self._context_origin_control = control_id
        self._context_open = True
        self.setProperty("App.ContextTitle", _text(model.get("label", "Actions")))
        self.setProperty("App.ContextSubtitle", _text(model.get("label2", "")))
        self.setProperty("App.ContextOpen", "true")
        self._focus(CONTEXT_MENU)

    def _close_context_menu(self, restore_focus=True):
        if not self._context_open:
            return
        origin = self._context_origin_control
        self._context_open = False
        self._context_origin_control = None
        self.setProperty("App.ContextOpen", "false")
        if restore_focus and origin is not None:
            self._focus(origin)

    def _populate_control(self, control_id, models):
        try:
            control = self.getControl(control_id)
            reset = getattr(control, "reset", None)
            if callable(reset):
                reset()
            items = [self._list_item(model) for model in models]
            add_items = getattr(control, "addItems", None)
            if callable(add_items):
                add_items(items)
            else:
                add_item = getattr(control, "addItem")
                for item in items:
                    add_item(item)
        except Exception as exc:
            _log(
                "Could not populate {0} ({1}): {2}".format(
                    _CONTROL_NAMES.get(control_id, control_id),
                    control_id,
                    exc,
                ),
                xbmc.LOGERROR,
            )

    @staticmethod
    def _list_item(model):
        item = xbmcgui.ListItem(
            label=_text(model.get("label")),
            label2=_text(model.get("label2")),
        )
        art = model.get("art")
        if isinstance(art, dict):
            item.setArt({_text(key): _text(value) for key, value in art.items()})
        properties = model.get("properties")
        if isinstance(properties, dict):
            for key, value in properties.items():
                item.setProperty(_text(key), _text(value))
        return item

    def _selected_model(self, control_id):
        models = self._items_by_control.get(control_id)
        if models is None:
            return None
        try:
            position = int(self.getControl(control_id).getSelectedPosition())
        except Exception:
            return None
        return models[position] if 0 <= position < len(models) else None

    def _capture_reactivation_state(self):
        selections = {}
        for control_id, models in self._items_by_control.items():
            if control_id == CONTEXT_MENU:
                continue
            try:
                position = int(self.getControl(control_id).getSelectedPosition())
            except Exception:
                continue
            selected = models[position] if 0 <= position < len(models) else None
            selections[control_id] = {
                "position": position,
                "target": _text(selected.get("target")) if selected else "",
                "command": _text(selected.get("command")) if selected else "",
                "label": _text(selected.get("label")) if selected else "",
            }
        try:
            focus_id = int(self.getFocusId())
        except Exception:
            focus_id = BROWSER if self._page == "browse" else NAV
        return {
            "page": self._page,
            "previous_page": self._previous_page,
            "focus_id": focus_id,
            "selections": selections,
        }

    def _restore_reactivated_window(self):
        state = self._reactivation_state
        if not isinstance(state, dict):
            state = {
                "page": self._page or self.initial_page,
                "previous_page": self._previous_page,
                "selections": {},
            }

        page = _text(state.get("page", self._page or self.initial_page)) or "home"
        self._page = page
        self._previous_page = (
            _text(state.get("previous_page", self._previous_page))
            or self._previous_page
        )
        self.setProperty("App.Page", page)
        title, subtitle = _PAGE_TITLES.get(page, ("", ""))
        self.setProperty("App.PageTitle", title)
        self.setProperty("App.PageSubtitle", subtitle)
        self._select_navigation(
            self._previous_page if page == "detail" else page
        )

        if page in ("movies", "tv"):
            self._populate_control(TABS, self._tabs)
            self._set_catalog(self._catalog_items)
        elif page in ("favorites", "search"):
            self._set_catalog(self._catalog_items)
        elif page == "browse":
            view = self._browser_view
            self.setProperty("App.BrowserTitle", _text(view.get("title", "Browse")))
            self.setProperty("App.BrowserSubtitle", _text(view.get("subtitle", "")))
            self.setProperty(
                "App.BrowserEyebrow",
                _text(view.get("eyebrow", "MEDIA HUB")),
            )
            self.setProperty(
                "App.BrowserEmpty",
                _text(view.get("empty", "Nothing to show yet.")),
            )
            self.setProperty(
                "App.BrowserArt",
                _text(view.get("fanart", self.fallback_art)),
            )
            self.setProperty(
                "App.BrowserDepth",
                "{0:02d}".format(max(1, len(self._browser_targets))),
            )
            self._populate_control(BROWSER, self._browser_items)
            self.setProperty(
                "App.HasBrowser",
                "true" if self._browser_items else "false",
            )
        elif page == "detail":
            self._populate_control(
                DETAIL_ACTIONS,
                self._items_by_control[DETAIL_ACTIONS],
            )
            self._populate_control(DETAIL_MORE, self._detail_more)
            self.setProperty("App.HasMore", "true" if self._detail_more else "false")

        selections = state.get("selections")
        if isinstance(selections, dict):
            for control_id, selection in selections.items():
                self._restore_control_selection(control_id, selection)

        try:
            focus_id = int(state.get("focus_id"))
        except (TypeError, ValueError):
            focus_id = BROWSER if page == "browse" else NAV
        self._focus(focus_id)
        self._reactivation_state = None

    def _restore_control_selection(self, control_id, selection):
        if not isinstance(selection, dict):
            return
        try:
            control_id = int(control_id)
        except (TypeError, ValueError):
            return
        models = self._items_by_control.get(control_id)
        if not models:
            return

        target = _text(selection.get("target"))
        command = _text(selection.get("command"))
        label = _text(selection.get("label"))
        matched = None
        for index, model in enumerate(models):
            if target and _text(model.get("target")) == target:
                matched = index
                break
            if (
                not target
                and command
                and _text(model.get("command")) == command
                and _text(model.get("label")) == label
            ):
                matched = index
                break
        if matched is None:
            try:
                matched = int(selection.get("position", 0))
            except (TypeError, ValueError):
                matched = 0
            matched = min(max(0, matched), len(models) - 1)
        try:
            self.getControl(control_id).selectItem(matched)
        except Exception:
            pass

    def _select_navigation(self, page):
        index = self._nav_index.get(page)
        if index is None:
            return
        try:
            self.getControl(NAV).selectItem(index)
            self._nav_position = index
        except Exception:
            pass

    def _remember_navigation_position(self):
        try:
            self._nav_position = int(
                self.getControl(NAV).getSelectedPosition()
            )
        except Exception:
            self._nav_position = None

    def _remember_tab_position(self):
        try:
            self._tab_position = int(
                self.getControl(TABS).getSelectedPosition()
            )
        except Exception:
            self._tab_position = None

    def _sync_navigation_selection(self):
        try:
            if int(self.getFocusId()) != NAV:
                return
            position = int(self.getControl(NAV).getSelectedPosition())
        except Exception:
            return

        if position == self._nav_position:
            return
        self._nav_position = position
        if not 0 <= position < len(self.navigation):
            return

        page = _model_property(self.navigation[position], "App.Page", "home")
        if page != self._page:
            self._show_page(page, load=True, focus=False)

    def _sync_tab_selection(self):
        if self._page != "movies":
            return
        try:
            if int(self.getFocusId()) != TABS:
                return
            position = int(self.getControl(TABS).getSelectedPosition())
        except Exception:
            return

        if position == self._tab_position:
            return
        self._tab_position = position
        if not 0 <= position < len(self._tabs):
            return

        tab = _model_property(self._tabs[position], "App.Tab")
        if tab:
            self._load_catalog(
                self._page,
                tab,
                force=False,
                focus=False,
            )

    def _focus(self, control_id):
        try:
            self.setFocusId(control_id)
        except Exception as exc:
            _log("Could not focus control {0}: {1}".format(control_id, exc), xbmc.LOGERROR)

    def _focus_home_content(self):
        self._show_page("home", load=False)


def open_home(addon_path, **kwargs):
    """Open the unified Media Hub application and return its exit command."""
    dialog = None
    try:
        dialog = MediaHubHomeDialog(
            XML_FILENAME,
            addon_path,
            "Default",
            "1080i",
            **kwargs
        )
        dialog.doModal()
        return dialog.result
    except Exception as exc:
        _log("Could not open the app window: {0}".format(exc), xbmc.LOGERROR)
        raise
    finally:
        if dialog is not None:
            del dialog
