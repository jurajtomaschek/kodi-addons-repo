import json
import xbmc
import xbmcaddon
import urllib.parse

from urllib.request import urlopen, Request
from urllib.error import HTTPError

#BASE_API_URL = "https://localhost:7009"  # Make sure it's https if your server uses it

BASE_API_URL = "https://media-vault-app-service-b8cmhsbsaefadbex.northeurope-01.azurewebsites.net"
LEGACY_ADDON_ID = "plugin.video.mediahub"

class ApiError(Exception):
    def __init__(self, status_code, reason, body="", headers=None):
        self.status_code = status_code
        self.reason = reason
        self.body = body or ""
        self.headers = headers or {}
        self.message = self._extract_message()
        super().__init__(self.message)

    def _extract_message(self):
        if not self.body:
            return f"Server returned {self.status_code}."

        try:
            payload = json.loads(self.body)
            if isinstance(payload, dict):
                return payload.get("detail") or payload.get("title") or self.body
        except Exception:
            pass

        return self.body


def _get_api_key():
    addon = xbmcaddon.Addon()
    api_key = addon.getSetting("api_key").strip()
    if api_key:
        return api_key

    try:
        addon_id = addon.getAddonInfo("id")
    except Exception:
        addon_id = ""

    # The original add-on already owns this settings namespace, so there is
    # nothing to migrate when this source is installed under its legacy ID.
    if addon_id == LEGACY_ADDON_ID:
        return ""

    try:
        legacy_api_key = (
            xbmcaddon.Addon(LEGACY_ADDON_ID)
            .getSetting("api_key")
            .strip()
        )
    except Exception as ex:
        xbmc.log(
            f"[API] Could not read settings from {LEGACY_ADDON_ID}: {ex}",
            xbmc.LOGWARNING,
        )
        return ""

    if not legacy_api_key:
        return ""

    try:
        addon.setSetting("api_key", legacy_api_key)
    except Exception as ex:
        xbmc.log(
            f"[API] Could not persist the migrated API key: {ex}",
            xbmc.LOGWARNING,
        )

    return legacy_api_key


def _get_json(endpoint, timeout=60):
    full_url = f"{BASE_API_URL}{endpoint}"
    req = Request(full_url)
    req.add_header("Accept", "application/json")
    # Settings can change while Kodi is running. Read the credential for every
    # request instead of keeping the value captured when this module was loaded.
    req.add_header("x-api-key", _get_api_key())
    
    # ✅ LOG the full request URL
    xbmc.log(f"Calling: {full_url}", xbmc.LOGINFO)

    try:
        # Do not supply an unverified SSL context. urllib's default context
        # performs the platform's normal certificate and hostname validation.
        with urlopen(req, timeout=timeout) as response:
            return json.loads(response.read().decode())
    except HTTPError as e:
        body = e.read().decode("utf-8", "replace")
        xbmc.log(f"[HTTPError] {e.code} - {e.reason}", xbmc.LOGERROR)
        xbmc.log(body, xbmc.LOGERROR)
        raise ApiError(e.code, e.reason, body, dict(e.headers.items())) from e
    except Exception as ex:
        xbmc.log(f"[Exception] {str(ex)}", xbmc.LOGERROR)
        raise

def get_tv_latest(page=1):
    return _get_json(f"/media/tmdb/tvseries/latest?page={page}")

def get_tv_recently_aired(page=1, days=30):
    params = urllib.parse.urlencode({"page": page, "days": days})
    return _get_json(f"/media/tmdb/tvseries/recently-aired?{params}")

def get_tv_popular(page=1):
    return _get_json(f"/media/tmdb/tvseries/popular?page={page}")

def get_tv_sk(page=1):
    return _get_json(f"/media/tmdb/tvseries/sk?page={page}")

def get_tv_genres(language="sk-SK"):
    params = urllib.parse.urlencode({"language": language})
    return _get_json(f"/media/tmdb/tvseries/genres?{params}")

def discover_tv(page=1, genre_id=None, year=None, sort="popularity.desc", minimum_rating=None):
    params = {
        "page": page,
        "sort": sort
    }
    if genre_id is not None:
        params["genreId"] = genre_id
    if year is not None:
        params["year"] = year
    if minimum_rating is not None:
        params["minimumRating"] = minimum_rating
    return _get_json(f"/media/tmdb/tvseries/discover?{urllib.parse.urlencode(params)}")

def get_tv_details(tv_id):
    return _get_json(f"/media/tmdb/tvseries/{tv_id}")

def get_episodes(tv_id, season):
    return _get_json(f"/media/tmdb/tvseries/{tv_id}/season/{season}/episodes")

def get_movies_search(query, page=1):
    params = urllib.parse.urlencode({"query": query, "page": page})
    return _get_json(f"/media/tmdb/movies/search?{params}")

def get_tv_search(query, page=1):
    params = urllib.parse.urlencode({"query": query, "page": page})
    return _get_json(f"/media/tmdb/tvseries/search?{params}")

def get_movies_latest(page=1):
    return _get_json(f"/media/tmdb/movies/latest?page={page}")

def get_movie_genres(language="sk-SK"):
    params = urllib.parse.urlencode({"language": language})
    return _get_json(f"/media/tmdb/movies/genres?{params}")

def discover_movies(page=1, genre_id=None, year=None, sort="popularity.desc", minimum_rating=None):
    params = {
        "page": page,
        "sort": sort
    }
    if genre_id is not None:
        params["genreId"] = genre_id
    if year is not None:
        params["year"] = year
    if minimum_rating is not None:
        params["minimumRating"] = minimum_rating
    return _get_json(f"/media/tmdb/movies/discover?{urllib.parse.urlencode(params)}")

def get_movies_popular(page=1, year=None):
    url = f"/media/tmdb/movies/popular?page={page}"
    if year is not None:
        url += f"&firstAirDateYear={year}"
    return _get_json(url)

def get_movies_toprated(page=1, year=None):
    url = f"/media/tmdb/movies/toprated?page={page}"
    if year is not None:
        url += f"&firstAirDateYear={year}"
    return _get_json(url)

def get_movie_versions(movie_id):
    return _get_json(f"/media/tmdb/movies/{movie_id}")

def get_streams(stream_id):
    return _get_json(f"/media/stream/{stream_id}")

def get_download_url(stream_id):
    """Compatibility helper for callers which only need the ephemeral URL."""
    return get_download_ticket(stream_id)["url"]


def get_download_ticket(stream_id):
    """Return and validate the server's authoritative download metadata."""
    payload = _get_json(f"/media/download/{stream_id}", timeout=15)
    if not isinstance(payload, dict):
        raise ValueError("Download service returned an invalid ticket.")

    url = payload.get("url")
    size_bytes = payload.get("sizeBytes")
    file_name = payload.get("fileName")
    if not isinstance(url, str) or not url.strip():
        raise ValueError("Download ticket does not contain a URL.")
    if isinstance(size_bytes, bool) or not isinstance(size_bytes, int):
        raise ValueError("Download ticket does not contain a valid size.")
    if size_bytes < 0:
        raise ValueError("Download ticket contains a negative size.")
    if not isinstance(file_name, str) or not file_name.strip():
        raise ValueError("Download ticket does not contain a file name.")

    # Keep the rest of the add-on independent of the backend's JSON casing.
    return {
        "url": url.strip(),
        "size_bytes": size_bytes,
        "file_name": file_name.strip(),
        "expires_at": payload.get("expiresAt"),
        "etag": payload.get("etag"),
        "hash": payload.get("hash")
    }


def get_download_metadata(stream_id):
    """Return authoritative size/hash without creating a signed provider URL."""
    payload = _get_json(f"/media/download/{stream_id}/metadata", timeout=15)
    if not isinstance(payload, dict):
        raise ValueError("Download service returned invalid metadata.")
    size_bytes = payload.get("sizeBytes")
    file_name = payload.get("fileName")
    if isinstance(size_bytes, bool) or not isinstance(size_bytes, int) or size_bytes < 0:
        raise ValueError("Download metadata does not contain a valid size.")
    if not isinstance(file_name, str) or not file_name.strip():
        raise ValueError("Download metadata does not contain a file name.")
    return {
        "size_bytes": size_bytes,
        "file_name": file_name.strip(),
        "etag": payload.get("etag"),
        "hash": payload.get("hash")
    }
