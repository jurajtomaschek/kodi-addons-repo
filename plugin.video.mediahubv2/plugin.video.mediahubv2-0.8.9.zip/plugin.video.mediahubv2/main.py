import sys
import urllib.parse
import xbmcplugin
import xbmcgui

from resources.lib import ui

BASE_URL = sys.argv[0]
HANDLE = int(sys.argv[1])
ARGS = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))

def router():
    ui._CLASSIC_CATALOG_ENABLED = True
    action = ARGS.get('action')
    
    routes = {
        "classic_home":                lambda: ui.show_main_menu(HANDLE),
        "menu_item_search":            lambda: ui.menu_item_search(HANDLE),
        "menu_item_movies":             lambda: ui.menu_item_movies(HANDLE),
        "menu_item_movies_search":      lambda: ui.menu_item_movies_search(HANDLE),
        'menu_item_movies_latest':      lambda: ui.menu_item_movies_latest(HANDLE),
        'menu_item_movies_popular':     lambda: ui.menu_item_movies_popular(HANDLE),
        'menu_item_movies_toprated':    lambda: ui.menu_item_movies_toprated(HANDLE),
        'show_discovery_filters':       lambda: ui.show_discovery_filters(HANDLE, ARGS.get('media_type', 'movie')),
        'configure_discovery_filter':   lambda: ui.configure_discovery_filter(ARGS.get('media_type', 'movie'), ARGS.get('filter'), ARGS),
        'list_discovery_results':       lambda: ui.list_discovery_results(HANDLE, ARGS.get('media_type', 'movie')),
        
        "menu_item_tvshows":            lambda: ui.menu_item_tvshows(HANDLE),
        "menu_item_tvshows_search":     lambda: ui.menu_item_tvshows_search(HANDLE),
        'list_tv_shows_latest':         lambda: ui.list_tv_shows_latest(HANDLE),
        'list_tv_shows_recently_aired': lambda: ui.list_tv_shows_recently_aired(HANDLE, progressive=True),
        'list_tv_shows_popular':        lambda: ui.list_tv_shows_popular(HANDLE),
        'list_tv_shows_sk':             lambda: ui.list_tv_shows_sk(HANDLE),
        'list_seasons':                 lambda: ui.list_seasons(HANDLE, int(ARGS['tv_id'])),
        'list_episodes':                lambda: ui.list_episodes(HANDLE, int(ARGS['tv_id']), int(ARGS['season']), ARGS.get('tv_title', ''), ARGS.get('poster', ''), ARGS.get('fanart', ''), progressive=True),
        'show_streams':                 lambda: ui.show_streams_popup(HANDLE, int(ARGS['tv_id']), int(ARGS['season']), int(ARGS['episode_id']), int(ARGS.get('episode_number', 0)), ARGS.get('tv_title', ''), ARGS.get('poster', ''), ARGS.get('fanart', ''), progressive=True),
        'show_next_episode':            lambda: ui.show_next_episode_classic(HANDLE, ARGS),
    
    
        'list_movie_versions':          lambda: ui.list_movie_versions(HANDLE, ARGS['movie_id'], ARGS.get('title', ''), ARGS.get('year', ''), ARGS.get('poster', ''), ARGS.get('fanart', ''), ARGS, progressive=True),
        'play_movie_stream':            lambda: ui.play_movie_stream(HANDLE, ARGS['stream_id'], ARGS),
        'download_movie_stream':        lambda: ui.download_movie_stream(ARGS['stream_id'], ARGS['filename'], ARGS),
        'prepare_stream_background':    lambda: ui.prepare_stream_background(ARGS['stream_id'], ARGS),
        'cancel_preparation':           lambda: ui.cancel_preparation(ARGS['id']),
        'retry_preparation':            lambda: ui.retry_preparation(ARGS['id']),
        'show_preparation_actions':     lambda: ui.show_preparation_actions(ARGS['id']),
        'show_watch_history':           lambda: ui.show_watch_history(HANDLE),
        'remove_watch_history_item':    lambda: ui.remove_watch_history_item(ARGS['id']),
        'clear_watch_history':          lambda: ui.clear_watch_history(),
        'show_favorites':               lambda: ui.show_favorites(HANDLE),
        'add_media_list_item':          lambda: ui.add_media_list_item(ARGS.get('collection'), ARGS),
        'remove_media_list_item':       lambda: ui.remove_media_list_item(ARGS.get('collection'), ARGS.get('item_id')),
        'clear_media_list':             lambda: ui.clear_media_list(ARGS.get('collection')),
        'show_downloads_menu':          lambda: ui.show_downloads_menu(HANDLE),
        'show_download_actions':        lambda: ui.show_download_actions(ARGS['id']),
        'move_download':                lambda: ui.move_download(ARGS['id'], ARGS.get('direction')),
        'pause_download':               lambda: ui.pause_download(ARGS['id']),
        'resume_download':              lambda: ui.resume_download(ARGS['id']),
        'cancel_download':              lambda: ui.cancel_download(ARGS['id']),
        'retry_download':               lambda: ui.retry_download(ARGS['id']),
        'verify_download':              lambda: ui.verify_download(ARGS['id']),
        'repair_download':              lambda: ui.repair_download(ARGS['id']),
        'remove_download_history':      lambda: ui.remove_download_history(ARGS['id']),
        'clear_download_history':       lambda: ui.clear_download_history(),
        'show_subtitle_jobs':           lambda: ui.show_subtitle_jobs(HANDLE),
        'show_subtitle_job_actions':    lambda: ui.show_subtitle_job_actions(ARGS['job_id']),
        'start_subtitle_translation':   lambda: ui.start_subtitle_translation(ARGS.get('stream_id'), ARGS),
        'refresh_subtitle_job':         lambda: ui.refresh_subtitle_job(ARGS.get('job_id')),
        'cancel_subtitle_job':          lambda: ui.cancel_subtitle_job(ARGS.get('job_id')),
        'retry_subtitle_job':           lambda: ui.retry_subtitle_job(ARGS.get('job_id')),
        'play_subtitle_job':            lambda: ui.play_subtitle_job(HANDLE, ARGS.get('job_id')),
    }
    
    if action in routes:
        routes[action]()
    else:
        ui.show_modern_home(HANDLE)

if __name__ == '__main__':
    router()
