from resources.lib.downloads_worker import DownloadsWorker
from resources.lib.torbox_worker import TorboxPreparationWorker
from resources.lib.subtitles_worker import SubtitlePlaybackMonitor, SubtitleTranslationWorker
from resources.lib.playback_worker import PlaybackMonitor
import threading
from resources.lib import classic_browse

if __name__ == "__main__":
    threading.Thread(target=classic_browse.run, name="MediaHubBrowseService", daemon=True).start()
    subtitle_playback_monitor = SubtitlePlaybackMonitor()
    playback_monitor = PlaybackMonitor()
    preparation_worker = TorboxPreparationWorker()
    preparation_thread = threading.Thread(
        target=preparation_worker.run,
        name="TorboxPreparationWorker",
        daemon=True,
    )
    preparation_thread.start()
    subtitle_thread = threading.Thread(
        target=SubtitleTranslationWorker().run,
        name="SubtitleTranslationWorker",
        daemon=True,
    )
    subtitle_thread.start()
    DownloadsWorker().run()
