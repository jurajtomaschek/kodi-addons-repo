"""Controller for the fullscreen Media Hub application shell."""

import threading
import queue
import time
import functools
import json

_UNLOADED = object()

def _serialized(method):
    @functools.wraps(method)
    def call(self, *args, **kwargs):
        with self._ui_lock:
            return method(self, *args, **kwargs)
    return call

import urllib.parse
import xbmc
import xbmcgui
try:
    from .localization import tr
    from . import search_history, search_results
except ImportError:  # Direct module loading used by the lightweight test harness.
    from resources.lib.localization import tr
    from resources.lib import search_history, search_results


XML_FILENAME = "MediaHubHome.xml"
ADDON_ID = "plugin.video.mediahub"

NAV = 100
SEARCH = 200
QUIT = 220
EMPTY_ACTION = 230
CATALOG_SEARCH = 240
CATALOG_RECENT = 250
CATALOG_RECENT_CLEAR = 251
CATALOG_SEARCH_SORT = 252
CATALOG_SEARCH_SORT_OPTIONS = 253
CATALOG_SEARCH_COMPACT = 254
CATALOG_SEARCH_CLOSE = 255
TABS = 210
HOME_PRIMARY = 300
HOME_SECONDARY = 310
HOME_TERTIARY = 320
HOME_RETRY = 330
HOME_SHELVES = (HOME_PRIMARY, HOME_SECONDARY, HOME_TERTIARY)
CATALOG = 400
HISTORY = 420
BROWSER = 430
STREAM_FILTERS = 440
STREAM_LIST = 441
DOWNLOADS = 500
SETTINGS = 510
DETAIL_ACTIONS = 600
CONTEXT_MENU = 700
BROWSER_TABS = 710
BROWSER_ACTIONS = 720
FILTER_GROUPS = 800
FILTER_OPTIONS = 810
FILTER_ACTIONS = 820
FILTER_RESULTS = 830
FILTER_RESULT_ACTIONS = 840
FILTER_RESULT_CHIPS = 850
FILTER_PAGINATION = 860

# Compatibility names used by older tests and callers.
QUICK = HOME_PRIMARY
FAVORITES = HOME_SECONDARY

_BACK_ACTIONS = frozenset((9, 10, 92, 110))
_PAGE_UP_ACTION = 5
BROWSER_PAGES = frozenset(("browse", "filterresults"))
DOWNLOAD_REFRESH_INTERVAL_SECONDS = 1.0
_CONTROL_NAMES = {
    NAV: "navigation",
    EMPTY_ACTION: "empty state action",
    CATALOG_SEARCH: "catalog search field",
    CATALOG_SEARCH_COMPACT: "compact catalog search",
    CATALOG_SEARCH_CLOSE: "close catalog search popup",
    CATALOG_RECENT: "recent searches",
    CATALOG_RECENT_CLEAR: "clear recent searches",
    CATALOG_SEARCH_SORT: "search sort button",
    CATALOG_SEARCH_SORT_OPTIONS: "search sort options",
    TABS: "tabs",
    HOME_PRIMARY: "home primary",
    HOME_SECONDARY: "home secondary",
    HOME_TERTIARY: "home TV",
    CATALOG: "catalog",
    HISTORY: "history",
    BROWSER: "browser",
    STREAM_FILTERS: "stream filters",
    STREAM_LIST: "stream list",
    DOWNLOADS: "downloads",
    SETTINGS: "settings",
    DETAIL_ACTIONS: "detail actions",
    CONTEXT_MENU: "context menu",
    BROWSER_TABS: "browser tabs",
    BROWSER_ACTIONS: "browser actions",
    FILTER_GROUPS: "filter groups",
    FILTER_OPTIONS: "filter options",
    FILTER_ACTIONS: "filter actions",
    FILTER_RESULTS: "filter results",
    FILTER_RESULT_ACTIONS: "filter result actions",
    FILTER_RESULT_CHIPS: "filter result chips",
    FILTER_PAGINATION: "filter pagination",
}

_PAGE_TITLES = {
    "home": ("Home", ""),
    "movies": ("Movies", ""),
    "tv": ("TV Series", ""),
    "downloads": ("Downloads", ""),
    "favorites": ("Favourites", ""),
    "history": ("Recently Viewed", ""),
    "settings": ("Settings", ""),
    "search": ("Search", ""),
    "browse": ("Browse", ""),
    "filterresults": ("Discovery Results", ""),
}


def _log(message, level=None):
    if level is None:
        level = xbmc.LOGDEBUG
    try:
        xbmc.log("[Media Hub app] {0}".format(message), level)
    except Exception:
        pass


def _models(value):
    if value is None:
        return []
    try:
        values = list(value)
    except TypeError:
        return []
    return [model for model in values if isinstance(model, dict)]


def _text(value):
    if value is None:
        return ""
    if isinstance(value, bool):
        return "true" if value else "false"
    return str(value)


def _model_property(model, key, default=""):
    properties = model.get("properties")
    if not isinstance(properties, dict):
        return _text(default)
    return _text(properties.get(key, default))


class MediaHubHomeDialog(xbmcgui.WindowXML):
    """Single-window, remote-first interface for every primary addon page."""

    def __init__(self, *args, **kwargs):
        self._ui_lock = threading.RLock()
        self._shutdown_lock = threading.Lock()
        self._cleanup_started = False
        self._load_generation = 0
        self._load_jobs = set()
        self._load_queue = queue.Queue(maxsize=16)
        self._load_workers = []
        self._metadata_queue = queue.Queue(maxsize=16)
        self._metadata_workers = []
        self.async_loading = bool(kwargs.pop("async_loading", False))
        self.display_handler = kwargs.pop("display_handler", None)
        self.close_handler = kwargs.pop("close_handler", None)
        self.navigation = _models(kwargs.pop("navigation", None))
        self.home_primary = _models(
            kwargs.pop("home_primary", kwargs.pop("quick_items", None))
        )
        secondary_items = kwargs.pop("home_secondary", None)
        favorite_items = kwargs.pop("favorite_items", None)
        self.home_secondary = _models(secondary_items)
        self.home_tertiary = _models(kwargs.pop("home_tertiary", None))
        self.favorite_items = _models(favorite_items)
        self._home_focus_control = HOME_PRIMARY
        self.history_items = _models(kwargs.pop("history_items", None))
        self.download_items = _models(kwargs.pop("download_items", None))
        self._download_row_targets = [
            _text(model.get("target")) for model in self.download_items
        ]
        self.settings_items = _models(kwargs.pop("settings_items", None))
        self.fallback_art = _text(kwargs.pop("fallback_art", ""))
        self.logo_art = _text(kwargs.pop("logo_art", ""))
        self.initial_page = _text(kwargs.pop("initial_page", "home")) or "home"
        self.catalog_loader = kwargs.pop("catalog_loader", None)
        self.catalog_page_loader = kwargs.pop("catalog_page_loader", None)
        self.catalog_columns = max(1, int(kwargs.pop("catalog_columns", 6)))
        self.reduce_catalog_motion = bool(kwargs.pop("reduce_catalog_motion", False))
        self.search_loader = kwargs.pop("search_loader", None)
        self.search_history_path = _text(kwargs.pop("search_history_path", ""))
        self.home_loader = kwargs.pop("home_loader", None)
        self.home_primary_loader = kwargs.pop("home_primary_loader", None)
        self.catalog_metadata_loader = kwargs.pop("catalog_metadata_loader", None)
        self._home_primary_loaded = False
        self.browser_loader = kwargs.pop("browser_loader", None)
        self.filter_view_ready = kwargs.pop("filter_view_ready", None)
        self.discovery_targets = dict(kwargs.pop("discovery_targets", None) or {})
        self.action_handler = kwargs.pop("action_handler", None)
        self.play_handler = kwargs.pop("play_handler", None)
        self.resume_choice_loader = kwargs.pop("resume_choice_loader", None)
        self.state_loader = kwargs.pop("state_loader", None)
        self.initial_target = _text(kwargs.pop("initial_target", ""))
        self.result = None

        self._page = ""
        self._previous_page = "home"
        self._catalog_cache = {}
        self._catalog_pages = {}
        self._catalog_exhausted = set()
        self._catalog_page_loading = False
        self._filter_page_loading = False
        self._tabs = []
        self._browser_tabs = []
        self._active_browser_tab = ""
        self._browser_actions = []
        self._catalog_items = []
        self._browser_items = []
        self._stream_all_items = []
        self._stream_filters = []
        self._browser_targets = []
        self._browser_origin = "home"
        self._browser_view = {}
        self._browser_return_state = None
        self._filter_groups = []
        self._filter_options = []
        self._filter_actions = []
        self._filter_results = []
        self._filter_result_actions = []
        self._filter_result_chips = []
        self._filter_pagination = []
        self._context_items = []
        self._context_open = False
        self._context_origin_control = None
        self._nav_index = {}
        self._nav_position = None
        self._tab_position = None
        self._filter_group_position = None
        self._filter_requested_section = ""
        self._filter_overlay_active = False
        self._active_catalog_tab = ""
        self._highlighted_catalog_tab = ""
        self._catalog_workspace_page = ""
        self._catalog_search_queries = {"movies": "", "tv": ""}
        self._catalog_search_results = {"movies": [], "tv": []}
        self._catalog_search_errors = {"movies": False, "tv": False}
        self._catalog_search_sorts = {"movies": "match", "tv": "match"}
        self._catalog_search_next_targets = {"movies": "", "tv": ""}
        self._catalog_sort_options = []
        self._catalog_sort_open = False
        self._catalog_search_overlay_open = False
        self._catalog_search_history = search_history.load(self.search_history_path)
        self._catalog_recent_items = []
        self._initialized = False
        self._reactivation_state = None
        self._close_event = threading.Event()
        self._home_refresh_thread = None
        self._downloads_refresh_thread = None

        self._items_by_control = {
            NAV: self.navigation,
            TABS: self._tabs,
            BROWSER_TABS: self._browser_tabs,
            BROWSER_ACTIONS: self._browser_actions,
            HOME_PRIMARY: self.home_primary,
            HOME_SECONDARY: self.home_secondary,
            HOME_TERTIARY: self.home_tertiary,
            CATALOG: self._catalog_items,
            CATALOG_RECENT: self._catalog_recent_items,
            CATALOG_SEARCH_SORT_OPTIONS: self._catalog_sort_options,
            HISTORY: self.history_items,
            BROWSER: self._browser_items,
            STREAM_FILTERS: self._stream_filters,
            STREAM_LIST: self._browser_items,
            DOWNLOADS: self.download_items,
            SETTINGS: self.settings_items,
            DETAIL_ACTIONS: [],
            CONTEXT_MENU: self._context_items,
            FILTER_GROUPS: self._filter_groups,
            FILTER_OPTIONS: self._filter_options,
            FILTER_ACTIONS: self._filter_actions,
            FILTER_RESULTS: self._filter_results,
            FILTER_RESULT_ACTIONS: self._filter_result_actions,
            FILTER_RESULT_CHIPS: self._filter_result_chips,
            FILTER_PAGINATION: self._filter_pagination,
        }

    @_serialized
    def onInit(self):
        # Kodi temporarily focuses navigation before the page is populated.
        self.setProperty("App.InitialFocusReady", "false")
        try:
            self.setProperty("App.FallbackArt", self.fallback_art)
            self.setProperty("App.Logo", self.logo_art)
            self.setProperty(
                "App.HomePrimaryTitle",
                tr("Continue Watching"),
            )
            self.setProperty(
                "App.HomeSecondaryTitle",
                tr("Popular Movies"),
            )
            self.setProperty("App.HomeTertiaryTitle", tr("Popular TV Series"))
            self.setProperty("App.HomeLabel", tr("Home"))
            self.setProperty("App.HomeRetryLabel", tr("Retry recommendations"))
            self.setProperty("App.HomeLoadingLabel", tr("Loading recommendations…"))
            self.setProperty("App.HomeErrorLabel", tr("Recommendations could not be loaded."))
            self.setProperty("App.HomeEmptyLabel", tr("Start a movie or episode to continue watching here."))
            self._publish_home_state()
            self.setProperty(
                "App.HasHomePrimary",
                "true" if self.home_primary else "false",
            )
            self.setProperty(
                "App.HasHomeSecondary",
                "true" if self.home_secondary else "false",
            )
            self.setProperty(
                "App.HasHistory",
                "true" if self.history_items else "false",
            )
            self.setProperty(
                "App.HasDownloads",
                "true" if self.download_items else "false",
            )
            self.setProperty(
                "App.HasSettings",
                "true" if self.settings_items else "false",
            )
            if not self._initialized:
                self.setProperty(
                    "App.HomeReady",
                    "false" if callable(self.home_loader) else "true",
                )
            self.setProperty("App.ContextOpen", "false")
            self.setProperty("App.ReduceCatalogMotion", "true" if self.reduce_catalog_motion else "false")
            self.setProperty("App.Loading", "false")
            for name, text in {
                "SearchLabel": "Search",
                "QuitLabel": "Quit",
                "LoadingLabel": "LOADING",
                "StreamLoadingLabel": "Finding streams…",
                "StreamLoadingHint": "Getting things ready for movie night",
                "StreamOptionsLabel": "STREAM OPTIONS",
                "PlayLabel": "Play",
                "PlaySelectedLabel": "Play selected version",
                "TechnicalDetailsLabel": "Technical details",
                "ChooseVersionLabel": "Choose version",
                "BackLabel": "BACK",
                "CatalogTabsHint": "BACK  Categories",
                "CatalogDetailsHint": "OK · Details",
                "ContextHelp": "OK  Select     BACK  Close",
                "EmptyTitle": "No titles to show",
                "EmptyHint": "Try another tab, search, or check the API connection.",
                "EmptyActionLabel": "Browse movies",
                "NothingHereLabel": "Nothing here yet",
                "SummaryLabel": "SUMMARY",
                "ResumePlaybackLabel": "RESUME PLAYBACK",
            }.items():
                self.setProperty("App." + name, tr(text))
        except Exception as exc:
            _log("Could not initialize window properties: {0}".format(exc), xbmc.LOGERROR)

        self._nav_index = {
            _model_property(model, "App.Page"): index
            for index, model in enumerate(self.navigation)
            if _model_property(model, "App.Page")
        }
        for control_id in (
            NAV,
            HOME_PRIMARY,
            HOME_SECONDARY,
            HOME_TERTIARY,
            HISTORY,
            DOWNLOADS,
            SETTINGS,
        ):
            self._populate_control(control_id, self._items_by_control[control_id])

        if self._initialized:
            self._restore_reactivated_window()
            self.setProperty("App.InitialFocusReady", "true")
            return
        self._initialized = True
        self._show_page(self.initial_page, load=True)
        if self.initial_target:
            self._open_browser(self.initial_target)
        self.setProperty("App.InitialFocusReady", "true")
        if callable(self.home_loader):
            self._home_refresh_thread = threading.Thread(
                target=self._load_home_background,
                name="MediaHubHomeLoader",
                daemon=True,
            )
            self._home_refresh_thread.start()
        if callable(self.state_loader):
            self._downloads_refresh_thread = threading.Thread(
                target=self._refresh_downloads_background,
                name="MediaHubDownloadsRefresher",
                daemon=True,
            )
            self._downloads_refresh_thread.start()

    def _stop_background(self):
        # Signal before taking any lock: a worker can hold _ui_lock while
        # waiting for Kodi's GUI, which is itself waiting for Python to exit.
        self._close_event.set()
        with self._shutdown_lock:
            if self._cleanup_started:
                return False
            self._cleanup_started = True
        try:
            if callable(self.close_handler):
                self.close_handler()
        except Exception as exc:
            _log("Could not clean up the app window: {0}".format(exc), xbmc.LOGERROR)
        return True

    def close(self):
        if not self._stop_background():
            return
        return super().close()

    @_serialized
    def onClick(self, control_id):
        try:
            if self._catalog_search_overlay_open and control_id not in (
                CATALOG_SEARCH,
                CATALOG_RECENT,
                CATALOG_RECENT_CLEAR,
                CATALOG_SEARCH_CLOSE,
            ):
                self._focus(CATALOG_SEARCH)
                return
            if (
                self._filter_overlay_active
                and self._is_discovery_workspace()
                and control_id not in (
                    FILTER_GROUPS,
                    FILTER_OPTIONS,
                    FILTER_ACTIONS,
                )
            ):
                if control_id == NAV:
                    self._select_navigation(self._page)
                elif control_id == TABS:
                    self._restore_discovery_tab_selection()
                self._focus(FILTER_GROUPS)
                return
            if control_id == HOME_RETRY:
                if self._home_refresh_thread is None or not self._home_refresh_thread.is_alive():
                    self.setProperty("App.HomeReady", "false")
                    self.setProperty("App.HomeError", "false")
                    self._home_refresh_thread = threading.Thread(
                        target=self._load_home_background, name="MediaHubHomeLoader", daemon=True,
                    )
                    self._home_refresh_thread.start()
                    self._focus(NAV)
                return
            if control_id == CONTEXT_MENU:
                model = self._selected_model(CONTEXT_MENU)
                if model is not None:
                    self._close_context_menu(restore_focus=True)
                    self._activate(model)
                return

            if control_id == SEARCH:
                self._show_search()
                return

            if control_id == CATALOG_SEARCH:
                self._show_catalog_search()
                return

            if control_id == CATALOG_SEARCH_COMPACT:
                self._open_catalog_search_overlay()
                return

            if control_id == CATALOG_SEARCH_CLOSE:
                self._close_catalog_search_overlay()
                return

            if control_id == CATALOG_SEARCH_SORT:
                if self._catalog_sort_open:
                    self._close_catalog_search_sort()
                else:
                    self._open_catalog_search_sort()
                return

            if control_id == CATALOG_SEARCH_SORT_OPTIONS:
                model = self._selected_model(CATALOG_SEARCH_SORT_OPTIONS)
                if self._catalog_sort_open and model is not None:
                    sort = _model_property(model, "App.SearchSort")
                    changed = sort != self._catalog_search_sorts.get(self._page, "match")
                    self._catalog_search_sorts[self._page] = sort
                    if changed:
                        self._apply_catalog_search_order(reset_to_top=True)
                    self._close_catalog_search_sort()
                    if changed and self._catalog_items:
                        self._focus(CATALOG)
                return

            if control_id == CATALOG_RECENT:
                model = self._selected_model(CATALOG_RECENT)
                if model is not None:
                    self._run_catalog_search(_model_property(model, "App.SearchQuery"))
                return

            if control_id == CATALOG_RECENT_CLEAR:
                if self._catalog_workspace_page in self._catalog_search_history:
                    self._catalog_search_history[self._catalog_workspace_page] = []
                    self._save_catalog_search_history()
                    self._publish_catalog_search_history()
                    self._publish_catalog_search_state()
                    self._focus(CATALOG_SEARCH if self._catalog_search_overlay_open else CATALOG_SEARCH_COMPACT)
                return

            if control_id == EMPTY_ACTION:
                self._show_page("movies", load=True)
                return

            if control_id == STREAM_FILTERS:
                model = self._selected_model(STREAM_FILTERS)
                if model is not None:
                    self._toggle_stream_filter(model)
                return

            if control_id == QUIT:
                if self._close_event.is_set():
                    return
                self.result = {"command": "quit"}
                try:
                    # Queue shutdown before modal teardown or worker cleanup.
                    xbmc.executebuiltin("Quit")
                    self.result["quit_requested"] = True
                finally:
                    self.close()
                return

            model = self._selected_model(control_id)
            if model is None:
                return

            if control_id == NAV:
                page = _model_property(model, "App.Page", "home")
                if (
                    _text(model.get("command")).strip().lower() == "browse"
                    and _text(model.get("target")).strip()
                ):
                    self._open_browser(model.get("target"))
                else:
                    self._show_page(page, load=True)
            elif control_id == TABS:
                tab = _model_property(model, "App.Tab")
                self._highlighted_catalog_tab = tab
                try:
                    self._tab_position = int(
                        self.getControl(TABS).getSelectedPosition()
                    )
                except Exception:
                    pass
                if tab == "search":
                    self._show_catalog_search_workspace(self._page, focus=True)
                elif tab == "filters":
                    self._show_discovery_workspace(self._page, focus=True)
                else:
                    self._clear_catalog_workspace()
                    self._load_catalog(self._page, tab, force=False)
            elif control_id == BROWSER_TABS:
                if _model_property(model, "App.Tab") != self._active_browser_tab:
                    self._activate(model)
            elif control_id == BROWSER_ACTIONS:
                self._activate(model)
            elif control_id == DETAIL_ACTIONS:
                self._activate_detail_action(model)
            else:
                self._activate(model)
        except Exception as exc:
            _log(
                "Click handling failed for control {0}: {1}".format(control_id, exc),
                xbmc.LOGERROR,
            )

    @_serialized
    def onFocus(self, control_id):
        if control_id in HOME_SHELVES:
            self._home_focus_control = control_id
            self.setProperty("App.HomeShelf", str(control_id))
            return
        if (
            control_id == TABS
            and self._filter_overlay_active
            and self._is_discovery_workspace()
        ):
            self._restore_discovery_tab_selection()
            self._focus(FILTER_GROUPS)
            return
        if control_id == TABS:
            self._remember_tab_position()
            return
        if control_id in (FILTER_GROUPS, FILTER_OPTIONS, FILTER_ACTIONS):
            if self._is_discovery_workspace():
                self._filter_overlay_active = True
        if control_id == FILTER_OPTIONS and self._is_discovery_workspace():
            group = self._selected_model(FILTER_GROUPS)
            section = _text(self._browser_view.get("section"))
            group_key = (
                _model_property(group, "App.FilterKey")
                if group is not None
                else ""
            )
            if group_key and group_key != section:
                target = _text(group.get("target")).strip()
                if target:
                    self._open_browser(target, replace=True)
                    selected_option_index = next(
                        (
                            index
                            for index, model in enumerate(
                                self._filter_options
                            )
                            if _model_property(
                                model,
                                "App.Selected",
                            ) == "true"
                        ),
                        0,
                    )
                    if self._filter_options:
                        try:
                            self.getControl(
                                FILTER_OPTIONS
                            ).selectItem(selected_option_index)
                        except Exception:
                            pass
            return
        if control_id != NAV:
            return
        page = self._navigation_page(self._page)
        self._select_navigation(page)
        self._remember_navigation_position()

    @_serialized
    def onAction(self, action):
        try:
            action_id = action.getId()
        except (AttributeError, TypeError):
            try:
                action_id = int(action)
            except (TypeError, ValueError):
                return

        if self._catalog_sort_open:
            if action_id in _BACK_ACTIONS or action_id == 1:
                self._close_catalog_search_sort()
            return
        if self._catalog_search_overlay_open:
            if action_id in _BACK_ACTIONS:
                self._close_catalog_search_overlay()
                return
            if self.getFocusId() not in (
                CATALOG_SEARCH, CATALOG_RECENT,
                CATALOG_RECENT_CLEAR, CATALOG_SEARCH_CLOSE,
            ):
                self._focus(CATALOG_SEARCH)
                return
        if action_id in _BACK_ACTIONS:
            self._invalidate_loads()
        if self._context_open:
            if action_id in _BACK_ACTIONS or action_id in (101, 117):
                self._close_context_menu()
            return
        if self._filter_overlay_active and self._is_discovery_workspace():
            if action_id in _BACK_ACTIONS:
                if len(self._browser_targets) > 1:
                    self._close_browser_level()
                else:
                    self._close_discovery_overlay()
                return
            if self.getFocusId() not in (
                FILTER_GROUPS,
                FILTER_OPTIONS,
                FILTER_ACTIONS,
            ):
                self._restore_discovery_tab_selection()
                self._focus(FILTER_GROUPS)
                return
            if action_id == _PAGE_UP_ACTION:
                return
        if (
            action_id in (3, 4)
            and self.getFocusId() == FILTER_GROUPS
            and self._is_discovery_workspace()
            and self._filter_groups
        ):
            control = self.getControl(FILTER_GROUPS)
            try:
                position = int(control.getSelectedPosition())
            except (TypeError, ValueError):
                position = 0
            previous_position = self._filter_group_position
            if previous_position is None:
                previous_position = position
            next_position = (
                position
                if position != previous_position
                else max(
                    0,
                    min(
                        len(self._filter_groups) - 1,
                        position + (1 if action_id == 4 else -1),
                    ),
                )
            )
            if next_position != previous_position:
                control.selectItem(next_position)
                self._preview_filter_group(next_position)
                return
        if action_id in (1, 2) and self.getFocusId() == TABS and self._tabs:
            control = self.getControl(TABS)
            last_position = len(self._tabs) - 1
            try:
                category_position = next(
                    index
                    for index, model in enumerate(self._tabs)
                    if _model_property(model, "App.Tab")
                    == self._highlighted_catalog_tab
                )
            except (StopIteration, TypeError, ValueError):
                category_position = self._tab_position
            if category_position is None:
                category_position = 0
            step = 1 if action_id == 2 else -1
            next_position = max(
                0,
                min(last_position, category_position + step),
            )
            if next_position != category_position:
                control.selectItem(next_position)
                # Force the existing selection synchronizer to apply the newly
                # highlighted category even if Kodi already moved or wrapped
                # the native list before delivering this callback.
                self._tab_position = category_position
                self._sync_tab_selection()
                return
            control.selectItem(category_position)
            self._tab_position = category_position
            if action_id == 1:
                # Some Kodi list implementations wrap before onAction runs.
                # Restore the boundary item before handing focus to the rail.
                self._focus(NAV)
            # Right on the final category deliberately remains there.
            return
        if action_id in (1, 2) and self.getFocusId() == BROWSER_TABS:
            control = self.getControl(BROWSER_TABS)
            models = self._browser_tabs
            if models:
                try:
                    position = next(
                        index
                        for index, model in enumerate(models)
                        if _model_property(model, "App.Tab")
                        == self._active_browser_tab
                    )
                except (StopIteration, TypeError, ValueError):
                    try:
                        position = int(control.getSelectedPosition())
                    except Exception:
                        position = 0
                step = 1 if action_id == 2 else -1
                next_position = max(0, min(len(models) - 1, position + step))
                if next_position != position:
                    control.selectItem(next_position)
                    model = models[next_position]
                    if _model_property(model, "App.Tab") != self._active_browser_tab:
                        self._activate(model)
                elif action_id == 1:
                    # Category strips never wrap. Left from the first category
                    # returns to the persistent main navigation rail; Right
                    # from the final category remains on that category.
                    self._focus(NAV)
            return
        if action_id == 4 and self.getFocusId() == BROWSER_TABS:
            if self._browser_actions:
                try:
                    self.getControl(BROWSER_ACTIONS).selectItem(0)
                except Exception:
                    pass
                self._focus(BROWSER_ACTIONS)
            elif self._browser_items:
                try:
                    self.getControl(BROWSER).selectItem(0)
                except Exception:
                    pass
                self._focus(BROWSER)
            return
        if action_id in (101, 117):
            self._open_context_menu()
            return
        if action_id == _PAGE_UP_ACTION and self._focus_catalog_tabs():
            return
        if action_id not in _BACK_ACTIONS:
            self._sync_navigation_selection()
            self._sync_tab_selection()
            if action_id == 4:
                self._load_next_catalog_page_if_needed()
                self._load_next_filter_results_page_if_needed()
            return
        if self._page in BROWSER_PAGES:
            self._close_browser_level()
            return
        if self._is_discovery_workspace() and len(self._browser_targets) > 1:
            self._close_browser_level()
            return
        if self._page == "detail":
            self._show_page(self._previous_page, load=False)
            return

        try:
            focus_id = int(self.getFocusId())
        except (TypeError, ValueError):
            focus_id = None

        if self._focus_catalog_tabs():
            return

        # At a top-level module, Back first returns to that module's selected
        # navigation item. A second Back returns to Home without closing Kodi's
        # application shell.
        if focus_id != NAV:
            self._select_navigation(self._navigation_page(self._page))
            self._focus(NAV)
            return

        if self._page != "home":
            self._show_page("home", load=False)
            return

        # Keep the application shell open at its root. In particular, do not
        # close the window here: repeated/queued Back actions would otherwise
        # continue through Kodi's navigation stack and leave the add-on.
        self._focus_home_content()

    def _show_page(self, page, load=True, focus=True):
        self._invalidate_loads()
        if page == "filters":
            self._apply_filter_studio_view(self._browser_view, focus=focus)
            return
        if page not in _PAGE_TITLES and page != "detail":
            page = "home"
        restored_workspace = (
            self._highlighted_catalog_tab
            if (
                self._page == "detail"
                and self._catalog_workspace_page == page
                and self._highlighted_catalog_tab in ("search", "filters")
            )
            else ""
        )
        if page != "detail":
            self._previous_page = page
        if page in ("movies", "tv"):
            if not restored_workspace:
                self._clear_catalog_workspace()
        elif page != "filterresults":
            self._clear_catalog_workspace(clear_origin=True)
        self._page = page
        self.setProperty("App.Page", page)

        title, subtitle = _PAGE_TITLES.get(page, ("", ""))
        title, subtitle = tr(title), tr(subtitle)
        self.setProperty("App.PageTitle", title)
        self.setProperty("App.PageSubtitle", subtitle)
        empty_copy = {
            "favorites": (
                tr("Nothing saved yet"),
                tr("Save a movie or series and it will appear here."),
            ),
            "history": (
                tr("No recently viewed titles"),
                tr("Start watching something and it will appear here."),
            ),
            "downloads": (
                tr("No downloads yet"),
                tr("Download a title to make it available offline."),
            ),
            "search": (
                tr("No search results"),
                tr("Try a different title or search phrase."),
            ),
        }.get(
            page,
            (
                tr("No titles to show"),
                tr("Try another category or check the API connection."),
            ),
        )
        self.setProperty("App.EmptyTitle", empty_copy[0])
        self.setProperty("App.EmptyHint", empty_copy[1])
        navigation_page = self._navigation_page(page)
        self.setProperty("App.NavPage", navigation_page)
        self._select_navigation(navigation_page)

        if page in ("movies", "tv"):
            self._set_tabs(page)
            if restored_workspace:
                restored_index = next(
                    (
                        index
                        for index, model in enumerate(self._tabs)
                        if _model_property(model, "App.Tab") == restored_workspace
                    ),
                    0,
                )
                self._highlighted_catalog_tab = restored_workspace
                self._tab_position = restored_index
                try:
                    self.getControl(TABS).selectItem(restored_index)
                except Exception:
                    pass
                if restored_workspace == "search":
                    self._show_catalog_search_workspace(page, focus=False)
                else:
                    self._show_discovery_workspace(page, focus=False)
            selected_tab = restored_workspace or self._active_catalog_tab
            if load:
                if selected_tab not in ("search", "filters"):
                    self._load_catalog(
                        page,
                        selected_tab,
                        force=False,
                        focus=focus,
                        show_loading=focus,
                    )
            if self._tabs and not restored_workspace:
                try:
                    self.getControl(TABS).selectItem(0)
                    self._tab_position = 0
                except Exception:
                    pass
            if focus:
                self._focus(CATALOG if self._catalog_items else TABS)
        elif page == "favorites":
            self._set_catalog(self.favorite_items)
            if focus:
                self._focus(CATALOG if self._catalog_items else EMPTY_ACTION)
        elif page == "history":
            self.setProperty(
                "App.HasHistory",
                "true" if self.history_items else "false",
            )
            if focus:
                self._focus(HISTORY if self.history_items else EMPTY_ACTION)
        elif page == "downloads":
            if load and focus and callable(self.browser_loader):
                self._open_browser(
                    "plugin://{0}/?action=show_downloads_menu".format(ADDON_ID),
                    focus=focus,
                )
                return
            self.setProperty(
                "App.HasDownloads",
                "true" if self.download_items else "false",
            )
            if focus:
                self._focus(DOWNLOADS if self.download_items else EMPTY_ACTION)
        elif page == "settings":
            if focus:
                self._focus(SETTINGS if self.settings_items else NAV)
        elif page == "search":
            if focus:
                self._focus(CATALOG if self._catalog_items else SEARCH)
        elif page == "browse":
            restored = self._restore_browser_state(focus=focus)
            if not restored and focus:
                self._focus(BROWSER if self._browser_items else NAV)
        elif page == "filterresults":
            restored = self._restore_browser_state(focus=focus)
            if not restored:
                self._apply_filter_results_view(self._browser_view, focus=focus)
        elif page == "home":
            self._publish_home_state()
            if focus:
                self._focus(self._preferred_page_focus("home", self._home_focus_control))

    def _set_tabs(self, page):
        labels = (
            (
                (
                    tr("Popular"),
                    "popular",
                    "Trending now",
                    "category-popular.png",
                ),
                (
                    tr("New Releases"),
                    "latest",
                    "Just added",
                    "category-latest.png",
                ),
                (
                    tr("Top Rated"),
                    "top",
                    "Best reviewed",
                    "category-top-rated.png",
                ),
                (
                    tr("Search"),
                    "search",
                    "Find a movie by name",
                    "nav-search.png",
                ),
                (
                    tr("Discover"),
                    "filters",
                    "Mix genres, eras and ratings",
                    "filter-funnel.png",
                ),
            )
            if page == "movies"
            else (
                (
                    tr("Popular"),
                    "popular",
                    "Trending now",
                    "category-popular.png",
                ),
                (
                    tr("New Releases"),
                    "latest",
                    "Just added",
                    "category-latest.png",
                ),
                (
                    tr("Recently Aired"),
                    "recent",
                    "Recently shown",
                    "category-recent.png",
                ),
                (
                    tr("Slovak"),
                    "slovak",
                    "Slovak productions",
                    "category-slovak.png",
                ),
                (
                    tr("Search"),
                    "search",
                    "Find a TV series by name",
                    "nav-search.png",
                ),
                (
                    tr("Discover"),
                    "filters",
                    "Mix genres, eras and ratings",
                    "filter-funnel.png",
                ),
            )
        )
        self._tabs[:] = [
            {
                "label": label,
                "command": "workspace" if value in ("filters", "search") else "tab",
                "target": (
                    _text(self.discovery_targets.get(page))
                    if value == "filters"
                    else "plugin://{}/?action={}".format(
                        ADDON_ID,
                        "menu_item_movies_search"
                        if page == "movies"
                        else "menu_item_tvshows_search",
                    )
                    if value == "search"
                    else ""
                ),
                "properties": {
                    "App.Tab": value,
                    "App.Hint": hint,
                    "App.Icon": icon,
                },
            }
            for label, value, hint, icon in labels
        ]
        default_index = next(
            (
                index
                for index, model in enumerate(self._tabs)
                if _model_property(model, "App.Tab") != "filters"
            ),
            0,
        )
        active_tab = (
            _model_property(self._tabs[default_index], "App.Tab")
            if self._tabs
            else ""
        )
        self._active_catalog_tab = active_tab
        self._highlighted_catalog_tab = active_tab
        self._tab_position = default_index
        self.setProperty("App.ActiveTab", active_tab)
        self._populate_control(TABS, self._tabs)
        if self._tabs:
            try:
                self.getControl(TABS).selectItem(default_index)
            except Exception:
                pass

    def _invalidate_loads(self):
        self._catalog_sort_open = False
        self.setProperty("App.CatalogSearchSortOpen", "false")
        self._catalog_search_overlay_open = False
        self.setProperty("App.CatalogSearchOverlayOpen", "false")
        self._load_generation += 1
        self._catalog_page_loading = False
        self._filter_page_loading = False
        self.setProperty("App.Loading", "false")
        self.setProperty("App.MetadataStatus", "")
        self.setProperty("App.MetadataBusy", "false")
        self.setProperty("App.StreamLoading", "false")
        if callable(self.display_handler):
            self.display_handler({}, False)

    def _submit_load(self, key, load, apply):
        generation = self._load_generation
        identity = (generation, key)
        if identity in self._load_jobs:
            return
        self._load_jobs.add(identity)
        background = key[0] in ("catalog-metadata", "home-primary")
        work_queue = self._metadata_queue if background else self._load_queue
        workers = self._metadata_workers if background else self._load_workers
        try:
            work_queue.put_nowait((identity, load, apply))
        except queue.Full:
            self._load_jobs.discard(identity)
            self.setProperty("App.Loading", "false")
            return
        while len(workers) < (2 if background else 3):
            worker = threading.Thread(target=self._load_worker, args=(work_queue,), daemon=True,
                                      name="MediaHubCatalogMetadata" if background else "MediaHubScreen")
            workers.append(worker)
            worker.start()

    def _load_worker(self, work_queue):
        while not self._close_event.is_set():
            try:
                identity, load, apply = work_queue.get(timeout=.25)
            except queue.Empty:
                continue
            try:
                if identity[0] != self._load_generation:
                    continue
                result = load()
                results = result if hasattr(result, "__next__") else iter((result,))
                for value in results:
                    with self._ui_lock:
                        if self._close_event.is_set() or identity[0] != self._load_generation:
                            break
                        apply(value)
            except Exception as exc:
                with self._ui_lock:
                    if not self._close_event.is_set() and identity[0] == self._load_generation:
                        _log("Background load failed: {0}".format(exc), xbmc.LOGERROR)
                        self.setProperty("App.Loading", "false")
                        self._catalog_page_loading = self._filter_page_loading = False
                        self.setProperty("App.MetadataStatus", tr("Content could not be loaded."))
            finally:
                with self._ui_lock:
                    self._load_jobs.discard(identity)
                work_queue.task_done()

    def _load_catalog(
        self,
        page,
        tab,
        force=False,
        query="",
        focus=True,
        show_loading=True,
        _loaded=_UNLOADED,
    ):
        if _loaded is _UNLOADED:
            self._invalidate_loads()
        if page in ("movies", "tv") and tab:
            self.setProperty("App.ActiveTab", tab)
            if tab != "filters":
                self._active_catalog_tab = tab
        cache_key = (page, tab, query)
        if not force and cache_key in self._catalog_cache:
            self._set_catalog(self._catalog_cache[cache_key])
            if focus:
                self._focus(CATALOG if self._catalog_items else TABS)
            return

        loader = self.search_loader if page == "search" else self.catalog_loader
        if not callable(loader):
            self._set_catalog([])
            return

        if show_loading:
            self.setProperty("App.Loading", "true")
        if self.async_loading and _loaded is _UNLOADED:
            self._set_catalog([])
            self._submit_load(("catalog", cache_key),
                lambda: loader(query) if page == "search" else loader(page, tab),
                lambda result: self._load_catalog(page, tab, force=True, query=query,
                    focus=focus, show_loading=show_loading, _loaded=result))
            return
        try:
            if _loaded is not _UNLOADED:
                models = _loaded
            elif page == "search":
                models = loader(query)
            else:
                models = loader(page, tab)
            models = _models(models)
            self._catalog_cache[cache_key] = models
            self._catalog_pages[cache_key] = 1
            self._catalog_exhausted.discard(cache_key)
            self._set_catalog(models)
        except Exception as exc:
            _log("Could not load {0}/{1}: {2}".format(page, tab, exc), xbmc.LOGERROR)
            self._set_catalog([])
            try:
                xbmcgui.Dialog().notification(
                    "Media Hub",
                    tr("Content could not be loaded."),
                    xbmcgui.NOTIFICATION_ERROR,
                    2500,
                )
            except Exception:
                pass
        finally:
            if show_loading:
                self.setProperty("App.Loading", "false")

        if focus:
            self._focus(CATALOG if self._catalog_items else TABS)

    def _load_next_catalog_page_if_needed(self, _loaded=_UNLOADED):
        if self._page in ("movies", "tv") and self._catalog_workspace_page == self._page and self._highlighted_catalog_tab == "search":
            self._load_next_catalog_search_page_if_needed()
            return
        if (
            self._page not in ("movies", "tv")
            or not callable(self.catalog_page_loader)
            or self._catalog_page_loading
            or not self._catalog_items
            or (
                self._catalog_workspace_page == self._page
                and self._highlighted_catalog_tab in ("search", "filters")
            )
        ):
            return
        try:
            if _loaded is _UNLOADED and self.getFocusId() != CATALOG:
                return
            control = self.getControl(CATALOG)
            position = int(control.getSelectedPosition())
        except Exception:
            return
        # Kodi calls onAction before the panel applies the Down movement. The
        # poster panel is six columns wide, so anticipate entry into the final
        # row and fetch while the penultimate row is focused. Waiting until the
        # reported position is already in the final row is unreliable because
        # some Kodi versions stop dispatching Down at the panel boundary.
        if _loaded is _UNLOADED and position < max(
            0, len(self._catalog_items) - (self.catalog_columns * 2 + 1)
        ):
            return

        tab = self._active_catalog_tab
        if not tab or tab == "filters":
            tab = next(
                (
                    _model_property(model, "App.Tab")
                    for model in self._tabs
                    if _model_property(model, "App.Tab") != "filters"
                ),
                "",
            )
        if not tab:
            return
        cache_key = (self._page, tab, "")
        if cache_key in self._catalog_exhausted:
            return
        next_page = self._catalog_pages.get(cache_key, 1) + 1
        self._catalog_page_loading = True
        if self.async_loading and _loaded is _UNLOADED:
            page = self._page
            def apply(result):
                self._catalog_page_loading = False
                self._load_next_catalog_page_if_needed(_loaded=result)
            self._submit_load(("page", cache_key, next_page),
                lambda: self.catalog_page_loader(page, tab, next_page), apply)
            return
        try:
            models = _models(self.catalog_page_loader(self._page, tab, next_page) if _loaded is _UNLOADED else _loaded)
            if not models:
                self._catalog_exhausted.add(cache_key)
                return
            existing_ids = {
                (_model_property(model, "App.Kind"), _model_property(model, "App.Id"))
                for model in self._catalog_items
                if _model_property(model, "App.Id")
            }
            additions = []
            for model in models:
                identity = (_model_property(model, "App.Kind"), _model_property(model, "App.Id"))
                if identity[1] and identity in existing_ids:
                    continue
                additions.append(model)
                if identity[1]:
                    existing_ids.add(identity)
            if not additions:
                self._catalog_pages[cache_key] = next_page
                self._catalog_exhausted.add(cache_key)
                return
            # Prepare and add only new cards; never clear the visible grid while
            # constructing the next page's ListItems.
            self._append_control_items(CATALOG, additions)
            self._catalog_items.extend(additions)
            self._catalog_cache[cache_key] = list(self._catalog_items)
            self._catalog_pages[cache_key] = next_page
        except Exception as exc:
            _log(
                "Could not load catalog page {0}: {1}".format(next_page, exc),
                xbmc.LOGERROR,
            )
        finally:
            self.setProperty("App.Loading", "false")
            self._catalog_page_loading = False

    def _load_next_filter_results_page_if_needed(self, _loaded=_UNLOADED):
        if (
            self._page != "filterresults"
            or not callable(self.browser_loader)
            or self._filter_page_loading
            or not self._filter_results
        ):
            return
        try:
            if _loaded is _UNLOADED and int(self.getFocusId()) != FILTER_RESULTS:
                return
            control = self.getControl(FILTER_RESULTS)
            position = int(control.getSelectedPosition())
        except Exception:
            return
        # As with the regular movie/TV catalog, Kodi reports the selection
        # before applying Down. Start loading while focus is in the penultimate
        # six-column row so navigation never reaches a hard end to the grid.
        if _loaded is _UNLOADED and position < max(
            0, len(self._filter_results) - (self.catalog_columns * 2 + 1)
        ):
            return

        target = _text(
            self._browser_view.get("next_page_target")
        ).strip()
        if not target:
            return

        self._filter_page_loading = True
        if self.async_loading and _loaded is _UNLOADED:
            def apply(result):
                self._filter_page_loading = False
                self._load_next_filter_results_page_if_needed(_loaded=result)
            self._submit_load(("filter-page", target), lambda: self.browser_loader(target), apply)
            return
        try:
            view = self.browser_loader(target) if _loaded is _UNLOADED else _loaded
            if not isinstance(view, dict) or (
                _text(view.get("layout")).strip().lower() != "filter_results"
            ):
                return

            existing_ids = {
                (_model_property(model, "App.Kind"), _model_property(model, "App.Id"))
                for model in self._filter_results
                if _model_property(model, "App.Id")
            }
            existing_targets = {
                _text(model.get("target"))
                for model in self._filter_results
                if _text(model.get("target"))
            }
            additions = []
            for model in _models(view.get("items")):
                media_id = _model_property(model, "App.Id")
                identity = (_model_property(model, "App.Kind"), media_id)
                item_target = _text(model.get("target"))
                if media_id and identity in existing_ids:
                    continue
                if not media_id and item_target and item_target in existing_targets:
                    continue
                additions.append(model)
                if media_id:
                    existing_ids.add(identity)
                elif item_target:
                    existing_targets.add(item_target)

            combined_view = dict(view)
            combined_view["items"] = list(self._filter_results) + additions
            self._append_control_items(FILTER_RESULTS, additions)
            self._filter_results.extend(additions)
            if self._browser_targets:
                self._browser_targets[-1] = target
            else:
                self._browser_targets = [target]
            self._browser_view = combined_view
            # Criteria and page chrome remain mounted while infinite results grow.
        except Exception as exc:
            _log(
                "Could not load discovery results page: {0}".format(exc),
                xbmc.LOGERROR,
            )
        finally:
            self.setProperty("App.Loading", "false")
            self._filter_page_loading = False

    def _show_search(self):
        try:
            keyboard = xbmc.Keyboard("", tr("Search movies and TV series"))
            keyboard.doModal()
            if not keyboard.isConfirmed():
                return
            query = _text(keyboard.getText()).strip()
        except Exception as exc:
            _log("Could not open search keyboard: {0}".format(exc), xbmc.LOGERROR)
            return
        if not query:
            return

        self._page = "search"
        self.setProperty("App.Page", "search")
        self.setProperty("App.PageTitle", tr("Search"))
        self.setProperty("App.PageSubtitle", tr("Results for “{0}”", query))
        self._select_navigation("")
        self._load_catalog("search", "results", force=True, query=query)

    def _clear_catalog_workspace(self, clear_origin=True):
        self._filter_overlay_active = False
        self._catalog_search_overlay_open = False
        self.setProperty("App.CatalogSearchOverlayOpen", "false")
        self.setProperty("App.CatalogWorkspace", "")
        self.setProperty("App.FilterTitle", "")
        self.setProperty("App.FilterSubtitle", "")
        if clear_origin:
            self._catalog_workspace_page = ""

    def _is_discovery_workspace(self):
        return (
            self._page in ("movies", "tv")
            and self._page == self._catalog_workspace_page
            and self._highlighted_catalog_tab == "filters"
        )

    def _show_catalog_search_workspace(self, page, focus=False):
        self._invalidate_loads()
        self.setProperty("App.FilterTitle", "")
        self.setProperty("App.FilterSubtitle", "")
        page = "tv" if page == "tv" else "movies"
        self._catalog_workspace_page = page
        self._page = page
        self._highlighted_catalog_tab = "search"
        self.setProperty("App.Page", page)
        self.setProperty("App.NavPage", page)
        self.setProperty("App.ActiveTab", "search")
        self.setProperty("App.CatalogWorkspace", "search")
        query = self._catalog_search_queries.get(page, "")
        prompt = (
            tr("Enter a TV series title")
            if page == "tv"
            else tr("Enter a movie title")
        )
        self.setProperty("App.CatalogSearchValue", query or prompt)
        self.setProperty("App.CatalogSearchExpandLabel", tr("Edit search") if query else tr("Search"))
        self.setProperty("App.CatalogSearchAction", tr("OK  •  Search"))
        self.setProperty("App.CatalogSearchRecentLabel", tr("Recent searches"))
        self.setProperty(
            "App.CatalogSearchWorkspaceTitle",
            tr("Search TV series") if page == "tv" else tr("Search movies"),
        )
        self.setProperty(
            "App.CatalogSearchWorkspaceSubtitle",
            tr("Search every available series") if page == "tv"
            else tr("Search the film catalogue"),
        )
        self.setProperty(
            "App.CatalogSearchHasRun",
            "true" if query else "false",
        )
        self.setProperty("App.CatalogSearchClearLabel", tr("Clear"))
        self.setProperty("App.CatalogSearchCloseLabel", tr("Close"))
        self._catalog_search_overlay_open = bool(focus and not query)
        self.setProperty("App.CatalogSearchOverlayOpen", "true" if self._catalog_search_overlay_open else "false")
        self._publish_catalog_search_history()
        if query:
            self._apply_catalog_search_order()
        else:
            self._set_catalog([])
        self._publish_catalog_search_state()
        if focus:
            self._focus(CATALOG_SEARCH if self._catalog_search_overlay_open else CATALOG_SEARCH_COMPACT)

    def _open_catalog_search_overlay(self):
        if self._catalog_workspace_page != self._page or self._highlighted_catalog_tab != "search":
            return
        self._catalog_sort_open = False
        self.setProperty("App.CatalogSearchSortOpen", "false")
        self._catalog_search_overlay_open = True
        self.setProperty("App.CatalogSearchOverlayOpen", "true")
        self._focus(CATALOG_SEARCH)

    def _close_catalog_search_overlay(self, focus=True):
        self._catalog_search_overlay_open = False
        self.setProperty("App.CatalogSearchOverlayOpen", "false")
        if focus:
            self._focus(CATALOG_SEARCH_COMPACT)

    def _save_catalog_search_history(self):
        try:
            search_history.save(self.search_history_path, self._catalog_search_history)
        except OSError as exc:
            _log("Could not save search history: {0}".format(exc), xbmc.LOGWARNING)

    def _publish_catalog_search_history(self):
        queries = self._catalog_search_history.get(self._catalog_workspace_page, [])
        self._catalog_recent_items[:] = [
            {"label": query, "properties": {"App.SearchQuery": query}}
            for query in queries
        ]
        self._populate_control(CATALOG_RECENT, self._catalog_recent_items)
        self.setProperty("App.CatalogSearchHasRecent", "true" if queries else "false")

    def _publish_catalog_search_state(self):
        page = self._catalog_workspace_page
        query = self._catalog_search_queries.get(page, "")
        sort = self._catalog_search_sorts.get(page, "match")
        self.setProperty("App.CatalogSearchSortLabel", tr(dict(search_results.SORT_OPTIONS).get(sort, "Best match")))
        failed = self._catalog_search_errors.get(page, False)
        self.setProperty("App.CatalogSearchError", "true" if failed else "false")
        self.setProperty("App.CatalogSearchHeading", tr("Search results") if query else "")
        self.setProperty(
            "App.CatalogSearchCount",
            str(len(self._catalog_items)) if query and not failed else "",
        )
        if failed:
            title = "Search unavailable"
            hint = "Check the connection, then press OK to search again."
        elif query:
            title = "No matching titles"
            hint = "Try a shorter title or check the spelling."
        else:
            title = "Results will appear after you search."
            hint = ""
        self.setProperty("App.CatalogSearchEmpty", tr(title))
        self.setProperty("App.CatalogSearchEmptyHint", tr(hint))

    def _apply_catalog_search_order(self, reset_to_top=False):
        page = self._catalog_workspace_page
        # Preserve enrichment received while the cards were visible.
        visible = {search_results.identity(model): model for model in self._catalog_items}
        models = [visible.get(search_results.identity(model), model)
                  for model in self._catalog_search_results.get(page, [])]
        self._catalog_search_results[page] = models
        self._set_catalog(search_results.ordered(
            models, self._catalog_search_queries.get(page, ""),
            self._catalog_search_sorts.get(page, "match"), page=page,
        ))
        if reset_to_top and self._catalog_items:
            self.getControl(CATALOG).selectItem(0)
        self._publish_catalog_search_state()

    def _open_catalog_search_sort(self):
        page = self._catalog_workspace_page
        if page != self._page or not self._catalog_search_queries.get(page) or not self._catalog_items:
            return
        sort = self._catalog_search_sorts.get(page, "match")
        self._catalog_sort_options[:] = [
            {"label": tr(label), "properties": {"App.SearchSort": key,
             "App.Selected": "true" if key == sort else "false"}}
            for key, label in search_results.SORT_OPTIONS
        ]
        self._populate_control(CATALOG_SEARCH_SORT_OPTIONS, self._catalog_sort_options)
        self.getControl(CATALOG_SEARCH_SORT_OPTIONS).selectItem(
            next(index for index, (key, _) in enumerate(search_results.SORT_OPTIONS) if key == sort))
        self._catalog_sort_open = True
        self.setProperty("App.CatalogSearchSortOpen", "true")
        self._focus(CATALOG_SEARCH_SORT_OPTIONS)

    def _close_catalog_search_sort(self):
        self._catalog_sort_open = False
        self.setProperty("App.CatalogSearchSortOpen", "false")
        self._focus(CATALOG_SEARCH_SORT if self._catalog_items else CATALOG_SEARCH_COMPACT)

    def _fetch_catalog_search_page(self, target, page, generation):
        visited = set()
        while target and target not in visited:
            if self._close_event.is_set() or generation != self._load_generation:
                return None
            visited.add(target)
            view = self.browser_loader(target)
            if not isinstance(view, dict):
                return None
            items = _models(view.get("items"))
            continuation = next((_text(model.get("target")) for model in items
                                 if _text(model.get("command")).lower() == "browse"), "")
            if continuation in visited:
                continuation = ""
            models = [model for model in items
                      if _text(model.get("command")).lower() != "browse"
                      and search_results.eligible(model, page)]
            if models or not continuation:
                return dict(view, items=models, search_next_target=continuation)
            target = continuation
        return {"items": [], "search_next_target": ""}

    def _load_next_catalog_search_page_if_needed(self):
        page = self._catalog_workspace_page
        target = self._catalog_search_next_targets.get(page, "")
        if not target or self._catalog_page_loading or not self._catalog_items:
            return
        try:
            if self.getFocusId() != CATALOG:
                return
            position = self.getControl(CATALOG).getSelectedPosition()
        except Exception:
            return
        if position < max(0, len(self._catalog_items) - (self.catalog_columns * 2 + 1)):
            return
        self._catalog_page_loading = True
        generation = self._load_generation

        def load():
            try:
                return self._fetch_catalog_search_page(target, page, generation)
            except Exception as exc:
                _log("Could not load search page: {0}".format(exc), xbmc.LOGERROR)
                return None

        def apply(view):
            self._catalog_page_loading = False
            if view is None:
                return  # Keep the continuation available for a retry.
            models = self._catalog_search_results[page]
            seen = {search_results.identity(model) for model in models}
            for model in _models(view.get("items")):
                identity = search_results.identity(model)
                if identity not in seen:
                    models.append(model)
                    seen.add(identity)
            self._catalog_search_next_targets[page] = view.get("search_next_target", "")
            self._apply_catalog_search_order()

        if self.async_loading:
            self._submit_load(("search-page", target), load, apply)
        else:
            apply(load())

    def _show_catalog_search(self):
        page = self._catalog_workspace_page
        if page not in ("movies", "tv"):
            page = "tv" if self._page == "tv" else "movies"
        current_query = self._catalog_search_queries.get(page, "")
        title = tr("Search TV series") if page == "tv" else tr("Search movies")
        try:
            keyboard = xbmc.Keyboard(current_query, title)
            keyboard.doModal()
            if not keyboard.isConfirmed():
                return
            query = _text(keyboard.getText()).strip()
        except Exception as exc:
            _log("Could not open catalog search keyboard: {0}".format(exc), xbmc.LOGERROR)
            return
        self._run_catalog_search(query)

    def _run_catalog_search(self, query):
        page = self._catalog_workspace_page
        query = _text(query).strip()
        if page not in ("movies", "tv") or not query or not callable(self.browser_loader):
            return

        action = (
            "menu_item_tvshows_search"
            if page == "tv"
            else "menu_item_movies_search"
        )
        target = "plugin://{0}/?{1}".format(
            ADDON_ID,
            urllib.parse.urlencode({
                "action": action,
                "search_query": query,
            }),
        )
        self._invalidate_loads()
        self._catalog_search_queries[page] = query
        self.setProperty("App.CatalogSearchExpandLabel", tr("Edit search"))
        self._catalog_search_results[page] = []
        self._catalog_search_next_targets[page] = ""
        self._catalog_search_errors[page] = False
        self.setProperty("App.CatalogSearchValue", query)
        self.setProperty("App.CatalogSearchHasRun", "true")
        history = self._catalog_search_history[page]
        history[:] = [query] + [entry for entry in history if entry.casefold() != query.casefold()]
        del history[search_history.LIMIT:]
        self._save_catalog_search_history()
        self._publish_catalog_search_history()
        self._set_catalog([])
        self._publish_catalog_search_state()
        self.setProperty("App.Loading", "true")
        generation = self._load_generation

        def load():
            try:
                return self._fetch_catalog_search_page(target, page, generation)
            except Exception as exc:
                _log("Could not search {0}: {1}".format(page, exc), xbmc.LOGERROR)
                return None

        def apply(view):
            models = [
                model for model in _models(view.get("items") if view else None)
                if _text(model.get("command")).lower() != "browse"
            ]
            self._catalog_search_errors[page] = view is None
            self._catalog_search_results[page] = models
            self._catalog_search_next_targets[page] = view.get("search_next_target", "") if view else ""
            self.setProperty("App.Loading", "false")
            self._apply_catalog_search_order()
            # A fresh query starts at the first result. Returning from details
            # uses the existing selection preservation in _set_catalog instead.
            if models:
                self.getControl(CATALOG).selectItem(0)
            self._focus(CATALOG if models else CATALOG_SEARCH_COMPACT)

        if self.async_loading:
            self._submit_load(("search", target), load, apply)
        else:
            apply(load())

    def _show_discovery_workspace(self, page, focus=False):
        page = "tv" if page == "tv" else "movies"
        target = _text(self.discovery_targets.get(page)).strip()
        if not target or not callable(self.browser_loader):
            return
        already_loaded = (
            self._catalog_workspace_page == page
            and _text(self._browser_view.get("layout")).lower() == "filter_studio"
            and self._page == page
        )
        self._catalog_workspace_page = page
        self.setProperty("App.CatalogWorkspace", "filters")
        self.setProperty("App.ActiveTab", "filters")
        if already_loaded:
            if focus:
                self._focus(
                    FILTER_GROUPS
                    if self._filter_groups
                    else FILTER_ACTIONS
                    if self._filter_actions
                    else TABS
                )
            return
        self._browser_origin = page
        self._browser_targets = []
        self._open_browser(target, focus=focus)

    def _load_home_background(self):
        try:
            if self._close_event.is_set():
                return
            loaded = self.home_loader()
            batches = loaded if hasattr(loaded, "__next__") else iter((loaded,))
            for loaded in batches:
                with self._ui_lock:
                    if self._close_event.is_set():
                        return
                    if isinstance(loaded, dict):
                        movies, shows = loaded.get("movies"), loaded.get("tv")
                        self.setProperty("App.HomeError", "true" if loaded.get("errors") else "false")
                    elif isinstance(loaded, (list, tuple)) and len(loaded) == 2:
                        movies, shows = loaded
                        self.setProperty("App.HomeError", "false")
                    else:
                        raise ValueError("No recommendation response")
                    for control_id, models in ((HOME_SECONDARY, movies), (HOME_TERTIARY, shows)):
                        if models is None:
                            continue
                        selection = self._control_selection(control_id)
                        self._items_by_control[control_id][:] = _models(models)
                        self._populate_control(control_id, self._items_by_control[control_id])
                        self._restore_control_selection(control_id, selection)
                    self._publish_home_state()
        except Exception as exc:
            _log("Could not refresh home artwork: {0}".format(exc), xbmc.LOGWARNING)
            if not self._close_event.is_set():
                self.setProperty("App.HomeError", "true")
        finally:
            if not self._close_event.is_set():
                self.setProperty("App.HomeReady", "true")

    def _publish_home_state(self):
        for control_id, suffix in zip(HOME_SHELVES, ("Primary", "Secondary", "Tertiary")):
            models = self._items_by_control[control_id]
            self.setProperty("App.HasHome" + suffix, "true" if models else "false")
            self.setProperty("App.Home" + suffix + "Count", str(len(models)))
        populated = [control_id for control_id in HOME_SHELVES if self._items_by_control[control_id]]
        if self._home_focus_control not in populated:
            self._home_focus_control = populated[0] if populated else HOME_PRIMARY
        self.setProperty("App.HomeShelf", str(self._home_focus_control))
        self.setProperty("App.HasHomeContent", "true" if populated else "false")

    def _refresh_downloads_background(self):
        last_download_refresh = 0
        while not self._close_event.wait(.25 if self.async_loading else DOWNLOAD_REFRESH_INTERVAL_SECONDS):
            with self._ui_lock:
                if self._close_event.is_set():
                    return
                self._consume_playback_outcome()
            if self._page == "downloads":
                if time.monotonic() - last_download_refresh >= DOWNLOAD_REFRESH_INTERVAL_SECONDS:
                    with self._ui_lock:
                        self._refresh_state(downloads_only=True)
                    last_download_refresh = time.monotonic()
                continue
            with self._ui_lock:
                if self._close_event.is_set():
                    return
                if self.async_loading and self._page == "home" and not self._home_primary_loaded and callable(self.home_primary_loader):
                    def apply_primary(models):
                        selection = self._control_selection(HOME_PRIMARY)
                        self.home_primary[:] = _models(models)
                        self._populate_control(HOME_PRIMARY, self.home_primary)
                        self._restore_control_selection(HOME_PRIMARY, selection)
                        self._publish_home_state()
                        self._home_primary_loaded = True
                    self._submit_load(("home-primary",), self.home_primary_loader, apply_primary)
                if self.async_loading:
                    self._enrich_catalog_rows()
                if self._page != "browse" or not self._browser_targets:
                    continue
                target = self._browser_targets[-1]
                try:
                    query = urllib.parse.parse_qs(urllib.parse.urlsplit(target).query)
                    action = (query.get("action") or [""])[0]
                except Exception:
                    action = ""
                if action in ("show_streams", "list_movie_versions", "show_downloads_menu"):
                    self._open_browser(target, replace=True, silent=True)

    def _consume_playback_outcome(self):
        try:
            window = xbmcgui.Window(10000)
            raw = window.getProperty("MediaHub.PlaybackOutcome")
            if not raw:
                return
            window.clearProperty("MediaHub.PlaybackOutcome")
            context = json.loads(raw)
        except Exception:
            return
        if not isinstance(context, dict) or context.get("mode") != "modern":
            return
        self._refresh_state()
        if context.get("media_type") == "episode":
            fields = {key: context[key] for key in (
                "tv_id", "season", "episode_id", "episode_number",
                "tv_title", "poster", "fanart") if context.get(key) not in (None, "")}
            fields["action"] = "post_watch"
            target = "plugin://{0}/?{1}".format(ADDON_ID, urllib.parse.urlencode(fields))
            if self._page == "browse" and self._browser_targets:
                # The view loads asynchronously; stop polling the old picker.
                self._browser_targets[-1] = target
            self._open_browser(target, replace=self._page == "browse")
        elif context.get("media_type") == "movie" and self._page == "browse":
            self._close_browser_level()

    def _enrich_catalog_rows(self):
        if not callable(self.catalog_metadata_loader):
            return
        if self._page in ("movies", "tv", "search", "favorites"):
            control_id, models = CATALOG, self._catalog_items
        elif self._page == "filterresults":
            control_id, models = FILTER_RESULTS, self._filter_results
        elif self._page == "home":
            control_id = next((shelf for shelf in (HOME_PRIMARY, HOME_SECONDARY, HOME_TERTIARY)
                               if any(m.get("catalog_source") and not m.get("catalog_enriched")
                                      and m.get("catalog_retry_at", 0) <= time.monotonic()
                                      for m in self._items_by_control[shelf])), None)
            if control_id is None:
                return
            models = self._items_by_control[control_id]
        else:
            return
        try:
            start = max(0, self.getControl(control_id).getSelectedPosition())
        except Exception:
            start = 0
        ordered = list(models[start:]) + list(models[:start])
        for model in [m for m in ordered if m.get("catalog_source") and not m.get("catalog_enriched")
                      and m.get("catalog_retry_at", 0) <= time.monotonic()][:3]:
            identity = (_model_property(model, "App.Kind"), _model_property(model, "App.Id"))
            def apply(updated, identity=identity, models=models, control_id=control_id):
                for index, current in enumerate(models):
                    if (_model_property(current, "App.Kind"), _model_property(current, "App.Id")) == identity:
                        # Cache lists share these model objects; patch the object as well as its ListItem.
                        current.clear()
                        current.update(updated)
                        self._update_list_item(self.getControl(control_id).getListItem(index), current)
                        break
            def load(model=model):
                try:
                    return self.catalog_metadata_loader(model)
                except Exception as exc:
                    _log("Optional catalog metadata unavailable: {0}".format(exc), xbmc.LOGWARNING)
                    return dict(model, catalog_retry_at=time.monotonic() + 60)
            self._submit_load(("catalog-metadata", control_id, identity), load, apply)

    def _set_catalog(self, models):
        selection = self._control_selection(CATALOG)
        self._catalog_items[:] = _models(models)
        self._populate_control(CATALOG, self._catalog_items)
        self._restore_control_selection(CATALOG, selection)
        self.setProperty("App.HasCatalog", "true" if self._catalog_items else "false")

    def _show_detail(self, model):
        self._invalidate_loads()
        if self._page in BROWSER_PAGES:
            try:
                browser_focus_id = int(self.getFocusId())
            except (TypeError, ValueError):
                browser_focus_id = None
            browser_selection = (
                self._control_selection(browser_focus_id)
                if browser_focus_id in self._items_by_control
                else {}
            )
            # Kodi can report the temporary navigation handoff as focused while
            # a result click is being dispatched. The clicked model is the
            # authoritative return target, so retain it directly.
            if self._page == "filterresults":
                clicked_target = _text(model.get("target"))
                for index, candidate in enumerate(self._filter_results):
                    if candidate is model or (
                        clicked_target
                        and _text(candidate.get("target")) == clicked_target
                    ):
                        browser_focus_id = FILTER_RESULTS
                        browser_selection = {
                            "position": index,
                            "target": clicked_target,
                            "command": _text(model.get("command")),
                            "label": _text(model.get("label")),
                            "filter_key": _model_property(
                                model,
                                "App.FilterKey",
                            ),
                        }
                        break
            self._browser_return_state = {
                "page": self._page,
                "targets": list(self._browser_targets),
                "view": dict(self._browser_view),
                "items": list(self._browser_items),
                "focus_id": browser_focus_id,
                "selection": browser_selection,
            }
        elif self._page != "detail":
            self._browser_return_state = None
        self._previous_page = self._page if self._page != "detail" else self._previous_page
        self._page = "detail"
        self.setProperty("App.Page", "detail")

        properties = model.get("properties") if isinstance(model.get("properties"), dict) else {}
        is_movie = properties.get("App.Kind") == "movie"
        detail_values = {
            "App.Detail.Title": properties.get("MediaHub.Title") or model.get("label"),
            "App.Detail.Eyebrow": properties.get("MediaHub.Eyebrow") or "MEDIA HUB",
            "App.Detail.Meta": properties.get("MediaHub.Meta") or model.get("label2"),
            "App.Detail.Description": properties.get("MediaHub.Description"),
            "App.Detail.HeroDescription": (
                properties.get("MediaHub.HeroDescription")
                or properties.get("MediaHub.Description")
            ),
            "App.Detail.Year": properties.get("App.Year") or "—",
            "App.Detail.Rating": properties.get("App.Rating") or "—",
            "App.Detail.Kind": properties.get("App.KindLabel") or "Media",
            "App.Detail.Fanart": (model.get("art") or {}).get("fanart", ""),
            "App.Detail.Poster": (model.get("art") or {}).get("poster", ""),
            "App.Detail.IsTV": (
                "true" if properties.get("App.Kind") == "tv" else "false"
            ),
            "App.Detail.Director": (
                tr("Director") + ": " + _text(properties.get("App.Director"))
                if is_movie and properties.get("App.Director") else ""
            ),
            "App.Detail.Cast": (
                tr("Cast") + ": " + _text(properties.get("App.Cast"))
                if is_movie and properties.get("App.Cast") else ""
            ),
        }
        # Preserve the original name and identify the score without crowding the cards.
        original = properties.get("App.OriginalTitle")
        if original and original not in _text(detail_values["App.Detail.Title"]):
            detail_values["App.Detail.Title"] += " / " + original
        detail_values["App.Detail.LongTitle"] = (
            "true" if len(_text(detail_values["App.Detail.Title"])) > 32 else "false"
        )
        if properties.get("App.SeriesStatus"):
            detail_values["App.Detail.Meta"] = "  ·  ".join(filter(None, (
                detail_values["App.Detail.Meta"], properties["App.SeriesStatus"],
            )))
        if properties.get("App.Rating"):
            detail_values["App.Detail.Meta"] = _text(detail_values["App.Detail.Meta"]).replace(
                "★ " + properties["App.Rating"], "TMDB " + properties["App.Rating"] + "/10",
            )
        for key, value in detail_values.items():
            self.setProperty(key, _text(value))

        target = _text(model.get("target"))
        self._detail_target = target
        if (is_movie and model.get("catalog_source")
                and callable(self.catalog_metadata_loader)
                and (not properties.get("App.Director") or not properties.get("App.Cast"))):
            def load():
                try:
                    return self.catalog_metadata_loader(model)
                except Exception as exc:
                    _log("Optional movie credits unavailable: {0}".format(exc), xbmc.LOGWARNING)
                    return model

            def apply(updated):
                if self._page != "detail" or self._detail_target != target:
                    return
                credits = updated.get("properties") or {}
                for field, label in (("Director", "Director"), ("Cast", "Cast")):
                    value = _text(credits.get("App." + field))
                    self.setProperty("App.Detail." + field,
                                     tr(label) + ": " + value if value else "")

            self._submit_load(("detail-metadata", target), load, apply)
        primary_label = tr("SEASONS") if properties.get("App.Kind") == "tv" else tr("PLAY")
        actions = [
            {
                "label": primary_label,
                "command": "browse" if callable(self.browser_loader) else "navigate",
                "target": target,
                "properties": {"App.ActionGlyph": "▶", "App.Primary": "true"},
            },
            {
                "label": tr("BACK"),
                "command": "back_detail",
                "target": "",
                "properties": {"App.ActionGlyph": "←"},
            },
        ]
        self._items_by_control[DETAIL_ACTIONS] = actions
        self._populate_control(DETAIL_ACTIONS, actions)

        self._focus(DETAIL_ACTIONS)

    def _activate_detail_action(self, model):
        command = _text(model.get("command")).strip().lower()
        if command == "back_detail":
            self._show_page(self._previous_page, load=False)
        else:
            self._activate(model)

    def _activate(self, model):
        command = _text(model.get("command")).strip().lower()
        target = _text(model.get("target")).strip()

        if command == "page":
            self._show_page(_model_property(model, "App.Page", "home"), load=True)
        elif command == "detail":
            self._show_detail(model)
        elif command == "browse":
            self._open_browser(target)
        elif command == "browser_replace":
            self._open_browser(target, replace=True)
        elif command == "confirm_action":
            self._open_action_confirmation(model)
        elif command == "noop":
            return
        elif command == "browser_back":
            self._close_browser_level()
        elif command == "edit_filters":
            if target:
                self._open_browser(target)
        elif command == "apply_filters":
            if target:
                current_filter_target = (
                    self._browser_targets[-1]
                    if self._browser_targets
                    else ""
                )
                self._browser_targets = (
                    [current_filter_target]
                    if current_filter_target
                    else []
                )
                self._open_browser(target)
        elif command == "navigate":
            if target:
                self.result = {"command": "navigate", "target": target}
                self.close()
        elif command == "play":
            if target:
                if callable(self.resume_choice_loader):
                    try:
                        choice = self.resume_choice_loader(target)
                    except Exception as exc:
                        _log("Could not determine resume choice: {0}".format(exc), xbmc.LOGWARNING)
                        choice = None
                    if choice:
                        self._open_resume_choice(target, choice)
                        return
                handled = False
                if callable(self.play_handler):
                    reactivation_state = self._capture_reactivation_state()
                    self.setProperty("App.Loading", "true")
                    try:
                        outcome = self.play_handler(target)
                        handled = outcome is not False
                        if (
                            isinstance(outcome, dict)
                            and _text(outcome.get("command")).lower() == "browse"
                            and _text(outcome.get("target")).strip()
                        ):
                            self._open_browser(
                                _text(outcome.get("target")).strip()
                            )
                        elif outcome is True:
                            self._reactivation_state = reactivation_state
                            self._refresh_state()
                    except Exception as exc:
                        _log(
                            "Direct playback failed for {0}: {1}".format(
                                target, exc
                            ),
                            xbmc.LOGERROR,
                        )
                    finally:
                        self.setProperty("App.Loading", "false")
                if not handled:
                    xbmc.executebuiltin("PlayMedia({0})".format(target))
        elif command == "builtin":
            if target:
                xbmc.executebuiltin(target)
        elif command == "action":
            self._run_action(target)
        elif command == "run":
            if target:
                xbmc.executebuiltin("RunPlugin({0})".format(target))
        elif command == "settings":
            xbmc.executebuiltin("Addon.OpenSettings({0})".format(ADDON_ID))
        elif command == "stream_details":
            details = _model_property(model, "App.StreamDetails")
            dialog = xbmcgui.Dialog()
            textviewer = getattr(dialog, "textviewer", None)
            if callable(textviewer):
                textviewer(tr("Technical details"), details)
            else:
                ok = getattr(dialog, "ok", None)
                if callable(ok):
                    ok(tr("Technical details"), details)
        elif command == "back_detail":
            self._show_page(self._previous_page, load=False)
        else:
            _log("Ignored unsupported app command: {0}".format(command), xbmc.LOGWARNING)

    def _open_action_confirmation(self, model):
        target = _text(model.get("target")).strip()
        if not target:
            return
        separator = "&" if "?" in target else "?"
        confirmed_target = target + separator + "confirmed=true"
        self._context_items[:] = [
            {
                "label": _model_property(
                    model, "App.ConfirmActionLabel", tr("Clear history")
                ),
                "label2": tr("Downloaded files will remain on disk"),
                "command": "action",
                "target": confirmed_target,
                "properties": {
                    "App.Badge": tr("CONFIRM"),
                    "App.Destructive": "true",
                },
            },
            {
                "label": tr("Cancel"),
                "label2": tr("Go back without making changes"),
                "command": "noop",
                "target": "",
                "properties": {"App.Badge": tr("SAFE")},
            },
        ]
        self._populate_control(CONTEXT_MENU, self._context_items)
        try:
            self._context_origin_control = int(self.getFocusId())
        except Exception:
            self._context_origin_control = None
        self._context_open = True
        self.setProperty(
            "App.ContextTitle",
            _model_property(model, "App.ConfirmTitle", tr("Clear download history?")),
        )
        self.setProperty(
            "App.ContextSubtitle",
            _model_property(
                model,
                "App.ConfirmMessage",
                tr("Terminal history is removed; downloaded files are kept."),
            ),
        )
        self.setProperty("App.ContextEyebrow", tr("CONFIRM CLEANUP"))
        self.setProperty("App.ContextOpen", "true")
        try:
            self.getControl(CONTEXT_MENU).selectItem(1)
        except Exception:
            pass
        self._focus(CONTEXT_MENU)

    @staticmethod
    def _browser_view_signature(view):
        if not isinstance(view, dict):
            return None
        signature = [
            _text(view.get("title")),
            _text(view.get("subtitle")),
            _text(view.get("eyebrow")),
            _text(view.get("empty")),
            bool(view.get("loading_active")),
        ]
        for model in view.get("items") or ():
            if not isinstance(model, dict):
                signature.append(())
                continue
            properties = model.get("properties") or {}
            signature.append((
                _text(model.get("label")),
                _text(model.get("label2")),
                _text(model.get("target")),
                tuple(sorted(
                    (_text(key), _text(value))
                    for key, value in properties.items()
                )),
            ))
        signature.append(tuple(
            (
                _text(model.get("label")),
                _text(model.get("target")),
                _model_property(model, "App.Tab"),
                _model_property(model, "App.Selected"),
            )
            for model in view.get("tabs") or ()
            if isinstance(model, dict)
        ))
        signature.append(tuple(
            (
                _text(model.get("label")),
                _text(model.get("target")),
                _text(model.get("command")),
            )
            for model in view.get("actions") or ()
            if isinstance(model, dict)
        ))
        return tuple(signature)

    def _open_browser(self, target, replace=False, silent=False, focus=True, _loaded=_UNLOADED):
        target = _text(target).strip()
        if not target or not callable(self.browser_loader):
            return

        # Fixed filter options (and cached genres) can be built on the UI
        # thread. Keep the asynchronous loading veil for the first genre fetch
        # and for result requests, which can actually wait on the network.
        immediate_filter = (
            _loaded is _UNLOADED
            and not silent
            and callable(self.filter_view_ready)
            and self.filter_view_ready(target)
        )
        show_loading = not silent and not immediate_filter and (focus or self.async_loading)
        if self.async_loading and _loaded is _UNLOADED and not immediate_filter:
            if not silent:
                self._invalidate_loads()
                self.setProperty("App.Loading", "true")
            self._submit_load(("browser", target), lambda: self.browser_loader(target),
                lambda view: self._open_browser(target, replace=replace, silent=silent,
                    focus=focus, _loaded=view))
            return
        if immediate_filter:
            # A queued genre/results view must not replace the newer selection.
            self._invalidate_loads()
        previous_page = self._page
        restore_control_id = None
        restore_selection = None
        discovery_workspace = self._is_discovery_workspace()
        browser_transition = (
            previous_page in BROWSER_PAGES or discovery_workspace
        ) and not silent
        if replace and (previous_page in BROWSER_PAGES or discovery_workspace):
            try:
                candidate = int(self.getFocusId())
            except (TypeError, ValueError):
                candidate = None
            if candidate in self._items_by_control:
                restore_control_id = candidate
                restore_selection = self._control_selection(candidate)
        if show_loading:
            self.setProperty("App.Loading", "true")
        try:
            view = self.browser_loader(target) if _loaded is _UNLOADED else _loaded
        except Exception as exc:
            _log("Could not load browser target {0}: {1}".format(target, exc), xbmc.LOGERROR)
            try:
                xbmcgui.Dialog().notification(
                    "Media Hub",
                    tr("This screen could not be loaded."),
                    xbmcgui.NOTIFICATION_ERROR,
                    2500,
                )
            except Exception:
                pass
            return
        finally:
            if show_loading:
                self.setProperty("App.Loading", "false")

        if not isinstance(view, dict):
            return
        target = _text(view.get("resolved_target")) or target
        self.setProperty("App.MetadataStatus", tr(view.get("loading_status", "")))
        self.setProperty("App.MetadataBusy", "true" if view.get("loading_active") else "false")
        if callable(self.display_handler):
            same_session = view.get("browse_session") is not None and view.get("browse_session") is self._browser_view.get("browse_session")
            self.display_handler(view, self._prioritized_stream_models() if same_session else False)
        if silent and self._browser_view_signature(view) == self._browser_view_signature(
            self._browser_view
        ):
            return
        stream_picker_transition = (
            browser_transition
            and _text(view.get("layout")).strip().lower() == "stream_picker"
        )
        in_place_refresh = (
            restore_control_id == FILTER_OPTIONS
            and _text(view.get("layout")).strip().lower() == "filter_studio"
            and self._can_update_control_in_place(
                FILTER_OPTIONS,
                _models(view.get("options")),
            )
        )
        if (
            previous_page not in BROWSER_PAGES
            and previous_page != self._catalog_workspace_page
        ):
            self._browser_origin = previous_page
            self._browser_targets = []
        if replace and self._browser_targets:
            self._browser_targets[-1] = target
        elif not self._browser_targets or self._browser_targets[-1] != target:
            self._browser_targets.append(target)

        self._browser_view = dict(view)
        # Kodi can leave a focused list/panel visually empty when it is reset.
        # Option toggles keep the same semantic items, so update those ListItems
        # in place. Structural changes use the persistent navigation control as
        # a safe focus handoff.
        if (
            focus
            and not silent
            and (browser_transition or restore_control_id is not None)
        ) and not in_place_refresh and not stream_picker_transition:
            self._focus(NAV)
        self._apply_browser_view(
            view,
            focus=focus and not browser_transition and not silent,
        )
        if focus and restore_control_id is not None:
            focus_id = self._preferred_browser_focus(restore_control_id)
            if focus_id == restore_control_id:
                restored_position = (
                    self._restore_control_selection(
                        restore_control_id,
                        restore_selection,
                    )
                    if restore_control_id != BROWSER_TABS
                    else None
                )
                if not in_place_refresh and not silent:
                    self._defer_browser_focus(
                        focus_id,
                        target,
                        restored_position,
                    )
            else:
                self._focus(focus_id)
        elif focus and browser_transition and not silent:
            focus_id = self._preferred_browser_focus()
            if focus_id == FILTER_GROUPS and self._is_discovery_workspace():
                self._focus(focus_id)
            self._defer_browser_focus(
                focus_id,
                target,
                self._filter_group_position
                if focus_id == FILTER_GROUPS
                and _text(view.get("layout")).strip().lower()
                == "filter_studio"
                else None,
            )

    def _apply_browser_view(self, view, focus=True):
        layout = _text(view.get("layout")).strip().lower()
        if layout == "filter_studio":
            self._apply_filter_studio_view(view, focus=focus)
            return
        if layout == "filter_results":
            self._apply_filter_results_view(view, focus=focus)
            return

        self._page = "browse"
        self.setProperty("App.Page", "browse")
        self.setProperty("App.BrowserLayout", layout)
        # Use all results rather than the filtered list: a filter with no
        # matches must never bring the initial searching scene back.
        self.setProperty("App.StreamLoading", "true" if (
            layout == "stream_picker" and view.get("loading_active")
            and not view.get("items")
        ) else "false")
        self.setProperty(
            "App.BrowserBoundedVertical",
            "true" if view.get("navigation") == "bounded_vertical" else "false",
        )
        self.setProperty("App.NavPage", self._navigation_page("browse"))
        self._select_navigation(self._navigation_page("browse"))
        self.setProperty(
            "App.BrowserTitle",
            _text(view.get("title", tr("Browse"))),
        )
        self.setProperty("App.BrowserSubtitle", _text(view.get("subtitle", "")))
        self.setProperty(
            "App.BrowserEyebrow",
            _text(view.get("eyebrow", "MEDIA HUB")),
        )
        self.setProperty(
            "App.BrowserEmpty",
            _text(view.get("empty", tr("Nothing to show yet."))),
        )
        self.setProperty(
            "App.BrowserArt",
            _text(view.get("fanart", self.fallback_art)),
        )
        self.setProperty(
            "App.BrowserDepth",
            "{0:02d}".format(max(1, len(self._browser_targets))),
        )
        self._browser_tabs[:] = _models(view.get("tabs"))
        self._populate_control(BROWSER_TABS, self._browser_tabs)
        self.setProperty(
            "App.BrowserTabs",
            "true" if self._browser_tabs else "false",
        )
        active_tab = next(
            (
                _model_property(model, "App.Tab")
                for model in self._browser_tabs
                if _model_property(model, "App.Selected") == "true"
            ),
            _model_property(self._browser_tabs[0], "App.Tab")
            if self._browser_tabs else "",
        )
        self.setProperty("App.ActiveBrowserTab", active_tab)
        self._active_browser_tab = active_tab
        if active_tab:
            try:
                self.getControl(BROWSER_TABS).selectItem(next(
                    index
                    for index, model in enumerate(self._browser_tabs)
                    if _model_property(model, "App.Tab") == active_tab
                ))
            except Exception:
                pass
        self._browser_actions[:] = _models(view.get("actions"))
        self._populate_control(BROWSER_ACTIONS, self._browser_actions)
        self.setProperty(
            "App.BrowserActions",
            "true" if self._browser_actions else "false",
        )
        self._browser_items[:] = _models(view.get("items"))
        if layout == "stream_picker":
            selected_stream_filters = {
                _model_property(model, "App.StreamFilterKey")
                for model in self._stream_filters
                if _model_property(model, "App.Selected") == "true"
            }
            self._stream_all_items[:] = list(self._browser_items)
            self._stream_filters[:] = _models(view.get("filters"))
            if selected_stream_filters:
                for model in self._stream_filters:
                    properties = model.setdefault("properties", {})
                    properties["App.Selected"] = (
                        "true"
                        if _model_property(model, "App.StreamFilterKey")
                        in selected_stream_filters
                        else "false"
                    )
            self._populate_control(STREAM_FILTERS, self._stream_filters)
            self._apply_stream_filters(preserve_selection=False)
        else:
            self._stream_all_items[:] = []
            self._stream_filters[:] = []
            self._populate_control(BROWSER, self._browser_items)
        self.setProperty("App.HasBrowser", "true" if self._browser_items else "false")
        if callable(self.display_handler):
            ordered = list(self._browser_items)
            if layout == "stream_picker" and ordered:
                position = self._control_selection(STREAM_LIST)
                # Selection restoration is also applied by _open_browser.
                try:
                    index = self.getControl(STREAM_LIST).getSelectedPosition()
                    ordered = ordered[index:index + 8] + ordered[:index] + ordered[index + 8:]
                except Exception:
                    pass
            self.display_handler(view, ordered)
        if focus:
            self._focus(self._preferred_browser_focus())

    def _prioritized_stream_models(self):
        models = list(self._browser_items)
        try:
            index = max(0, self.getControl(STREAM_LIST).getSelectedPosition())
        except Exception:
            index = 0
        return models[index:index + 8] + models[:index] + models[index + 8:]

    def _toggle_stream_filter(self, model):
        key = _model_property(model, "App.StreamFilterKey")
        if not key:
            return
        if key == "clear":
            for filter_model in self._stream_filters:
                filter_model.setdefault("properties", {})[
                    "App.Selected"
                ] = "false"
        else:
            for filter_model in self._stream_filters:
                properties = filter_model.setdefault("properties", {})
                filter_key = _text(properties.get("App.StreamFilterKey"))
                if filter_key == key:
                    properties["App.Selected"] = (
                        "false"
                        if _text(properties.get("App.Selected")) == "true"
                        else "true"
                    )
        self._populate_control(STREAM_FILTERS, self._stream_filters)
        self._apply_stream_filters(preserve_selection=True)
        self._focus(STREAM_FILTERS)

    def _apply_stream_filters(self, preserve_selection=True):
        selection = (
            self._control_selection(STREAM_LIST)
            if preserve_selection else None
        )
        active = {
            _model_property(model, "App.StreamFilterKey")
            for model in self._stream_filters
            if _model_property(model, "App.Selected") == "true"
        }

        checking = set()

        def matches(model):
            properties = model.get("properties") or {}
            modern = "App.StreamCard.VideoVerified" in properties
            if not modern and _text(properties.get("App.MetadataPending")) == "true":
                checking.add(id(model))
                return True
            audio = _text(properties.get("App.StreamAudioCompact")).upper()
            subtitles = _text(
                properties.get("App.StreamSubtitlesCompact")
                or properties.get("App.Subtitles")
            ).upper()
            subtitle_state = _text(
                properties.get("App.SubtitleState")
            ).lower()
            has_full_local_subtitles = (
                subtitle_state == "available"
                if subtitle_state
                else "SK" in subtitles or "CZ" in subtitles
            )
            hdr = _text(
                properties.get("App.StreamHdrPill")
                or properties.get("App.StreamHdr")
            ).lower()
            quality = _text(properties.get("App.Quality")).upper()
            if modern:
                criteria = {
                    "local_audio": (
                        properties.get("App.StreamCard.AudioKnown") == "true",
                        properties.get("App.StreamCard.HasLocalAudio") == "true",
                    ),
                    "local_subtitles": (
                        properties.get("App.StreamCard.SubtitlesKnown") == "true",
                        properties.get("App.StreamCard.HasLocalSubtitles") == "true",
                    ),
                    "dolby_vision": (
                        properties.get("App.StreamCard.HdrKnown", properties.get("App.StreamCard.VideoVerified")) == "true",
                        "dolby vision" in hdr,
                    ),
                    "hdr10": (
                        properties.get("App.StreamCard.HdrKnown", properties.get("App.StreamCard.VideoVerified")) == "true",
                        "hdr10" in hdr,
                    ),
                    "4k": (
                        properties.get("App.StreamCard.ResolutionKnown", properties.get("App.StreamCard.VideoVerified")) == "true",
                        quality == "4K",
                    ),
                }
                uncertain = False
                for key in active:
                    known, accepted = criteria.get(key, (True, True))
                    if known and not accepted:
                        return False
                    uncertain |= not known
                if uncertain or (not active and properties.get("App.MetadataPending") == "true"):
                    checking.add(id(model))
                return True
            return (
                ("local_audio" not in active or "SK" in audio or "CZ" in audio)
                and (
                    "local_subtitles" not in active
                    or has_full_local_subtitles
                )
                and ("dolby_vision" not in active or "dolby vision" in hdr)
                and ("hdr10" not in active or "hdr10" in hdr)
                and ("4k" not in active or quality == "4K")
            )

        self._browser_items[:] = [
            model for model in self._stream_all_items if matches(model)
        ]
        self._populate_control(STREAM_LIST, self._browser_items)
        checking_count = sum(id(model) in checking for model in self._browser_items)
        summary = tr(
            "{0} matches · {1} checking · {2} total",
            len(self._browser_items) - checking_count, checking_count,
            len(self._stream_all_items),
        ) if active.difference(("clear",)) or checking_count else tr("{0} versions", len(self._stream_all_items))
        try:
            expected = float(self._browser_view.get("expected_runtime_minutes") or 0)
        except (TypeError, ValueError, OverflowError):
            expected = 0
        if 0 < expected < 10000:
            summary += " · " + tr("Expected runtime ≈{0} min", int(round(expected)))
        self.setProperty("App.StreamSummary", summary)
        self.setProperty(
            "App.HasBrowser", "true" if self._browser_items else "false"
        )
        self.setProperty(
            "App.BrowserEmpty",
            tr("No versions match these filters.")
            if active.difference(("clear",))
            else _text(
                self._browser_view.get("empty", tr("Nothing to show yet."))
            ),
        )
        if selection:
            self._restore_control_selection(STREAM_LIST, selection)

    def _apply_filter_studio_view(self, view, focus=True):
        page = "tv" if view.get("media_type") == "tv" else "movies"
        if not view.get("media_type") and self._catalog_workspace_page in ("movies", "tv"):
            page = self._catalog_workspace_page
        if self._page != page or not self._tabs:
            self._set_tabs(page)
        self._page = page
        self._catalog_workspace_page = page
        self._highlighted_catalog_tab = "filters"
        self.setProperty("App.Page", page)
        self.setProperty("App.CatalogWorkspace", "filters")
        self.setProperty("App.ActiveTab", "filters")
        title, subtitle = _PAGE_TITLES[page]
        self.setProperty("App.PageTitle", tr(title))
        self.setProperty("App.PageSubtitle", tr(subtitle))
        self.setProperty("App.NavPage", page)
        self._select_navigation(page)
        self._tab_position = next(
            index for index, model in enumerate(self._tabs)
            if _model_property(model, "App.Tab") == "filters"
        )
        try:
            self.getControl(TABS).selectItem(self._tab_position)
        except Exception:
            pass

        self._filter_groups[:] = _models(view.get("groups"))
        self._filter_options[:] = _models(view.get("options"))
        self._filter_actions[:] = _models(view.get("actions"))
        self._populate_control(FILTER_GROUPS, self._filter_groups)
        self._populate_control(FILTER_OPTIONS, self._filter_options)
        self._populate_control(FILTER_ACTIONS, self._filter_actions)
        primary_action_index = next(
            (
                index
                for index, model in enumerate(self._filter_actions)
                if _model_property(model, "App.Primary") == "true"
            ),
            0,
        )
        if self._filter_actions:
            try:
                self.getControl(FILTER_ACTIONS).selectItem(
                    primary_action_index
                )
            except Exception:
                pass

        selected_group_index = next(
            (
                index
                for index, model in enumerate(self._filter_groups)
                if _model_property(model, "App.Selected") == "true"
            ),
            0,
        )
        selected_group = (
            self._filter_groups[selected_group_index]
            if self._filter_groups
            else {}
        )
        if self._filter_groups:
            try:
                self.getControl(FILTER_GROUPS).selectItem(
                    selected_group_index
                )
            except Exception:
                pass
        self._filter_group_position = selected_group_index
        self._filter_requested_section = _text(view.get("section"))
        selected_option_index = next(
            (
                index
                for index, model in enumerate(self._filter_options)
                if _model_property(model, "App.Selected") == "true"
            ),
            0,
        )
        if self._filter_options:
            try:
                self.getControl(FILTER_OPTIONS).selectItem(
                    selected_option_index
                )
            except Exception:
                pass
        active_count = max(0, int(view.get("active_count") or 0))
        properties = {
            "App.FilterTitle": tr("Filters"),
            "App.FilterSubtitle": tr(view.get(
                "subtitle",
                "Adjust your selection without leaving the content",
            )),
            "App.FilterSummary": view.get("summary", ""),
            "App.FilterSectionTitle": view.get(
                "section_title",
                selected_group.get("label", ""),
            ),
            "App.FilterSectionHint": view.get("section_hint", ""),
            "App.FilterSectionStep": view.get("section_step", ""),
            "App.FilterSummaryTitle": tr("YOUR FILTERS"),
            "App.FilterControlHint": tr(
                "OK  •  Select     Back  •  Close"
            ),
            "App.FilterActiveCount": str(active_count),
            "App.FilterActiveLabel": (
                tr("{0} active filters", active_count)
                if active_count
                else tr("No active filters")
            ),
            "App.FilterHasOptions": (
                "true" if self._filter_options else "false"
            ),
            "App.FilterHasGroups": (
                "true" if self._filter_groups else "false"
            ),
            "App.FilterHasActions": (
                "true" if self._filter_actions else "false"
            ),
        }
        for key, value in properties.items():
            self.setProperty(key, _text(value))
        if focus:
            self._focus(
                FILTER_GROUPS
                if self._filter_groups
                else FILTER_ACTIONS
                if self._filter_actions
                else NAV
            )

    def _preview_filter_group(self, position):
        if not 0 <= position < len(self._filter_groups):
            return
        group = self._filter_groups[position]
        section = _model_property(group, "App.FilterKey")
        target = _text(group.get("target")).strip()
        if not section or not target:
            return
        self._filter_group_position = position
        if section == _text(self._browser_view.get("section")):
            if self._filter_requested_section != section:
                self._invalidate_loads()
            self._filter_requested_section = section
            return
        if section == self._filter_requested_section:
            return
        self._filter_requested_section = section
        self._open_browser(target, replace=True, focus=False)

    def _restore_discovery_tab_selection(self):
        for index, model in enumerate(self._tabs):
            if _model_property(model, "App.Tab") == "filters":
                self._tab_position = index
                try:
                    self.getControl(TABS).selectItem(index)
                except Exception:
                    pass
                return

    def _close_discovery_overlay(self):
        page = self._page
        tab = self._active_catalog_tab
        if not any(
            _model_property(model, "App.Tab") == tab
            and tab not in ("search", "filters")
            for model in self._tabs
        ):
            tab = next(
                (
                    _model_property(model, "App.Tab")
                    for model in self._tabs
                    if _model_property(model, "App.Tab")
                    not in ("search", "filters")
                ),
                "",
            )
        self._browser_targets = []
        self._clear_catalog_workspace()
        self._highlighted_catalog_tab = tab
        for index, model in enumerate(self._tabs):
            if _model_property(model, "App.Tab") == tab:
                self._tab_position = index
                try:
                    self.getControl(TABS).selectItem(index)
                except Exception:
                    pass
                break
        if tab:
            self._load_catalog(page, tab, focus=False, show_loading=False)
        self._focus(TABS)

    def _apply_filter_results_view(self, view, focus=True):
        self._filter_overlay_active = False
        self._page = "filterresults"
        self.setProperty("App.Page", "filterresults")
        self.setProperty("App.CatalogWorkspace", "")
        navigation_page = self._navigation_page("filterresults", view)
        self.setProperty("App.NavPage", navigation_page)
        self._select_navigation(navigation_page)

        self._filter_results[:] = _models(view.get("items"))
        self._filter_result_actions[:] = _models(view.get("result_actions"))
        self._filter_result_chips[:] = _models(view.get("chips"))
        self._filter_pagination[:] = _models(
            view.get("pagination_actions")
        )
        self._populate_control(FILTER_RESULTS, self._filter_results)
        self._populate_control(
            FILTER_RESULT_ACTIONS,
            self._filter_result_actions,
        )
        self._populate_control(
            FILTER_RESULT_CHIPS,
            self._filter_result_chips,
        )
        self._populate_control(
            FILTER_PAGINATION,
            self._filter_pagination,
        )
        primary_action_index = next(
            (
                index
                for index, model in enumerate(
                    self._filter_result_actions
                )
                if _model_property(model, "App.Primary") == "true"
            ),
            0,
        )
        if self._filter_result_actions:
            try:
                self.getControl(FILTER_RESULT_ACTIONS).selectItem(
                    primary_action_index
                )
            except Exception:
                pass
        properties = {
            "App.FilterResultsTitle": view.get("title", tr("Discovery Results")),
            "App.FilterResultsSubtitle": view.get("subtitle", ""),
            "App.FilterResultsEyebrow": view.get("eyebrow", "FILTERED RESULTS"),
            "App.FilterEditHint": tr("OK · Edit filter"),
            "App.FilterResultsEmptyTitle": view.get(
                "empty_title",
                tr("No matching titles"),
            ),
            "App.FilterSummary": view.get("summary", ""),
            "App.FilterResultsEmpty": view.get(
                "empty",
                tr("No titles match these filters."),
            ),
            "App.FilterHasResults": (
                "true" if self._filter_results else "false"
            ),
            "App.FilterHasChips": (
                "true" if self._filter_result_chips else "false"
            ),
            "App.FilterHasPagination": (
                "true" if self._filter_pagination else "false"
            ),
            "App.FilterHasResultActions": (
                "true" if self._filter_result_actions else "false"
            ),
        }
        for key, value in properties.items():
            self.setProperty(key, _text(value))
        if focus:
            self._focus(
                FILTER_RESULTS
                if self._filter_results
                else FILTER_RESULT_ACTIONS
                if self._filter_result_actions
                else NAV
            )

    def _restore_browser_state(self, focus=True):
        state = self._browser_return_state
        if not isinstance(state, dict):
            return False
        view = state.get("view")
        if not isinstance(view, dict):
            return False
        self._browser_targets = list(state.get("targets") or [])
        self._browser_view = dict(view)
        if _text(view.get("layout")).strip().lower() not in (
            "filter_studio",
            "filter_results",
        ):
            self._browser_items[:] = _models(state.get("items"))
            view = dict(view)
            view["items"] = list(self._browser_items)
        self._focus(NAV)
        self._apply_browser_view(view, focus=False)
        try:
            saved_focus_id = int(state.get("focus_id"))
        except (TypeError, ValueError):
            saved_focus_id = None
        focus_id = self._preferred_browser_focus(saved_focus_id)
        restored_position = None
        if focus_id == saved_focus_id:
            restored_position = self._restore_control_selection(
                focus_id,
                state.get("selection"),
            )
        if focus:
            target = (
                self._browser_targets[-1]
                if self._browser_targets
                else ""
            )
            if target:
                self._defer_browser_focus(
                    focus_id,
                    target,
                    restored_position,
                )
            else:
                self._focus(focus_id)
        self._browser_return_state = None
        return True

    def _preferred_browser_focus(self, preferred=None):
        if preferred == BROWSER_TABS and self._browser_tabs:
            return BROWSER_TABS
        if _text(self._browser_view.get("layout")).lower() == "stream_picker":
            if preferred in (STREAM_FILTERS, STREAM_LIST) and (
                self._items_by_control.get(preferred)
            ):
                return preferred
            return (
                STREAM_LIST
                if self._browser_items
                else STREAM_FILTERS
                if self._stream_filters
                else NAV
            )
        if (
            preferred in self._items_by_control
            and self._items_by_control.get(preferred)
        ):
            return preferred
        if self._is_discovery_workspace():
            return (
                FILTER_GROUPS
                if self._filter_groups
                else FILTER_ACTIONS
                if self._filter_actions
                else NAV
            )
        if self._page == "filterresults":
            return (
                FILTER_RESULTS
                if self._filter_results
                else FILTER_RESULT_ACTIONS
                if self._filter_result_actions
                else NAV
            )
        # Downloads use tabs as filters, but the rows are the primary task.
        # Enter the first row when the active category contains downloads;
        # retain the tabs as the fallback for an empty category.
        if (
            self._navigation_page("browse") == "downloads"
            and self._browser_items
        ):
            return BROWSER
        if self._browser_tabs:
            return BROWSER_TABS
        if self._browser_items:
            return BROWSER
        if self._browser_actions:
            return BROWSER_ACTIONS
        return NAV

    def _preferred_page_focus(self, page=None, preferred=None):
        """Return a visible, actionable focus target for the current page."""
        page = _text(page or self._page) or "home"
        if preferred == NAV:
            return NAV
        if page == "home":
            if preferred in HOME_SHELVES and self._items_by_control[preferred]:
                return preferred
            return next((control for control in HOME_SHELVES if self._items_by_control[control]), NAV)
        if page in ("movies", "tv"):
            if self._catalog_workspace_page == page:
                if self._highlighted_catalog_tab == "search":
                    if self._catalog_search_overlay_open:
                        return CATALOG_SEARCH
                    if preferred == CATALOG and self._catalog_items:
                        return CATALOG
                    if preferred in (CATALOG_SEARCH_SORT, CATALOG_SEARCH_SORT_OPTIONS) and self._catalog_items and self._catalog_search_queries.get(page):
                        return CATALOG_SEARCH_SORT
                    return CATALOG_SEARCH_COMPACT
                if self._highlighted_catalog_tab == "filters":
                    if preferred in (FILTER_GROUPS, FILTER_OPTIONS, FILTER_ACTIONS) and self._items_by_control.get(preferred):
                        return preferred
                    return (
                        FILTER_GROUPS
                        if self._filter_groups
                        else FILTER_ACTIONS
                        if self._filter_actions
                        else TABS
                    )
            if preferred == CATALOG and self._catalog_items:
                return CATALOG
            if preferred == TABS and self._tabs:
                return TABS
            return CATALOG if self._catalog_items else TABS if self._tabs else NAV
        if page == "favorites":
            return CATALOG if self._catalog_items else EMPTY_ACTION
        if page == "history":
            return HISTORY if self.history_items else EMPTY_ACTION
        if page == "downloads":
            return DOWNLOADS if self.download_items else EMPTY_ACTION
        if page == "settings":
            return SETTINGS if self.settings_items else NAV
        if page == "search":
            if preferred == SEARCH:
                return SEARCH
            return CATALOG if self._catalog_items else SEARCH
        if page == "browse":
            return self._preferred_browser_focus(preferred)
        if page == "filterresults":
            return (
                FILTER_RESULTS
                if self._filter_results
                else FILTER_RESULT_ACTIONS
                if self._filter_result_actions
                else NAV
            )
        if page == "detail" and self._items_by_control.get(DETAIL_ACTIONS):
            return DETAIL_ACTIONS
        return NAV

    def _defer_browser_focus(self, control_id, _target, position=None):
        """Queue focus restoration on Kodi's GUI thread after this callback."""

        if (
            (self._page not in BROWSER_PAGES and not self._is_discovery_workspace())
            or self._preferred_browser_focus(control_id) != control_id
        ):
            return
        if position is None:
            try:
                position = int(
                    self.getControl(control_id).getSelectedPosition()
                )
            except Exception:
                position = 0
        else:
            try:
                position = int(position)
            except (TypeError, ValueError):
                position = 0
        # Unlike WindowXML.setFocusId, the builtin is queued for the next GUI
        # message and therefore repaints a container that was just reset.
        xbmc.executebuiltin(
            "Control.SetFocus({0},{1},absolute)".format(
                control_id,
                max(0, position),
            )
        )

    def _navigation_page(self, page, view=None):
        view = view if isinstance(view, dict) else self._browser_view
        if page in ("filters", "filterresults"):
            return "tv" if view.get("media_type") == "tv" else "movies"
        if page == "browse":
            origin = self._browser_origin
            if origin in ("movies", "tv", "home", "downloads", "favorites",
                          "history", "settings", "search"):
                return origin
            if self._previous_page in ("movies", "tv"):
                return self._previous_page
            return "home"
        if page == "detail":
            return self._navigation_page(self._previous_page, view)
        return page

    def _reload_browser(self, target=None):
        if target:
            self._open_browser(target, replace=True)
        elif self._browser_targets:
            self._open_browser(self._browser_targets[-1], replace=True)

    def _close_browser_level(self):
        if len(self._browser_targets) > 1:
            self._browser_targets.pop()
            target = self._browser_targets.pop()
            self._open_browser(target)
            return
        self._browser_targets = []
        origin = self._browser_origin
        if origin in BROWSER_PAGES:
            origin = "home"
        self._show_page(origin, load=False)

    def _run_action(self, target):
        if not target or not callable(self.action_handler):
            return
        try:
            next_target = self.action_handler(target)
        except Exception as exc:
            _log("Action failed for {0}: {1}".format(target, exc), xbmc.LOGERROR)
            return
        self._refresh_state()
        self._reload_browser(_text(next_target).strip() if next_target else None)

    def _refresh_state(self, downloads_only=False):
        if not callable(self.state_loader):
            return
        try:
            state = self.state_loader()
        except Exception as exc:
            _log("Could not refresh app state: {0}".format(exc), xbmc.LOGWARNING)
            return
        if not isinstance(state, dict):
            return

        if "reduce_catalog_motion" in state:
            self.reduce_catalog_motion = bool(state["reduce_catalog_motion"])
            self.setProperty("App.ReduceCatalogMotion", "true" if self.reduce_catalog_motion else "false")
        if not downloads_only:
            # Re-read personal viewing state after playback or a history change.
            # Enrichment stays in background workers and reuses cached catalog metadata.
            for models in list(self._catalog_cache.values()) + [self._catalog_items, self._filter_results]:
                for model in models:
                    if model.get("catalog_source"):
                        model.pop("catalog_enriched", None)
            favourites = state.get("favorites")
            if favourites is not None:
                focus_id = self._current_focus_id()
                selection = self._control_selection(CATALOG)
                self.favorite_items[:] = _models(favourites)
                if self._page == "favorites":
                    self._set_catalog(self.favorite_items)
                    if focus_id == CATALOG:
                        if self._catalog_items:
                            self._restore_control_selection(CATALOG, selection)
                        else:
                            self._focus(EMPTY_ACTION)
            history = state.get("history")
            if history is not None:
                focus_id = self._current_focus_id()
                selection = self._control_selection(HISTORY)
                self.history_items[:] = _models(history)
                self._populate_control(HISTORY, self.history_items)
                self.setProperty(
                    "App.HasHistory",
                    "true" if self.history_items else "false",
                )
                if self._page == "history" and focus_id == HISTORY:
                    if self.history_items:
                        self._restore_control_selection(HISTORY, selection)
                    else:
                        self._focus(EMPTY_ACTION)
        if not downloads_only and state.get("continue_watching") is not None:
            self._home_primary_loaded = False
            selection = self._control_selection(HOME_PRIMARY)
            self.home_primary[:] = _models(state["continue_watching"])
            self._populate_control(HOME_PRIMARY, self.home_primary)
            self._restore_control_selection(HOME_PRIMARY, selection)
            self._publish_home_state()
            if self._page == "home" and self._current_focus_id() == HOME_PRIMARY and not self.home_primary:
                self._focus(self._preferred_page_focus("home"))
        downloads = state.get("downloads")
        if downloads is not None:
            refreshed_downloads = _models(downloads)
            if refreshed_downloads != self.download_items:
                focus_id = self._current_focus_id()
                selection = self._control_selection(DOWNLOADS)
                self.download_items[:] = refreshed_downloads
                self._populate_control(DOWNLOADS, self.download_items)
                self.setProperty(
                    "App.HasDownloads",
                    "true" if self.download_items else "false",
                )
                if self.download_items:
                    self._restore_control_selection(DOWNLOADS, selection)
                if (
                    self._page == "downloads"
                    and focus_id == DOWNLOADS
                    and not self.download_items
                ):
                    self._focus(EMPTY_ACTION)

    def _current_focus_id(self):
        try:
            return int(self.getFocusId())
        except (TypeError, ValueError):
            return None

    def _control_selection(self, control_id):
        models = self._items_by_control.get(control_id)
        if models is None:
            return {}
        try:
            position = int(self.getControl(control_id).getSelectedPosition())
        except Exception:
            position = 0
        selected = models[position] if 0 <= position < len(models) else None
        return {
            "position": position,
            "target": _text(selected.get("target")) if selected else "",
            "command": _text(selected.get("command")) if selected else "",
            "label": _text(selected.get("label")) if selected else "",
            "media_id": (_model_property(selected, "App.StreamId") or _model_property(selected, "App.HomeId")) if selected else "",
            "filter_key": (
                _model_property(selected, "App.FilterKey")
                if selected else ""
            ),
        }

    def _open_context_menu(self):
        try:
            control_id = int(self.getFocusId())
        except Exception:
            return
        model = self._selected_model(control_id)
        if model is None:
            return
        actions = _models(model.get("context_actions"))
        # Optional feature actions stay outside the legacy context_actions
        # contract so existing model consumers retain their stable ordering.
        actions.extend(_models(model.get("subtitle_context_actions")))
        if not actions:
            target = _model_property(model, "App.ContextTarget")
            if target:
                actions = [{
                    "label": tr("Download"),
                    "label2": tr("Add this stream to the download queue"),
                    "command": "action",
                    "target": target,
                    "properties": {"App.Badge": "QUEUE"},
                }]
        if not actions:
            return

        self._context_items[:] = actions
        self._populate_control(CONTEXT_MENU, self._context_items)
        self._context_origin_control = control_id
        self._context_open = True
        self.setProperty("App.ContextTitle", _text(model.get("label", tr("Actions"))))
        self.setProperty("App.ContextSubtitle", _text(model.get("label2", "")))
        get_property = getattr(self, "getProperty", None)
        eyebrow = (
            get_property("App.StreamOptionsLabel")
            if callable(get_property) else tr("STREAM OPTIONS")
        )
        self.setProperty("App.ContextEyebrow", eyebrow)
        self.setProperty("App.ContextOpen", "true")
        self._focus(CONTEXT_MENU)

    def _open_resume_choice(self, target, choice):
        position = _text(choice.get("position"))
        title = _text(choice.get("title")) or tr("Continue watching")
        self._context_items[:] = [
            {
                "label": tr("Resume") + ("  " + position if position else ""),
                "label2": tr("Continue from your saved position"),
                "command": "play",
                "target": choice.get("resume_target", target),
                "properties": {"App.Badge": "RESUME"},
            },
            {
                "label": tr("Start from beginning"),
                "label2": tr("Play this title from the beginning"),
                "command": "play",
                "target": choice.get("beginning_target", target),
                "properties": {"App.Badge": "START"},
            },
        ]
        self._populate_control(CONTEXT_MENU, self._context_items)
        try:
            self._context_origin_control = int(self.getFocusId())
        except Exception:
            self._context_origin_control = None
        self._context_open = True
        self.setProperty("App.ContextTitle", title)
        self.setProperty("App.ContextSubtitle", tr("Choose where playback should begin"))
        self.setProperty("App.ContextEyebrow", tr("RESUME PLAYBACK"))
        self.setProperty("App.ContextOpen", "true")
        self._focus(CONTEXT_MENU)

    def _close_context_menu(self, restore_focus=True):
        if not self._context_open:
            return
        origin = self._context_origin_control
        self._context_open = False
        self._context_origin_control = None
        self.setProperty("App.ContextOpen", "false")
        if restore_focus and origin is not None:
            self._focus(origin)

    def _home_display_models(self, control_id, models):
        if control_id not in HOME_SHELVES or not models:
            return models
        page = {
            HOME_PRIMARY: "history",
            HOME_SECONDARY: "movies",
            HOME_TERTIARY: "tv",
        }[control_id]
        shelf_title = tr({
            HOME_PRIMARY: "Continue Watching",
            HOME_SECONDARY: "Popular Movies",
            HOME_TERTIARY: "Popular TV Series",
        }[control_id])
        title = tr("View all")
        source_art = dict(models[-1].get("art") or {})
        source_art["fanart"] = ""
        model = {
            "label": title,
            "label2": "",
            "command": "page",
            "target": "",
            "art": source_art,
            "properties": {
                "App.HomeId": "view-all:{0}".format(page),
                "App.HomeViewAll": "true",
                "App.HomeLinkLabel": title,
                "App.HomeTitle": title,
                "App.HomeLongTitle": "false",
                "App.HomeMeta": shelf_title,
                "App.HomeSummary": "",
                "App.HomeHint": "",
                "MediaHub.Title": title,
                "MediaHub.Meta": shelf_title,
                "MediaHub.Description": "",
            },
        }
        properties = model["properties"]
        properties["App.Page"] = page
        if control_id == HOME_PRIMARY and callable(self.browser_loader):
            model["command"] = "browse"
            model["target"] = "plugin://{0}/?action=show_continue_watching".format(ADDON_ID)
        return list(models) + [model]

    def _append_control_items(self, control_id, models):
        """Prepare a page before touching the grid, retaining existing ListItems."""
        if not models:
            return
        control = self.getControl(control_id)
        items = [self._list_item(model) for model in models]
        # ControlList.addItems internally sends LABEL_BIND, which selects zero
        # even without reset(). Read the latest position AFTER preparing cards,
        # then queue its restoration immediately after that single batch bind.
        position = int(control.getSelectedPosition())
        add_items = getattr(control, "addItems", None)
        if callable(add_items):
            add_items(items)
        else:
            for item in items:
                control.addItem(item)
        if position >= 0:
            control.selectItem(position)

    def _populate_control(self, control_id, models):
        try:
            control = self.getControl(control_id)
            display_models = self._home_display_models(control_id, models)
            if (
                control_id in (
                    HOME_PRIMARY,
                    HOME_SECONDARY,
                    HOME_TERTIARY,
                    DOWNLOADS,
                    BROWSER_TABS,
                    BROWSER_ACTIONS,
                    STREAM_FILTERS,
                    STREAM_LIST,
                    CATALOG,
                    FILTER_RESULTS,
                    FILTER_GROUPS,
                    FILTER_OPTIONS,
                    FILTER_ACTIONS,
                )
                and self._can_update_control_in_place(control_id, display_models)
            ):
                for index, model in enumerate(display_models):
                    self._update_list_item(
                        control.getListItem(index),
                        model,
                    )
                if control_id == DOWNLOADS:
                    self._download_row_targets = [
                        _text(model.get("target")) for model in models
                    ]
                return
            items = [self._list_item(model) for model in display_models]
            reset = getattr(control, "reset", None)
            if callable(reset):
                reset()
            add_items = getattr(control, "addItems", None)
            if callable(add_items):
                add_items(items)
            else:
                add_item = getattr(control, "addItem")
                for item in items:
                    add_item(item)
            if control_id == DOWNLOADS:
                self._download_row_targets = [
                    _text(model.get("target")) for model in models
                ]
        except Exception as exc:
            _log(
                "Could not populate {0} ({1}): {2}".format(
                    _CONTROL_NAMES.get(control_id, control_id),
                    control_id,
                    exc,
                ),
                xbmc.LOGERROR,
            )

    def _can_update_control_in_place(self, control_id, models):
        if control_id not in (
            HOME_PRIMARY,
            HOME_SECONDARY,
            HOME_TERTIARY,
            DOWNLOADS,
            BROWSER_TABS,
            BROWSER_ACTIONS,
            STREAM_FILTERS,
            STREAM_LIST,
            CATALOG,
            FILTER_RESULTS,
            FILTER_GROUPS,
            FILTER_OPTIONS,
            FILTER_ACTIONS,
        ) or not models:
            return False
        identity_property = (
            "App.HomeId"
            if control_id in HOME_SHELVES
            else "App.Tab"
            if control_id == BROWSER_TABS
            else "App.FilterKey"
            if control_id in (
                FILTER_GROUPS,
                FILTER_OPTIONS,
                FILTER_ACTIONS,
            )
            else "App.StreamFilterKey"
            if control_id == STREAM_FILTERS
            else "App.HomeId"
            if control_id in (CATALOG, FILTER_RESULTS)
            else "App.StreamId"
            if control_id == STREAM_LIST
            else None
        )
        try:
            control = self.getControl(control_id)
            if int(control.size()) != len(models):
                return False
            if control_id == DOWNLOADS:
                model_targets = [
                    _text(model.get("target")) for model in models
                ]
                return (
                    all(model_targets)
                    and self._download_row_targets == model_targets
                )
            if control_id == BROWSER_ACTIONS:
                return True
            for index, model in enumerate(models):
                current_item = control.getListItem(index)
                current_identity = _text(
                    current_item.getProperty(identity_property)
                )
                model_identity = _model_property(
                    model,
                    identity_property,
                )
                if not current_identity or current_identity != model_identity:
                    return False
        except Exception:
            return False
        return True

    @staticmethod
    def _list_item(model):
        item = xbmcgui.ListItem(
            label=tr(_text(model.get("label"))),
            label2=tr(_text(model.get("label2"))),
        )
        MediaHubHomeDialog._update_list_item(item, model, labels=False)
        return item

    @staticmethod
    def _update_list_item(item, model, labels=True):
        if labels:
            item.setLabel(tr(_text(model.get("label"))))
            item.setLabel2(tr(_text(model.get("label2"))))
        art = model.get("art")
        if isinstance(art, dict):
            normalized_art = {
                _text(key): _text(value) for key, value in art.items()
            }
            item.setArt(normalized_art)
            # WindowXML list/panel controls do not expose ListItem.Art
            # consistently across Kodi versions. Mirror artwork as ordinary
            # properties, which custom skin controls reliably resolve.
            item.setProperty(
                "MediaHub.Thumb", normalized_art.get("thumb", "")
            )
            item.setProperty(
                "MediaHub.Poster", normalized_art.get("poster", "")
            )
            item.setProperty(
                "MediaHub.Fanart", normalized_art.get("fanart", "")
            )
        properties = model.get("properties")
        if isinstance(properties, dict):
            # Favorites and legacy rows also use the shared poster grid.
            item.setProperty("App.CardTitle", _text(properties.get("App.CardTitle")
                or properties.get("MediaHub.Title") or model.get("label")).split(" / ", 1)[0])
            item.setProperty("App.CardContext", _text(properties.get("App.CardContext")
                or properties.get("MediaHub.Title") or model.get("label")))
            item.setProperty("App.CardStatus", _text(properties.get("App.CardStatus")))
            item.setProperty("App.CardProgressTexture", _text(properties.get("App.CardProgressTexture")))
            for key, value in properties.items():
                text_key = _text(key)
                text_value = _text(value)
                if text_key in ("App.Badge", "App.Hint"):
                    text_value = tr(text_value)
                item.setProperty(text_key, text_value)

    def _selected_model(self, control_id):
        models = self._items_by_control.get(control_id)
        if models is None:
            return None
        models = self._home_display_models(control_id, models)
        try:
            position = int(self.getControl(control_id).getSelectedPosition())
        except Exception:
            return None
        return models[position] if 0 <= position < len(models) else None

    def _capture_reactivation_state(self):
        selections = {}
        for control_id, models in self._items_by_control.items():
            if control_id == CONTEXT_MENU:
                continue
            try:
                position = int(self.getControl(control_id).getSelectedPosition())
            except Exception:
                continue
            selected = models[position] if 0 <= position < len(models) else None
            selections[control_id] = {
                "position": position,
                "target": _text(selected.get("target")) if selected else "",
                "command": _text(selected.get("command")) if selected else "",
                "label": _text(selected.get("label")) if selected else "",
                "filter_key": (
                    _model_property(selected, "App.FilterKey")
                    if selected else ""
                ),
            }
        try:
            focus_id = int(self.getFocusId())
        except Exception:
            focus_id = (
                BROWSER
                if self._page == "browse"
                else FILTER_GROUPS
                if self._is_discovery_workspace()
                else FILTER_RESULTS
                if self._page == "filterresults"
                else NAV
            )
        return {
            "page": self._page,
            "previous_page": self._previous_page,
            "focus_id": focus_id,
            "selections": selections,
        }

    def _restore_reactivated_window(self):
        state = self._reactivation_state
        if not isinstance(state, dict):
            state = {
                "page": self._page or self.initial_page,
                "previous_page": self._previous_page,
                "selections": {},
            }

        page = _text(state.get("page", self._page or self.initial_page)) or "home"
        self._page = page
        if page == "home":
            self._refresh_state()
        self._previous_page = (
            _text(state.get("previous_page", self._previous_page))
            or self._previous_page
        )
        self.setProperty("App.Page", page)
        navigation_page = self._navigation_page(page)
        self.setProperty("App.NavPage", navigation_page)
        title, subtitle = _PAGE_TITLES.get(page, ("", ""))
        title, subtitle = tr(title), tr(subtitle)
        if page in ("movies", "tv"):
            title = title.upper()
        self.setProperty("App.PageTitle", title)
        self.setProperty("App.PageSubtitle", subtitle)
        self._select_navigation(navigation_page)

        if page in ("movies", "tv"):
            self._populate_control(TABS, self._tabs)
            self._set_catalog(self._catalog_items)
            if self._is_discovery_workspace():
                self._apply_filter_studio_view(self._browser_view, focus=False)
        elif page in ("favorites", "search"):
            self._set_catalog(self._catalog_items)
        elif page == "browse":
            view = self._browser_view
            layout = _text(view.get("layout")).strip().lower()
            self.setProperty("App.BrowserLayout", layout)
            self.setProperty("App.BrowserTitle", _text(view.get("title", "Browse")))
            self.setProperty("App.BrowserSubtitle", _text(view.get("subtitle", "")))
            self.setProperty(
                "App.BrowserEyebrow",
                _text(view.get("eyebrow", "MEDIA HUB")),
            )
            self.setProperty(
                "App.BrowserEmpty",
                _text(view.get("empty", "Nothing to show yet.")),
            )
            self.setProperty(
                "App.BrowserArt",
                _text(view.get("fanart", self.fallback_art)),
            )
            self._browser_tabs[:] = _models(view.get("tabs"))
            self._populate_control(BROWSER_TABS, self._browser_tabs)
            self.setProperty(
                "App.BrowserTabs",
                "true" if self._browser_tabs else "false",
            )
            active_tab = next(
                (
                    _model_property(model, "App.Tab")
                    for model in self._browser_tabs
                    if _model_property(model, "App.Selected") == "true"
                ),
                _model_property(self._browser_tabs[0], "App.Tab")
                if self._browser_tabs else "",
            )
            self.setProperty("App.ActiveBrowserTab", active_tab)
            self._active_browser_tab = active_tab
            if active_tab:
                try:
                    self.getControl(BROWSER_TABS).selectItem(next(
                        index
                        for index, model in enumerate(self._browser_tabs)
                        if _model_property(model, "App.Tab") == active_tab
                    ))
                except Exception:
                    pass
            self._browser_actions[:] = _models(view.get("actions"))
            self._populate_control(BROWSER_ACTIONS, self._browser_actions)
            self.setProperty(
                "App.BrowserActions",
                "true" if self._browser_actions else "false",
            )
            self.setProperty(
                "App.BrowserDepth",
                "{0:02d}".format(max(1, len(self._browser_targets))),
            )
            if layout == "stream_picker":
                self._populate_control(STREAM_FILTERS, self._stream_filters)
                self._populate_control(STREAM_LIST, self._browser_items)
            else:
                self._populate_control(BROWSER, self._browser_items)
            self.setProperty(
                "App.HasBrowser",
                "true" if self._browser_items else "false",
            )
        elif page == "filterresults":
            self._apply_filter_results_view(
                self._browser_view,
                focus=False,
            )
        elif page == "detail":
            self._populate_control(
                DETAIL_ACTIONS,
                self._items_by_control[DETAIL_ACTIONS],
            )

        selections = state.get("selections")
        if isinstance(selections, dict):
            for control_id, selection in selections.items():
                self._restore_control_selection(control_id, selection)

        try:
            focus_id = int(state.get("focus_id"))
        except (TypeError, ValueError):
            focus_id = (
                BROWSER
                if page == "browse"
                else FILTER_GROUPS
                if self._is_discovery_workspace()
                else FILTER_RESULTS
                if page == "filterresults"
                else NAV
            )
        self._focus(self._preferred_page_focus(page, focus_id))
        self._reactivation_state = None

    def _restore_control_selection(self, control_id, selection):
        if not isinstance(selection, dict):
            return None
        try:
            control_id = int(control_id)
        except (TypeError, ValueError):
            return None
        models = self._items_by_control.get(control_id)
        if not models:
            return None

        target = _text(selection.get("target"))
        command = _text(selection.get("command"))
        label = _text(selection.get("label"))
        filter_key = _text(selection.get("filter_key"))
        media_id = _text(selection.get("media_id"))
        matched = None
        for index, model in enumerate(models):
            if media_id and media_id == (_model_property(model, "App.StreamId") or _model_property(model, "App.HomeId")):
                matched = index
                break
            if (
                filter_key
                and _model_property(model, "App.FilterKey") == filter_key
            ):
                matched = index
                break
            if target and _text(model.get("target")) == target:
                matched = index
                break
            if (
                not target
                and command
                and _text(model.get("command")) == command
                and _text(model.get("label")) == label
            ):
                matched = index
                break
        if matched is None:
            try:
                matched = int(selection.get("position", 0))
            except (TypeError, ValueError):
                matched = 0
            matched = min(max(0, matched), len(models) - 1)
        try:
            self.getControl(control_id).selectItem(matched)
        except Exception:
            return None
        return matched

    def _select_navigation(self, page):
        index = self._nav_index.get(page)
        if index is None:
            return
        try:
            self.getControl(NAV).selectItem(index)
            self._nav_position = index
        except Exception:
            pass

    def _remember_navigation_position(self):
        try:
            self._nav_position = int(
                self.getControl(NAV).getSelectedPosition()
            )
        except Exception:
            self._nav_position = None

    def _remember_tab_position(self):
        try:
            self._tab_position = int(
                self.getControl(TABS).getSelectedPosition()
            )
        except Exception:
            self._tab_position = None

    def _sync_navigation_selection(self):
        try:
            if int(self.getFocusId()) != NAV:
                return
            position = int(self.getControl(NAV).getSelectedPosition())
        except Exception:
            return

        if position == self._nav_position:
            return
        self._nav_position = position
        if not 0 <= position < len(self.navigation):
            return

        page = _model_property(self.navigation[position], "App.Page", "home")
        if page != self._page:
            # Downloads already has its rows in the shell. Wait for selection
            # before opening its separate browser view so a click cannot cancel
            # an in-flight preview and start the same database load again.
            self._show_page(page, load=page != "downloads", focus=False)

    def _sync_tab_selection(self):
        if self._page not in ("movies", "tv"):
            return
        try:
            if int(self.getFocusId()) != TABS:
                return
            position = int(self.getControl(TABS).getSelectedPosition())
        except Exception:
            return

        if position == self._tab_position:
            return
        self._tab_position = position
        if not 0 <= position < len(self._tabs):
            return

        tab = _model_property(self._tabs[position], "App.Tab")
        self._highlighted_catalog_tab = tab
        if tab == "search":
            self._show_catalog_search_workspace(self._page, focus=False)
            return
        if tab == "filters":
            self._show_discovery_workspace(self._page, focus=True)
            return
        if tab:
            self._clear_catalog_workspace()
            self._load_catalog(
                self._page,
                tab,
                force=False,
                focus=False,
                show_loading=True,
            )

    def _focus(self, control_id):
        if (
            control_id in (FILTER_GROUPS, FILTER_OPTIONS, FILTER_ACTIONS)
            and self._is_discovery_workspace()
        ):
            self._filter_overlay_active = True
        if control_id in HOME_SHELVES:
            self._home_focus_control = control_id
            self.setProperty("App.HomeShelf", str(control_id))
        try:
            self.setFocusId(control_id)
        except Exception as exc:
            _log("Could not focus control {0}: {1}".format(control_id, exc), xbmc.LOGERROR)

    def _focus_home_content(self):
        self._show_page("home", load=False)

    def _focus_catalog_tabs(self):
        """Return to category tabs without reversing an infinite catalog."""
        if self._page not in ("movies", "tv") or not self._tabs:
            return False
        try:
            focus_id = int(self.getFocusId())
        except (TypeError, ValueError):
            return False
        if focus_id not in (CATALOG, CATALOG_SEARCH, CATALOG_SEARCH_COMPACT, CATALOG_RECENT, CATALOG_RECENT_CLEAR, CATALOG_SEARCH_SORT, FILTER_GROUPS, FILTER_OPTIONS, FILTER_ACTIONS):
            return False
        self._focus(TABS)
        return True


def _watch_home_abort(dialog, monitor):
    # onAbortRequested was removed from Kodi's Python API. Poll the supported
    # monitor API, including while the application window is modal.
    while not dialog._close_event.wait(.1):
        if monitor.abortRequested():
            dialog.close()
            return


def open_home(addon_path, **kwargs):
    """Open the unified Media Hub application and return its exit command."""
    dialog = None
    abort_thread = None
    try:
        dialog = MediaHubHomeDialog(
            XML_FILENAME,
            addon_path,
            "Default",
            "1080i",
            **kwargs
        )

        abort_thread = threading.Thread(
            target=_watch_home_abort,
            args=(dialog, xbmc.Monitor()),
            name="MediaHubShutdownMonitor",
            daemon=True,
        )
        abort_thread.start()
        dialog.doModal()
        return dialog.result
    except Exception as exc:
        _log("Could not open the app window: {0}".format(exc), xbmc.LOGERROR)
        raise
    finally:
        if dialog is not None:
            # Kodi can dismiss a modal window as part of global shutdown
            # without taking the normal WindowXML.close path.
            dialog._stop_background()
            if abort_thread is not None:
                abort_thread.join(.5)
            del dialog
