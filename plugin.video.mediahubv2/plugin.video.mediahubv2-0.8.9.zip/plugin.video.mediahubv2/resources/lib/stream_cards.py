"""Field-level, honest presentation for the modern stream picker.

This module does not fetch metadata, rank streams, or decide playability.
Unknown metadata never means that a track is absent.
"""
import math
import re

from .localization import tr


MUTED = "FFB0BAC4"
NORMAL = "FFE7ECEF"
WARNING = "FFFFC45C"


def number(value):
    try:
        result = float(value)
        return result if math.isfinite(result) and result > 0 else 0
    except (TypeError, ValueError, OverflowError):
        return 0


def text(value):
    # Metadata is text, not Kodi formatting. Prevent filenames/track metadata
    # from injecting color, font or line-break markup into our own labels.
    return re.sub(r"\[(?:/?(?:COLOR|B|I|LIGHT|UPPERCASE|LOWERCASE|CAPITALIZE)|CR|TABS|FONT)[^\]]*\]",
                  "", str(value or ""), flags=re.I).strip()


def color(value, tone=MUTED):
    return "[COLOR {0}]{1}[/COLOR]".format(tone, text(value)) if value else ""


def language(value):
    value = text(value).lower().replace("_", "-").split("-")[0]
    return {"cs": "CZ", "cz": "CZ", "ces": "CZ", "cze": "CZ", "czech": "CZ",
            "sk": "SK", "slk": "SK", "slo": "SK", "slovak": "SK", "en": "EN", "eng": "EN",
            "und": "", "unknown": ""}.get(value, value.upper())


def lang_label(value):
    value = language(value)
    return color(value, {"SK": "FF5FCB7E", "CZ": "FFEAB650"}.get(value, NORMAL)) if value else color(tr("Language unknown"))


def full_subtitle_tracks(stream):
    tracks = [track for track in (stream.get("subtitleTracks") or []) if isinstance(track, dict)]
    # An explicit inventory must not be replaced by a language-only summary:
    # that summary may include forced tracks.
    if not tracks:
        tracks = [{"language": value} for value in stream.get("subtitleLanguages", []) or []]
    return [track for track in tracks if not any(
        str(track.get(key, False)).lower() in ("true", "1")
        for key in ("isForced", "is_forced", "forced"))]


def has_full_local_subtitles(stream):
    if isinstance(stream.get("metadataFields"), dict) and field_evidence(stream, "subtitleTracks").get("verified") is not True:
        return False
    return any(language(track.get("language")) in ("SK", "CZ") for track in full_subtitle_tracks(stream))


def duration_seconds(stream):
    return number(stream.get("durationInSeconds")) or number(stream.get("lengthInMins")) * 60


def duration_label(seconds):
    minutes = max(1, int(seconds // 60))
    hours, minutes = divmod(minutes, 60)
    return ("{0} h {1} min".format(hours, minutes) if minutes else "{0} h".format(hours)) if hours else "{0} min".format(minutes)


def filename_lines(value):
    """Allow Kodi's textbox to wrap release names at their dot separators.

    Keep the raw identity and playback filename intact; zero-width spaces
    only affect the presentation. The file extension stays attached.
    """
    value = text(value)
    stem, dot, extension = value.rpartition(".")
    return stem.replace(".", ".\u200b") + dot + extension if dot else value


def expected_minutes(params, episode=None):
    """Only use title metadata, never the stream runtime or series average."""
    explicit = number(params.get("expected_runtime_minutes"))
    if explicit:
        return explicit
    if episode is not None or params.get("tv_id") or params.get("media_type") == "episode":
        return number((episode or {}).get("runtime"))
    # Movie catalog routes already carry a '<minutes> min' duration label.
    match = re.fullmatch(r"\s*(\d+(?:\.\d+)?)\s*min\s*", str(params.get("duration") or ""))
    return number(match.group(1)) if match else 0


def _missing(status):
    return tr("Loading…") if status == "pending" else tr("Not verified")


def provider_properties(provider, availability, availability_label):
    pending = provider.lower() == "torbox" and availability == "unknown"
    if pending:
        label = text(provider)
    elif availability in ("ready", "cached"):
        label = text(provider) + " · " + color(tr("Ready"), "FF48E092")
    else:
        label = text(availability_label)
    return {
        "App.StreamCard.Provider": label,
        "App.StreamCard.ProviderPending": str(pending).lower(),
    }


def field_evidence(stream, field):
    fields = stream.get("metadataFields")
    return fields.get(field, {}) if isinstance(fields, dict) else {}


def hdr_formats(stream):
    formats = stream.get("hdrFormats")
    if isinstance(formats, list) and formats:
        values = [item for item in formats if isinstance(item, dict) and text(item.get("format"))]
        def rank(item):
            return (3 if item.get("source") == "container" else 2) if item.get("verified") is True else 1
        strongest = max((rank(item) for item in values), default=0)
        return [item for item in values if rank(item) == strongest]
    evidence = field_evidence(stream, "hdrFormat")
    return [{"format": text(stream.get("hdrFormat")), **evidence}] if stream.get("hdrFormat") else []


def _video_properties(stream, quality, pending):
    """Color confirmed values separately; '?' marks only uncertain fields."""
    uncertain = False

    def value(label, field, tone=NORMAL):
        nonlocal uncertain
        if not label:
            return ""
        verified = field_evidence(stream, field).get("verified") is True
        uncertain |= not verified
        return color(text(label) + (" ?" if not verified else ""), tone if verified else MUTED)

    resolution = value(quality, "resolution", "FFB47BFA")
    formats = hdr_formats(stream)
    hdr = " · ".join(color(text(item["format"]) + ("" if item.get("verified") is True else " ?"),
                           NORMAL if item.get("verified") is True else MUTED) for item in formats)
    if not formats and not pending:
        hdr = color("SDR", NORMAL)
    uncertain |= any(item.get("verified") is not True for item in formats)
    codec = value(text(stream.get("videoCodec")), "videoCodec")
    # Release source describes the release's origin; file inspection cannot verify it.
    source = color(text(stream.get("releaseSource")), NORMAL)
    lines = [" · ".join(filter(None, (resolution, hdr))), " · ".join(filter(None, (codec, source)))]
    lines = [line for line in lines if line]
    if not lines:
        lines = [color(tr("Loading…") if pending else tr("Not verified"))]
    else:
        if not quality and not pending:
            lines.insert(0, color(tr("Resolution unknown")))
        if not stream.get("videoCodec") and not pending:
            lines.append(color(tr("Codec unknown")))
        if uncertain:
            lines.append(color(tr("? = unverified")))
    status = text(stream.get("metadataStatus")).lower()
    if status in ("temporaryfailure", "providerbusy"):
        lines.append(color(tr("Retrieval failed") if status == "temporaryfailure" else tr("Provider busy")))
    resolution_known = bool(quality) and field_evidence(stream, "resolution").get("verified") is True
    hdr_verified = bool(formats) and all(item.get("verified") is True for item in formats)
    hdr_known = hdr_verified or (not formats and not pending)
    codec_known = bool(stream.get("videoCodec")) and field_evidence(stream, "videoCodec").get("verified") is True
    return {
        "App.StreamCard.Video": "[CR]".join(lines),
        "App.StreamCard.VideoPending": str(pending and not (quality or stream.get("hdrFormat") or stream.get("videoCodec"))).lower(),
        "App.StreamCard.VideoVerified": str(resolution_known and hdr_verified and codec_known).lower(),
        "App.StreamCard.ResolutionKnown": str(resolution_known).lower(),
        "App.StreamCard.HdrKnown": str(hdr_known).lower(),
    }


def properties(stream, quality="", audio_tracks=(), audio_format=None,
               external=None, expected=0):
    status = text(stream.get("metadataStatus")).lower()
    complete = status == "complete"
    pending = status == "pending" or stream.get("metadataRefreshing") is True
    fieldwise = isinstance(stream.get("metadataFields"), dict)
    audio_complete = field_evidence(stream, "audioTracks").get("complete") is True if fieldwise else complete
    subtitle_complete = field_evidence(stream, "subtitleTracks").get("complete") is True if fieldwise else complete
    external = external or {}
    filename = text(stream.get("originalName") or stream.get("name") or tr("Stream"))
    result = {"App.StreamCard.Filename": filename_lines(filename)}
    missing = tr("Loading…") if pending else _missing(status)

    # Older APIs expose only an overall status; keep their fallback conservative.
    # New responses override these labels with per-field evidence below.
    hdr = text(stream.get("hdrFormat"))
    if not hdr and not pending:
        hdr = "SDR"
    hdr_known = bool(hdr)
    codec = text(stream.get("videoCodec"))
    video = " · ".join(filter(None, (text(quality), hdr)))
    details = " · ".join(filter(None, (codec, text(stream.get("releaseSource")))))
    if complete and not quality:
        video = tr("Resolution unknown") + (" · " + hdr if hdr else "")
    if complete and not codec:
        details = tr("Codec unknown") + (" · " + text(stream.get("releaseSource")) if stream.get("releaseSource") else "")
    inferred = False
    if not quality and not details and hdr in ("", "SDR"):
        resolution = re.search(r"(?<!\d)(2160|1440|1080|720|576|480)p(?!\d)", filename, re.I)
        if resolution and not complete:
            video = ("4K" if resolution[1] == "2160" else resolution[0]) + (" · " + hdr if hdr else "")
            inferred = True
    lines = [value for value in (video, details) if value]
    if inferred:
        lines.append(tr("From filename · unverified"))
        if pending:
            lines.append(missing)
    elif not complete and lines:
        lines.append(missing)
    if not lines:
        lines = [missing]
    if status in ("temporaryfailure", "providerbusy"):
        lines.append(tr("Retrieval failed") if status == "temporaryfailure" else tr("Provider busy"))
    if complete and quality:
        lines[0] = color(quality, "FFB47BFA") + (" · " + color(hdr, NORMAL) if hdr else "")
        result["App.StreamCard.Video"] = "[CR]".join([lines[0]] + [color(line, NORMAL) for line in lines[1:]])
    else:
        result["App.StreamCard.Video"] = "[CR]".join(color(line, NORMAL if complete else MUTED) for line in lines)
    result["App.StreamCard.VideoPending"] = str(pending and not (video or details)).lower()
    result["App.StreamCard.VideoVerified"] = str(complete).lower()
    result["App.StreamCard.ResolutionKnown"] = str(complete and bool(quality)).lower()
    result["App.StreamCard.HdrKnown"] = str(not pending and hdr_known).lower()
    if fieldwise:
        result.update(_video_properties(stream, quality, pending))

    audio_verified = not fieldwise or field_evidence(stream, "audioTracks").get("verified") is True
    languages = {language(track.get("language")) for track in audio_tracks} - {""}
    preferred = ("SK", "CZ", "EN")
    displayed = [lang for lang in preferred if lang in languages] or sorted(languages)[:3]
    audio = [lang_label(lang) if audio_verified else color(lang + " ?")
             for lang in displayed]
    other_count = len(languages - set(displayed))
    if other_count:
        audio.append(color(tr("+ {0} other", other_count) + ("" if audio_verified else " ?")))
    if not audio:
        # A bounded language token may be useful, but must never become a
        # verified track or satisfy a language filter.
        inferred_lang = re.search(r"(?:^|[. _\-\[])(CZ|CS|SK|EN)(?=$|[. _\-\]])", filename, re.I) if not audio_complete and not audio_tracks else None
        audio = [color(tr("{0} · from filename", language(inferred_lang[1])))] if inferred_lang else [color(
            tr("Language unknown") if audio_tracks else tr("No audio tracks") if audio_complete else missing)]
    result["App.StreamCard.Audio"] = " · ".join(audio)
    result["App.StreamCard.AudioPending"] = str(pending and not audio_tracks and not audio_complete).lower()
    local_audio = audio_verified and any(language(track.get("language")) in ("SK", "CZ") for track in audio_tracks)
    result["App.StreamCard.AudioKnown"] = str(local_audio or (audio_complete and all(language(track.get("language")) for track in audio_tracks))).lower()
    result["App.StreamCard.HasLocalAudio"] = str(local_audio).lower()

    tracks = full_subtitle_tracks(stream)
    full_local = has_full_local_subtitles(stream)
    subtitle_verified = not fieldwise or field_evidence(stream, "subtitleTracks").get("verified") is True
    embedded_languages = {language(track.get("language")) for track in tracks}
    ext_status = text(external.get("status")).lower()
    ext_lang = language(external.get("language"))
    external_local = not full_local and ext_status == "available" and ext_lang in ("SK", "CZ")
    # Ignore old cached English matches; they are not an external card result.
    if ext_status == "available" and not external_local and not full_local:
        ext_status = "unavailable"
    subtitle_lines = []
    for lang in ("SK", "CZ", "EN"):
        tone = "FF5FCB7E" if lang in ("SK", "CZ") else "FFFFFFFF"
        if external_local and lang == ext_lang:
            subtitle_lines.append(color(lang, tone) + " · " + tr("external") + " · OpenSubtitles")
        elif lang in embedded_languages:
            subtitle_lines.append(color(lang + ("" if subtitle_verified else " ?"), tone) + " · " + tr("embedded"))
    if not subtitle_lines:
        if any(not language(track.get("language")) for track in tracks) or (not stream.get("subtitleTracks") and (stream.get("hasBundledSubtitles") or stream.get("hasPreferredSubtitles"))):
            subtitle_lines.append(color(tr("Embedded · language unknown")))
        else:
            absent = tr("No full SK/CZ/EN embedded subtitles") if stream.get("subtitleTracks") or stream.get("subtitleLanguages") else tr("No embedded subtitles")
            subtitle_lines.append(color(absent if subtitle_complete else missing))
    if not full_local:
        if ext_status == "checking":
            subtitle_lines.append(color(tr("External: searching…")))
        elif ext_status == "error":
            subtitle_lines.append(color(tr("External search failed")))
        elif ext_status == "unavailable":
            subtitle_lines.append(color(tr("External SK/CZ: not found")))
    result["App.StreamCard.Subtitles"] = "[CR]".join(subtitle_lines)
    result["App.StreamCard.SubtitlesPending"] = str((pending and not tracks and not subtitle_complete) or (not full_local and ext_status == "checking")).lower()
    result["App.StreamCard.HasLocalSubtitles"] = str(full_local or (ext_status == "available" and ext_lang in ("SK", "CZ"))).lower()
    embedded_known = all(language(track.get("language")) for track in tracks) and not (not tracks and (stream.get("hasBundledSubtitles") or stream.get("hasPreferredSubtitles")))
    result["App.StreamCard.SubtitlesKnown"] = str(full_local or (ext_status == "available" and ext_lang in ("SK", "CZ")) or (subtitle_complete and embedded_known and ext_status in ("unavailable", "available") and (ext_status != "available" or bool(ext_lang)))).lower()

    seconds = duration_seconds(stream)
    size_bytes = number(stream.get("sizeBytes")) or number(stream.get("sizeInGB")) * 1024 ** 3
    result["App.StreamCard.Size"] = "{0:g} GB".format(round(size_bytes / 1024 ** 3, 2)) if size_bytes else color(tr("Loading…") if pending else tr("Size unknown"))
    result["App.StreamCard.Bitrate"] = "≈{0:g} Mbps".format(round(size_bytes * 8 / seconds / 1000000, 1)) if size_bytes and seconds else color("—")
    # A conservative clue, not rejection: tolerate credits and minor cuts.
    # Require BOTH a 20% difference and >10 min. Never compare missing values.
    expected = number(expected)
    mismatch = bool(seconds and expected and abs(seconds / 60 - expected) > max(10, expected * .20))
    result["App.StreamCard.RuntimeMismatch"] = str(mismatch).lower()
    result["App.StreamCard.Runtime"] = color(duration_label(seconds), WARNING if mismatch else NORMAL) if seconds else color(tr("Loading…") if pending else tr("Runtime unknown"))
    result["App.StreamCard.Expected"] = color(tr("expected ≈{0} min", int(round(expected)))) if mismatch else ""
    result["App.StreamCard.RuntimePending"] = str(pending and not seconds).lower()
    if fieldwise and seconds and field_evidence(stream, "duration").get("verified") is not True:
        result["App.StreamCard.Runtime"] = color(duration_label(seconds) + " ?")
        if size_bytes:
            result["App.StreamCard.Bitrate"] = color("≈{0:g} Mbps ?".format(round(size_bytes * 8 / seconds / 1000000, 1)))
        result["App.StreamCard.RuntimeMismatch"] = "false"
        result["App.StreamCard.Expected"] = ""
    return result
