"""Bounded progressive stream browsing. No network work in snapshot/mark_displayed.

Discovery is independent of enrichment: only rows acknowledged as displayed can
enter the metadata queue. Workers publish data; the window owns all GUI updates.
"""
import copy
import hashlib
import json
import queue
import threading
import time
import xbmc

from . import api

_LOCK = threading.RLock()
_SESSIONS = {}
_DISCOVERY_GATE = threading.BoundedSemaphore(2)
_WORK = queue.Queue(maxsize=1000)
_WORKERS = []
_METADATA = {}
_INFLIGHT = set()
_MAX_ATTEMPTS = 3
_RETRY_DELAYS = (15, 45, 120)


def _log_failure(operation, error):
    # Exceptions can contain signed URLs or provider credentials; log only the
    # failure category and HTTP status needed to diagnose background failures.
    status = getattr(error, "status_code", None)
    detail = "HTTP {}".format(status) if status is not None else type(error).__name__
    xbmc.log("[MediaHubBrowse] {} failed: {}".format(operation, detail), xbmc.LOGWARNING)


def identity(context):
    fields = ("movie_id", "tv_id", "season", "episode_number")
    return hashlib.sha256(json.dumps([api.browse_account()] + [str(context.get(k) or "") for k in fields]).encode()).hexdigest()


class Session:
    def __init__(self, context):
        self.account = api.browse_account()
        self.context = dict(context)
        self.key = identity(context)
        self.rows = {}
        self.pending = set()
        self.discovery_done = False
        self.error = ""
        self.stop = threading.Event()
        self.last_seen = time.monotonic()
        self.created = self.last_seen
        self.displayed = set()
        self.revision = 0
        self.attempts = {}
        self.next_retry = {}
        self.force_refresh = set()
        self.generations = {}
        self.availability_retry = {}

    def snapshot(self):
        with _LOCK:
            return {
                "items": copy.deepcopy(list(self.rows.values())),
                "discovering": not self.discovery_done,
                "pending": sum(str(r.get("metadataStatus", "")).lower() == "pending" or r.get("metadataRefreshing") is True for r in self.rows.values()),
                "error": self.error,
                "metadata_errors": sum(str(r.get("metadataStatus", "")).lower() in ("temporaryfailure", "providerbusy") for r in self.rows.values()),
                "revision": self.revision,
            }


def get(context):
    key = identity(context)
    now = time.monotonic()
    with _LOCK:
        session = _SESSIONS.get(key)
        if session and not session.stop.is_set() and (now - session.created < 300 or now - session.last_seen < 5):
            session.last_seen = now
            return session
        if session:
            session.stop.set()
        if len(_SESSIONS) >= 16:
            oldest = min(_SESSIONS, key=lambda k: _SESSIONS[k].last_seen)
            _SESSIONS.pop(oldest).stop.set()
        session = Session(context)
        _SESSIONS[key] = session
        thread = threading.Thread(target=_discover, args=(session,), daemon=True, name="MediaHubDiscovery")
        thread.start()
        return session


def _discover(session):
    acquired = False
    try:
        while not session.stop.is_set():
            if _DISCOVERY_GATE.acquire(timeout=.2):
                acquired = True
                break
        if not acquired:
            return
        try:
            for batch in api.discover_streams(session.context, session.stop):
                with _LOCK:
                    for row in batch:
                        if isinstance(row, dict) and row.get("id") and len(session.rows) < 500:
                            session.rows.setdefault(str(row["id"]), dict(row))
                    session.revision += 1
        except api.ApiError as exc:
            if exc.status_code not in (404, 405):
                raise
            # Compatibility with a backend deployed before progressive browsing.
            ctx = session.context
            rows = (api.get_episode_streams(ctx["tv_id"], ctx["season"], ctx["episode_number"])
                    if ctx.get("tv_id") else api.get_movie_versions(ctx["movie_id"]))
            with _LOCK:
                session.rows = {str(row["id"]): dict(row) for row in rows or [] if row.get("id")}
                session.revision += 1
    except Exception as exc:
        _log_failure("Stream discovery", exc)
        with _LOCK:
            session.error = "Some streams could not be loaded. Please retry."
    finally:
        with _LOCK:
            session.discovery_done = True
            session.revision += 1
        if acquired:
            _DISCOVERY_GATE.release()


def mark_displayed(session, ordered_ids):
    """Call only after publishing rows, selected/visible IDs first."""
    with _LOCK:
        session.last_seen = time.monotonic()
        for position, stream_id in enumerate(ordered_ids):
            stream_id = str(stream_id)
            row = session.rows.get(stream_id)
            if not row:
                continue
            session.displayed.add(stream_id)
            status = str(row.get("metadataStatus", "")).lower()
            forced = stream_id in session.force_refresh
            torbox = str(row.get("provider", "")).lower() == "torbox" or stream_id.lower().startswith("torbox.")
            status_only = (not forced and position < 8 and torbox
                           and str(row.get("availability", "unknown")).lower() not in ("ready", "cached")
                           and (status == "complete" or session.attempts.get(stream_id, 0) >= _MAX_ATTEMPTS))
            if stream_id in session.pending:
                continue
            if status_only and session.availability_retry.get(stream_id, 0) > time.monotonic():
                continue
            if not forced and not status_only and (status == "complete" or session.attempts.get(stream_id, 0) >= _MAX_ATTEMPTS
                               or session.next_retry.get(stream_id, 0) > time.monotonic()):
                continue
            cached = _METADATA.get((session.account, stream_id, row.get("sizeBytes")))
            if not forced and not status_only and not session.attempts.get(stream_id) and cached and cached[0] > time.monotonic():
                row.update(copy.deepcopy(cached[1]))
                if str(row.get("metadataStatus", "")).lower() != "complete":
                    session.next_retry[stream_id] = time.monotonic() + _RETRY_DELAYS[0]
                    session.attempts[stream_id] = 1
                session.revision += 1
                continue
            if len(session.pending) >= 6:
                continue
            try:
                _WORK.put_nowait((session, stream_id, session.generations.get(stream_id, 0), status_only))
                session.pending.add(stream_id)
            except queue.Full:
                break
        while len(_WORKERS) < 3:
            worker = threading.Thread(target=_enrich_worker, daemon=True, name="MediaHubMetadata")
            _WORKERS.append(worker)
            worker.start()


def refresh_stream(session, stream_id):
    """Invalidate this row's cached result; the normal display queue does the work."""
    stream_id = str(stream_id)
    with _LOCK:
        row = session.rows.get(stream_id)
        if not row or session.stop.is_set():
            return False
        session.generations[stream_id] = session.generations.get(stream_id, 0) + 1
        session.attempts[stream_id] = 0
        session.next_retry[stream_id] = 0
        session.force_refresh.add(stream_id)
        _METADATA.pop((session.account, stream_id, row.get("sizeBytes")), None)
        row["metadataRefreshing"] = True
        session.revision += 1
        return True


def update_availability(session, stream_id, availability):
    """A completed local preparation unlocks a fresh file inspection immediately."""
    with _LOCK:
        row = session.rows.get(str(stream_id))
        if row and str(availability).lower() in ("ready", "cached") and str(row.get("availability", "")).lower() not in ("ready", "cached"):
            row["availability"] = availability
            refresh_stream(session, stream_id)


def _merge_metadata(previous, incoming):
    result = dict(incoming)
    old_fields = previous.get("metadataFields") or {}
    fields = dict(incoming.get("metadataFields") or {})
    groups = {
        "resolution": ("quality", "width", "height"), "videoCodec": ("videoCodec",),
        "hdrFormat": ("hdrFormat",), "duration": ("durationInSeconds", "lengthInMins"),
        "container": ("container",), "videoBitrate": ("videoBitrateKbps",),
        "frameRate": ("frameRate",), "releaseSource": ("releaseSource",), "edition": ("edition",),
        "audioTracks": ("audioTracks",),
        "subtitleTracks": ("subtitleTracks", "subtitleLanguages", "hasBundledSubtitles", "hasPreferredSubtitles"),
    }
    def rank(evidence):
        return (3 if evidence.get("source") == "container" else 2) if evidence.get("verified") else 1
    for field, keys in groups.items():
        old, new = old_fields.get(field), fields.get(field)
        if old and (not new or (old.get("complete") and not new.get("complete")) or rank(old) > rank(new)):
            fields[field] = old
            for key in keys:
                if key in previous:
                    result[key] = copy.deepcopy(previous[key])
    if old_fields or "metadataFields" in incoming:
        result["metadataFields"] = fields
    if previous.get("hdrFormats") or incoming.get("hdrFormats"):
        formats = {}
        current = [item for item in incoming.get("hdrFormats") or [] if isinstance(item, dict) and item.get("format")]
        prior = [item for item in previous.get("hdrFormats") or [] if isinstance(item, dict) and item.get("format")]
        current_rank = max((rank(item) for item in current), default=0)
        prior_rank = max((rank(item) for item in prior), default=0)
        strongest = max(current_rank, prior_rank)
        # A new confirmed check replaces the previous format set, including stale estimates.
        candidates = current if current_rank >= max(2, prior_rank) else current + prior
        for item in candidates:
            if not isinstance(item, dict) or not item.get("format"):
                continue
            if rank(item) != strongest:
                continue
            key = "PQ" if item["format"] in ("HDR10", "HDR (PQ)") else item["format"]
            old = formats.get(key)
            score = lambda value: (rank(value), value.get("format") == "HDR10", value.get("dolbyVisionProfile") is not None)
            if old is None or score(item) > score(old):
                formats[key] = copy.deepcopy(item)
        ordered = sorted(formats.values(), key=lambda item: 0 if item["format"] == "Dolby Vision" else 1 if item["format"] == "HDR10+" else 2)
        result["hdrFormats"] = ordered
        result["hdrFormat"] = " · ".join(item["format"] for item in ordered)
        if ordered:
            sources = {item.get("source") for item in ordered}
            result.setdefault("metadataFields", {})["hdrFormat"] = {
                "source": next(iter(sources)) if len(sources) == 1 else "mixed",
                "verified": all(item.get("verified") is True for item in ordered)}
    return result


def deactivate_except(session=None):
    with _LOCK:
        for candidate in _SESSIONS.values():
            if candidate is not session:
                candidate.last_seen = 0
                if not candidate.discovery_done:
                    candidate.stop.set()


def invalidate(context):
    with _LOCK:
        session = _SESSIONS.pop(identity(context), None)
        if session:
            session.stop.set()


def close():
    with _LOCK:
        for session in _SESSIONS.values():
            session.stop.set()


def _enrich_worker():
    while True:
        try:
            session, stream_id, generation, status_only = _WORK.get(timeout=.25)
        except queue.Empty:
            with _LOCK:
                # Kodi waits for Python threads, including daemon threads,
                # when unloading the add-on. Never wait forever on an idle queue.
                if not _WORK.empty():
                    continue
                _WORKERS.remove(threading.current_thread())
                return
        key = None
        owns_probe = False
        try:
            with _LOCK:
                if session.stop.is_set() or session.account != api.browse_account() or time.monotonic() - session.last_seen > 5:
                    continue
                if generation != session.generations.get(stream_id, 0):
                    continue
                row = dict(session.rows[stream_id])
                key = (session.account, stream_id, row.get("sizeBytes"))
                if key in _INFLIGHT:
                    continue
                _INFLIGHT.add(key)
                owns_probe = True
                if not status_only:
                    force = stream_id in session.force_refresh or session.attempts.get(stream_id, 0) > 0
                    session.force_refresh.discard(stream_id)
                    session.attempts[stream_id] = session.attempts.get(stream_id, 0) + 1
                    if force:
                        row["_force_metadata_refresh"] = True
                    session.rows[stream_id]["metadataRefreshing"] = True
                    session.revision += 1
            if status_only:
                status = api.get_stream_status(stream_id)
                if not isinstance(status, dict) or not status.get("availability"):
                    raise ValueError("Invalid stream availability response")
                with _LOCK:
                    if generation != session.generations.get(stream_id, 0) or session.stop.is_set():
                        continue
                    update_availability(session, stream_id, status["availability"])
                    for field in ("availability", "progressPercent", "etaSeconds", "isReady"):
                        if field in status:
                            session.rows[stream_id][field] = status[field]
                    if "message" in status:
                        session.rows[stream_id]["availabilityMessage"] = status["message"]
                    session.availability_retry[stream_id] = time.monotonic() + 30
                    session.revision += 1
                continue
            result = None
            for attempt in range(3):
                try:
                    result = api.enrich_stream(row)
                    break
                except api.ApiError as exc:
                    if exc.status_code not in (429, 503) or attempt == 2:
                        raise
                    if session.stop.wait(2 * (attempt + 1)):
                        break
            if not isinstance(result, dict) or result.get("id") != stream_id:
                raise ValueError("Invalid stream metadata response")
            with _LOCK:
                if generation != session.generations.get(stream_id, 0) or session.stop.is_set():
                    continue
                was_ready = str(session.rows[stream_id].get("availability", "")).lower() in ("ready", "cached")
                result = _merge_metadata(session.rows[stream_id], result)
                session.rows[stream_id].update(result)
                session.rows[stream_id]["metadataRefreshing"] = False
                session.availability_retry[stream_id] = time.monotonic() + 30
                session.next_retry[stream_id] = time.monotonic() + _RETRY_DELAYS[min(session.attempts[stream_id] - 1, len(_RETRY_DELAYS) - 1)]
                if not was_ready and str(result.get("availability", "")).lower() in ("ready", "cached") and str(result.get("metadataStatus", "")).lower() != "complete":
                    session.attempts[stream_id] = 0
                    session.next_retry[stream_id] = 0
                    session.force_refresh.add(stream_id)
                session.revision += 1
                if len(_METADATA) >= 1000:
                    _METADATA.pop(next(iter(_METADATA)))
                ttl = 45 if row.get("provider") == "TorBox" else 300
                _METADATA[key] = (time.monotonic() + ttl, copy.deepcopy(result))
        except Exception as exc:
            _log_failure("Stream metadata", exc)
            with _LOCK:
                if generation == session.generations.get(stream_id, 0) and not session.stop.is_set():
                    if status_only:
                        session.availability_retry[stream_id] = time.monotonic() + 30
                    else:
                        session.rows[stream_id]["metadataStatus"] = "TemporaryFailure"
                        session.rows[stream_id]["metadataRefreshing"] = False
                        session.next_retry[stream_id] = time.monotonic() + _RETRY_DELAYS[min(session.attempts.get(stream_id, 1) - 1, len(_RETRY_DELAYS) - 1)]
                    session.revision += 1
        finally:
            with _LOCK:
                session.pending.discard(stream_id)
                if owns_probe:
                    _INFLIGHT.discard(key)
            _WORK.task_done()
