"""Search ranking and release-date filtering, independent of Kodi controls."""

import datetime
import difflib
import math
import re
import unicodedata

SORT_OPTIONS = (
    ("match", "Best match"),
    ("popular", "Most popular"),
    ("rated", "Best rated"),
    ("newest", "Newest first"),
    ("oldest", "Oldest first"),
)


def release_date(value):
    try:
        return datetime.date.fromisoformat(str(value or "")[:10])
    except ValueError:
        return None


def is_future_movie(movie, today=None):
    date = release_date(movie.get("release_date"))
    return date is not None and date > (today or datetime.date.today())


def released_movie_response(response, today=None):
    if not isinstance(response, dict):
        return response
    # Pagination describes the provider's pages, even if a page becomes empty.
    return dict(response, results=[
        movie for movie in response.get("results", []) or []
        if isinstance(movie, dict) and not is_future_movie(movie, today)
    ])


def source(model):
    value = model.get("catalog_source")
    return value if isinstance(value, dict) else {}


def eligible(model, page, today=None):
    return page != "movies" or not is_future_movie(source(model), today)


def identity(model):
    data = source(model)
    return str(model.get("target") or data.get("id") or model.get("label") or "")


def _number(value):
    try:
        value = float(value or 0)
        return value if math.isfinite(value) else 0
    except (TypeError, ValueError):
        return 0


def _normalize(value):
    value = unicodedata.normalize("NFKD", str(value or "").casefold())
    value = "".join(char for char in value if not unicodedata.combining(char))
    return " ".join(re.sub(r"[^\w]+", " ", value).split())


def _match(model, query):
    data = source(model)
    properties = model.get("properties") or {}
    titles = [data.get(key) for key in ("title", "original_title", "name", "original_name")]
    titles.extend((properties.get("App.OriginalTitle"), properties.get("App.CardTitle"), model.get("label")))
    score = 0
    words = set(query.split())
    for title in titles:
        title = _normalize(title)
        if not title:
            continue
        without_article = re.sub(r"^(the|an|a) ", "", title)
        if title == query:
            return 100
        if without_article == query:
            score = max(score, 95)
        elif difflib.SequenceMatcher(None, query, title).ratio() >= .85:
            score = max(score, 90)
        elif title.startswith(query + " ") or without_article.startswith(query + " "):
            score = max(score, 80)
        elif words and words.issubset(set(title.split())):
            score = max(score, 70)
        elif query in title:
            score = max(score, 50)
    return score


def ordered(models, query, sort="match", today=None, page="movies"):
    query = _normalize(query)
    models = [model for model in models if eligible(model, page, today)]

    def key(model):
        data = source(model)
        popularity = max(0, _number(data.get("popularity")))
        if sort in ("newest", "oldest"):
            date = release_date(data.get("release_date") or data.get("first_air_date"))
            ordinal = date.toordinal() if date else 0
            return (date is None, -ordinal if sort == "newest" else ordinal, -popularity)
        if sort == "popular":
            return (-popularity,)
        if sort == "rated":
            rating = min(10, max(0, _number(data.get("vote_average"))))
            votes = max(0, _number(data.get("vote_count")))
            # A fixed prior prevents a handful of perfect votes dominating.
            weighted = (rating * votes + 6.5 * 500) / (votes + 500)
            return (votes <= 0, -weighted, -popularity)
        return (-_match(model, query) if query else 0, -popularity)

    # Python's stable sort retains provider order for equal keys.
    return sorted(models, key=key)
