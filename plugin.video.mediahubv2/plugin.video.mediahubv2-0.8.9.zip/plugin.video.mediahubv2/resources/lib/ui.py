import sys
import hashlib
import xbmc
import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmcvfs
import os
import stat
import urllib.parse
import time
import threading
import queue
import datetime
import re
import math
from concurrent.futures import ThreadPoolExecutor
from urllib.error import URLError
from . import api
import uuid
from .downloads_db import DownloadsDb, now_iso
from .torbox_preparations import TorboxPreparationsDb
from .media_lists_db import MEDIA_LIST_KEYS, MediaListsDb
from .watch_history_db import WatchHistoryDb
from .playback_worker import WATCHED_PERCENT, playback_context, register_playback
from .subtitles_db import ACTIVE_STATUSES as SUBTITLE_ACTIVE_STATUSES
from .subtitles_db import (
    SubtitleJobsDb,
    normalize_run_attempt,
    now_iso as subtitle_now_iso,
    stream_identity,
)
from .subtitles_worker import normalized_status_payload, store_subtitle_result
from . import external_subtitles
from . import browse
from . import classic_browse
from . import stream_cards
from .localization import SLOVAK, language, tr


db = DownloadsDb()
preparations_db = TorboxPreparationsDb()
media_lists_db = MediaListsDb()
watch_history_db = WatchHistoryDb()
subtitle_jobs_db = None

QUEUE_STATUSES = ("queued", "paused", "waiting_retry")
ACTIVE_DOWNLOAD_STATUSES = ("downloading", "pausing", "canceling", "repairing", "finalizing")
VERIFICATION_ERROR_CODE = "verification_failed"
FINALIZATION_MARKER_PREFIX = b"MEDIAHUB-FINALIZATION-V1:"
MAX_WATCH_HISTORY_ITEMS = 200
ANIMATION_GENRE_ID = 16
STREAM_PREPARATION_POLL_SECONDS = 2
STREAM_PREPARATION_MAX_POLL_SECONDS = 15
STREAM_PILL_PADDING_X = 14
STREAM_PILL_GAP = 8
STREAM_PILL_HEIGHT = 31
STREAM_PILL_SHEET_WIDTH = 1172
STREAM_PILL_SHEET_HEIGHT = 115
STREAM_PILL_ROW_TOPS = (0, 42, 84)
STREAM_PILL_RENDER_SCALE = 2
STREAM_PILL_DRAW_SCALE = 4
_STREAM_PILL_CACHE_VERSION = 8
_STREAM_PILL_CACHE_LOCK = threading.Lock()
_STREAM_PILL_PIL = None
SUBTITLE_TERMINAL_STATUSES = ("completed", "failed", "canceled")
PLACEHOLDER_POSTER_IMAGE = "poster-placeholder-v2.png"


def _subtitle_db():
    global subtitle_jobs_db
    if subtitle_jobs_db is None:
        subtitle_jobs_db = SubtitleJobsDb()
    return subtitle_jobs_db

DISCOVERY_SORTS = (
    ("popularity.desc", "Popular"),
    ("release_date.desc", "Newest"),
    ("release_date.asc", "Oldest"),
    ("vote_average.desc", "Best rated"),
    ("vote_average.asc", "Lowest rated")
)
DISCOVERY_STATE_KEYS = (
    "genre_ids",
    "genre_names",
    "genre_id",
    "genre_name",
    "year",
    "year_from",
    "year_to",
    "sort",
    "minimum_rating",
    "minimum_vote_count",
    "minimum_runtime",
    "maximum_runtime",
)
DISCOVERY_SECTIONS = (
    "genre",
    "release_period",
    "minimum_rating",
    "minimum_vote_count",
    "runtime",
    "sort",
)
DISCOVERY_MIN_YEAR = 1870
DISCOVERY_MAX_RUNTIME = 1440

class _RepairOwnershipLost(Exception):
    pass


class _StreamPreparationFailed(Exception):
    pass

COLLECTION_TITLES = {
    "favorites": "Favorites"
}

COLLECTION_ADD_LABELS = {
    "favorites": "Add to Media Hub Favorites"
}

COLLECTION_REMOVE_LABELS = {
    "favorites": "Remove from Media Hub Favorites"
}

COLLECTION_RECORD_KEYS = (
    "kind",
    "media_type",
    "movie_id",
    "tv_id",
    "season",
    "episode_id",
    "stream_id",
    "title",
    "tv_title",
    "season_title",
    "episode_title",
    "year",
    "duration",
    "rating",
    "genres",
    "number_of_seasons",
    "episode_count",
    "plot",
    "poster",
    "fanart",
    "stream_name",
    "size_gb",
    "provider",
    "availability",
    "availability_message",
)

VIDEO_FILE_EXTENSIONS = {
    ".3gp",
    ".avi",
    ".divx",
    ".flv",
    ".iso",
    ".m2ts",
    ".m4v",
    ".mkv",
    ".mov",
    ".mp4",
    ".mpeg",
    ".mpg",
    ".mts",
    ".ogm",
    ".ts",
    ".vob",
    ".webm",
    ".wmv"
}

def _is_vfs_path(path):
    return "://" in path

def _join_path(base, filename):
    if _is_vfs_path(base):
        return base.rstrip("/\\") + "/" + filename
    return os.path.join(base, filename)

def _video_extension(value):
    if not value:
        return ""

    path = urllib.parse.urlparse(value).path if "://" in value else value
    name = os.path.basename(urllib.parse.unquote(path)).strip()
    ext = os.path.splitext(name)[1].lower()
    return ext if ext in VIDEO_FILE_EXTENSIONS else ""

def _strip_video_extensions(value):
    base = (value or "").strip()
    while True:
        ext = _video_extension(base)
        if not ext:
            return base
        base = os.path.splitext(base)[0].rstrip(" .")

def _safe_download_filename(filename, source_url=""):
    ext = _video_extension(filename) or _video_extension(source_url)
    base = _strip_video_extensions(filename)
    invalid_chars = set('<>:"/\\|?*')
    safe_base = "".join(
        " " if c in invalid_chars or ord(c) < 32 else c
        for c in base
    ).strip(" .")
    if not safe_base:
        safe_base = "download"

    if ext:
        while safe_base.lower().endswith(ext):
            safe_base = safe_base[:-len(ext)].rstrip(" .")
        if not safe_base:
            safe_base = "download"

    return f"{safe_base}{ext}"

def _stream_display_name(stream):
    return stream.get("originalName") or stream.get("name") or "Stream"


def _stream_provider(stream, stream_id=""):
    stream = stream if isinstance(stream, dict) else {}
    provider = _clean_query_value(stream.get("provider"))
    effective_id = _clean_query_value(
        stream_id or stream.get("stream_id") or stream.get("id")
    )
    if provider:
        if provider.lower() == "torbox":
            return "TorBox"
        if provider.lower() == "webshare":
            return "WebShare"
        return provider
    return "TorBox" if effective_id.lower().startswith("torbox.") else "WebShare"


def _stream_is_torbox(stream, stream_id=""):
    return _stream_provider(stream, stream_id).lower() == "torbox"


def _stream_availability(stream):
    stream = stream if isinstance(stream, dict) else {}
    raw_value = stream.get("availability")
    numeric_values = {
        0: "ready",
        1: "downloading",
        2: "queued",
        3: "uncached",
        4: "stalled",
        5: "error",
        6: "unknown",
        # Cached was appended to the provider contract so existing numeric
        # status values remain stable for older backend deployments.
        7: "cached",
    }
    if isinstance(raw_value, int) and not isinstance(raw_value, bool):
        value = numeric_values.get(raw_value, "unknown")
    else:
        value = _clean_query_value(raw_value).lower()
        if value.isdigit():
            value = numeric_values.get(_as_int(value, 6), "unknown")
    if value:
        return value
    return "unknown" if _stream_is_torbox(stream) else "ready"


def _stream_bool(stream, *keys):
    for key in keys:
        if key not in stream:
            continue
        value = stream.get(key)
        if isinstance(value, bool):
            return value
        normalized = _clean_query_value(value).lower()
        if normalized in ("true", "1", "yes", "on"):
            return True
        if normalized in ("false", "0", "no", "off"):
            return False
    return None


def _stream_is_ready(stream):
    stream = stream if isinstance(stream, dict) else {}
    explicit = _stream_bool(stream, "isReady", "is_ready")
    return explicit if explicit is not None else _stream_availability(stream) == "ready"


def _stream_can_download(stream):
    stream = stream if isinstance(stream, dict) else {}
    explicit = _stream_bool(stream, "canDownload", "can_download")
    if explicit is not None:
        return explicit
    return _stream_is_ready(stream) if _stream_is_torbox(stream) else True


def _stream_progress_percent(stream):
    stream = stream if isinstance(stream, dict) else {}
    value = stream.get("progressPercent", stream.get("progress_percent"))
    if value in (None, ""):
        return None
    return max(0, min(100, _as_int(value, 0)))


def _stream_eta_seconds(stream):
    stream = stream if isinstance(stream, dict) else {}
    value = stream.get("etaSeconds", stream.get("eta_seconds"))
    if value in (None, ""):
        return None
    seconds = _as_int(value, 0)
    return seconds if seconds > 0 else None


def _stream_eta_label(stream):
    seconds = _stream_eta_seconds(stream)
    if not seconds:
        return ""
    if seconds < 60:
        return tr("less than a minute")
    minutes = max(1, int(math.ceil(seconds / 60.0)))
    if minutes < 60:
        return tr("{0} min", minutes)
    hours, remaining_minutes = divmod(minutes, 60)
    if remaining_minutes:
        return tr("{0} h {1} min", hours, remaining_minutes)
    return tr("{0} h", hours)


def _stream_cache_status_label(stream):
    if not _stream_is_torbox(stream):
        return ""
    if _stream_availability(stream) == "unknown":
        return tr("Loading…")
    return (
        tr("Cached")
        if _stream_availability(stream) in ("ready", "cached")
        else tr("Not cached")
    )


def _stream_provider_display_label(stream):
    provider = _stream_provider(stream)
    if not _stream_is_torbox(stream):
        return provider
    if _stream_availability(stream) == "unknown":
        return "{0} · {1}".format(provider, tr("Loading…"))
    cached = _stream_availability(stream) in ("ready", "cached")
    color = "FF48E092" if cached else "FFFFB547"
    status = "cached" if cached else "uncached"
    return "{0} [COLOR {1}]({2})[/COLOR]".format(provider, color, status)


def _stream_availability_presentation(stream):
    stream = stream if isinstance(stream, dict) else {}
    provider = _stream_provider(stream)
    availability = _stream_availability(stream)
    progress = _stream_progress_percent(stream)
    eta = _stream_eta_label(stream)

    if availability == "ready":
        state, parts = "ready", [tr("Ready")]
    elif availability == "cached":
        state, parts = "cached", [tr("Cached"), tr("Ready after preparation")]
    elif availability == "downloading":
        state, parts = "downloading", []
        parts.append("{0}%".format(progress) if progress is not None else tr("Downloading"))
        parts.append("~{0}".format(eta) if eta else tr("Estimating time"))
    elif availability == "queued":
        state, parts = "waiting", [tr("Queued")]
        parts.append("~{0}".format(eta) if eta else tr("Waiting for a download slot"))
    elif availability == "uncached":
        state, parts = "waiting", [tr("Download required"), tr("ETA after start")]
    elif availability == "stalled":
        state, parts = "stalled", []
        if progress is not None:
            parts.append("{0}%".format(progress))
        parts.extend((tr("Stalled"), tr("No seeds")))
    elif availability == "error":
        state, parts = "error", [tr("Unavailable")]
    else:
        state, parts = "unknown", [tr("Availability unknown")]

    if provider.lower() == "torbox":
        parts = [_stream_cache_status_label(stream)]

    status = "  •  ".join(part for part in parts if part)
    label = "  •  ".join(part for part in (provider.upper(), status) if part)
    return state, label


def _stream_with_preparation_status(stream):
    """Overlay the durable background preparation state onto a stream row."""
    if not _stream_is_torbox(stream):
        return stream
    job = preparations_db.find_stream(stream.get("id"))
    if not job:
        return stream
    result = dict(stream)
    preparation_state = {
        "queued": "queued",
        "preparing": "downloading",
        "stalled": "stalled",
        "ready": "ready",
        "failed": "error",
        "canceled": "uncached",
    }.get(job.get("status"), stream.get("availability", "unknown"))
    result["availability"] = preparation_state
    result["isReady"] = job.get("status") == "ready"
    if job.get("status") == "ready":
        result["canDownload"] = True
    if job.get("progress") is not None:
        result["progressPercent"] = job.get("progress")
    if job.get("eta_seconds") is not None:
        result["etaSeconds"] = job.get("eta_seconds")
    if job.get("message"):
        result["availabilityMessage"] = job.get("message")
    return result


def _stream_playback_query_fields(stream):
    state, availability_label = _stream_availability_presentation(stream)
    progress = _stream_progress_percent(stream)
    eta = _stream_eta_seconds(stream)
    fields = {
        "provider": _stream_provider(stream),
        "availability": _stream_availability(stream),
        "is_ready": "true" if _stream_is_ready(stream) else "false",
        "can_download": "true" if _stream_can_download(stream) else "false",
        "availability_state": state,
        "availability_label": availability_label,
        "native_preferred": (
            "true"
            if _stream_preferred_subtitle_state(stream)[0] == "available"
            else "false"
        ),
        "native_subtitle_indexes": ",".join(
            str(index) for index in _stream_native_subtitle_indexes(stream)
        ),
        "subtitle_metadata_complete": (
            "true" if _stream_metadata_is_complete(stream) else "false"
        ),
    }
    if progress is not None:
        fields["progress_percent"] = progress
    if eta is not None:
        fields["eta_seconds"] = eta
    message = _clean_query_value(stream.get("availabilityMessage"))
    if message:
        fields["availability_message"] = message
    return fields

def _stream_language_label(language):
    normalized = _clean_query_value(language).lower().split("-", 1)[0]
    return {
        "cs": "CZ",
        "cze": "CZ",
        "ces": "CZ",
        "sk": "SK",
        "slo": "SK",
        "slk": "SK",
        "en": "EN",
        "eng": "EN",
        "de": "DE",
        "deu": "DE",
        "ger": "DE",
        "pl": "PL",
        "pol": "PL",
        "hu": "HU",
        "hun": "HU",
        "und": "UND",
    }.get(normalized, normalized.upper())


def _stream_subtitle_tracks(stream):
    return [
        track for track in (stream.get("subtitleTracks") or [])
        if isinstance(track, dict)
    ]


def _stream_subtitle_track_is_forced(track):
    return _stream_bool(
        track if isinstance(track, dict) else {},
        "isForced", "is_forced", "forced",
    ) is True


def _stream_native_subtitle_indexes(stream):
    """Return non-forced SK/CZ subtitle indexes, preferring Slovak."""
    preferred = []
    for index, track in enumerate(_stream_subtitle_tracks(stream)):
        language = _stream_language_label(track.get("language"))
        if language not in ("SK", "CZ") or _stream_subtitle_track_is_forced(track):
            continue
        preferred.append((0 if language == "SK" else 1, index))
    return [index for _rank, index in sorted(preferred)]

def _stream_quality(stream):
    quality = _clean_query_value(stream.get("quality"))
    width = _as_int(stream.get("width"), 0)
    height = _as_int(stream.get("height"), 0)
    dimension_quality = ""
    if width >= 3800 or height >= 2100:
        dimension_quality = "4K"
    elif width >= 2500 or height >= 1400:
        dimension_quality = "1440p"
    elif width >= 1900 or height >= 1000:
        dimension_quality = "1080p"
    elif width >= 1200 or height >= 700:
        dimension_quality = "720p"
    elif height > 0:
        dimension_quality = "{0}p".format(height)

    # Complete dimensions are the source of truth. This also corrects labels
    # from an older backend that classified cropped video by height alone.
    if width > 0 and height > 0:
        return dimension_quality
    return quality or dimension_quality

def _stream_channel_label(channels):
    channels = _as_int(channels, 0)
    return {
        1: "1.0",
        2: "2.0",
        6: "5.1",
        8: "7.1",
    }.get(channels, "{0} ch".format(channels) if channels else "")

def _stream_audio_label(track, include_language=True):
    if not isinstance(track, dict):
        return ""
    return " ".join(value for value in (
        _stream_language_label(track.get("language")) if include_language else "",
        _clean_query_value(track.get("codec")),
        _stream_channel_label(track.get("channels")),
    ) if value and value != "UND")

def _stream_sorted_audio_tracks(stream):
    tracks = [track for track in (stream.get("audioTracks") or [])
              if isinstance(track, dict)]

    def priority(track):
        language = _stream_language_label(track.get("language"))
        if language == "SK":
            return 0
        if language == "CZ":
            return 1
        if language == "EN":
            return 2
        if language and language != "UND":
            return 3
        return 4

    # Python's sort is stable, so tracks within the same language tier retain
    # their original container order and default-track relationship.
    return sorted(tracks, key=priority)

def _stream_audio_summary(stream):
    tracks = _stream_sorted_audio_tracks(stream)
    if not tracks:
        return "NO AUDIO" if _stream_inventory_complete(stream, "audio") else "AUDIO ?"

    best_track = tracks[0]
    language = _stream_language_label(best_track.get("language"))
    language_status = (
        "{0} AUDIO".format(language)
        if language and language != "UND"
        else "AUDIO ?"
    )
    format_status = _stream_audio_label(best_track, include_language=False)
    return "  •  ".join(value for value in (
        language_status,
        format_status,
    ) if value)

def _stream_metadata_is_complete(stream):
    return _clean_query_value(stream.get("metadataStatus")).lower() == "complete"

def _stream_inventory_complete(stream, kind):
    if isinstance(stream.get("metadataFields"), dict):
        return stream_cards.field_evidence(stream, kind + "Tracks").get("complete") is True
    return _stream_metadata_is_complete(stream)

def _stream_track_detail(track, kind):
    if not isinstance(track, dict):
        return ""
    values = []
    codec = _clean_query_value(track.get("codec"))
    if kind == "audio":
        channels = _stream_channel_label(track.get("channels"))
        technical = " ".join(value for value in (codec, channels) if value)
        if technical:
            values.append(technical)
    elif codec:
        values.append(codec)
    if track.get("isDefault"):
        values.append(tr("default"))
    if kind == "subtitle" and _stream_subtitle_track_is_forced(track):
        values.append(tr("forced"))
    return ", ".join(values)

def _stream_grouped_track_summary(tracks, kind):
    """Group tracks into the scan order used by the stream picker.

    Audio and subtitle arrays can contain several tracks for one language.
    Keep every distinct format while presenting the household's likely choices
    first: Slovak, Czech, English, then all remaining/unknown languages.
    """
    preferred = {"SK": [], "CZ": [], "EN": []}
    other = {}
    other_order = []
    for track in tracks:
        if not isinstance(track, dict):
            continue
        language_label = _stream_language_label(track.get("language"))
        detail = _stream_track_detail(track, kind)
        if language_label in preferred:
            bucket = preferred[language_label]
        else:
            display_language = (
                tr("Unknown")
                if language_label in ("", "UND")
                else language_label
            )
            if display_language not in other:
                other[display_language] = []
                other_order.append(display_language)
            bucket = other[display_language]
        if detail not in bucket:
            bucket.append(detail)

    def entry(language_label, details):
        details = [detail for detail in details if detail]
        return (
            "{0} ({1})".format(language_label, " / ".join(details))
            if details else language_label
        )

    segments = [
        entry(language_label, preferred[language_label])
        for language_label in ("SK", "CZ", "EN")
        if preferred[language_label]
    ]
    if other_order:
        segments.append("{0}: {1}".format(
            tr("Other"),
            ", ".join(entry(language_label, other[language_label])
                      for language_label in other_order),
        ))
    return "  •  ".join(segments)

def _stream_audio_presentation(stream):
    tracks = _stream_sorted_audio_tracks(stream)
    if not tracks:
        return (
            ("none", tr("None"))
            if _stream_inventory_complete(stream, "audio")
            else ("unknown", tr("Not verified"))
        )
    summary = _stream_grouped_track_summary(tracks, "audio")
    languages = {_stream_language_label(track.get("language"))
                 for track in tracks}
    state = "preferred" if languages.intersection(("SK", "CZ")) else "available"
    return state, summary

def _stream_subtitle_presentation(stream):
    tracks = _stream_subtitle_tracks(stream)
    if not tracks:
        tracks = [
            {"language": language}
            for language in (stream.get("subtitleLanguages") or [])
            if _clean_query_value(language)
        ]
    if not tracks and stream.get("hasPreferredSubtitles"):
        return "preferred", tr("CZ/SK (details unavailable)")
    if not tracks and stream.get("hasBundledSubtitles"):
        return "available", "{0}: {1}".format(
            tr("Other"), tr("Language unknown")
        )
    if not tracks:
        return (
            ("none", tr("None"))
            if _stream_inventory_complete(stream, "subtitle")
            else ("unknown", tr("Not verified"))
        )
    summary = _stream_grouped_track_summary(tracks, "subtitle")
    full_languages = {
        _stream_language_label(track.get("language"))
        for track in tracks
        if not _stream_subtitle_track_is_forced(track)
    }
    state = (
        "preferred"
        if full_languages.intersection(("SK", "CZ"))
        else "available"
    )
    return state, summary

def _stream_state_markup(value, state):
    color = {
        "preferred": "FF48E092",
        "available": "FFE7E7EA",
        "none": "FF8A8D92",
        "unknown": "FFFFC45C",
    }.get(state, "FFE7E7EA")
    return "[COLOR {0}]{1}[/COLOR]".format(color, value)

def _stream_value_markup(value, state):
    # Keep known track languages neutral: a preferred SK/CZ track should not
    # make every EN/Other track look preferred too. Only absence/uncertainty
    # needs value-level status color; the field label carries other states.
    if state in ("none", "unknown"):
        return _stream_state_markup(value, state)
    return value

def _stream_size_label(stream):
    size = stream.get("sizeInGB")
    if size in (None, ""):
        return tr("SIZE ?")
    try:
        numeric_size = float(size)
    except (TypeError, ValueError):
        return "{0} GB".format(size)
    return "{0:g} GB".format(numeric_size) if numeric_size > 0 else tr("SIZE ?")

def _stream_resolution_label(stream):
    quality = _stream_quality(stream)
    width = _as_int(stream.get("width"), 0)
    height = _as_int(stream.get("height"), 0)
    dimensions = "{0}×{1}".format(width, height) if width and height else ""
    return "  ".join(value for value in (quality, dimensions) if value) or tr("RES ?")


def _stream_resolution_note(stream):
    """Return the compact, non-duplicative resolution note from Reference 08."""
    quality = _stream_quality(stream).strip().lower()
    note = {
        "4k": "2160p",
        "1440p": "QHD",
        "1080p": "Full HD",
        "720p": "HD",
    }.get(quality)
    if note:
        return note

    match = re.fullmatch(r"(\d+)p", quality)
    if match and int(match.group(1)) <= 576:
        return "SD"
    return ""

def _stream_hdr_label(stream):
    formats = stream_cards.hdr_formats(stream)
    if formats:
        return " · ".join(item["format"] for item in formats)
    hdr = _clean_query_value(stream.get("hdrFormat"))
    if hdr:
        return hdr
    if _clean_query_value(stream.get("metadataStatus")).lower() == "pending" or stream.get("metadataRefreshing") is True:
        return tr("Loading…")
    return "SDR"

def _stream_source_label(stream):
    source = _clean_query_value(stream.get("releaseSource"))
    # Older API/cache entries used only "Remux" for Blu-ray remux names.
    # Recover the actual source for display without invalidating that cache.
    if source.lower() == "remux" and re.search(
            r"(?:blu[. _-]?ray|(?:^|[. _-])bd[. _-]?remux(?:$|[. _-]))",
            _stream_display_name(stream), re.I):
        return "Blu-ray Remux"
    return source or tr("SOURCE ?")

def _stream_metadata_badge(stream):
    status = _clean_query_value(stream.get("metadataStatus")).lower()
    return {
        "complete": "",
        "partial": tr("PARTIAL INFO"),
        "providerbusy": tr("PROBE BUSY"),
        "unsupported": tr("LIMITED INFO"),
        "temporaryfailure": tr("UNVERIFIED"),
    }.get(status, tr("UNVERIFIED"))

def _stream_container_label(stream):
    container = _clean_query_value(stream.get("container"))
    return {
        "matroska": "MKV",
        "mpeg-ts": "MPEG-TS",
    }.get(container.lower(), container)

def _stream_extra_summary(stream):
    fps = _as_float(stream.get("frameRate"), 0.0)
    return "  •  ".join(value for value in (
        _stream_container_label(stream),
        _stream_duration_label(stream),
        "{0:g} fps".format(fps) if fps else "",
        _stream_bitrate_label(stream),
    ) if value)


def _stream_stats_summary(stream):
    """Compact right-aligned facts used by the dedicated stream picker."""
    fps = _as_float(stream.get("frameRate"), 0.0)
    return "  •  ".join(value for value in (
        _stream_duration_label(stream),
        "{0:g} fps".format(fps) if fps else "",
        _stream_bitrate_label(stream),
    ) if value)


def _stream_bitrate_label(stream):
    """Return the whole-file average bitrate needed to stream the item."""
    duration = _as_int(stream.get("durationInSeconds"), 0)
    if duration <= 0:
        duration = _as_int(stream.get("lengthInMins"), 0) * 60
    size_gib = _as_float(stream.get("sizeInGB"), 0.0)
    bitrate = 0
    if duration > 0 and size_gib > 0:
        bitrate = int(round(
            (size_gib * 8 * 1024 * 1024 * 1024) / (duration * 1000)
        ))

    if bitrate >= 1000:
        value = "{0:g} Mbps".format(round(bitrate / 1000.0, 1))
    elif bitrate > 0:
        value = "{0} kbps".format(bitrate)
    else:
        return tr("BITRATE ?")
    return value


def _stream_duration_pill_label(stream):
    return _stream_duration_label(stream) or tr("LENGTH ?")


def _stream_metrics_summary(stream):
    """Combine the existing truthful metric labels for the row header."""
    return " · ".join((
        _stream_size_label(stream),
        _stream_bitrate_label(stream),
        _stream_duration_pill_label(stream),
    ))


def _stream_source_pill_label(stream):
    """Refine broad backend source values when the release name is explicit."""
    source = _clean_query_value(stream.get("releaseSource"))
    name = _stream_display_name(stream)
    is_remux = bool(re.search(r"remux", name, re.I))
    is_bluray = bool(re.search(
        r"(?:blu[. _-]?ray|(?:^|[. _-])(?:bd|br)(?=$|[. _-]|rip|remux))",
        name, re.I
    ))
    if is_remux and is_bluray:
        if re.search(
                r"(?:^|[. _-])(?:uhd|ultra[. _-]?hd)(?:$|[. _-])",
                name, re.I):
            return "UHD Blu-ray remux"
        return "Blu-ray remux"
    if is_remux:
        return "Remux"
    if re.search(r"(?:^|[. _-])(?:bd|br)[. _-]?rip(?:$|[. _-])", name, re.I):
        return "Blu-ray rip"
    if re.search(r"web[. _-]?dl", name, re.I):
        return "WEB-DL"
    if re.search(r"web[. _-]?rip", name, re.I):
        return "WEB rip"
    if re.search(r"blu[. _-]?ray", name, re.I):
        return "Blu-ray"
    if re.search(r"(?:^|[. _-])hdtv(?:$|[. _-])", name, re.I):
        return "TV broadcast"
    if re.search(r"(?:^|[. _-])dvd(?:rip)?(?:$|[. _-])", name, re.I):
        return "DVD"
    if not source:
        return ""
    return {
        "remux": "Remux",
        "web-dl": "WEB-DL",
        "webrip": "WEB rip",
        "hdtv": "TV broadcast",
        "dvd": "DVD",
    }.get(source.lower(), source)


def _stream_hdr_pill_labels(stream):
    """Expose each dynamic-range format as a separate, ordered pill label."""
    formats = stream_cards.hdr_formats(stream)
    if any(item.get("verified") is True for item in formats):
        return [item["format"] for item in formats]
    hdr = _clean_query_value(stream.get("hdrFormat"))
    evidence = "{0} {1}".format(hdr, _stream_display_name(stream))
    labels = []

    def add(label, pattern):
        if re.search(pattern, evidence, re.I) and label not in labels:
            labels.append(label)

    add("Dolby Vision", r"(?:dolby[. _-]?vision|dovi|(?:^|[. _-])dv(?:$|[. _-]))")
    add("HDR10+", r"(?:hdr10[+]|hdr10[. _-]?plus)")
    add("HDR10", r"(?:^|[. _-])hdr10(?:$|[. _-])")
    add("HDR", r"(?:^|[. _-])hdr(?:$|[. _-])")
    add("HLG", r"(?:^|[. _-])hlg(?:$|[. _-])")
    if hdr and not labels:
        labels.append(hdr)
    if labels:
        return labels
    return [_stream_hdr_label(stream)]


def _stream_hdr_pill_label(stream):
    """Retain a combined value for filters and non-skin stream summaries."""
    return " + ".join(_stream_hdr_pill_labels(stream))


def _stream_audio_feature_label(stream):
    """Identify premium audio only from explicit codec or release evidence."""
    name = _stream_display_name(stream)
    codecs = " ".join(
        _clean_query_value(track.get("codec"))
        for track in (stream.get("audioTracks") or [])
        if isinstance(track, dict)
    )
    evidence = "{0} {1}".format(name, codecs)
    features = (
        ("Dolby Atmos", r"(?:^|[. _-])atmos(?:$|[. _-])"),
        ("DTS:X", r"(?:^|[. _-])dts[. _:-]?x(?:$|[. _-])"),
        ("Auro-3D", r"(?:^|[. _-])auro[. _-]?3d(?:$|[. _-])"),
        ("DTS-HD MA", r"(?:dts[. _-]?hd[. _-]?(?:ma|master))"),
        ("Dolby TrueHD", r"(?:true[. _-]?hd)"),
        ("Dolby Digital+", r"(?:e[. _-]?ac[. _-]?3|ddp)"),
    )
    return next((label for label, pattern in features
                 if re.search(pattern, evidence, re.I)), "")


def _stream_audio_track_feature(stream, track, track_index):
    """Attach a stream-level spatial-audio hint to its best matching track."""
    if not stream:
        return ""
    feature = _stream_audio_feature_label(stream)
    if feature != "Dolby Atmos":
        return ""

    tracks = [item for item in (stream.get("audioTracks") or [])
              if isinstance(item, dict)]

    def normalized_codec(item):
        return re.sub(
            r"[^A-Z0-9+]", "",
            _clean_query_value(item.get("codec")).upper(),
        )

    # Atmos is most commonly carried by TrueHD. Prefer that explicit carrier,
    # then fall back to Dolby Digital+ when it is the only viable option.
    truehd_indexes = [
        index for index, item in enumerate(tracks)
        if normalized_codec(item) in ("TRUEHD", "DOLBYTRUEHD")
    ]
    compatible_indexes = truehd_indexes or [
        index for index, item in enumerate(tracks)
        if normalized_codec(item) in (
            "EAC3", "DOLBYDIGITAL+", "DOLBYDIGITALPLUS", "DDP",
        )
    ]
    return "Atmos" if compatible_indexes[:1] == [track_index] else ""


def _stream_audio_pill_label(track, stream=None, track_index=None):
    language_label = _stream_language_label(track.get("language"))
    codec = _clean_query_value(track.get("codec"))
    normalized_codec = re.sub(r"[^A-Z0-9+]", "", codec.upper())
    codec = {
        "DTSHDMA": "DTS-HD MA",
        "DTSHDMASTERAUDIO": "DTS-HD MA",
        "DOLBYTRUEHD": "Dolby TrueHD",
        "TRUEHD": "Dolby TrueHD",
        "DOLBYDIGITALPLUS": "Dolby Digital+",
        "DOLBYDIGITAL+": "Dolby Digital+",
        "EAC3": "Dolby Digital+",
        "DDP": "Dolby Digital+",
        "DOLBYDIGITAL": "Dolby Digital",
        "AC3": "Dolby Digital",
        "DTSX": "DTS:X",
        "MPEG4AAC": "AAC",
    }.get(normalized_codec, codec) or tr("CODEC ?")
    feature = _stream_audio_track_feature(stream, track, track_index)
    if feature:
        codec = "{0} + {1}".format(codec, feature)
    channels = _stream_channel_label(track.get("channels"))
    return " · ".join(value for value in (
        language_label if language_label != "UND" else tr("Unknown"),
        codec,
        channels,
    ) if value)


def _stream_pill_tone(pill):
    """Return the semantic language color token for an emitted pill."""
    if tr("forced").upper() in _clean_query_value(pill).upper():
        return "neutral"
    language = _clean_query_value(pill).partition("·")[0].strip().upper()
    return {
        "SK": "sk",
        "CZ": "cz",
        "EN": "en",
    }.get(language, "neutral")


def _stream_preferred_track_pills(stream, kind):
    """Pack SK, CZ and EN into fixed Kodi pill slots, then count the rest."""
    if kind == "audio":
        tracks = [track for track in (stream.get("audioTracks") or [])
                  if isinstance(track, dict)]
    else:
        tracks = _stream_subtitle_tracks(stream)
        if not tracks:
            tracks = [
                {"language": language}
                for language in (stream.get("subtitleLanguages") or [])
                if _clean_query_value(language)
            ]

    pills = []
    used_indexes = set()
    for preferred_language in ("SK", "CZ", "EN"):
        candidates = [
            (index, track) for index, track in enumerate(tracks)
            if _stream_language_label(track.get("language")) == preferred_language
        ]
        if not candidates:
            continue
        if kind == "subtitle":
            index, track = min(
                candidates,
                key=lambda candidate: (
                    1 if _stream_subtitle_track_is_forced(candidate[1]) else 0,
                    0 if candidate[1].get("isDefault") else 1,
                    candidate[0],
                ),
            )
        else:
            index, track = next(
                ((index, track) for index, track in candidates
                 if track.get("isDefault")),
                candidates[0],
            )
        used_indexes.add(index)
        if kind == "audio":
            pills.append(_stream_audio_pill_label(track, stream, index))
        else:
            pills.append(
                "{0} · {1}".format(preferred_language, tr("forced").upper())
                if _stream_subtitle_track_is_forced(track)
                else preferred_language
            )

    # If there is no household-preferred language, keep the best known
    # alternative actionable instead of reducing the row to "+N OTHER".
    if not pills and tracks:
        index, track = next(
            (
                (index, track)
                for index, track in enumerate(tracks)
                if track.get("isDefault")
            ),
            (0, tracks[0]),
        )
        used_indexes.add(index)
        if kind == "audio":
            pills.append(_stream_audio_pill_label(track, stream, index))
        else:
            language = _stream_language_label(track.get("language"))
            label = tr("Unknown") if language in ("", "UND") else language
            if _stream_subtitle_track_is_forced(track):
                label = "{0} · {1}".format(label, tr("forced").upper())
            pills.append(label)

    overflow = max(0, len(tracks) - len(used_indexes))
    if kind == "subtitle" and not pills and overflow == 0:
        if stream.get("hasPreferredSubtitles"):
            pills.append("SK/CZ")
        elif stream.get("hasBundledSubtitles"):
            pills.append("SUB")
    if not pills and overflow == 0:
        if _stream_inventory_complete(stream, "audio" if kind == "audio" else "subtitle"):
            pills.append(tr("NO AUDIO") if kind == "audio" else tr("NO SUBTITLES"))
        else:
            pills.append(tr("AUDIO ?") if kind == "audio" else tr("SUBTITLES ?"))
    return pills[:3], "+{0} {1}".format(
        overflow, tr("Other").upper()
    ) if overflow else ""


def _stream_pill_properties(stream):
    audio_pills, audio_overflow = _stream_preferred_track_pills(stream, "audio")
    subtitle_pills, subtitle_overflow = _stream_preferred_track_pills(
        stream, "subtitle"
    )
    hdr_pills = _stream_hdr_pill_labels(stream)
    properties = {
        "App.StreamQualityPill": _stream_quality(stream) or tr("RES ?"),
        "App.StreamBitrate": _stream_bitrate_label(stream),
        "App.StreamDuration": _stream_duration_pill_label(stream),
        "App.StreamContainer": _stream_container_label(stream),
        "App.StreamHdrPill": " + ".join(hdr_pills),
        "App.StreamAudioFeature": _stream_audio_feature_label(stream),
        "App.StreamSourcePill": _stream_source_pill_label(stream),
        "App.StreamAudioOverflow": audio_overflow,
        "App.StreamSubtitleOverflow": subtitle_overflow,
    }
    for index in range(5):
        properties["App.StreamHdrPill{0}".format(index + 1)] = (
            hdr_pills[index] if index < len(hdr_pills) else ""
        )
    quality = properties["App.StreamQualityPill"]
    quality_tone = {
        "4K": "quality_4k",
        "1080p": "quality_1080p",
        "720p": "quality_720p",
    }.get(quality, "quality_other")
    video_pills = [(quality, quality_tone)]
    video_pills.extend((label, "hdr") for label in hdr_pills)
    codec = _clean_query_value(stream.get("videoCodec"))
    if codec:
        video_pills.append((codec, "codec"))
    for index in range(7):
        slot = index + 1
        text, tone = (
            video_pills[index]
            if index < len(video_pills)
            else ("", "neutral")
        )
        properties["App.StreamVideoPill{0}".format(slot)] = text
        properties["App.StreamVideoPill{0}Tone".format(slot)] = tone
    for index in range(3):
        slot = index + 1
        audio_pill = audio_pills[index] if index < len(audio_pills) else ""
        subtitle_pill = (
            subtitle_pills[index] if index < len(subtitle_pills) else ""
        )
        properties["App.StreamAudioPill{0}".format(slot)] = audio_pill
        properties["App.StreamAudioPill{0}Tone".format(slot)] = (
            _stream_pill_tone(audio_pill)
        )
        properties["App.StreamSubtitlePill{0}".format(slot)] = subtitle_pill
        properties["App.StreamSubtitlePill{0}Tone".format(slot)] = (
            _stream_pill_tone(subtitle_pill)
        )
        properties["App.StreamSubtitlePill{0}Wide".format(slot)] = (
            "true" if len(subtitle_pill) > 4 else "false"
        )
    separator = "  ·  "
    properties["App.StreamVideoText"] = separator.join(
        text for text, _tone in video_pills if text
    )
    audio_separator = separator

    def audio_text(value):
        parts = value.split(" · ")
        if len(parts) < 2:
            return value
        return "{0}: {1}".format(parts[0], " ".join(parts[1:]))

    properties["App.StreamAudioText"] = audio_separator.join(
        audio_text(value)
        for value in audio_pills + ([audio_overflow] if audio_overflow else [])
        if value
    )
    properties["App.StreamSubtitleText"] = separator.join(
        value
        for value in subtitle_pills
        + ([subtitle_overflow] if subtitle_overflow else [])
        if value
    )
    for focused, suffix in ((False, "Display"), (True, "FocusedDisplay")):
        highlight_colors = {
            "4k": "FFB98AFF" if focused else "FFA773F2",
            "hdr": "FFFFD477" if focused else "FFF0BE5A",
            "sk": "FF72DC91" if focused else "FF5FCB7E",
            "cz": "FFFFCB66" if focused else "FFEAB650",
        }

        def highlighted(
            values, tone_for_value, join_separator=separator, formatter=None
        ):
            pieces = []
            for value in values:
                if not value:
                    continue
                tone = tone_for_value(value)
                display_value = formatter(value) if formatter else value
                if tone in highlight_colors:
                    display_value = "[COLOR {0}]{1}[/COLOR]".format(
                        highlight_colors[tone], display_value
                    )
                pieces.append(display_value)
            return join_separator.join(pieces)

        video_pieces = []
        for value, tone in video_pills:
            normalized_value = value.upper().replace(" ", "")
            highlight_tone = (
                "4k"
                if normalized_value == "4K"
                else "hdr"
                if tone == "hdr" and normalized_value not in ("SDR", "HDR?")
                else ""
            )
            if highlight_tone in highlight_colors:
                value = "[COLOR {0}]{1}[/COLOR]".format(
                    highlight_colors[highlight_tone], value
                )
            video_pieces.append(value)
        properties["App.StreamVideoText" + suffix] = separator.join(
            video_pieces
        )
        properties["App.StreamAudioText" + suffix] = highlighted(
            audio_pills + ([audio_overflow] if audio_overflow else []),
            lambda value: _stream_pill_tone(value),
            audio_separator,
            audio_text,
        )
        properties["App.StreamSubtitleText" + suffix] = highlighted(
            subtitle_pills
            + ([subtitle_overflow] if subtitle_overflow else []),
            lambda value: _stream_pill_tone(value),
        )
    return properties


def _stream_pill_sheet_rows(properties):
    """Return the ordered, row-bound pills used by the stream picker."""
    quality = properties.get("App.StreamQualityPill", "")
    quality_tone = {
        "4K": "quality_4k",
        "1080p": "quality_1080p",
        "720p": "quality_720p",
    }.get(quality, "quality_other")
    video = [(quality, quality_tone)] if quality else []
    video.extend(
        (properties.get("App.StreamHdrPill{0}".format(index), ""), "hdr")
        for index in range(1, 6)
        if properties.get("App.StreamHdrPill{0}".format(index), "")
    )
    codec = properties.get("App.StreamCodec", "")
    if codec:
        video.append((codec, "codec"))

    audio = []
    subtitles = []
    for index in range(1, 4):
        audio_text = properties.get("App.StreamAudioPill{0}".format(index), "")
        if audio_text:
            audio.append((
                audio_text,
                properties.get(
                    "App.StreamAudioPill{0}Tone".format(index), "neutral"
                ),
            ))
        subtitle_text = properties.get(
            "App.StreamSubtitlePill{0}".format(index), ""
        )
        if subtitle_text:
            subtitles.append((
                subtitle_text,
                properties.get(
                    "App.StreamSubtitlePill{0}Tone".format(index), "neutral"
                ),
            ))
    audio_overflow = properties.get("App.StreamAudioOverflow", "")
    if audio_overflow:
        audio.append((audio_overflow, "neutral"))
    subtitle_overflow = properties.get("App.StreamSubtitleOverflow", "")
    if subtitle_overflow:
        subtitles.append((subtitle_overflow, "neutral"))
    return video, audio, subtitles


def _stream_pill_fit_text(text, available_width, measure_text):
    """Ellipsize only when a complete pill row reaches the card boundary."""
    text_room = max(0, available_width - 2 * STREAM_PILL_PADDING_X)
    if math.ceil(measure_text(text)) <= text_room:
        return text
    ellipsis = "…"
    if math.ceil(measure_text(ellipsis)) > text_room:
        return ""
    candidate = text
    while candidate and math.ceil(
            measure_text(candidate.rstrip() + ellipsis)) > text_room:
        candidate = candidate[:-1]
    return candidate.rstrip() + ellipsis


def _stream_pill_sheet_layout(properties, measure_text):
    """Measure content-width pills with one shared left/right padding value."""
    rows = []
    for row_index, pills in enumerate(_stream_pill_sheet_rows(properties)):
        left = 0
        laid_out = []
        for text, tone in pills:
            available = STREAM_PILL_SHEET_WIDTH - left
            minimum = 2 * STREAM_PILL_PADDING_X + int(
                math.ceil(measure_text("…"))
            )
            if available < minimum:
                break
            display_text = _stream_pill_fit_text(text, available, measure_text)
            if not display_text:
                break
            width = int(math.ceil(measure_text(display_text))) + (
                2 * STREAM_PILL_PADDING_X
            )
            laid_out.append({
                "text": display_text,
                "source_text": text,
                "tone": tone,
                "left": left,
                "top": STREAM_PILL_ROW_TOPS[row_index],
                "width": width,
                "height": STREAM_PILL_HEIGHT,
            })
            left += width + STREAM_PILL_GAP
        rows.append(laid_out)
    return rows


def _stream_pill_argb(value):
    value = value.lstrip("#")
    if len(value) == 6:
        value = "FF" + value
    return (
        int(value[2:4], 16),
        int(value[4:6], 16),
        int(value[6:8], 16),
        int(value[0:2], 16),
    )


def _stream_pill_color_values(tone, focused):
    fills = {
        "quality_4k": ("EE7639E8", "FF8748FA"),
        "quality_1080p": ("E7357FD1", "F94891ED"),
        "quality_720p": ("E72E9B68", "F93CB77B"),
        "quality_other": ("D8946A25", "EEAA7B2D"),
        "hdr": ("B57435B6", "E1894BD2"),
        "codec": ("B82D70CC", "E23E88EC"),
        "sk": ("A83A8E58", "C849AE6B"),
        "cz": ("A89B7626", "C8BE9233"),
        "en": ("A8327EA8", "C83D9AC7"),
        "neutral": ("78343B44", "963D4651"),
    }
    text_colors = {
        "hdr": ("FFE4CAFF", "FFF0DDFF"),
        "codec": ("FFC8DAFA", "FFE0EBFF"),
        "neutral": ("FFB9BBBE", "FFD3D5D8"),
    }
    state = 1 if focused else 0
    fill = fills.get(tone, fills["neutral"])[state]
    text = text_colors.get(
        tone,
        ("FFE7ECEF", "FFF4F7F8")
        if tone in ("sk", "cz", "en")
        else ("FFFFFFFF", "FFFFFFFF"),
    )[state]
    return fill, text


def _stream_pill_colors(tone, focused):
    fill, text = _stream_pill_color_values(tone, focused)
    return _stream_pill_argb(fill), _stream_pill_argb(text)


def _stream_pill_pil_modules():
    global _STREAM_PILL_PIL
    if _STREAM_PILL_PIL is False:
        return None
    if _STREAM_PILL_PIL is None:
        try:
            from PIL import Image, ImageDraw, ImageFont
            _STREAM_PILL_PIL = (Image, ImageDraw, ImageFont)
        except (ImportError, OSError):
            _STREAM_PILL_PIL = False
    return _STREAM_PILL_PIL or None


def _stream_pill_font(image_font, size=18):
    candidates = []
    get_skin_dir = getattr(xbmc, "getSkinDir", None)
    if callable(get_skin_dir):
        try:
            skin_id = get_skin_dir()
            if skin_id:
                skin_path = xbmcaddon.Addon(skin_id).getAddonInfo("path")
                candidates.extend((
                    os.path.join(skin_path, "fonts", "NotoSans-Regular.ttf"),
                    os.path.join(skin_path, "fonts", "arial.ttf"),
                ))
        except Exception:
            pass
    candidates.extend((
        "special://xbmc/addons/skin.estuary/fonts/NotoSans-Regular.ttf",
        "special://xbmc/media/Fonts/arial.ttf",
    ))
    for candidate in candidates:
        path = xbmcvfs.translatePath(candidate)
        if path and os.path.isfile(path):
            try:
                return image_font.truetype(path, size), path
            except (OSError, ValueError):
                continue
    try:
        return image_font.load_default(size=size), "default"
    except TypeError:
        return image_font.load_default(), "default"


def _stream_pill_text_width(font, text):
    get_length = getattr(font, "getlength", None)
    if callable(get_length):
        return float(get_length(text))
    get_bbox = getattr(font, "getbbox", None)
    if callable(get_bbox):
        box = get_bbox(text)
        return float(box[2] - box[0])
    return float(font.getsize(text)[0])


def _stream_pill_text_origin(draw, font, text, bounds):
    """Center glyphs horizontally while preserving a shared text baseline."""
    text_bounds = draw.textbbox((0, 0), text, font=font)
    reference_bounds = draw.textbbox((0, 0), "Ag", font=font)
    left, top, right, bottom = bounds
    text_width = text_bounds[2] - text_bounds[0]
    reference_height = reference_bounds[3] - reference_bounds[1]
    return (
        left + ((right - left - text_width) / 2.0) - text_bounds[0],
        top
        + ((bottom - top - reference_height) / 2.0)
        - reference_bounds[1],
    )


def _draw_stream_pill(draw, font, pill, focused):
    """Draw one pill with a single, unduplicated glyph layer."""
    left = pill["left"] * STREAM_PILL_DRAW_SCALE
    top = pill["top"] * STREAM_PILL_DRAW_SCALE
    right = (
        (pill["left"] + pill["width"]) * STREAM_PILL_DRAW_SCALE
    ) - 1
    bottom = (
        (pill["top"] + pill["height"]) * STREAM_PILL_DRAW_SCALE
    ) - 1
    fill, text_color = _stream_pill_colors(pill["tone"], focused)
    draw.rounded_rectangle(
        (left, top, right, bottom),
        radius=11 * STREAM_PILL_DRAW_SCALE,
        fill=fill,
    )
    text_origin = _stream_pill_text_origin(
        draw,
        font,
        pill["text"],
        (left, top, right + 1, bottom + 1),
    )
    draw.text(
        text_origin,
        pill["text"],
        font=font,
        fill=text_color,
    )


def _stream_pill_render_dimensions():
    """Render once at 2x: 4K-native and supersampled below 4K."""
    return (
        STREAM_PILL_SHEET_WIDTH * STREAM_PILL_RENDER_SCALE,
        STREAM_PILL_SHEET_HEIGHT * STREAM_PILL_RENDER_SCALE,
    )


def _stream_pill_cache_dir():
    profile = xbmcaddon.Addon().getAddonInfo("profile")
    path = xbmcvfs.translatePath(profile)
    if not path:
        return ""
    cache_dir = os.path.join(path, "stream-pill-cache")
    os.makedirs(cache_dir, exist_ok=True)
    return cache_dir


def _render_stream_pill_sheet(properties, focused=False):
    modules = _stream_pill_pil_modules()
    if not modules:
        return ""
    Image, ImageDraw, ImageFont = modules
    try:
        font, font_key = _stream_pill_font(ImageFont)
        draw_font, _draw_font_key = _stream_pill_font(
            ImageFont, 18 * STREAM_PILL_DRAW_SCALE
        )
        layout = _stream_pill_sheet_layout(
            properties,
            lambda text: _stream_pill_text_width(font, text),
        )
        render_dimensions = _stream_pill_render_dimensions()
        cache_key = repr((
            _STREAM_PILL_CACHE_VERSION,
            focused,
            font_key,
            render_dimensions,
            [[(pill["text"], pill["tone"], pill["left"], pill["width"])
              for pill in row] for row in layout],
        ))
        filename = hashlib.sha256(cache_key.encode("utf-8")).hexdigest() + ".png"
        cache_dir = _stream_pill_cache_dir()
        if not cache_dir:
            return ""
        target = os.path.join(cache_dir, filename)
        if os.path.isfile(target):
            return target

        with _STREAM_PILL_CACHE_LOCK:
            if os.path.isfile(target):
                return target
            image = Image.new(
                "RGBA",
                (
                    STREAM_PILL_SHEET_WIDTH * STREAM_PILL_DRAW_SCALE,
                    STREAM_PILL_SHEET_HEIGHT * STREAM_PILL_DRAW_SCALE,
                ),
                (0, 0, 0, 0),
            )
            draw = ImageDraw.Draw(image)
            for row in layout:
                for pill in row:
                    _draw_stream_pill(draw, draw_font, pill, focused)
            draw_dimensions = (
                STREAM_PILL_SHEET_WIDTH * STREAM_PILL_DRAW_SCALE,
                STREAM_PILL_SHEET_HEIGHT * STREAM_PILL_DRAW_SCALE,
            )
            if draw_dimensions != render_dimensions:
                resampling = getattr(Image, "Resampling", Image)
                image = image.resize(
                    render_dimensions,
                    resample=resampling.LANCZOS,
                )
            temporary = target + ".{0}.tmp".format(uuid.uuid4().hex)
            try:
                image.save(temporary, format="PNG", optimize=True)
                os.replace(temporary, target)
            finally:
                if os.path.exists(temporary):
                    os.remove(temporary)
        return target
    except Exception as ex:
        xbmc.log(
            "[stream_picker] Could not render dynamic pill sheet: {0}".format(ex),
            xbmc.LOGWARNING,
        )
        return ""


def _stream_pill_native_text(properties, focused=False):
    """Build native Kodi label rows aligned to the measured backgrounds."""
    modules = _stream_pill_pil_modules()
    if not modules:
        return ("", "", "")
    _Image, _ImageDraw, ImageFont = modules
    try:
        font, _font_key = _stream_pill_font(ImageFont)
        layout = _stream_pill_sheet_layout(
            properties,
            lambda text: _stream_pill_text_width(font, text),
        )
    except Exception:
        return ("", "", "")

    # Noto Sans' em space is exactly one font em. Two of them reproduce the
    # 14px trailing padding + 8px pill gap + 14px leading padding at size 18.
    separator = "\u2003\u2003"
    rows = []
    for row in layout:
        pieces = []
        for pill in row:
            _fill, text_color = _stream_pill_color_values(
                pill["tone"], focused
            )
            pieces.append(
                "[COLOR {0}]{1}[/COLOR]".format(
                    text_color, pill["text"]
                )
            )
        rows.append(separator.join(pieces))
    return tuple(rows)


def _stream_pill_image_properties(properties):
    """Select direct row-local controls; nested controls leak active item data."""
    result = {
        "App.StreamPillsImage": "",
        "App.StreamPillsFocusedImage": "",
        "App.StreamPillsNative": "false",
    }

    tones = {
        "App.StreamQualityPill": {
            "4K": "quality_4k",
            "1080p": "quality_1080p",
            "720p": "quality_720p",
        }.get(properties.get("App.StreamQualityPill", ""), "quality_other"),
        "App.StreamCodec": "codec",
        "App.StreamAudioOverflow": "neutral",
        "App.StreamSubtitleOverflow": "neutral",
    }
    for index in range(1, 6):
        tones["App.StreamHdrPill{0}".format(index)] = "hdr"
    for index in range(1, 4):
        tones["App.StreamAudioPill{0}".format(index)] = properties.get(
            "App.StreamAudioPill{0}Tone".format(index), "neutral"
        )
        tones["App.StreamSubtitlePill{0}".format(index)] = properties.get(
            "App.StreamSubtitlePill{0}Tone".format(index), "neutral"
        )

    for property_name, tone in tones.items():
        normal_fill, normal_text = _stream_pill_color_values(tone, False)
        focused_fill, focused_text = _stream_pill_color_values(tone, True)
        result[property_name + "Color"] = normal_fill
        result[property_name + "TextColor"] = normal_text
        result[property_name + "FocusedColor"] = focused_fill
        result[property_name + "FocusedTextColor"] = focused_text
    return result


def _external_subtitle_text_properties(status, language):
    """Return the subtitle-row text used by the active modern stream layout."""
    status = _clean_query_value(status).lower() or "checking"
    language = _clean_query_value(language).upper()
    if status == "available":
        text, tone = {
            "SK": ("EXTERNAL SK  ·  OpenSubtitles", "sk"),
            "CS": ("EXTERNAL CZ  ·  OpenSubtitles", "cz"),
            "CZ": ("EXTERNAL CZ  ·  OpenSubtitles", "cz"),
            "EN": ("EXTERNAL EN  ·  Translate to Slovak with AI", "en"),
        }.get(language, ("EXTERNAL SUBTITLE AVAILABLE", "available"))
    elif status == "unavailable":
        text, tone = "NO EXTERNAL SK/CZ/EN SUBTITLES", "neutral"
    elif status == "error":
        text, tone = "EXTERNAL SUBTITLE SEARCH FAILED", "error"
    else:
        text, tone = "SEARCHING EXTERNAL SK/CZ/EN SUBTITLES…", "checking"

    normal_color, focused_color = {
        "sk": ("FF5FCB7E", "FF72DC91"),
        "cz": ("FFEAB650", "FFFFCB66"),
        "en": ("FF68B9E8", "FF83CEFA"),
        "available": ("FF68B9E8", "FF83CEFA"),
        "error": ("FFFF7A82", "FFFF9298"),
        "checking": ("FFB9C2CB", "FFD6DCE2"),
        "neutral": ("FF8F99A3", "FFADB5BD"),
    }[tone]
    return {
        "App.StreamSubtitleText": text,
        "App.StreamSubtitleTextDisplay": "[COLOR {0}]{1}[/COLOR]".format(
            normal_color, text
        ),
        "App.StreamSubtitleTextFocusedDisplay": "[COLOR {0}]{1}[/COLOR]".format(
            focused_color, text
        ),
    }


def _stream_audio_languages(stream):
    return list(dict.fromkeys(
        _stream_language_label(track.get("language"))
        for track in _stream_sorted_audio_tracks(stream)
        if _stream_language_label(track.get("language")) not in ("", "UND")
    ))


def _stream_friendly_title(stream):
    """Turn a release filename into the decision-oriented picker title."""
    quality = _stream_quality(stream) or tr("Unknown quality")
    hdr = _clean_query_value(stream.get("hdrFormat"))
    video = " ".join(value for value in (quality, hdr) if value)
    languages = set(_stream_audio_languages(stream))
    if "SK" in languages and "CZ" in languages:
        audio = tr("Slovak and Czech audio")
    elif "SK" in languages:
        audio = tr("Slovak audio")
    elif "CZ" in languages:
        audio = tr("Czech audio")
    elif "EN" in languages:
        audio = tr("English audio")
    elif languages:
        audio = tr("Other audio")
    else:
        audio = tr("Audio not verified")
    return "{0} — {1}".format(video, audio)


def _stream_compact_tracks(stream, kind):
    values, overflow = _stream_preferred_track_pills(stream, kind)
    if overflow:
        values.append(overflow)
    return "  •  ".join(values)


def _modern_stream_filter_models():
    return [
        {
            "label": tr(label),
            "command": "stream_filter",
            "properties": {
                "App.StreamFilterKey": key,
                "App.Selected": "false",
                "App.FilterIcon": icon,
            },
        }
        for label, key, icon in (
            ("SK/CZ audio", "local_audio", "stream-filter-audio.png"),
            (
                "SK/CZ subtitles",
                "local_subtitles",
                "stream-filter-subtitles.png",
            ),
            (
                "Dolby Vision",
                "dolby_vision",
                "stream-filter-dolby-vision.png",
            ),
            ("HDR10", "hdr10", "stream-filter-hdr.png"),
            ("4K", "4k", "stream-filter-4k.png"),
            ("Clear filters", "clear", "stream-filter-clear.png"),
        )
    ]

def _classic_stream_details_label(stream):
    """Best-effort rich secondary label for host-skin directory views."""
    _, audio = _stream_audio_presentation(stream)
    _, subtitles = _stream_subtitle_presentation(stream)
    availability = (
        "  •  ".join((
            _stream_provider(stream).upper(),
            _stream_cache_status_label(stream),
        ))
        if _stream_is_torbox(stream)
        else _stream_availability_presentation(stream)[1]
    )
    video = " ".join("[{0}]".format(value) for value in (
        _stream_quality(stream) or tr("RES ?"),
        _clean_query_value(stream.get("videoCodec")) or tr("CODEC ?"),
        _stream_hdr_pill_label(stream),
        _stream_audio_feature_label(stream),
        _stream_source_pill_label(stream),
        _clean_query_value(stream.get("edition")),
        _stream_bitrate_label(stream),
        _stream_size_label(stream),
        _stream_duration_pill_label(stream),
    ) if value)
    return "    |    ".join(value for value in (
        availability,
        video,
        "{0}: {1}".format(tr("Audio"), audio),
        "{0}: {1}".format(tr("Subtitles"), subtitles),
    ) if value)

def _stream_subtitle_labels(stream):
    tracks = stream.get("subtitleTracks")
    if isinstance(tracks, list) and tracks:
        labels = [_stream_language_label(track.get("language"))
                  for track in tracks if isinstance(track, dict)]
    else:
        labels = [_stream_language_label(language)
                  for language in (stream.get("subtitleLanguages") or [])]
    labels = list(dict.fromkeys(label for label in labels if label))
    if not labels and stream.get("hasBundledSubtitles"):
        labels = ["SUB"]
    return labels

def _stream_preferred_subtitle_state(stream):
    tracks = _stream_subtitle_tracks(stream)
    if tracks:
        full_preferred = list(dict.fromkeys(
            _stream_language_label(track.get("language"))
            for track in tracks
            if (
                _stream_language_label(track.get("language")) in ("CZ", "SK")
                and not _stream_subtitle_track_is_forced(track)
            )
        ))
        if full_preferred:
            return "available", "{0} SUBS".format("/".join(full_preferred))
        forced_preferred = list(dict.fromkeys(
            _stream_language_label(track.get("language"))
            for track in tracks
            if (
                _stream_language_label(track.get("language")) in ("CZ", "SK")
                and _stream_subtitle_track_is_forced(track)
            )
        ))
        if forced_preferred:
            return "forced", tr(
                "{0} FORCED ONLY", "/".join(forced_preferred)
            )

    labels = _stream_subtitle_labels(stream)
    preferred = [label for label in labels if label in ("CZ", "SK")]
    preferred_flag = _stream_bool(stream, "hasPreferredSubtitles")
    if preferred_flag is True or (preferred_flag is None and preferred):
        return "available", "{0} SUBS".format(
            "/".join(preferred) if preferred else "CZ/SK"
        )

    metadata_status = _clean_query_value(
        stream.get("metadataStatus")
    ).lower()
    if _stream_inventory_complete(stream, "subtitle"):
        return "unavailable", "NO CZ/SK SUBS"

    # Before structured metadata was introduced, hasBundledSubtitles meant
    # specifically Czech/Slovak subtitles. Preserve that signal when an older
    # backend response has no metadata status or preferred-subtitle field.
    if (not metadata_status and
            "hasPreferredSubtitles" not in stream and
            stream.get("hasBundledSubtitles")):
        return "available", "CZ/SK SUBS"

    return "unknown", "CZ/SK SUBS ?"

def _stream_metadata_summary(stream):
    _, preferred_subtitle_summary = _stream_preferred_subtitle_state(stream)
    _, availability_summary = _stream_availability_presentation(stream)

    size = stream.get("sizeInGB")
    size_label = "{0} GB".format(size) if size not in (None, "") else ""
    return "  •  ".join(value for value in (
        availability_summary,
        preferred_subtitle_summary,
        _stream_audio_summary(stream),
        _stream_quality(stream),
        _clean_query_value(stream.get("hdrFormat")),
        _clean_query_value(stream.get("videoCodec")),
        (_stream_source_label(stream)
         if _clean_query_value(stream.get("releaseSource")) else ""),
        size_label,
    ) if value)

def _classic_stream_label(stream, display_name):
    lead = _stream_quality(stream)
    if not lead and stream.get("sizeInGB") not in (None, ""):
        lead = "{0} GB".format(stream.get("sizeInGB"))
    lead_badge = "[COLOR FF00C8FF][{0}][/COLOR] ".format(lead) if lead else ""
    subtitle_state, subtitle_text = _stream_preferred_subtitle_state(stream)
    external = stream.get("externalSubtitleAvailability") or {}
    if external.get("status") == "available" and subtitle_state != "available":
        subtitle_state = "available"
        subtitle_text = tr("External {0} subtitles", str(external.get("language") or "").upper())
    subtitle_color = {
        "available": "FF35D07F",
        "forced": "FFFFB547",
        "unavailable": "FF8A8D92",
        "unknown": "FFFFB547",
    }[subtitle_state]
    subtitle_badge = "[COLOR {0}][{1}][/COLOR] ".format(
        subtitle_color, subtitle_text
    )
    audio_text = _stream_audio_summary(stream).split("  •  ", 1)[0]
    audio_color = "FFFFB547" if audio_text == "AUDIO ?" else "FFE7E7EA"
    if audio_text == "NO AUDIO":
        audio_color = "FF8A8D92"
    audio_badge = "[COLOR {0}][{1}][/COLOR] ".format(
        audio_color, audio_text
    )
    if _stream_is_torbox(stream):
        availability_state = _stream_availability(stream)
        availability_text = "  •  ".join((
            _stream_provider(stream).upper(),
            _stream_cache_status_label(stream),
        ))
    else:
        availability_state, availability_text = _stream_availability_presentation(stream)
    availability_color = {
        "ready": "FF35D07F",
        "cached": "FF48E092",
        "downloading": "FF00C8FF",
        "waiting": "FFFFB547",
        "stalled": "FFFF8C42",
        "error": "FFFF5C65",
        "unknown": "FFFFB547",
    }.get(availability_state, "FFE7E7EA")
    availability_badge = "[COLOR {0}][{1}][/COLOR] ".format(
        availability_color, availability_text
    )
    return "{0}{1}{2}{3}{4}".format(
        lead_badge,
        availability_badge,
        subtitle_badge,
        audio_badge,
        display_name,
    )


def _classic_stream_context_items(stream, download_query, play_query):
    items = []
    subtitle_job = _subtitle_job_for_stream(stream.get("id"), play_query)
    if subtitle_job:
        status = subtitle_job.get("status")
        if status == "completed" and subtitle_job.get("subtitle_path"):
            ai_play_query = dict(play_query)
            ai_play_query.update({
                "force_ai_subtitle": "true",
                "subtitle_job_id": subtitle_job.get("job_id"),
            })
            items.append((
                tr("Play with AI-translated Slovak subtitles"),
                "PlayMedia({0})".format(build_url(ai_play_query)),
            ))
        items.append((
            _subtitle_status_text(subtitle_job),
            "RunPlugin({0})".format(build_url({
                "action": "show_subtitle_job_actions",
                "job_id": subtitle_job.get("job_id"),
            })),
        ))
    else:
        create_query = dict(play_query)
        create_query["action"] = "start_subtitle_translation"
        items.append((
            tr("Find Slovak or Czech subtitles; translate English if needed"),
            "RunPlugin({0})".format(build_url(create_query)),
        ))
    is_torbox = _stream_is_torbox(stream)
    is_ready = _stream_is_ready(stream)
    if _stream_can_download(stream) or is_torbox:
        target = dict(download_query)
        if is_torbox and not is_ready:
            target["offline"] = "true"
        items.append((
            tr("Add to offline downloads") if is_torbox and not is_ready else tr("Download"),
            "RunPlugin({0})".format(build_url(target)),
        ))
    if is_torbox and not is_ready:
        target = dict(play_query)
        target["action"] = "prepare_stream_background"
        items.insert(0, (
            tr("Prepare in background"),
            "RunPlugin({0})".format(build_url(target)),
        ))
    return items

def _stream_duration_label(stream):
    seconds = _as_int(stream.get("durationInSeconds"), 0)
    if seconds <= 0:
        minutes = _as_int(stream.get("lengthInMins"), 0)
        seconds = minutes * 60
    if seconds <= 0:
        return ""
    hours, remainder = divmod(seconds, 3600)
    minutes = remainder // 60
    if hours and minutes:
        return "{0} h {1} min".format(hours, minutes)
    if hours:
        return "{0} h".format(hours)
    return "{0} min".format(max(1, minutes))

def _stream_metadata_description(stream, context_title=""):
    lines = []
    if context_title:
        lines.append(_clean_query_value(context_title))

    _, availability_label = _stream_availability_presentation(stream)
    lines.append("{0}: {1}".format(tr("Availability"), availability_label))
    provider_message = _clean_query_value(stream.get("availabilityMessage"))
    if provider_message and provider_message.lower() not in availability_label.lower():
        lines.append("{0}: {1}".format(tr("Provider status"), provider_message))

    source_line = "  •  ".join(value for value in (
        _stream_source_label(stream),
        _clean_query_value(stream.get("edition")),
        _clean_query_value(stream.get("container")),
        "{0} GB".format(stream.get("sizeInGB"))
        if stream.get("sizeInGB") not in (None, "") else "",
    ) if value)
    if source_line:
        lines.append("Source: {0}".format(source_line))

    width = _as_int(stream.get("width"), 0)
    height = _as_int(stream.get("height"), 0)
    dimensions = "{0}×{1}".format(width, height) if width and height else ""
    fps = _as_float(stream.get("frameRate"), 0.0)
    bitrate = _as_int(stream.get("videoBitrateKbps"), 0)
    video_line = "  •  ".join(value for value in (
        _stream_quality(stream),
        dimensions,
        _clean_query_value(stream.get("videoCodec")),
        _stream_hdr_label(stream),
        "{0:g} fps".format(fps) if fps else "",
        "{0} kbps".format(bitrate) if bitrate else "",
    ) if value)
    if video_line:
        lines.append("Video: {0}".format(video_line))
    for hdr in stream_cards.hdr_formats(stream):
        if hdr.get("verified") is True and hdr.get("dolbyVisionProfile") is not None:
            detail = "Dolby Vision: {0} {1}".format(tr("Profile"), hdr["dolbyVisionProfile"])
            if hdr.get("dolbyVisionLevel") is not None:
                detail += " · {0} {1}".format(tr("Level"), hdr["dolbyVisionLevel"])
            compatibility = hdr.get("baseLayerCompatibilityId")
            if compatibility is not None:
                detail += " · {0}: {1}".format(tr("Base layer compatibility"),
                    {0: tr("None signalled"), 1: "HDR10", 2: "SDR", 4: "HLG"}.get(compatibility, "ID {0}".format(compatibility)))
            lines.append(detail)

    subtitle_state, subtitle_status = _stream_preferred_subtitle_state(stream)
    metadata_status = _clean_query_value(stream.get("metadataStatus")).lower()
    subtitle_explanation = {
        "available": subtitle_status,
        "forced": tr("{0} — partial dialogue only", subtitle_status),
        "unavailable": "Not found",
        "unknown": (
            "Could not verify — another Webshare stream or download is active"
            if metadata_status == "providerbusy"
            else "Could not verify — Webshare metadata probe unavailable"
        ),
    }[subtitle_state]
    lines.append("Czech/Slovak subtitles: {0}".format(subtitle_explanation))

    audio_labels = [_stream_audio_label(track) for track in
                    _stream_sorted_audio_tracks(stream)]
    audio_labels = [label for label in audio_labels if label]
    if audio_labels:
        lines.append("Audio: {0}".format("; ".join(audio_labels)))
    elif _stream_inventory_complete(stream, "audio"):
        lines.append("Audio: Not found")
    else:
        lines.append("Audio: {0}".format(
            "Could not verify — another Webshare stream or download is active"
            if metadata_status == "providerbusy"
            else "Could not verify — Webshare metadata probe unavailable"
        ))

    subtitle_tracks = stream.get("subtitleTracks") or []
    subtitle_labels = []
    for track in subtitle_tracks:
        if not isinstance(track, dict):
            continue
        label = _stream_language_label(track.get("language"))
        flags = []
        if track.get("isDefault"):
            flags.append("default")
        if _stream_subtitle_track_is_forced(track):
            flags.append("forced")
        if flags:
            label += " ({0})".format(", ".join(flags))
        subtitle_labels.append(label)
    if not subtitle_labels:
        subtitle_labels = _stream_subtitle_labels(stream)
    if subtitle_labels:
        lines.append("Subtitles: {0}".format("; ".join(subtitle_labels)))

    duration = _stream_duration_label(stream)
    if duration:
        lines.append("Duration: {0}".format(duration))
    fields = stream.get("metadataFields")
    if isinstance(fields, dict) and fields:
        lines.append("")
        lines.append(tr("Metadata sources"))
        sources = {"container": tr("File inspection"), "provider": tr("Provider metadata"), "filename": tr("Filename estimate")}
        for hdr in stream_cards.hdr_formats(stream):
            lines.append("{0}: {1}{2}".format(hdr["format"], sources.get(hdr.get("source"), tr("Not verified")),
                " · " + tr("Not verified") if hdr.get("verified") is not True else ""))
        for field, label in (("resolution", "Resolution"), ("videoCodec", "Codec"),
                             ("duration", "Runtime"), ("audioTracks", "Audio"), ("subtitleTracks", "Subtitles")):
            evidence = fields.get(field)
            if evidence:
                lines.append("{0}: {1}{2}".format(tr(label), sources.get(evidence.get("source"), tr("Not verified")),
                             " · " + tr("Not verified") if not evidence.get("verified") else ""))
    return "\n".join(lines) or _stream_display_name(stream)

def _apply_stream_info(item, stream):
    add_stream_info = getattr(item, "addStreamInfo", None)
    if not callable(add_stream_info):
        return
    video = {
        "codec": _clean_query_value(stream.get("videoCodec")),
        "width": _as_int(stream.get("width"), 0),
        "height": _as_int(stream.get("height"), 0),
        "duration": _as_int(stream.get("durationInSeconds"), 0),
    }
    video = {key: value for key, value in video.items() if value}
    if video:
        add_stream_info("video", video)
    for track in stream.get("audioTracks") or []:
        if not isinstance(track, dict):
            continue
        audio = {
            "codec": _clean_query_value(track.get("codec")),
            "language": _clean_query_value(track.get("language")),
            "channels": _as_int(track.get("channels"), 0),
        }
        add_stream_info("audio", {key: value for key, value in audio.items() if value})
    for language in _stream_subtitle_labels(stream):
        add_stream_info("subtitle", {"language": language.lower()})

def _clean_query_value(value):
    if value is None:
        return ""
    return str(value).strip()

def _addon_bool_setting(setting_id, default=False):
    value = xbmcaddon.Addon().getSetting(setting_id)
    if value == "":
        return default
    return value.lower() == "true"

def _filter_anime_enabled():
    return _addon_bool_setting("filter_anime", True)


def _subtitle_context(params=None):
    params = params if isinstance(params, dict) else {}
    allowed = (
        "media_type", "movie_id", "tv_id", "season", "episode_id",
        "episode_number", "title", "tv_title", "episode_title", "year",
        "poster", "fanart", "stream_name", "provider", "native_preferred",
        "availability", "is_ready", "can_download", "availability_state",
        "availability_label", "availability_message", "progress_percent",
        "eta_seconds", "native_subtitle_indexes", "subtitle_metadata_complete",
    )
    return {
        key: _clean_query_value(params.get(key))
        for key in allowed
        if _clean_query_value(params.get(key))
    }


def _subtitle_media_identity(params=None):
    params = params if isinstance(params, dict) else {}
    media_type = _clean_query_value(params.get("media_type")).lower()
    identity = {}
    if media_type == "movie":
        tmdb_id = _as_int(params.get("movie_id"), 0)
        if tmdb_id > 0:
            identity.update({"mediaType": "movie", "tmdbId": tmdb_id})
    elif media_type == "episode":
        episode_tmdb_id = _as_int(params.get("episode_id"), 0)
        parent_tmdb_id = _as_int(params.get("tv_id"), 0)
        season_number = _as_int(params.get("season"), -1)
        episode_number = _as_int(params.get("episode_number"), 0)
        identity["mediaType"] = "episode"
        if episode_tmdb_id > 0:
            identity["tmdbId"] = episode_tmdb_id
        if parent_tmdb_id > 0:
            identity["parentTmdbId"] = parent_tmdb_id
        if season_number >= 0:
            identity["seasonNumber"] = season_number
        if episode_number > 0:
            identity["episodeNumber"] = episode_number
    return identity


def _subtitle_job_for_stream(stream_id, params=None, include_terminal=True):
    if not stream_id:
        return None
    database = _subtitle_db()
    try:
        record = database.find_stream(
            stream_id,
            _subtitle_context(params),
            include_terminal=include_terminal,
        )
        if record:
            return record
        return database.find_latest_stream_id(
            stream_id, include_terminal=include_terminal
        )
    except Exception as exc:
        xbmc.log(
            "[Subtitles] Could not read local job state: {0}".format(exc),
            xbmc.LOGWARNING,
        )
        return None


def _subtitle_status_text(record, compact=False):
    if not record:
        return tr("AI Slovak subtitles")
    status = _clean_query_value(record.get("status")).lower()
    stage = _clean_query_value(record.get("stage")).lower()
    progress = max(0, min(100, _as_int(record.get("progress"), 0)))
    if stage == "retrying":
        return tr("AI SK retry scheduled") if compact else tr("Subtitle translation retry scheduled")
    if stage == "finalizing":
        return tr("AI SK finalizing") if compact else tr("Finalizing Slovak subtitles")
    if status == "queued":
        return tr("AI SK queued") if compact else tr("AI Slovak subtitles queued")
    if status == "extracting":
        return tr("AI SK finding source") if compact else tr("Finding English subtitle source")
    if status == "translating":
        return (
            tr("AI SK {0}%", progress)
            if compact else tr("Translating to Slovak — {0}%", progress)
        )
    if status == "completed":
        return tr("AI SK ready") if compact else tr("AI Slovak subtitles ready")
    if status == "failed":
        return tr("AI SK needs attention") if compact else tr("AI subtitle translation needs attention")
    if status in ("canceled", "cancelled"):
        return tr("AI SK canceled") if compact else tr("AI subtitle translation canceled")
    return tr("AI Slovak subtitles")


def _subtitle_stage_text(record):
    stage = _clean_query_value((record or {}).get("stage")).lower()
    retry_at = _subtitle_datetime_label((record or {}).get("next_retry_at"))
    return {
        "queued": tr("Waiting in the background"),
        "extracting": tr("Finding and downloading English subtitles"),
        "translating": tr("Translating subtitle dialogue"),
        "retrying": (
            tr("Retry scheduled for {0}", retry_at)
            if retry_at else tr("Waiting to retry after a temporary service problem")
        ),
        "finalizing": tr("Validating and saving the translated SRT"),
        "completed": tr("Ready to attach in Kodi Player"),
        "failed": tr("Open actions to retry"),
        "canceled": tr("Canceled by you"),
        "cancelled": tr("Canceled by you"),
    }.get(stage, _clean_query_value((record or {}).get("message")))


def _subtitle_datetime_label(value):
    value = _clean_query_value(value)
    if not value:
        return ""
    try:
        timestamp = datetime.datetime.fromisoformat(value.replace("Z", "+00:00"))
        if timestamp.tzinfo is not None:
            timestamp = timestamp.astimezone()
        return timestamp.strftime("%Y-%m-%d %H:%M")
    except (TypeError, ValueError):
        return value


def _subtitle_job_detail(record):
    record = record if isinstance(record, dict) else {}
    lines = [
        _subtitle_error_text(record)
        if record.get("status") == "failed" else _subtitle_stage_text(record)
    ]
    if record.get("used_forced_fallback") is True:
        lines.append(tr(
            "Warning: the source appears to contain only forced or foreign-parts "
            "subtitles, so some dialogue may be missing."
        ))
    source = "  •  ".join(value for value in (
        _clean_query_value(record.get("source_provider")),
        _clean_query_value(record.get("source_release")),
    ) if value)
    confidence = record.get("source_match_confidence")
    try:
        confidence_label = "{0:.0f}%".format(float(confidence) * 100)
    except (TypeError, ValueError):
        confidence_label = ""
    if source or confidence_label:
        lines.append(tr(
            "Subtitle source: {0}",
            "  •  ".join(value for value in (source, confidence_label) if value)
        ))
    selection_message = _clean_query_value(record.get("source_selection_message"))
    if selection_message:
        lines.append(selection_message)
    result_error = _clean_query_value(record.get("result_error"))
    if record.get("status") == "completed" and result_error:
        lines.append(tr(
            "The translation finished, but Kodi could not save the SRT locally. "
            "Use Refresh status to try the result download again."
        ))
    return "\n\n".join(line for line in lines if line)


def _subtitle_error_text(record_or_code):
    if isinstance(record_or_code, dict):
        code = _clean_query_value(record_or_code.get("error_code"))
        fallback = _clean_query_value(record_or_code.get("message"))
    else:
        code = _clean_query_value(record_or_code)
        fallback = ""
    messages = {
        "no_english_text_subtitles": tr("No suitable English text subtitles were found."),
        "image_subtitles_not_supported": tr("Only image subtitles were found; they cannot be translated."),
        "subtitle_provider_auth_failed": tr("The subtitle provider could not be reached securely."),
        "subtitle_extraction_failed": tr("The English subtitle source could not be read."),
        "stream_resolution_failed": tr("The selected stream could not be inspected."),
        "translation_failed": tr("The AI translation service could not finish this subtitle."),
        "translation_call_budget_exceeded": tr("This subtitle exceeded the safe AI translation limit."),
        "invalid_translation_payload": tr("The translated subtitle failed validation."),
        "job_limit_exceeded": tr("Too many subtitle translations are active. Try again shortly."),
        "job_attempt_limit_exceeded": tr(
            "This subtitle translation reached its retry limit. Try again later."
        ),
        "job_cancelled": tr("This subtitle translation was canceled."),
        "result_unavailable": tr(
            "The translated subtitle file is no longer available. Try again to regenerate it."
        ),
        "job_not_found": tr("This job is no longer available on the server."),
        "unexpected_failure": tr("The subtitle service encountered an unexpected problem."),
    }
    return messages.get(code) or fallback or tr("Subtitle translation failed. Try again later.")


def _subtitle_record_from_response(stream_id, params, response):
    context = _subtitle_context(params)
    job_id = response.get("jobId", response.get("job_id"))
    status = _clean_query_value(response.get("status")).lower() or "queued"
    if status == "complete":
        status = "completed"
    elif status == "cancelled":
        status = "canceled"
    created_at = subtitle_now_iso()
    poll_after_seconds = max(2, min(3600, _as_int(
        response.get("pollAfterSeconds", response.get("poll_after_seconds")), 2
    )))
    try:
        created_datetime = datetime.datetime.fromisoformat(
            created_at.replace("Z", "+00:00")
        )
        next_poll_at = (
            created_datetime + datetime.timedelta(seconds=poll_after_seconds)
        ).isoformat()
    except (TypeError, ValueError):
        next_poll_at = ""
    return {
        "job_id": str(job_id),
        "stream_id": str(stream_id),
        "stream_key": stream_identity(stream_id, context),
        "status": status,
        "stage": _clean_query_value(response.get("stage")) or status,
        "progress": _as_int(
            response.get("progressPercent", response.get("progress_percent")), 0
        ),
        "message": _clean_query_value(response.get("message")),
        "poll_url": response.get("pollUrl", response.get("poll_url")),
        "result_url": response.get("resultUrl", response.get("result_url")),
        "reused": bool(response.get("reused", False)),
        "run_attempt": normalize_run_attempt(
            response.get("runAttempt", response.get("run_attempt", 0))
        ),
        "poll_after_seconds": poll_after_seconds,
        "next_poll_at": next_poll_at,
        "target_language": "sk",
        "title": context.get("title") or context.get("stream_name") or tr("Media Hub"),
        "stream_name": context.get("stream_name", ""),
        "native_preferred": context.get("native_preferred") == "true",
        "context": context,
        "created_at": created_at,
        "updated_at": created_at,
    }


def _subtitle_privacy_accepted():
    addon = xbmcaddon.Addon()
    if _addon_bool_setting("subtitle_privacy_ack_v2", False):
        return True
    accepted = xbmcgui.Dialog().yesno(
        tr("AI subtitle privacy"),
        tr(
            "Release filename/title metadata, a movie fingerprint, and file size "
            "are queried against OpenSubtitles and the selected subtitle is downloaded "
            "from it. A bounded 128 KiB media sample is read to calculate the fingerprint, "
            "but video/audio bytes are not sent to OpenSubtitles or OpenAI. Its English "
            "subtitle text and timing are sent to OpenAI. "
            "Media Hub temporarily stores job/checkpoint and per-job result data "
            "(normally 7 days); reusable translated cache data is normally stored "
            "for 90 days. Kodi also saves the completed SRT locally according to "
            "your retention setting. Continue?"
        ),
        nolabel=tr("Not now"),
        yeslabel=tr("I understand — continue"),
    )
    if accepted:
        addon.setSetting("subtitle_privacy_ack_v2", "true")
    return accepted


def _refresh_subtitle_container():
    try:
        xbmc.executebuiltin("Container.Refresh")
    except Exception:
        pass


def start_subtitle_translation(stream_id, params=None, retry=False):
    params = params if isinstance(params, dict) else {}
    stream_id = _clean_query_value(stream_id)
    if not stream_id:
        return None
    existing = _subtitle_job_for_stream(stream_id, params, include_terminal=False)
    if existing:
        xbmcgui.Dialog().notification(
            tr("AI Slovak subtitles"),
            _subtitle_status_text(existing),
            xbmcgui.NOTIFICATION_INFO,
            3000,
        )
        return existing

    native_preferred = _clean_query_value(
        params.get("native_preferred")
    ).lower() == "true"
    if native_preferred and _addon_bool_setting("subtitle_native_first", True):
        if not xbmcgui.Dialog().yesno(
            tr("Included subtitles available"),
            tr(
                "This stream already includes Slovak or Czech subtitles. "
                "Media Hub will prefer them. Translate an English subtitle anyway?"
            ),
            nolabel=tr("Use included subtitles"),
            yeslabel=tr("Translate anyway"),
        ):
            return None
    if not _subtitle_privacy_accepted():
        return None
    if _addon_bool_setting("subtitle_confirm_generation", True):
        if not xbmcgui.Dialog().yesno(
            tr("Create AI Slovak subtitles?"),
            tr(
                "Media Hub will first look for Slovak or Czech subtitles. If none "
                "are available, it will translate English subtitles in the background."
            ),
            nolabel=tr("Cancel"),
            yeslabel=tr("Start translation"),
        ):
            return None
    try:
        response = api.create_subtitle_translation_job(
            stream_id,
            "sk",
            _subtitle_media_identity(params),
        )
        record = _subtitle_record_from_response(stream_id, params, response)
        record = _subtitle_db().add(record)
    except Exception as exc:
        xbmc.log("[Subtitles] Could not create job: {0}".format(exc), xbmc.LOGERROR)
        message = (
            _subtitle_error_text(exc.error_code) if isinstance(exc, api.ApiError) and exc.error_code
            else exc.message if isinstance(exc, api.ApiError) else str(exc)
        )
        xbmcgui.Dialog().ok(
            tr("AI Slovak subtitles"),
            message or tr("Could not start subtitle translation."),
        )
        return None
    xbmcgui.Dialog().notification(
        tr("AI Slovak subtitles"),
        tr("Translation started in the background."),
        xbmcgui.NOTIFICATION_INFO,
        3500,
    )
    _refresh_subtitle_container()
    return record


def refresh_subtitle_job(job_id, notify=True):
    database = _subtitle_db()
    record = database.get(job_id)
    if not record:
        if notify:
            xbmcgui.Dialog().notification(
                tr("AI Slovak subtitles"), tr("Subtitle job not found."),
                xbmcgui.NOTIFICATION_ERROR, 2500
            )
        return None
    try:
        if record.get("status") in SUBTITLE_ACTIVE_STATUSES:
            run_attempt = normalize_run_attempt(record.get("run_attempt"))
            payload = api.get_subtitle_translation_job(
                job_id, url=record.get("poll_url")
            )
            updated = database.update(
                job_id,
                normalized_status_payload(payload),
                expected_statuses=SUBTITLE_ACTIVE_STATUSES,
                expected_run_attempt=run_attempt,
            )
            record = updated or database.get(job_id) or record
        if record.get("status") == "completed" and not (
            record.get("subtitle_path") and xbmcvfs.exists(record["subtitle_path"])
        ):
            content = api.get_subtitle_translation_result(
                job_id, url=record.get("result_url")
            )
            stored = store_subtitle_result(database, record, content)
            record = stored or database.get(job_id) or record
    except Exception as exc:
        xbmc.log("[Subtitles] Could not refresh job {0}: {1}".format(job_id, exc), xbmc.LOGWARNING)
        patch = {"sync_error": str(exc)}
        if record.get("status") == "completed" and isinstance(exc, api.ApiError):
            if exc.status_code == 410:
                patch.update({
                    "status": "canceled",
                    "stage": "canceled",
                    "error_code": exc.error_code or "job_cancelled",
                    "result_retry_disabled": True,
                })
            elif exc.status_code in (404, 422):
                patch.update({
                    "status": "failed",
                    "stage": "failed",
                    "error_code": exc.error_code or "result_unavailable",
                    "result_retry_disabled": True,
                })
        expected_statuses = (record.get("status"),) if record.get("status") else None
        record = database.update(
            job_id,
            patch,
            expected_statuses=expected_statuses,
            expected_run_attempt=normalize_run_attempt(record.get("run_attempt")),
        ) or database.get(job_id) or record
        if notify:
            message = (
                _subtitle_error_text(exc.error_code)
                if isinstance(exc, api.ApiError) and exc.error_code
                else tr("Could not refresh this job.")
            )
            xbmcgui.Dialog().notification(
                tr("AI Slovak subtitles"), message,
                xbmcgui.NOTIFICATION_ERROR, 2500
            )
        return record
    if notify:
        xbmcgui.Dialog().notification(
            tr("AI Slovak subtitles"), _subtitle_status_text(record),
            xbmcgui.NOTIFICATION_INFO, 2500
        )
    _refresh_subtitle_container()
    return record


def cancel_subtitle_job(job_id):
    database = _subtitle_db()
    record = database.get(job_id)
    if not record or record.get("status") not in SUBTITLE_ACTIVE_STATUSES:
        return record
    if not xbmcgui.Dialog().yesno(
        tr("Cancel subtitle translation?"),
        tr("Completed work may be discarded."),
        nolabel=tr("Keep running"),
        yeslabel=tr("Cancel job"),
    ):
        return record
    try:
        run_attempt = normalize_run_attempt(record.get("run_attempt"))
        payload = api.cancel_subtitle_translation_job(job_id)
        record = database.update(
            job_id,
            normalized_status_payload(payload),
            expected_statuses=SUBTITLE_ACTIVE_STATUSES,
            expected_run_attempt=run_attempt,
        ) or database.get(job_id) or record
    except Exception as exc:
        message = (
            _subtitle_error_text(exc.error_code) if isinstance(exc, api.ApiError) and exc.error_code
            else exc.message if isinstance(exc, api.ApiError) else str(exc)
        )
        xbmcgui.Dialog().notification(
            tr("AI Slovak subtitles"),
            message or tr("Could not cancel this job."),
            xbmcgui.NOTIFICATION_ERROR,
            3000,
        )
        return record
    _refresh_subtitle_container()
    return record


def retry_subtitle_job(job_id):
    record = _subtitle_db().get(job_id)
    if not record:
        return None
    params = dict(record.get("context") or {})
    params["subtitle_retry"] = "true"
    return start_subtitle_translation(record.get("stream_id"), params, retry=True)


def play_subtitle_job(handle, job_id):
    record = refresh_subtitle_job(job_id, notify=False)
    if not record or record.get("status") != "completed" or not record.get("subtitle_path"):
        xbmcgui.Dialog().notification(
            tr("AI Slovak subtitles"), tr("The translated subtitle is not ready."),
            xbmcgui.NOTIFICATION_ERROR, 2500
        )
        return
    params = dict(record.get("context") or {})
    params.update({
        "action": "play_movie_stream",
        "stream_id": record.get("stream_id"),
        "force_ai_subtitle": "true",
        "subtitle_job_id": record.get("job_id"),
    })
    play_movie_stream(handle, record.get("stream_id"), params)


def show_subtitle_job_actions(job_id):
    record = refresh_subtitle_job(job_id, notify=False)
    if not record:
        return
    status = record.get("status")
    options = [(tr("Refresh status"), "refresh")]
    if status in SUBTITLE_ACTIVE_STATUSES:
        options.append((tr("Cancel translation"), "cancel"))
    if status == "completed" and record.get("subtitle_path"):
        options.insert(0, (tr("Play with AI-translated Slovak subtitles"), "play"))
    elif status in ("failed", "canceled", "cancelled"):
        options.insert(0, (tr("Try again"), "retry"))
    details = _subtitle_status_text(record)
    stage = _subtitle_job_detail(record)
    labels = ["{0} — {1}".format(label, stage) if index == 0 else label
              for index, (label, _action) in enumerate(options)]
    selected = xbmcgui.Dialog().select(details, labels)
    if selected < 0:
        return
    action = options[selected][1]
    if action == "refresh":
        refresh_subtitle_job(job_id)
    elif action == "cancel":
        cancel_subtitle_job(job_id)
    elif action == "retry":
        retry_subtitle_job(job_id)
    elif action == "play":
        target = build_url(dict(
            record.get("context") or {},
            action="play_movie_stream",
            stream_id=record.get("stream_id"),
            force_ai_subtitle="true",
            subtitle_job_id=record.get("job_id"),
        ))
        xbmc.executebuiltin("PlayMedia({0})".format(target))

def _is_probable_anime(show):
    genre_ids = show.get("genre_ids") or []
    try:
        has_animation_genre = ANIMATION_GENRE_ID in [int(genre_id) for genre_id in genre_ids]
    except (TypeError, ValueError):
        has_animation_genre = False

    original_language = _clean_query_value(show.get("original_language")).lower()
    origin_country = [
        _clean_query_value(country).upper()
        for country in (show.get("origin_country") or [])
    ]

    return has_animation_genre and (
        original_language == "ja" or "JP" in origin_country
    )

def _filter_tv_shows(shows):
    if not _filter_anime_enabled():
        return shows
    return [show for show in shows if not _is_probable_anime(show)]

def _movie_display_title(movie):
    return (
        movie.get("title_with_original_title")
        or movie.get("title")
        or movie.get("original_title")
        or "Movie"
    )

def _movie_release_year(movie):
    release_date = _clean_query_value(movie.get("release_date"))
    if len(release_date) >= 4:
        return release_date[:4]
    return _clean_query_value(movie.get("year"))


def _movie_duration_label(movie):
    runtime = _as_int((movie or {}).get("runtime"), 0)
    return f"{runtime} min" if runtime > 0 else ""


def _poster_card_meta(year="", duration=""):
    return "  •  ".join(
        value
        for value in (
            _clean_query_value(year),
            _clean_query_value(duration),
        )
        if value
    )


def _poster_card_genres(value, limit=2):
    names = []
    seen = set()
    for raw_name in _clean_query_value(value).split(","):
        name = raw_name.strip()
        key = name.casefold()
        if name and key not in seen:
            names.append(name)
            seen.add(key)
    if not names:
        return ""

    return ", ".join(names[:max(1, limit)])


def _catalog_season_label(source):
    count = _as_int(source.get("number_of_seasons"), 0)
    if count <= 0:
        return ""
    if language() == "sk":
        return "{0} {1}".format(count, "séria" if count == 1 else "série" if count < 5 else "sérií")
    return "{0} {1}".format(count, "season" if count == 1 else "seasons")


def _catalog_episode_count_label(value):
    count = _as_int(value, -1)
    if count < 0:
        return ""
    if language() == "sk":
        noun = "epizóda" if count == 1 else "epizódy" if 2 <= count <= 4 else "epizód"
    else:
        noun = "episode" if count == 1 else "episodes"
    return "{0} {1}".format(count, noun)


def _catalog_card_presentation(source, kind, display_title):
    # Keep bilingual titles for details and playback; the grid uses the localized name.
    field = "name" if kind == "tv" else "title"
    title = _clean_query_value(source.get(field)) or display_title.split(" / ", 1)[0]
    original = _clean_query_value(source.get("original_" + field))
    status = {
        "Returning Series": tr("Returning series"),
        "Ended": tr("Series ended"),
        "Canceled": tr("Series canceled"),
        "In Production": tr("In production"),
        "Planned": tr("Planned series"),
    }.get(source.get("status"), "") if kind == "tv" else ""
    rating = _as_float(source.get("vote_average"), 0.0)
    context = "  ·  ".join(value for value in (
        title, _catalog_season_label(source) if kind == "tv" else "", status,
        "TMDB {0:.1f}/10".format(rating) if rating else "",
    ) if value)
    return {
        "App.CardTitle": title,
        "App.CardContext": context,
        "App.OriginalTitle": original if original != title else "",
        "App.SeriesStatus": status,
        "App.CardStatus": "",
        "App.CardProgressTexture": "",
    }


def _movie_credits_properties(source):
    director = _clean_query_value(source.get("director"))
    cast = source.get("cast") or []
    if isinstance(cast, str):
        cast = [cast]
    names = [_clean_query_value(name) for name in cast[:4]] if isinstance(cast, list) else []
    return {
        "App.Director": director,
        "App.Cast": ", ".join(name for name in names if name),
    }


def _catalog_watch_properties(source, kind, snapshot):
    """Personal state only from recorded playback, never from catalog release status."""
    result = {"App.CardStatus": "", "App.CardProgressTexture": ""}
    identity = _clean_query_value(source.get("id"))
    if not identity or not isinstance(snapshot, dict):
        return result
    records = [record for record in snapshot.values() if isinstance(record, dict)
               and record.get("media_type") == ("episode" if kind == "tv" else "movie")
               and _clean_query_value(record.get("tv_id" if kind == "tv" else "movie_id")) == identity]
    if not records:
        return result
    latest = max(records, key=lambda r: r.get("last_played_at") or r.get("created_at") or "")
    progress = _history_progress(latest)
    complete = _history_is_complete(latest, progress)
    position = _history_resume_position(latest)
    if kind == "movie":
        if complete:
            result["App.CardStatus"] = tr("Watched")
        elif position is not None:
            result["App.CardStatus"] = tr("Resume")
    elif position is not None and not complete:
        code = "S{0:02d} E{1:02d}".format(_as_int(latest.get("season"), 0), _episode_number(latest))
        result["App.CardStatus"] = tr("Resume {0}", code)
    else:
        # Require every regular episode to be recorded complete before saying caught up.
        completed = {(_as_int(r.get("season"), 0), _episode_number(r)) for r in records
                     if _as_int(r.get("season"), 0) > 0 and _episode_number(r) > 0
                     and _history_is_complete(r, _history_progress(r))}
        total = _as_int(source.get("number_of_episodes"), 0)
        last = source.get("last_episode_to_air") or {}
        last_key = (_as_int(last.get("season_number"), 0), _as_int(last.get("episode_number"), 0))
        if total > 0 and len(completed) >= total and last_key in completed:
            result["App.CardStatus"] = tr("Caught up")
        elif complete:
            result["App.CardStatus"] = tr("Continue series")
    if position is not None and not complete and progress is not None:
        result["App.CardProgressTexture"] = _home_progress_texture(progress)
    return result


def _catalog_next_episode_status(source, snapshot):
    """Resolve the next unwatched, aired episode using metadata only (no stream search)."""
    identity = _clean_query_value(source.get("id"))
    records = [r for r in snapshot.values() if isinstance(r, dict)
               and r.get("media_type") == "episode" and _clean_query_value(r.get("tv_id")) == identity]
    if not records:
        return ""
    completed = {(_as_int(r.get("season"), 0), _episode_number(r)) for r in records
                 if _history_is_complete(r, _history_progress(r))}
    seasons = sorted({_as_int(s.get("season_number"), 0) for s in source.get("seasons") or []
                      if isinstance(s, dict) and _as_int(s.get("season_number"), 0) > 0})
    today = datetime.date.today().isoformat()
    for season in seasons:
        episodes = api.get_episodes(identity, season, include_streams=False) or []
        if isinstance(episodes, dict):
            episodes = episodes.get("episodes") or []
        for episode in sorted((e for e in episodes if isinstance(e, dict)), key=_episode_number):
            number = _episode_number(episode)
            aired = str(episode.get("air_date") or episode.get("airDate") or "")[:10]
            if number > 0 and aired and aired <= today and (season, number) not in completed:
                return tr("Next: {0}", "S{0:02d} E{1:02d}".format(season, number))
    return ""

def _build_movie_versions_url(movie, genre_names=None):
    return build_url({
        'action': 'list_movie_versions',
        'media_type': 'movie',
        'movie_id': movie.get('id', ''),
        'title': _movie_display_title(movie),
        'year': _movie_release_year(movie),
        'poster': _poster_art_url(movie.get('poster_path')),
        'fanart': movie.get('backdrop_path', ''),
        'plot': movie.get('overview', ''),
        'genres': _modern_genre_label(movie, genre_names),
        'duration': _movie_duration_label(movie),
        'rating': (
            f"{_as_float(movie.get('vote_average'), 0.0):.1f}"
            if _as_float(movie.get('vote_average'), 0.0) else ""
        )
    })

def build_url(query):
    return f"{sys.argv[0]}?{urllib.parse.urlencode(query)}"

def get_addon_art_path(image_name="fanart.png"):
    addon = xbmcaddon.Addon()
    return os.path.join(addon.getAddonInfo('path'), 'resources', image_name)

def _media_art_url(value):
    value = str(value or "").strip()
    if value.startswith("/"):
        return "https://image.tmdb.org/t/p/original{0}".format(value)
    return value

def _poster_art_url(value):
    return _media_art_url(value) or os.path.join(
        xbmcaddon.Addon().getAddonInfo('path'),
        'resources',
        'skins',
        'Default',
        'media',
        PLACEHOLDER_POSTER_IMAGE,
    )

def _set_utility_fanart(item):
    item.setArt({"fanart": get_addon_art_path()})

_CLASSIC_CATALOG_ENABLED = False


def _classic_catalog_enabled():
    return _CLASSIC_CATALOG_ENABLED


_CLASSIC_CATALOG_RESPONSE = None


def _classic_catalog_response(loader):
    global _CLASSIC_CATALOG_RESPONSE
    target = sys.argv[0] + sys.argv[2]
    cached = classic_browse.catalog_snapshot(target)
    response = cached if cached is not None else loader()
    _CLASSIC_CATALOG_RESPONSE = (target, response)
    return response


def _finish_catalog_directory(handle, **kwargs):
    global _CLASSIC_CATALOG_RESPONSE
    xbmcplugin.endOfDirectory(handle, **kwargs)
    if _CLASSIC_CATALOG_RESPONSE is not None:
        target, response = _CLASSIC_CATALOG_RESPONSE
        _CLASSIC_CATALOG_RESPONSE = None
        classic_browse.acknowledge_catalog(target, response)


def _prepare_directory(handle, category, content="files"):
    global _CLASSIC_CATALOG_RESPONSE
    _CLASSIC_CATALOG_RESPONSE = None
    xbmcplugin.setPluginCategory(handle, category)
    try:
        xbmcplugin.setContent(handle, content)
    except Exception:
        pass

def _catalog_load_failed(handle, section, ex):
    xbmc.log(f"[catalog] Failed to load {section}: {ex}", xbmc.LOGERROR)
    xbmcgui.Dialog().ok(
        "Media Hub",
        "Obsah sa nepodarilo načítať. Skontrolujte pripojenie k API."
    )
    xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)

def _as_int(value, default=0):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default

def _as_float(value, default=None):
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _streams_by_size_descending(streams):
    availability_rank = {
        "ready": 0,
        "cached": 1,
        "downloading": 2,
        "queued": 3,
        "uncached": 4,
        "stalled": 5,
        "unknown": 6,
        "error": 7,
    }
    return sorted(
        [stream for stream in (streams or []) if isinstance(stream, dict)],
        key=lambda stream: (
            -(stream_cards.number(stream.get("sizeBytes"))
              or stream_cards.number(stream.get("sizeInGB")) * 1024 ** 3),
            availability_rank.get(_stream_availability(stream), 7),
            _stream_display_name(stream).lower(),
        ),
    )


def _split_filter_values(value, separator=","):
    return [
        item.strip()
        for item in _clean_query_value(value).split(separator)
        if item.strip()
    ]


def _normalized_genre_ids(value):
    normalized = []
    for candidate in _split_filter_values(value):
        genre_id = _as_int(candidate, 0)
        if genre_id > 0 and genre_id not in normalized:
            normalized.append(genre_id)
    return normalized


def _normalized_genre_names(value):
    return _split_filter_values(value, "|")


def _format_decimal(value):
    number = _as_float(value)
    if number is None:
        return ""
    return "{0:.1f}".format(number)


def _valid_discovery_year(value):
    year = _as_int(value, 0)
    maximum = time.gmtime().tm_year + 1
    return year if DISCOVERY_MIN_YEAR <= year <= maximum else 0


def _valid_discovery_runtime(value):
    runtime = _as_int(value, 0)
    return runtime if 1 <= runtime <= DISCOVERY_MAX_RUNTIME else 0

def _episode_number(item, default=0):
    if not isinstance(item, dict):
        return default
    for key in ("episode_number", "episodeNumber", "episode"):
        value = _as_int(item.get(key), 0)
        if value > 0:
            return value
    title = str(item.get("title") or item.get("name") or "")
    match = re.search(r"\bS\d{1,3}\s*E(\d{1,3})\b", title, re.IGNORECASE)
    if not match:
        match = re.search(r"\b\d{1,3}x(\d{1,3})\b", title, re.IGNORECASE)
    return _as_int(match.group(1), default) if match else default

def _discovery_state(params=None):
    if params is None:
        params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    state = {
        key: _clean_query_value(params.get(key))
        for key in DISCOVERY_STATE_KEYS
        if _clean_query_value(params.get(key))
    }

    genre_ids = _normalized_genre_ids(
        state.get("genre_ids") or state.get("genre_id")
    )
    genre_names = _normalized_genre_names(
        state.get("genre_names") or state.get("genre_name")
    )
    state.pop("genre_id", None)
    state.pop("genre_name", None)
    state.pop("genre_ids", None)
    state.pop("genre_names", None)
    if genre_ids:
        state["genre_ids"] = ",".join(str(value) for value in genre_ids)
        if genre_names:
            state["genre_names"] = "|".join(genre_names[:len(genre_ids)])

    exact_year = _valid_discovery_year(state.get("year"))
    year_from = _valid_discovery_year(state.get("year_from"))
    year_to = _valid_discovery_year(state.get("year_to"))
    state.pop("year", None)
    state.pop("year_from", None)
    state.pop("year_to", None)
    if year_from or year_to:
        year_from = year_from or DISCOVERY_MIN_YEAR
        year_to = year_to or (time.gmtime().tm_year + 1)
        if year_from <= year_to:
            state["year_from"] = str(year_from)
            state["year_to"] = str(year_to)
    elif exact_year:
        state["year"] = str(exact_year)

    minimum_rating = _as_float(state.get("minimum_rating"))
    state.pop("minimum_rating", None)
    if minimum_rating is not None and 0 <= minimum_rating <= 10:
        state["minimum_rating"] = _format_decimal(minimum_rating)

    minimum_vote_count = _as_int(state.get("minimum_vote_count"), -1)
    state["minimum_vote_count"] = str(max(0, minimum_vote_count))

    minimum_runtime = _valid_discovery_runtime(
        state.pop("minimum_runtime", None)
    )
    maximum_runtime = _valid_discovery_runtime(
        state.pop("maximum_runtime", None)
    )
    if minimum_runtime and maximum_runtime:
        if minimum_runtime <= maximum_runtime:
            state["minimum_runtime"] = str(minimum_runtime)
            state["maximum_runtime"] = str(maximum_runtime)
    elif minimum_runtime:
        state["minimum_runtime"] = str(minimum_runtime)
    elif maximum_runtime:
        state["maximum_runtime"] = str(maximum_runtime)

    if state.get("sort") not in {value for value, _ in DISCOVERY_SORTS}:
        state["sort"] = "popularity.desc"
    return state


def _discovery_genre_ids(state):
    return _normalized_genre_ids((state or {}).get("genre_ids"))


def _discovery_genre_names(state):
    return _normalized_genre_names((state or {}).get("genre_names"))


def _discovery_state_with(state, **changes):
    updated = dict(state or {})
    for key, value in changes.items():
        if value in (None, ""):
            updated.pop(key, None)
        else:
            updated[key] = value
    return _discovery_state(updated)


def _discovery_period_label(state):
    exact = _valid_discovery_year((state or {}).get("year"))
    if exact:
        return str(exact)
    year_from = _valid_discovery_year((state or {}).get("year_from"))
    year_to = _valid_discovery_year((state or {}).get("year_to"))
    if year_from and year_to:
        return (
            str(year_from)
            if year_from == year_to
            else "{0}–{1}".format(year_from, year_to)
        )
    return "Any time"


def _discovery_genre_label(state):
    names = _discovery_genre_names(state)
    if not names:
        count = len(_discovery_genre_ids(state))
        return "{0} selected".format(count) if count else "All genres"
    if len(names) <= 2:
        return ", ".join(names)
    return "{0}, {1} (+{2})".format(names[0], names[1], len(names) - 2)


def _discovery_runtime_label(state):
    minimum = _valid_discovery_runtime(
        (state or {}).get("minimum_runtime")
    )
    maximum = _valid_discovery_runtime(
        (state or {}).get("maximum_runtime")
    )
    if minimum and maximum:
        return "{0}–{1} min".format(minimum, maximum)
    if maximum:
        return tr("Up to {0} min", maximum)
    if minimum:
        return tr("{0}+ min", minimum)
    return tr("Any length")


def _discovery_active_count(state):
    count = 0
    if _discovery_genre_ids(state):
        count += 1
    if (
        _valid_discovery_year((state or {}).get("year"))
        or _valid_discovery_year((state or {}).get("year_from"))
        or _valid_discovery_year((state or {}).get("year_to"))
    ):
        count += 1
    if _as_float((state or {}).get("minimum_rating")) is not None:
        count += 1
    if _as_int((state or {}).get("minimum_vote_count"), 0) > 0:
        count += 1
    if (
        _valid_discovery_runtime((state or {}).get("minimum_runtime"))
        or _valid_discovery_runtime((state or {}).get("maximum_runtime"))
    ):
        count += 1
    if (state or {}).get("sort", "popularity.desc") != "popularity.desc":
        count += 1
    return count

def _discovery_query(action, media_type, state=None, **extra):
    query = {
        "action": action,
        "media_type": "tv" if media_type == "tv" else "movie"
    }
    query.update(state or {})
    query.update({key: value for key, value in extra.items() if value not in (None, "")})
    return query

def _replace_discovery_container(media_type, state):
    url = build_url(_discovery_query("show_discovery_filters", media_type, state))
    xbmc.executebuiltin(f"Container.Update({url})")

def _add_discovery_filter_item(handle, label, media_type, filter_name, state):
    item = xbmcgui.ListItem(label=label)
    item.setProperty('IsPlayable', 'false')
    item.setInfo('video', {'plot': u"\u00A0"})
    url = build_url(_discovery_query(
        "configure_discovery_filter",
        media_type,
        state,
        filter=filter_name
    ))
    xbmcplugin.addDirectoryItem(handle, url, item, isFolder=False)

def _queue_position(record):
    value = _as_int(record.get("queue_position"), 0)
    return value if value > 0 else 999999

def _normalize_queue_positions(data):
    queued = []
    for download_id, record in data.items():
        if record.get("status") not in QUEUE_STATUSES:
            continue
        if not record.get("id"):
            record["id"] = download_id
        queued.append((download_id, record))

    queued.sort(key=lambda item: (
        _queue_position(item[1]),
        item[1].get("created_at") or "",
        item[0]
    ))

    for index, (_, record) in enumerate(queued, start=1):
        record["queue_position"] = index

def _list_downloads_normalized():
    # Rendering the Downloads page must not wait for the transfer worker's
    # SQLite write lock. Queue positions only need normalizing in this snapshot.
    data = {download_id: dict(record) for download_id, record in db.list().items()}
    _normalize_queue_positions(data)
    return data

def _next_queue_position(data):
    positions = [
        _as_int(record.get("queue_position"), 0)
        for record in data.values()
        if record.get("status") in QUEUE_STATUSES
    ]
    return max(positions or [0]) + 1

def _queue_count(data):
    return sum(1 for record in data.values() if record.get("status") in QUEUE_STATUSES)

def _download_action_queries(record, queue_count=0):
    download_id = record.get("id")
    status = record.get("status")
    position = _as_int(record.get("queue_position"), 0)
    actions = []

    if status in QUEUE_STATUSES:
        if position > 1:
            actions.append((tr("Move up"), {'action': 'move_download', 'id': download_id, 'direction': 'up'}))
            actions.append((tr("Move to top"), {'action': 'move_download', 'id': download_id, 'direction': 'top'}))
        if position and position < queue_count:
            actions.append((tr("Move down"), {'action': 'move_download', 'id': download_id, 'direction': 'down'}))
            actions.append((tr("Move to bottom"), {'action': 'move_download', 'id': download_id, 'direction': 'bottom'}))

    if status in ("queued", "waiting_retry", "downloading"):
        actions.append((tr("Pause"), {'action': 'pause_download', 'id': download_id}))
    elif status == "paused":
        actions.append((tr("Resume"), {'action': 'resume_download', 'id': download_id}))

    if status in ("queued", "waiting_retry", "downloading", "pausing", "paused", "failed"):
        actions.append((tr("Cancel"), {'action': 'cancel_download', 'id': download_id}))

    if status in ("failed", "canceled") and record.get("error_code") != VERIFICATION_ERROR_CODE:
        actions.append((tr("Retry"), {'action': 'retry_download', 'id': download_id}))

    if status in ("complete", "failed", "canceled"):
        if not record.get("cleanup_pending") and not _part_exists(record):
            actions.append((tr("Remove from history"), {
                'action': 'remove_download_history',
                'id': download_id,
            }))

    if status == "complete":
        actions.append((tr("Verify"), {'action': 'verify_download', 'id': download_id}))
        actions.append((tr("Repair"), {'action': 'repair_download', 'id': download_id}))
    elif status in ("failed", "canceled") and record.get("error_code") == VERIFICATION_ERROR_CODE:
        actions.append((tr("Repair"), {'action': 'repair_download', 'id': download_id}))

    return actions

def _format_bytes(value):
    if value is None:
        return "unknown"
    size = _as_int(value, -1)
    if size < 0:
        return "unknown"

    units = ("B", "KB", "MB", "GB", "TB")
    index = 0
    amount = float(size)
    while amount >= 1024 and index < len(units) - 1:
        amount /= 1024
        index += 1

    if index == 0:
        return f"{int(amount)} {units[index]}"
    return f"{amount:.1f} {units[index]}"

def _media_lists_snapshot():
    try:
        data = media_lists_db.list()
    except Exception as ex:
        xbmc.log(f"[media_lists] Could not read media lists: {ex}", xbmc.LOGWARNING)
        data = {}

    return {
        key: data.get(key, {}) if isinstance(data.get(key, {}), dict) else {}
        for key in MEDIA_LIST_KEYS
    }

def _collection_title(collection):
    return tr(COLLECTION_TITLES.get(collection, "Media List"))

def _collection_id(record):
    kind = record.get("kind")
    if kind == "movie" and record.get("movie_id") not in (None, ""):
        return f"movie:{record.get('movie_id')}"
    if kind == "tv_show" and record.get("tv_id") not in (None, ""):
        return f"tv:{record.get('tv_id')}"
    if kind == "season" and all(record.get(key) not in (None, "") for key in ("tv_id", "season")):
        return f"season:{record.get('tv_id')}:{record.get('season')}"
    if kind == "episode" and all(record.get(key) not in (None, "") for key in ("tv_id", "season", "episode_id")):
        return f"episode:{record.get('tv_id')}:{record.get('season')}:{record.get('episode_id')}"
    if kind == "stream" and record.get("stream_id") not in (None, ""):
        return f"stream:{record.get('stream_id')}"
    return ""

def _collection_action_query(action, collection, record, item_id=None):
    query = {
        "action": action,
        "collection": collection,
        "item_id": item_id or _collection_id(record)
    }
    for key in COLLECTION_RECORD_KEYS:
        value = record.get(key)
        if value not in (None, ""):
            query[key] = value
    return query

def _collection_context_menu_items(record, collections=None):
    item_id = _collection_id(record)
    if not item_id:
        return []

    collections = collections or _media_lists_snapshot()
    items = []
    for collection in MEDIA_LIST_KEYS:
        if item_id in collections.get(collection, {}):
            label = COLLECTION_REMOVE_LABELS[collection]
            query = {
                "action": "remove_media_list_item",
                "collection": collection,
                "item_id": item_id
            }
        else:
            label = COLLECTION_ADD_LABELS[collection]
            query = _collection_action_query("add_media_list_item", collection, record, item_id)
        items.append((tr(label), f"RunPlugin({build_url(query)})"))
    return items

def _add_collection_context_menu(item, record, collections=None, extra_items=None):
    context_items = list(extra_items or [])
    context_items.extend(_collection_context_menu_items(record, collections))
    if context_items:
        item.addContextMenuItems(context_items, True)

def _collection_record_from_movie(movie, genre_names=None):
    rating = _as_float(movie.get("vote_average"), 0.0)
    return {
        "kind": "movie",
        "movie_id": movie.get("id"),
        "title": _movie_display_title(movie),
        "year": _movie_release_year(movie),
        "duration": _movie_duration_label(movie),
        "rating": f"{rating:.1f}" if rating else "",
        "genres": _modern_genre_label(movie, genre_names),
        "plot": movie.get("overview", ""),
        "poster": _poster_art_url(movie.get("poster_path")),
        "fanart": movie.get("backdrop_path", "")
    }

def _collection_record_from_tv_show(show, genre_names=None):
    rating = _as_float(show.get("vote_average"), 0.0)
    return {
        "kind": "tv_show",
        "tv_id": show.get("id"),
        "title": show.get("name_with_original_name") or show.get("name") or show.get("original_name") or "TV Show",
        "year": _get_tv_year(show),
        "rating": f"{rating:.1f}" if rating else "",
        "genres": _modern_genre_label(show, genre_names),
        "number_of_seasons": _as_int(show.get("number_of_seasons"), 0),
        "plot": show.get("overview", ""),
        "poster": _poster_art_url(show.get("poster_path")),
        "fanart": show.get("backdrop_path", "")
    }

def _collection_record_from_season(tv_id, tv_title, season, season_title, year, poster, fanart, season_data=None):
    title = f"{tv_title} - {season_title}" if tv_title else season_title
    season_data = season_data or {}
    rating = _as_float(season_data.get("vote_average"), 0.0)
    return {
        "kind": "season",
        "tv_id": tv_id,
        "season": season,
        "title": title,
        "tv_title": tv_title,
        "season_title": season_title,
        "year": year,
        "episode_count": season_data.get("episode_count"),
        "rating": f"{rating:.1f}" if rating else "",
        "plot": season_data.get("overview", ""),
        "poster": poster,
        "fanart": fanart
    }

def _collection_record_from_episode(tv_id, season, episode_id, tv_title, episode_title, poster, fanart):
    title = f"{tv_title} - {episode_title}" if tv_title else episode_title
    return {
        "kind": "episode",
        "media_type": "episode",
        "tv_id": tv_id,
        "season": season,
        "episode_id": episode_id,
        "title": title,
        "tv_title": tv_title,
        "episode_title": episode_title,
        "poster": poster,
        "fanart": fanart
    }

def _collection_record_from_movie_stream(
    stream,
    movie_id,
    movie_title,
    year,
    poster,
    fanart,
    duration="",
    rating="",
    genres="",
):
    display_name = _stream_display_name(stream)
    return {
        "kind": "stream",
        "media_type": "movie",
        "movie_id": movie_id,
        "stream_id": stream.get("id"),
        "title": movie_title or display_name,
        "year": year,
        "duration": duration,
        "rating": rating,
        "genres": genres,
        "poster": poster,
        "fanart": fanart,
        "stream_name": display_name,
        "size_gb": stream.get("sizeInGB"),
        "provider": _stream_provider(stream),
        "availability": _stream_availability(stream),
        "availability_message": stream.get("availabilityMessage"),
    }

def _collection_record_from_episode_stream(stream, tv_id, season, episode_id, tv_title, episode_title, poster, fanart):
    display_name = _stream_display_name(stream)
    title = f"{tv_title} - {episode_title}" if tv_title else episode_title
    return {
        "kind": "stream",
        "media_type": "episode",
        "tv_id": tv_id,
        "season": season,
        "episode_id": episode_id,
        "stream_id": stream.get("id"),
        "title": title,
        "tv_title": tv_title,
        "episode_title": episode_title,
        "poster": poster,
        "fanart": fanart,
        "stream_name": display_name,
        "size_gb": stream.get("sizeInGB"),
        "provider": _stream_provider(stream),
        "availability": _stream_availability(stream),
        "availability_message": stream.get("availabilityMessage"),
    }

def _collection_record_from_params(params):
    record = {
        key: params.get(key)
        for key in COLLECTION_RECORD_KEYS
        if params.get(key) not in (None, "")
    }
    item_id = params.get("item_id") or _collection_id(record)
    if item_id:
        record["id"] = item_id
    return item_id, record

def _collection_label(record):
    kind = record.get("kind")
    title = record.get("title") or record.get("stream_name") or "Media"
    year = record.get("year")

    if kind == "movie":
        return f"[Movie] {title} [COLOR FFAAAAAA][{year}][/COLOR]" if year else f"[Movie] {title}"
    if kind == "tv_show":
        return f"[TV] {title} [COLOR FFAAAAAA][{year}][/COLOR]" if year else f"[TV] {title}"
    if kind == "season":
        season_title = record.get("season_title") or f"Séria {record.get('season', '')}".strip()
        tv_title = record.get("tv_title")
        label = f"{tv_title} - {season_title}" if tv_title else title
        return f"[Season] {label}"
    if kind == "episode":
        return f"[Episode] {title}"
    if kind == "stream":
        stream_name = record.get("stream_name") or title
        if stream_name != title:
            return f"[Stream] {title} - {stream_name}"
        return f"[Stream] {stream_name}"
    return title

def _collection_plot(record):
    lines = []
    kind = record.get("kind")
    if kind:
        lines.append(f"Type: {kind.replace('_', ' ')}")
    if record.get("stream_name"):
        lines.append(f"Stream: {record.get('stream_name')}")
    if record.get("size_gb"):
        lines.append(f"Size: {record.get('size_gb')} GB")
    if record.get("tv_title"):
        lines.append(f"TV show: {record.get('tv_title')}")
    if record.get("season"):
        lines.append(f"Season: {record.get('season')}")
    if record.get("episode_title"):
        lines.append(f"Episode: {record.get('episode_title')}")
    if record.get("added_at"):
        lines.append(f"Added: {record.get('added_at').replace('T', ' ')}")
    return "\n".join(lines) or u"\u00A0"

def _collection_art(record):
    art = {}
    if record.get("poster"):
        art["poster"] = record.get("poster")
        art["thumb"] = record.get("poster")
    if record.get("fanart"):
        art["fanart"] = record.get("fanart")
    return art

def _collection_open_query(record):
    kind = record.get("kind")
    if kind == "movie":
        return {
            "action": "list_movie_versions",
            "movie_id": record.get("movie_id", ""),
            "title": record.get("title", ""),
            "year": record.get("year", ""),
            "duration": record.get("duration", ""),
            "rating": record.get("rating", ""),
            "genres": record.get("genres", ""),
            "poster": record.get("poster", ""),
            "fanart": record.get("fanart", "")
        }
    if kind == "tv_show":
        return {
            "action": "list_seasons",
            "tv_id": record.get("tv_id", "")
        }
    if kind == "season":
        return {
            "action": "list_episodes",
            "tv_id": record.get("tv_id", ""),
            "season": record.get("season", ""),
            "tv_title": record.get("tv_title", ""),
            "poster": record.get("poster", ""),
            "fanart": record.get("fanart", "")
        }
    if kind == "episode":
        return {
            "action": "show_streams",
            "tv_id": record.get("tv_id", ""),
            "season": record.get("season", ""),
            "episode_id": record.get("episode_id", ""),
            "tv_title": record.get("tv_title", ""),
            "poster": record.get("poster", ""),
            "fanart": record.get("fanart", "")
        }
    if kind == "stream":
        query = {
            "action": "play_movie_stream",
            "stream_id": record.get("stream_id", "")
        }
        for key in (
            "media_type",
            "movie_id",
            "tv_id",
            "season",
            "episode_id",
            "tv_title",
            "episode_title",
            "title",
            "year",
            "poster",
            "fanart",
            "stream_name",
            "provider",
            "availability",
            "availability_message",
        ):
            value = record.get(key)
            if value not in (None, ""):
                query[key] = value
        return query
    return {}

def _collection_is_folder(record):
    return record.get("kind") != "stream"

def show_media_collection(handle, collection):
    source_collection = collection
    if source_collection not in MEDIA_LIST_KEYS:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    title = _collection_title(source_collection)
    _prepare_directory(handle, title, "videos")
    try:
        xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_UNSORTED)
    except Exception:
        pass

    collections = _media_lists_snapshot()
    records = sorted(
        collections.get(source_collection, {}).values(),
        key=lambda record: record.get("added_at") or "",
        reverse=True
    )
    if records:
        clear_item = xbmcgui.ListItem(label=f"Clear {_collection_title(source_collection)}")
        clear_item.setInfo('video', {'plot': f"Remove all local {_collection_title(source_collection).lower()} entries."})
        clear_url = build_url({'action': 'clear_media_list', 'collection': source_collection})
        xbmcplugin.addDirectoryItem(handle, clear_url, clear_item, isFolder=False)
    elif not records:
        empty_item = xbmcgui.ListItem(label=f"{title} is empty")
        empty_item.setInfo('video', {'plot': u"\u00A0"})
        xbmcplugin.addDirectoryItem(handle, "", empty_item, isFolder=False)
        xbmcplugin.endOfDirectory(handle)
        return

    for record in records:
        item_id = record.get("id") or _collection_id(record)
        if not item_id:
            continue

        item = xbmcgui.ListItem(label=_collection_label(record))
        item.setInfo('video', {
            'title': record.get("title") or record.get("stream_name") or "Media",
            'plot': _collection_plot(record)
        })
        art = _collection_art(record)
        if art:
            item.setArt(art)

        if record.get("kind") == "stream":
            item.setProperty('IsPlayable', 'true')

        context_items = _collection_context_menu_items(record, collections)
        context_items.append((
            f"Clear {_collection_title(source_collection)}",
            f"RunPlugin({build_url({'action': 'clear_media_list', 'collection': source_collection})})"
        ))
        item.addContextMenuItems(context_items, True)

        open_query = _collection_open_query(record)
        url = build_url(open_query) if open_query else ""
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=_collection_is_folder(record))

    xbmcplugin.endOfDirectory(handle)

def show_favorites(handle):
    show_media_collection(handle, "favorites")

def add_media_list_item(collection, params):
    if collection not in MEDIA_LIST_KEYS:
        xbmcgui.Dialog().notification("Media List", "Unknown list", xbmcgui.NOTIFICATION_ERROR, 2000)
        return

    item_id, record = _collection_record_from_params(params or {})
    if not item_id:
        xbmcgui.Dialog().notification(_collection_title(collection), "Item cannot be saved", xbmcgui.NOTIFICATION_ERROR, 2000)
        return

    try:
        added = media_lists_db.upsert(collection, item_id, record)
    except Exception as ex:
        xbmc.log(f"[media_lists] Could not add item {item_id} to {collection}: {ex}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification(_collection_title(collection), "Could not save item", xbmcgui.NOTIFICATION_ERROR, 2500)
        return

    message = "Added" if added else "Updated"
    xbmcgui.Dialog().notification(_collection_title(collection), f"{message}: {_collection_label(record)}", xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin("Container.Refresh")

def remove_media_list_item(collection, item_id):
    if collection not in MEDIA_LIST_KEYS or not item_id:
        return

    try:
        removed = media_lists_db.remove(collection, item_id)
    except Exception as ex:
        xbmc.log(f"[media_lists] Could not remove item {item_id} from {collection}: {ex}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification(_collection_title(collection), "Could not remove item", xbmcgui.NOTIFICATION_ERROR, 2500)
        return

    if removed:
        xbmcgui.Dialog().notification(_collection_title(collection), "Item removed", xbmcgui.NOTIFICATION_INFO, 1500)
    xbmc.executebuiltin("Container.Refresh")

def clear_media_list(collection):
    if collection not in MEDIA_LIST_KEYS:
        return

    title = _collection_title(collection)
    confirm = xbmcgui.Dialog().yesno(title, f"All local {title.lower()} entries will be removed. Continue?", yeslabel="Yes", nolabel="No")
    if not confirm:
        return

    media_lists_db.clear(collection)
    xbmc.executebuiltin("Container.Refresh")

def _history_id(record):
    media_type = record.get("media_type")
    if media_type == "movie" and record.get("movie_id") not in (None, ""):
        return f"movie:{record.get('movie_id')}"
    if media_type == "episode" and all(record.get(key) not in (None, "") for key in ("tv_id", "season", "episode_id")):
        return f"episode:{record.get('tv_id')}:{record.get('season')}:{record.get('episode_id')}"
    return f"stream:{record.get('stream_id')}"

def _trim_watch_history(data):
    if len(data) <= MAX_WATCH_HISTORY_ITEMS:
        return

    ordered = sorted(
        data.items(),
        key=lambda item: item[1].get("last_played_at") or item[1].get("created_at") or ""
    )
    for history_id, _ in ordered[:len(data) - MAX_WATCH_HISTORY_ITEMS]:
        data.pop(history_id, None)

def _record_watch_history(stream_id, params):
    if not stream_id:
        return

    params = params or {}
    media_type = params.get("media_type") or "stream"
    stream_name = params.get("stream_name") or params.get("filename") or ""
    title = params.get("title") or stream_name or f"Stream {stream_id}"
    timestamp = now_iso()
    record = {
        "stream_id": stream_id,
        "media_type": media_type,
        "movie_id": params.get("movie_id"),
        "tv_id": params.get("tv_id"),
        "season": params.get("season"),
        "episode_id": params.get("episode_id"),
        "episode_number": params.get("episode_number"),
        "tv_title": params.get("tv_title"),
        "episode_title": params.get("episode_title"),
        "title": title,
        "year": params.get("year"),
        "poster": _media_art_url(params.get("poster")),
        "fanart": _media_art_url(params.get("fanart")),
        "stream_name": stream_name,
        "provider": params.get("provider"),
        "availability": params.get("availability"),
        "availability_message": params.get("availability_message"),
        "last_played_at": timestamp
    }
    history_id = _history_id(record)
    record["id"] = history_id

    def op(data):
        existing = data.get(history_id, {})
        record["plot"] = params.get("plot") or existing.get("plot") or ""
        record["created_at"] = existing.get("created_at") or timestamp
        record["play_count"] = _as_int(existing.get("play_count"), 0) + 1
        for key in ("position_seconds", "duration_seconds", "progress_percent"):
            if existing.get(key) not in (None, ""):
                record[key] = existing[key]
        if existing.get("completed"):
            record["completed"] = True
        data[history_id] = {
            key: value for key, value in record.items()
            if value not in (None, "")
        }
        _trim_watch_history(data)

    try:
        watch_history_db.mutate(op)
    except Exception as ex:
        xbmc.log(f"[watch_history] Could not record stream {stream_id}: {ex}", xbmc.LOGWARNING)


def _history_resume_position(record):
    try:
        position = float(record.get("position_seconds", record.get("resume_seconds")) or 0)
        duration = float(record.get("duration_seconds") or 0)
        if position <= 0 and duration > 0:
            position = duration * float(record.get("progress_percent", 0) or 0) / 100
    except (TypeError, ValueError):
        return None
    if position <= 0 or (duration > 0 and position >= duration * WATCHED_PERCENT / 100):
        return None
    return position


def _format_playback_time(seconds):
    seconds = max(0, int(seconds))
    minutes, seconds = divmod(seconds, 60)
    hours, minutes = divmod(minutes, 60)
    return f"{hours}:{minutes:02d}:{seconds:02d}" if hours else f"{minutes}:{seconds:02d}"


def _modern_resume_options(target):
    params = _modern_target_params(target)
    if params.get("resume_mode"):
        return None
    record = dict(params)
    try:
        saved = watch_history_db.list().get(_history_id(record), {})
    except Exception as ex:
        xbmc.log(f"[modern_home] Could not read resume position: {ex}", xbmc.LOGWARNING)
        return None
    position = _history_resume_position(saved if isinstance(saved, dict) else {})
    if position is None:
        return None
    def target_for(mode):
        mode_params = dict(params)
        mode_params["resume_mode"] = mode
        if mode == "resume":
            mode_params["resume_seconds"] = str(position)
        return build_url(mode_params)
    return {
        "title": params.get("title") or params.get("stream_name") or tr("Continue watching"),
        "position": _format_playback_time(position),
        "resume_target": target_for("resume"),
        "beginning_target": target_for("beginning"),
    }


def _clear_modern_resume_position(params):
    history_id = _history_id(dict(params or {}, stream_id=(params or {}).get("stream_id", "")))
    try:
        def clear(data):
            record = data.get(history_id)
            if isinstance(record, dict):
                record.pop("position_seconds", None)
                record.pop("resume_seconds", None)
                record.pop("progress_percent", None)
        watch_history_db.mutate(clear)
    except Exception as ex:
        xbmc.log(f"[watch_history] Could not clear resume position: {ex}", xbmc.LOGWARNING)


def _history_label(record):
    title = record.get("title") or record.get("stream_name") or "Stream"
    year = record.get("year")
    if record.get("media_type") == "movie" and year:
        return f"{title} [COLOR FFAAAAAA][{year}][/COLOR]"
    if record.get("media_type") == "episode":
        return f"[TV] {title}"
    return title

def _history_plot(record):
    lines = []
    if record.get("stream_name"):
        lines.append(f"Stream: {record.get('stream_name')}")
    if record.get("last_played_at"):
        lines.append(f"Last played: {record.get('last_played_at').replace('T', ' ')}")
    if record.get("play_count"):
        lines.append(f"Play count: {record.get('play_count')}")
    return "\n".join(lines) or u"\u00A0"

def _history_watched_when(record, now=None):
    value = record.get("last_played_at") or record.get("created_at")
    if not value:
        return tr("Watched recently")
    try:
        watched = datetime.datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        if watched.tzinfo is not None:
            watched = watched.astimezone()
        current = now or datetime.datetime.now().astimezone()
        if current.tzinfo is not None and watched.tzinfo is None:
            watched = watched.replace(tzinfo=current.tzinfo)
        day_delta = current.date() - watched.date()
        clock = watched.strftime("%H:%M")
        if day_delta.days == 0:
            return tr("Watched today at {0}", clock)
        if day_delta.days == 1:
            return tr("Watched yesterday at {0}", clock)
        if 1 < day_delta.days < 7:
            return tr("Watched {0} at {1}", watched.strftime('%A'), clock)
        return tr("Watched {0} at {1}", watched.strftime('%d %b %Y'), clock)
    except (TypeError, ValueError, OverflowError):
        return tr("Watched recently")

def _history_progress(record):
    progress = record.get("progress_percent", record.get("progress"))
    if progress in (None, ""):
        position = record.get("position_seconds", record.get("resume_seconds"))
        duration = record.get("duration_seconds")
        try:
            if float(duration) > 0:
                progress = (float(position) / float(duration)) * 100
        except (TypeError, ValueError, ZeroDivisionError):
            progress = None
    try:
        return max(0, min(100, int(round(float(progress)))))
    except (TypeError, ValueError):
        return None

def _history_is_complete(record, progress=None):
    explicit = record.get("completed", record.get("watched"))
    if isinstance(explicit, str):
        explicit = explicit.strip().lower() in ("1", "true", "yes")
    if explicit is not None:
        return bool(explicit)
    return progress is not None and progress >= WATCHED_PERCENT

def _history_play_query(record):
    query = {
        "action": "play_movie_stream",
        "stream_id": record.get("stream_id", "")
    }
    for key in (
        "media_type",
        "movie_id",
        "tv_id",
        "season",
        "episode_id",
        "episode_number",
        "tv_title",
        "episode_title",
        "title",
        "year",
        "poster",
        "fanart",
        "stream_name",
        "provider",
        "availability",
        "availability_message",
    ):
        value = record.get(key)
        if value not in (None, ""):
            query[key] = value
    return query


def _history_stream_picker_query(record):
    media_type = record.get("media_type")
    if media_type == "episode":
        required = ("tv_id", "season", "episode_id")
        action = "show_streams"
    elif media_type == "movie":
        required = ("movie_id",)
        action = "list_movie_versions"
    else:
        return None
    if any(record.get(key) in (None, "") for key in required):
        return None

    query = _history_play_query(record)
    query["action"] = action
    query.pop("stream_id", None)
    for key in ("resume_mode", "resume_seconds"):
        value = record.get(key)
        if value not in (None, ""):
            query[key] = value
    return query


def _remembered_history_stream(record):
    """Return the saved stream and whether its current listing was verified."""
    try:
        if record.get("media_type") == "episode":
            streams = api.get_episode_streams(
                record.get("tv_id"),
                record.get("season"),
                record.get("episode_number"),
            )
        elif record.get("media_type") == "movie":
            streams = api.get_movie_versions(record.get("movie_id"))
        else:
            return None, False
    except Exception as ex:
        xbmc.log(
            "[modern_home] Could not verify remembered stream {0}: {1}".format(
                record.get("stream_id", ""), ex
            ),
            xbmc.LOGWARNING,
        )
        return None, False

    remembered_id = _clean_query_value(record.get("stream_id"))
    match = next((
        stream for stream in (streams or [])
        if isinstance(stream, dict)
        and _clean_query_value(stream.get("id")) == remembered_id
    ), None)
    return match, True

def _history_episode_navigation_context_menu_items(record):
    if record.get("media_type") != "episode":
        return []

    tv_id = record.get("tv_id")
    if tv_id in (None, ""):
        return []

    tv_show_url = build_url({
        'action': 'list_seasons',
        'tv_id': tv_id
    })
    items = [(
        tr("Prejsť na seriál"),
        f"Container.Update({tv_show_url})"
    )]

    season = record.get("season")
    if season not in (None, ""):
        season_url = build_url({
            'action': 'list_episodes',
            'tv_id': tv_id,
            'season': season,
            'tv_title': record.get('tv_title') or '',
            'poster': record.get('poster') or '',
            'fanart': record.get('fanart') or ''
        })
        items.append((
            tr("Prejsť na sériu"),
            f"Container.Update({season_url})"
        ))

    return items

def _modern_history_episode_actions(record):
    if record.get("media_type") != "episode":
        return []
    tv_id = record.get("tv_id")
    if tv_id in (None, ""):
        return []

    common = {
        "tv_id": tv_id,
        "tv_title": record.get("tv_title") or "",
        "poster": record.get("poster") or "",
        "fanart": record.get("fanart") or "",
    }
    actions = []
    season = record.get("season")
    if season not in (None, ""):
        next_query = dict(common)
        next_query.update({
            "action": "show_next_episode",
            "season": season,
            "episode_id": record.get("episode_id") or "",
            "episode_number": record.get("episode_number") or "",
        })
        actions.append({
            "label": tr("Play next episode"),
            "label2": tr("Open the next available episode"),
            "command": "browse",
            "target": build_url(next_query),
            "properties": {"App.Badge": "PLAY"},
        })

        season_query = dict(common)
        season_query.update({"action": "list_episodes", "season": season})
        actions.append({
            "label": tr("View this season"),
            "label2": tr("Choose another episode"),
            "command": "browse",
            "target": build_url(season_query),
            "properties": {"App.Badge": "EPISODES"},
        })
    actions.append({
        "label": tr("View series"),
        "label2": tr("Browse every season"),
        "command": "browse",
        "target": build_url({"action": "list_seasons", "tv_id": tv_id}),
        "properties": {"App.Badge": "SERIES"},
    })
    return actions

def _hero_excerpt(value, limit=360):
    text = " ".join(str(value or "").split())
    if len(text) <= limit:
        return text
    boundary = text.rfind(" ", 0, limit + 1)
    if boundary < int(limit * 0.65):
        boundary = limit
    return text[:boundary].rstrip(" ,.;:-") + "…"


def _home_presentation(title, description):
    """Keep Home copy compact without changing catalogue or playback metadata."""
    title = " ".join(str(title or "").split())
    return {
        "App.HomeTitle": title,
        "App.HomeLongTitle": "true" if len(title) > 32 else "false",
        "App.HomeSummary": _hero_excerpt(description, limit=140),
    }


def _home_progress_texture(progress):
    if progress is None:
        return ""
    value = max(0.0, min(100.0, _as_float(progress, 0.0)))
    bucket = min(100, int((value + 2.5) // 5) * 5)
    return "home-progress-{0:03d}.png".format(bucket)


def _modern_row_description(value, line_limit=135):
    text = " ".join(str(value or "").split())
    if not text:
        return ""

    words = text.split(" ")
    lines = []
    current = ""
    while words and len(lines) < 3:
        word = words.pop(0)
        candidate = word if not current else current + " " + word
        if current and len(candidate) > line_limit:
            lines.append(current)
            current = word
        else:
            current = candidate
    if current:
        lines.append(current)
    if words:
        lines[-1] = lines[-1].rstrip(" ,.;:-") + "…"
    return "[CR]".join(lines)


def _home_model(
    label,
    label2,
    command,
    target,
    fallback_art,
    eyebrow,
    title,
    meta,
    description,
    poster="",
    fanart="",
    thumb=""
):
    tile_art = thumb or poster or fanart or fallback_art
    background = fanart or poster or fallback_art
    action_labels = {
        "home": tr("Explore").upper(),
        "navigate": tr("Open").upper(),
        "play": tr("PLAY"),
        "settings": tr("SETTINGS"),
        "detail": tr("Details").upper(),
    }
    return {
        "label": tr(label),
        "label2": tr(label2),
        "command": command,
        "target": target,
        "art": {
            "thumb": tile_art,
            "poster": poster or tile_art,
            "fanart": background
        },
        "properties": {
            **_home_presentation(tr(title), tr(description)),
            "MediaHub.Eyebrow": tr(eyebrow),
            "MediaHub.Title": tr(title),
            "MediaHub.Meta": meta,
            "MediaHub.Description": tr(description),
            "MediaHub.HeroDescription": _hero_excerpt(tr(description)),
            "MediaHub.Action": action_labels.get(command, tr("Open").upper()),
            "MediaHub.Progress": "0"
        }
    }

def _modern_home_navigation(fallback_art, history_count, favorite_count, download_count):
    entries = (
        (
            "Home",
            tr("{0} recent  •  {1} saved", history_count, favorite_count),
            "home",
            "MEDIA HUB",
            "Everything worth watching.",
            "Your personal streaming space",
            "Movies, series, favourites and downloads in one place."
        ),
        (
            "Movies",
            "Popular, new and top rated",
            "movies",
            "MOVIES",
            "A film for every night.",
            "New releases  •  Top rated  •  Popular",
            "Browse a poster-first catalogue without leaving the Media Hub app."
        ),
        (
            "TV Series",
            "Trending and recently aired",
            "tv",
            "TV SERIES",
            "Your next series is here.",
            "Trending  •  New episodes  •  Slovak",
            "Move through series and new episodes in the same cinematic interface."
        ),
        (
            "Downloads",
            tr("{0} downloads", download_count),
            "downloads",
            "OFFLINE LIBRARY",
            "Downloads under control.",
            tr("{0} downloads", download_count),
            "Check progress and manage offline titles without changing screens."
        ),
        (
            "Favourites",
            tr("{0} saved", favorite_count),
            "favorites",
            "MY LIST",
            "Your favourites, always close.",
            tr("{0} saved items", favorite_count),
            "Return to saved films, series, episodes and streams."
        ),
        (
            "Recently Viewed",
            tr("{0} recent plays", history_count),
            "history",
            "RECENTLY VIEWED",
            "Continue where you left off.",
            tr("{0} items in history", history_count),
            "Resume recent movies and episodes in one click."
        ),
        (
            "Settings",
            "Playback, API and downloads",
            "settings",
            "SETTINGS",
            "Media Hub, your way.",
            "Playback  •  API  •  Downloads",
            "Review the main preference areas before opening Kodi's settings panel."
        )
    )

    models = [
        _home_model(
            tr(label),
            label2,
            "page",
            "",
            fallback_art,
            tr(eyebrow),
            tr(title),
            meta,
            tr(description)
        )
        for (
            label,
            label2,
            page,
            eyebrow,
            title,
            meta,
            description
        ) in entries
    ]
    # Use the active skin's monochrome side-menu artwork so the rail reads like
    # a native TV application instead of a row of letter monograms.
    navigation_media = os.path.join(
        xbmcaddon.Addon().getAddonInfo("path"),
        "resources",
        "skins",
        "Default",
        "media",
    )
    icons = tuple(
        os.path.join(navigation_media, filename)
        for filename in (
            "nav-home.png",
            "nav-movies.png",
            "nav-tv.png",
            "nav-downloads.png",
            "nav-favorites.png",
            "nav-recent.png",
            "nav-settings.png",
        )
    )
    glyphs = ("H", "M", "T", "D", "F", "R", "S")
    for model, icon, glyph, entry in zip(models, icons, glyphs, entries):
        model["properties"]["MediaHub.NavIcon"] = icon
        model["properties"]["MediaHub.NavGlyph"] = glyph
        model["properties"]["App.Page"] = entry[2]
        if entry[2] == "downloads":
            model["command"] = "browse"
            model["target"] = build_url({"action": "show_downloads_menu"})
    return models

def _modern_home_quick_items(fallback_art):
    entries = (
        (
            "Populárne filmy",
            "Najsledovanejšie tituly",
            {"action": "menu_item_movies_popular", "filter_type": "all_time"},
            "TRENDY",
            "Najpopulárnejšie filmy práve teraz."
        ),
        (
            "Nové filmy",
            "Čerstvo pridané",
            {"action": "menu_item_movies_latest"},
            "NOVINKY",
            "Pozrite si najnovšie filmové prírastky."
        ),
        (
            "Populárne seriály",
            "Série, ktoré sa sledujú",
            {"action": "list_tv_shows_popular"},
            "TRENDY",
            "Objavte seriály, ktoré práve priťahujú pozornosť."
        ),
        (
            "Nové seriály",
            "Najnovšie série",
            {"action": "list_tv_shows_latest"},
            "NOVINKY",
            "Prejdite na nové seriály a čerstvé série."
        ),
        (
            "Objavovať",
            "Žánre, roky a hodnotenie",
            {"action": "show_discovery_filters", "media_type": "movie"},
            "OBJAVUJTE",
            "Vyberte si obsah pomocou inteligentných filtrov."
        ),
        (
            "Hľadať",
            "Filmy a seriály",
            {"action": "menu_item_search"},
            "HĽADAŤ",
            "Vyhľadajte konkrétny titul."
        )
    )
    return [
        _home_model(
            label,
            label2,
            "browse",
            build_url(query),
            fallback_art,
            eyebrow,
            label,
            label2,
            description
        )
        for label, label2, query, eyebrow, description in entries
    ]

def _modern_home_history_items(fallback_art, limit=10):
    try:
        snapshot = watch_history_db.list()
    except Exception as ex:
        xbmc.log(f"[modern_home] Could not read watch history: {ex}", xbmc.LOGWARNING)
        snapshot = {}

    records = sorted(
        (
            record
            for record in snapshot.values()
            if isinstance(record, dict)
        ) if isinstance(snapshot, dict) else (),
        key=lambda record: record.get("last_played_at") or record.get("created_at") or "",
        reverse=True
    )
    items = []
    for record in records:
        if not record.get("stream_id"):
            continue
        media_label = tr("Movie" if record.get("media_type") == "movie" else "Episode")
        year = _clean_query_value(record.get("year"))
        episode_meta = ""
        if record.get("media_type") == "episode":
            season = _as_int(record.get("season"), 0)
            episode = _episode_number(record)
            if season and episode:
                episode_meta = f"S{season:02d} E{episode:02d}"
            elif season:
                episode_meta = tr("Season {0}", season)
        meta = "  •  ".join(
            value for value in (media_label, episode_meta, year) if value
        )
        title = record.get("title") or record.get("stream_name") or "Nedávno prehrané"
        progress = _history_progress(record)
        complete = _history_is_complete(record, progress)
        action_label = tr("Watch again") if complete else tr("Continue watching")
        watched_when = _history_watched_when(record)
        poster = _media_art_url(record.get("poster"))
        fanart = _media_art_url(record.get("fanart")) or poster
        thumb = (
            poster
            if record.get("media_type") == "episode"
            else fanart or poster
        )
        model = _home_model(
            title,
            action_label,
            "play",
            build_url(_history_play_query(record)),
            fallback_art,
            "NEDÁVNO PREHRANÉ",
            title,
            meta,
            _history_plot(record),
            poster,
            fanart,
            thumb
        )
        model["properties"].update({
            "App.Kind": "movie" if record.get("media_type") == "movie" else "tv",
            "App.KindLabel": media_label,
            "App.Year": year,
            "App.Rating": "",
            "App.HistoryMeta": meta,
            "App.WatchedWhen": watched_when,
            "App.WatchAction": action_label,
            "App.Progress": "" if progress is None else str(progress),
            "App.ProgressDisplay": (
                tr("{0}% complete", progress) if progress is not None else ""
            ),
            "App.ProgressTexture": (
                _home_progress_texture(progress) if progress is not None and not complete else ""
            ),
            "App.HasProgress": "true" if progress is not None and not complete else "false",
            "App.HistoryLinks": (
                tr("MENU  •  Series, season & next episode")
                if record.get("media_type") == "episode" and record.get("tv_id")
                else ""
            )
        })
        if record.get("media_type") == "episode":
            model["context_actions"] = [{
                "label": action_label,
                "label2": tr("Resume this episode") if not complete else tr("Replay this episode"),
                "command": "play",
                "target": build_url(_history_play_query(record)),
                "properties": {"App.Badge": "PLAY"},
            }]
            model["context_actions"].extend(
                _modern_history_episode_actions(record)
            )
        items.append(model)
        if limit is not None and len(items) >= limit:
            break
    return items

def _ordered_series_episodes(tv_id, season_number):
    episodes = [
        episode
        for episode in (
            api.get_episodes(tv_id, season_number, include_streams=False) or []
        )
        if isinstance(episode, dict)
    ]
    return sorted(
        episodes,
        key=lambda episode: (
            _episode_number(episode, 1000000),
            _as_int(episode.get("id"), 1000000),
        ),
    )


def _next_playable_episode(record, fast=False):
    tv_id = _as_int(record.get("tv_id"), 0)
    season = _as_int(record.get("season"), 0)
    current_id = _as_int(record.get("episode_id"), -1)
    current_number = _as_int(record.get("episode_number"), 0)
    if tv_id <= 0 or season < 0:
        return None

    episodes = _ordered_series_episodes(tv_id, season)
    current_index = next((
        index for index, episode in enumerate(episodes)
        if _as_int(episode.get("id"), -2) == current_id
    ), None)
    candidates = (
        episodes[current_index + 1:]
        if current_index is not None
        else [
            episode for episode in episodes
            if _episode_number(episode) > current_number
        ]
    )

    def playable(candidate, season_number):
        episode_number = _episode_number(candidate)
        if episode_number <= 0:
            return None
        streams = candidate.get("streams") or (api.find_episode_candidates if fast else api.get_episode_streams)(
            tv_id, season_number, episode_number
        )
        streams = [
            stream for stream in (streams or [])
            if isinstance(stream, dict) and stream.get("id") not in (None, "")
        ]
        return (candidate, season_number, streams) if streams else None

    for candidate in candidates:
        resolved = playable(candidate, season)
        if resolved is not None:
            return resolved

    details = api.get_tv_details(tv_id) or {}
    later_seasons = sorted({
        _as_int(item.get("season_number"), -1)
        for item in details.get("seasons") or []
        if isinstance(item, dict)
        and _as_int(item.get("season_number"), -1) > season
    })
    for season_number in later_seasons:
        for candidate in _ordered_series_episodes(tv_id, season_number):
            resolved = playable(candidate, season_number)
            if resolved is not None:
                return resolved
    return None


def _modern_up_next_model(record, fallback_art, fast=False):
    resolved = _next_playable_episode(record, fast=True) if fast else _next_playable_episode(record)
    if resolved is None:
        return None
    episode, season, _streams = resolved
    episode_number = _episode_number(episode)
    tv_title = record.get("tv_title") or record.get("title") or "TV Series"
    raw_episode_title = _clean_query_value(_get_episode_title(episode))
    episode_title = re.sub(
        r"^S\d{1,2}\s*E\d{1,3}\s*[-–—:·]\s*",
        "",
        raw_episode_title,
        flags=re.IGNORECASE,
    )
    episode_code = "S{0:02d} E{1:02d}".format(season, episode_number)
    description = episode.get("description") or episode.get("overview") or ""
    episode_image = _media_art_url(
        episode.get("imageUrl") or episode.get("image_url")
    )
    poster = _media_art_url(record.get("poster")) or episode_image
    fanart = (
        _media_art_url(record.get("fanart"))
        or episode_image
        or poster
        or fallback_art
    )
    query = {
        "action": "show_streams",
        "media_type": "episode",
        "tv_id": record.get("tv_id", ""),
        "season": season,
        "episode_id": episode.get("id", ""),
        "episode_number": episode_number,
        "tv_title": tv_title,
        "episode_title": raw_episode_title,
        "title": "{0} - {1}".format(tv_title, raw_episode_title),
        "poster": poster,
        "fanart": fanart,
        "plot": description,
    }
    target = build_url(query)
    meta = " · ".join(value for value in (episode_code, episode_title) if value)
    card_meta = " · ".join((episode_code, tr("Next episode")))
    model = _home_model(
        tv_title,
        card_meta,
        "browse",
        target,
        fallback_art,
        tr("Next episode"),
        tv_title,
        meta,
        description,
        poster,
        fanart,
        fanart,
    )
    model["properties"].update({
        **_home_presentation(str(tv_title).split(" / ", 1)[0], description),
        "App.HomeMeta": meta,
        "App.HomeId": "up-next:{0}:{1}:{2}".format(
            record.get("tv_id", ""), season, episode.get("id", episode_number)
        ),
        "App.HomeCardMeta": card_meta,
        "App.HomeHint": "",
        "App.Progress": "0",
        "App.ProgressTexture": "",
        "App.HasProgress": "false",
        "App.HomeUpNext": "true",
        "App.Kind": "tv",
        "MediaHub.Progress": "0",
    })
    _prepare_home_resume_metadata(model, dict(record, duration_seconds=
        (_as_float(episode.get("runtime"), 0) * 60)), meta)
    model["context_actions"] = [
        {"label": tr("Choose stream"), "command": "browse", "target": target},
        *[action for action in _modern_history_episode_actions({
            **record,
            "season": season,
            "episode_id": episode.get("id", ""),
            "episode_number": episode_number,
        }) if action.get("label") != tr("Play next episode")],
    ]
    return model


def _home_resume_meta(record, base_meta, details=None, genre_names=None):
    details = details or {}
    is_episode = record.get("media_type") == "episode"
    runtime = _as_float(record.get("duration_seconds"), 0) / 60
    if not is_episode:
        runtime = _as_float(details.get("runtime"), 0) or runtime
    duration = "{0} min".format(int(round(runtime))) if runtime > 0 else ""
    rating = _as_float(details.get("vote_average"), 0) or _as_float(record.get("rating"), 0)
    genres = _modern_genre_label(details, genre_names) or _clean_query_value(record.get("genres"))
    return "  •  ".join(str(value) for value in (
        base_meta, duration, f"★ {rating:.1f}" if rating else "", genres,
    ) if value)


def _prepare_home_resume_metadata(model, record, base_meta):
    model["properties"]["App.HomeMeta"] = _home_resume_meta(record, base_meta)
    kind = "tv" if record.get("media_type") == "episode" else "movie"
    media_id = record.get("tv_id" if kind == "tv" else "movie_id")
    if media_id:
        model["catalog_source"] = {"id": media_id}
        model["catalog_type"] = kind
        model["home_resume_metadata"] = True
        model["home_resume_record"] = dict(record)
        model["home_resume_base_meta"] = base_meta
        model["properties"]["App.Id"] = _clean_query_value(media_id)


def _enrich_home_resume_metadata(model, genre_names=None):
    """Fill saved-card facts without replacing playback actions or progress."""
    source = model.get("catalog_source") or {}
    kind = model.get("catalog_type", "movie")
    try:
        details = api.get_catalog_metadata(kind, source.get("id")) or {}
    except api.ApiError as exc:
        if exc.status_code not in (404, 405):
            raise
        details = {}
    if not details.get("vote_average") or not _modern_genre_label(details, genre_names):
        summary = api.get_catalog_summary(kind, source.get("id"),
                                         model["properties"].get("App.HomeTitle", ""))
        details = dict(summary, **{key: value for key, value in details.items()
                                  if value not in (None, "", [])})
    updated = dict(model, properties=dict(model.get("properties") or {}), catalog_enriched=True)
    updated["properties"]["App.HomeMeta"] = _home_resume_meta(
        model.get("home_resume_record") or {}, model.get("home_resume_base_meta", ""), details, genre_names)
    description = _clean_query_value(details.get("overview"))
    if kind == "movie" and description and not updated["properties"].get("App.HomeSummary"):
        updated["properties"].update({
            "App.HomeSummary": _hero_excerpt(description, limit=140),
            "MediaHub.Description": description,
            "MediaHub.HeroDescription": _hero_excerpt(description),
        })
    if kind == "movie":
        updated["properties"].update(_movie_credits_properties(details))
    return updated


def _modern_continue_watching_items(fallback_art, limit=8, include_next=True, fast_next=False):
    """Local, resumable titles; one recent episode per series, independent of discovery."""
    try:
        snapshot = watch_history_db.list()
    except Exception as ex:
        xbmc.log(f"[modern_home] Could not read continuation history: {ex}", xbmc.LOGWARNING)
        return []
    records = sorted(
        (record for record in snapshot.values() if isinstance(record, dict)),
        key=lambda record: record.get("last_played_at") or record.get("created_at") or "",
        reverse=True,
    ) if isinstance(snapshot, dict) else []
    items, seen_series = [], set()
    for record in records:
        if not record.get("stream_id"):
            continue
        is_episode = record.get("media_type") == "episode"
        series_id = _clean_query_value(record.get("tv_id")) if is_episode else ""
        if series_id:
            if series_id in seen_series:
                continue
            seen_series.add(series_id)
        position = _history_resume_position(record)
        progress = _history_progress(record)
        complete = _history_is_complete(record, progress)
        if record.get("hidden_from_home"):
            continue
        if complete:
            if not include_next:
                continue
            if not is_episode:
                continue
            try:
                up_next = _modern_up_next_model(record, fallback_art, fast=True) if fast_next else _modern_up_next_model(record, fallback_art)
            except Exception as ex:
                xbmc.log(
                    "[modern_home] Could not resolve next episode for {0}: {1}".format(
                        series_id or record.get("id", "series"), ex
                    ),
                    xbmc.LOGWARNING,
                )
                up_next = None
            if up_next is not None:
                items.append(up_next)
                if limit is not None and len(items) >= limit:
                    break
            continue
        if position is None:
            continue
        title = (record.get("tv_title") if is_episode else "") or record.get("title") or record.get("stream_name") or "Media Hub"
        episode_code = ""
        if is_episode:
            season = _as_int(record.get("season"), 0)
            episode_code = "S{0:02d} E{1:02d}".format(season, _episode_number(record))
        episode_title = _clean_query_value(record.get("episode_title")) if is_episode else ""
        if episode_title:
            episode_title = re.sub(
                r"^S\d{1,2}\s*E\d{1,3}\s*[-–—:·]\s*",
                "",
                episode_title,
                flags=re.IGNORECASE,
            )
        duration = _as_float(record.get("duration_seconds"), 0.0) or 0.0
        remaining = (
            tr("{0} min left", max(1, int(math.ceil((duration - position) / 60))))
            if duration > position else tr("Resume at {0}", _format_playback_time(position))
        )
        card_meta = " · ".join((episode_code or tr("Movie"), remaining))
        meta = " · ".join(str(value) for value in (
            episode_code, episode_title if is_episode else record.get("year"),
        ) if value)
        query = _history_play_query(record)
        query["action"] = "resume_history_stream"
        query.update({"resume_mode": "resume", "resume_seconds": str(position)})
        beginning = dict(query, resume_mode="beginning")
        beginning.pop("resume_seconds", None)
        fanart = _media_art_url(record.get("fanart")) or _media_art_url(record.get("poster")) or fallback_art
        model = _home_model(
            title, card_meta, "play", build_url(query), fallback_art,
            tr("Continue watching series" if is_episode else "Continue watching movie"),
            title, meta, record.get("plot") or tr("Continue from your saved position"),
            _media_art_url(record.get("poster")), fanart, fanart,
        )
        model["properties"].update({
            **_home_presentation(str(title).split(" / ", 1)[0], record.get("plot") or ""),
            "App.HomeMeta": meta,
            "App.HomeId": record.get("id") or _history_id(record),
            "App.HomeCardMeta": card_meta,
            "App.HomeHint": remaining,
            "App.Progress": str(progress) if progress is not None else "0",
            "App.ProgressTexture": _home_progress_texture(progress),
            "App.HasProgress": "true" if progress is not None else "false",
            "App.Kind": "tv" if is_episode else "movie",
            "MediaHub.Progress": str(progress) if progress is not None else "0",
        })
        _prepare_home_resume_metadata(model, record, meta)
        model["context_actions"] = [
            {"label": tr("Resume"), "command": "play", "target": build_url(query)},
            {"label": tr("Start from beginning"), "command": "play", "target": build_url(beginning)},
        ]
        if is_episode:
            model["context_actions"].extend(_modern_history_episode_actions(record))
        elif record.get("movie_id"):
            model["context_actions"].append({
                "label": tr("Choose version"), "command": "browse",
                "target": build_url(dict(_history_play_query(record), action="list_movie_versions")),
            })
        model["context_actions"].append({
            "label": tr("Remove from Continue Watching"), "command": "action",
            "target": build_url({"action": "hide_continue_watching", "id": record.get("id") or _history_id(record)}),
        })
        items.append(model)
        if limit is not None and len(items) >= limit:
            break
    return items


def _modern_home_favorite_items(fallback_art, limit=10):
    collections = _media_lists_snapshot()
    records = sorted(
        (
            record
            for record in collections.get("favorites", {}).values()
            if isinstance(record, dict)
        ),
        key=lambda record: record.get("added_at") or "",
        reverse=True
    )
    kind_labels = {
        "movie": "Film",
        "tv_show": "Seriál",
        "season": "Séria",
        "episode": "Epizóda",
        "stream": "Stream"
    }
    items = []
    for record in records:
        query = _collection_open_query(record)
        if not query:
            continue
        art = _collection_art(record)
        title = _collection_label(record)
        kind = record.get("kind")
        media_kind = "tv" if kind in ("tv_show", "season", "episode") else "movie"
        card_title = _clean_query_value(record.get("title") or record.get("stream_name"))
        card_title = card_title.split(" / ", 1)[0]
        year = _clean_query_value(record.get("year"))
        if year == "----":
            year = ""
        duration = _clean_query_value(record.get("duration"))
        if kind == "tv_show":
            duration = _catalog_season_label(record)
        elif kind == "season":
            duration = _catalog_episode_count_label(record.get("episode_count"))
        genres = _clean_query_value(record.get("genres"))
        command = (
            "detail"
            if record.get("kind") in ("movie", "tv_show")
            else "play"
            if record.get("kind") == "stream"
            else "browse"
        )
        model = _home_model(
            title,
            kind_labels.get(record.get("kind"), "Médiá"),
            command,
            build_url(query),
            fallback_art,
            "OBĽÚBENÉ",
            record.get("title") or record.get("stream_name") or title,
            kind_labels.get(record.get("kind"), "Médiá"),
            record.get("plot") or _collection_plot(record),
            art.get("poster") or art.get("thumb") or "",
            art.get("fanart") or "",
            art.get("fanart") or art.get("thumb") or ""
        )
        model["properties"].update({
            "App.Kind": media_kind,
            "App.KindLabel": kind_labels.get(record.get("kind"), "Media"),
            "App.CardTitle": card_title,
            "App.CardContext": card_title,
            "App.CardStatus": "",
            "App.CardProgressTexture": "",
            "App.Year": year,
            "App.Rating": _clean_query_value(record.get("rating")),
            "App.Duration": duration,
            "App.Genres": genres,
            "App.CardGenres": _poster_card_genres(genres),
            "App.CardMeta": _poster_card_meta(year, duration),
        })
        if kind in ("movie", "tv_show", "season"):
            media_id = record.get("movie_id" if kind == "movie" else "tv_id")
            if media_id:
                model["catalog_source"] = {"id": media_id}
                model["catalog_type"] = media_kind
                model["favorite_record"] = dict(record)
                identity = _clean_query_value(media_id)
                if kind == "season":
                    identity += ":" + _clean_query_value(record.get("season"))
                model["properties"]["App.Id"] = identity
        items.append(model)
        if limit is not None and len(items) >= limit:
            break
    return items


def _enrich_favorite_card_model(model, genre_names=None):
    """Recover card facts for older favourites without changing their action."""
    kind = model.get("catalog_type")
    source = model.get("catalog_source") or {}
    media_id = source.get("id")
    if kind not in ("movie", "tv") or not media_id:
        return dict(model, catalog_enriched=True)

    record = model.get("favorite_record") or {}
    if record.get("kind") == "season":
        details = api.get_tv_details(media_id) or {}
        season_number = _as_int(record.get("season"), -1)
        season = next((item for item in details.get("seasons") or []
                       if isinstance(item, dict)
                       and _as_int(item.get("season_number"), -2) == season_number), {})
        updated = dict(model, properties=dict(model.get("properties") or {}), catalog_enriched=True)
        properties = updated["properties"]
        year = _extract_year(season)
        if year == "----":
            year = properties.get("App.Year", "")
        count = _catalog_episode_count_label(season.get("episode_count")) or properties.get("App.Duration", "")
        rating = _as_float(season.get("vote_average"), 0.0) or _as_float(record.get("rating"), 0.0)
        genres = _modern_genre_label(details, genre_names) or properties.get("App.Genres", "")
        properties.update({
            "App.Year": year,
            "App.Duration": count,
            "App.Rating": f"{rating:.1f}" if rating else "",
            "App.Genres": genres,
            "App.CardGenres": _poster_card_genres(genres),
            "App.CardMeta": _poster_card_meta(year, count),
        })
        overview = _clean_query_value(season.get("overview"))
        if overview:
            properties["MediaHub.Description"] = overview
            properties["MediaHub.HeroDescription"] = _hero_excerpt(overview)
            properties["App.HomeSummary"] = _hero_excerpt(overview, limit=140)
        return updated

    try:
        details = api.get_catalog_metadata(kind, media_id) or {}
    except api.ApiError as exc:
        if exc.status_code not in (404, 405):
            raise
        details = {}
    if not details.get("vote_average") or not _modern_genre_label(details, genre_names):
        summary = api.get_catalog_summary(
            kind, media_id, model.get("properties", {}).get("App.CardTitle", "")
        ) or {}
        details = dict(summary, **{
            key: value for key, value in details.items()
            if value not in (None, "", [])
        })
    if kind == "tv" and not details.get("number_of_seasons"):
        try:
            full_details = api.get_tv_details(media_id) or {}
            details = dict(full_details, **{
                key: value for key, value in details.items()
                if value not in (None, "", [])
            })
        except Exception as exc:
            xbmc.log("[catalog] Optional favourite TV facts unavailable: {0}".format(exc), xbmc.LOGWARNING)

    updated = dict(model, properties=dict(model.get("properties") or {}), catalog_enriched=True)
    properties = updated["properties"]
    title = properties.get("App.CardTitle", "")
    source_title = details.get("title" if kind == "movie" else "name") or title
    card = _catalog_card_presentation(details, kind, source_title)
    properties.update(card)
    year = (_movie_release_year(details) if kind == "movie" else _get_tv_year(details))
    if not year or year == "----":
        year = properties.get("App.Year", "")
    duration = (
        _movie_duration_label(details) if kind == "movie"
        else _catalog_season_label(details)
    ) or properties.get("App.Duration", "")
    rating = _as_float(details.get("vote_average"), 0.0) or _as_float(record.get("rating"), 0.0)
    genres = _modern_genre_label(details, genre_names) or properties.get("App.Genres", "")
    properties.update({
        "App.Year": year,
        "App.Duration": duration,
        "App.Rating": f"{rating:.1f}" if rating else "",
        "App.Genres": genres,
        "App.KindLabel": genres or properties.get("App.KindLabel", ""),
        "App.CardGenres": _poster_card_genres(genres),
        "App.CardMeta": _poster_card_meta(year, duration),
    })
    if kind == "movie":
        properties.update(_movie_credits_properties(details))
    overview = _clean_query_value(details.get("overview"))
    if overview:
        properties["MediaHub.Description"] = overview
        properties["MediaHub.HeroDescription"] = _hero_excerpt(overview)
        properties["App.HomeSummary"] = _hero_excerpt(overview, limit=140)
    try:
        properties.update(_catalog_watch_properties(dict(details, id=media_id), kind, watch_history_db.list()))
    except Exception as exc:
        xbmc.log("[catalog] Optional favourite viewing state unavailable: {0}".format(exc), xbmc.LOGWARNING)
    return updated

DOWNLOAD_MEDIA_KEYS = (
    "media_type",
    "movie_id",
    "tv_id",
    "season",
    "episode_id",
    "episode_number",
    "title",
    "tv_title",
    "episode_title",
    "year",
    "poster",
    "fanart",
    "plot",
    "genres",
    "duration",
    "rating",
)


def _download_media_metadata(params=None):
    if not isinstance(params, dict):
        return {}

    metadata = {}
    for key in DOWNLOAD_MEDIA_KEYS:
        value = params.get(key)
        if value not in (None, ""):
            metadata[key] = value

    if metadata.get("media_type") not in ("movie", "episode"):
        metadata["media_type"] = (
            "episode"
            if metadata.get("episode_id") not in (None, "")
            else "movie"
        )
    if metadata.get("poster"):
        metadata["poster"] = _media_art_url(metadata["poster"])
    if metadata.get("fanart"):
        metadata["fanart"] = _media_art_url(metadata["fanart"])
    return metadata


def _download_display_title(record):
    if record.get("media_type") == "episode":
        tv_title = _clean_query_value(record.get("tv_title"))
        episode_title = _clean_query_value(record.get("episode_title"))
        if tv_title and episode_title:
            return "{0} — {1}".format(tv_title, episode_title)
    return (
        _clean_query_value(record.get("title"))
        or _clean_query_value(record.get("episode_title"))
        or _clean_query_value(record.get("filename"))
        or tr("Download")
    )


def _download_media_meta(record):
    rating = _as_float(record.get("rating"), 0.0)
    return "  •  ".join(
        value for value in (
            _clean_query_value(record.get("year")),
            _clean_query_value(record.get("duration")),
            _clean_query_value(record.get("genres")),
            "★ {0:.1f}".format(rating) if rating else "",
        ) if value
    )


def _download_art(record, fallback_art=""):
    poster = _media_art_url(record.get("poster"))
    fanart = _media_art_url(record.get("fanart")) or poster or fallback_art
    return {
        "thumb": poster or fanart or fallback_art,
        "poster": poster or fanart or fallback_art,
        "fanart": fanart,
    }


def _modern_home_download_items(fallback_art, limit=6):
    try:
        snapshot = _list_downloads_normalized()
    except Exception as ex:
        xbmc.log(f"[modern_home] Could not read downloads: {ex}", xbmc.LOGWARNING)
        snapshot = {}

    records = [
        record for record in snapshot.values()
        if isinstance(record, dict) and record.get("status") != "waiting_preparation"
    ]
    active = sorted(
        (record for record in records if record.get("status") in ACTIVE_DOWNLOAD_STATUSES),
        key=lambda record: (
            _queue_position(record),
            record.get("updated_at") or record.get("created_at") or "",
        ),
    )
    queued = sorted(
        (record for record in records if record.get("status") in QUEUE_STATUSES),
        key=lambda record: (
            _queue_position(record),
            record.get("created_at") or "",
        ),
    )
    history = sorted(
        (
            record for record in records
            if record.get("status") not in ACTIVE_DOWNLOAD_STATUSES + QUEUE_STATUSES
        ),
        key=lambda record: record.get("updated_at") or record.get("created_at") or "",
        reverse=True,
    )
    records = active + queued + history
    status_labels = {
        "queued": "Vo fronte",
        "paused": "Pozastavené",
        "waiting_retry": "Čaká na opakovanie",
        "downloading": "Sťahuje sa",
        "pausing": "Pozastavuje sa",
        "canceling": "Ruší sa",
        "repairing": "Opravuje sa",
        "finalizing": "Dokončuje sa",
        "complete": tr("Complete"),
        "failed": tr("Failed"),
        "canceled": tr("Canceled"),
    }
    items = []
    visible_records = records if limit is None else records[:limit]
    for record in visible_records:
        status = record.get("status", "")
        progress = _as_int(record.get("progress"), 0)
        status_label = status_labels.get(status, status)
        transfer_meta = f"{status_label}  •  {progress}%"
        filename = _clean_query_value(record.get("filename"))
        media_meta = _download_media_meta(record)
        meta = "  •  ".join(
            value for value in (filename, media_meta, transfer_meta) if value
        )
        downloaded = _format_bytes(record.get("bytes_done"))
        total = _format_bytes(record.get("bytes_total"))
        transfer_description = f"Stiahnuté: {downloaded} / {total}"
        plot = _clean_query_value(record.get("plot"))
        description = (
            "{0}\n\n{1}".format(plot, transfer_description)
            if plot else transfer_description
        )
        art = _download_art(record, fallback_art)
        title = _download_display_title(record)
        playable = status == "complete" and bool(
            record.get("path") and xbmcvfs.exists(record.get("path"))
        )
        model = _home_model(
            title,
            meta,
            "play" if playable else "action",
            record.get("path", "") if playable else "",
            fallback_art,
            "OFFLINE LIBRARY",
            title,
            meta,
            description,
            art["poster"],
            art["fanart"],
            art["thumb"],
        )
        context_actions = []
        if playable:
            context_actions.append({
                "label": tr("Play Download"),
                "label2": tr("Open the completed local file"),
                "command": "play",
                "target": record.get("path", ""),
                "properties": {"App.Badge": "PLAY"},
            })
        for action_label, query in _download_action_queries(
            record, _queue_count(snapshot)
        ):
            context_actions.append({
                "label": action_label,
                "label2": tr("Manage this offline item"),
                "command": "action",
                "target": build_url(query),
                "properties": {"App.Badge": "ACTION"},
            })
        model["context_actions"] = context_actions
        model["properties"].update({
            "MediaHub.Progress": str(progress),
            "App.ProgressTexture": _home_progress_texture(progress),
            "App.HasProgress": "true" if progress > 0 else "false",
            "App.Status": status,
            "App.FileName": _clean_query_value(record.get("filename")),
            "App.Kind": record.get("media_type") or "movie",
            "App.KindLabel": "Episode" if record.get("media_type") == "episode" else "Movie",
            "App.Year": _clean_query_value(record.get("year")),
            "App.Rating": _clean_query_value(record.get("rating")),
            "App.Hint": (
                tr("OK  •  Play    MENU  •  Actions")
                if playable else tr("MENU  •  Actions")
            ),
        })
        items.append(model)
    return items


def _modern_preparation_items(fallback_art, limit=None, statuses=None):
    records = list(preparations_db.list().values())
    if statuses is not None:
        records = [
            record for record in records
            if record.get("status") in statuses
        ]
    records.sort(key=lambda record: (record.get("status") not in ("preparing", "queued", "stalled"), record.get("updated_at", "")))
    items = []
    labels = {
        "queued": tr("Queued"),
        "preparing": tr("Preparing"),
        "stalled": tr("Stalled"),
        "ready": tr("Ready"),
        "failed": tr("Unavailable"),
        "canceled": tr("Canceled"),
    }
    for record in records[:limit] if limit is not None else records:
        status = record.get("status", "queued")
        progress = _as_int(record.get("progress"), 0)
        title = _clean_query_value(record.get("title") or record.get("filename") or "TorBox stream")
        filename = _clean_query_value(record.get("filename"))
        state = labels.get(status, status.replace("_", " ").title())
        eta = _format_preparation_eta(record.get("eta_seconds"))
        meta = "  •  ".join(value for value in (filename, "TorBox", state, f"{progress}%" if status in ("preparing", "stalled") else "", eta) if value)
        description = _clean_query_value(record.get("message")) or tr("Provider-side preparation before playback or offline download.")
        model = _modern_browser_model(
            title, meta, "browse",
            build_url({"action": "show_preparation_actions", "id": record.get("id", "")}),
            fallback_art, description,
            _media_art_url(record.get("poster")) or fallback_art,
            _media_art_url(record.get("fanart")) or fallback_art,
            badge="TORBOX",
        )
        model["properties"].update({
            "MediaHub.Progress": str(progress),
            "App.Status": status,
            "App.Kind": "preparation",
            "App.PreparationId": record.get("id", ""),
        })
        items.append(model)
    return items


def _format_preparation_eta(seconds):
    try:
        seconds = int(seconds or 0)
    except (TypeError, ValueError):
        return ""
    return "~" + _stream_eta_label({"etaSeconds": seconds}) if seconds > 0 else ""


def _modern_settings_items(fallback_art):
    entries = (
        (
            "Account & API",
            "Connection, credentials and service access",
            "Manage the backend address and API authentication."
        ),
        (
            "Playback",
            "Quality, subtitles and language",
            "Review preferred playback behaviour and subtitle options."
        ),
        (
            "Downloads",
            "Storage, queue and offline files",
            "Choose download storage and background transfer behaviour."
        ),
        (
            "TV filtering",
            "Animation and catalogue preferences",
            "Control which series are included in discovery screens."
        ),
        (
            "Interface",
            "Modern home and compatibility options",
            "Switch between the app shell and Kodi's classic directory interface."
        ),
        (
            "About",
            "Media Hub  •  Kodi addon",
            "Version, privacy and addon information."
        ),
    )
    models = [
        _home_model(
            tr(label),
            tr(label2),
            "browse",
            build_url({"action": "modern_settings", "section": section}),
            fallback_art,
            "SETTINGS",
            tr(label),
            tr(label2),
            tr(description),
        )
        for section, (label, label2, description) in zip(
            ("account", "playback", "downloads", "tv", "interface", "about"),
            entries,
        )
    ]
    return models


def _modern_genre_name_map(response):
    if isinstance(response, dict):
        entries = response.get("genres") or response.get("results") or []
    elif isinstance(response, (list, tuple)):
        entries = response
    else:
        entries = []

    names = {}
    for genre in entries:
        if not isinstance(genre, dict):
            continue
        genre_id = _as_int(genre.get("id", genre.get("Id")), 0)
        name = _clean_query_value(genre.get("name", genre.get("Name")))
        if genre_id > 0 and name:
            names[genre_id] = name
    return names


def _modern_genre_label(media, genre_names):
    names = []
    seen = set()

    for genre in media.get("genres") or []:
        if not isinstance(genre, dict):
            continue
        name = _clean_query_value(genre.get("name", genre.get("Name")))
        key = name.casefold()
        if name and key not in seen:
            names.append(name)
            seen.add(key)

    for genre_id in media.get("genre_ids") or []:
        normalized_id = _as_int(genre_id, 0)
        name = _clean_query_value((genre_names or {}).get(normalized_id))
        key = name.casefold()
        if name and key not in seen:
            names.append(name)
            seen.add(key)

    return ", ".join(names)


def _modern_movie_catalog_models(
    response,
    fallback_art,
    eyebrow="MOVIE",
    genre_names=None,
):
    results = response.get("results", []) if isinstance(response, dict) else []
    models = []
    for movie in results:
        if not isinstance(movie, dict):
            continue
        title = _movie_display_title(movie) or "Movie"
        year = _movie_release_year(movie)
        rating = _as_float(movie.get("vote_average"), 0.0)
        duration = _movie_duration_label(movie)
        genre_label = _modern_genre_label(movie, genre_names)
        meta = "  •  ".join(
            value for value in (
                year,
                duration,
                genre_label,
                f"★ {rating:.1f}" if rating else "",
            ) if value
        )
        poster = _poster_art_url(movie.get("poster_path"))
        fanart = movie.get("backdrop_path", "") or poster
        model = _home_model(
            title,
            meta,
            "detail",
            _build_movie_versions_url(movie, genre_names),
            fallback_art,
            eyebrow,
            title,
            meta,
            movie.get("overview", ""),
            poster,
            fanart,
            fanart,
        )
        model["properties"].update({
            "App.Kind": "movie",
            **_movie_credits_properties(movie),
            **_catalog_card_presentation(movie, "movie", title),
            "App.KindLabel": genre_label,
            "App.Genres": genre_label,
            "App.Id": _clean_query_value(movie.get("id")),
            "App.HomeId": "movie:" + _clean_query_value(movie.get("id")),
            **_home_presentation(movie.get("title") or title.split(" / ", 1)[0], movie.get("overview", "")),
            "App.HomeMeta": "  •  ".join(value for value in (
                year,
                duration,
                f"★ {rating:.1f}" if rating else "",
                genre_label,
            ) if value),
            "App.HomeCardMeta": _poster_card_meta(year, duration),
            "App.HomeHint": "",
            "App.Year": year,
            "App.Rating": f"{rating:.1f}" if rating else "",
            "App.Duration": duration,
            "App.CardGenres": _poster_card_genres(genre_label),
            "App.CardMeta": _poster_card_meta(year, duration),
        })
        model["catalog_source"] = dict(movie)
        model["catalog_type"] = "movie"
        model["catalog_eyebrow"] = eyebrow
        models.append(model)
    return models


def _modern_tv_catalog_models(
    response,
    fallback_art,
    eyebrow="TV SERIES",
    genre_names=None,
):
    results = response.get("results", []) if isinstance(response, dict) else []
    results = _filter_tv_shows(results)
    models = []
    for show in results:
        if not isinstance(show, dict):
            continue
        title = show.get("name_with_original_name") or show.get("name") or "TV Series"
        year = _get_tv_year(show)
        rating = _as_float(show.get("vote_average"), 0.0)
        genre_label = _modern_genre_label(show, genre_names)
        meta = "  •  ".join(
            value for value in (
                year if year != "----" else "",
                genre_label,
                f"★ {rating:.1f}" if rating else "",
            ) if value
        )
        poster = _poster_art_url(show.get("poster_path"))
        fanart = _media_art_url(show.get("backdrop_path")) or poster
        model = _home_model(
            title,
            meta,
            "detail",
            build_url({"action": "list_seasons", "tv_id": show.get("id", "")}),
            fallback_art,
            eyebrow,
            title,
            meta,
            show.get("overview", ""),
            poster,
            fanart,
            fanart,
        )
        model["properties"].update({
            "App.Kind": "tv",
            **_catalog_card_presentation(show, "tv", title),
            "App.KindLabel": genre_label,
            "App.Genres": genre_label,
            "App.Id": _clean_query_value(show.get("id")),
            "App.HomeId": "tv:" + _clean_query_value(show.get("id")),
            **_home_presentation(show.get("name") or title.split(" / ", 1)[0], show.get("overview", "")),
            "App.HomeMeta": "  •  ".join(value for value in (
                year if year != "----" else "",
                f"★ {rating:.1f}" if rating else "",
                genre_label,
            ) if value),
            "App.HomeCardMeta": year,
            "App.HomeHint": "",
            "App.Year": year if year != "----" else "",
            "App.Rating": f"{rating:.1f}" if rating else "",
            "App.CardGenres": _poster_card_genres(genre_label),
            "App.CardMeta": _poster_card_meta(
                year if year != "----" else "",
                _catalog_season_label(show),
            ),
        })
        model["catalog_source"] = dict(show)
        model["catalog_type"] = "tv"
        model["catalog_eyebrow"] = eyebrow
        models.append(model)
    return models


def _load_modern_catalog(
    page,
    tab,
    fallback_art,
    movie_genre_names=None,
    tv_genre_names=None,
    page_number=1,
):
    if page == "movies":
        if tab == "latest":
            response = api.get_movies_latest(page_number)
            eyebrow = "NEW RELEASE"
        elif tab == "top":
            response = api.get_movies_toprated(page_number)
            eyebrow = "TOP RATED"
        else:
            response = api.get_movies_popular(page_number)
            eyebrow = "POPULAR MOVIE"
        return _modern_movie_catalog_models(
            response,
            fallback_art,
            eyebrow,
            movie_genre_names,
        )

    if page == "tv":
        if tab == "latest":
            response = api.get_tv_latest(page_number)
            eyebrow = "NEW SERIES"
        elif tab == "recent":
            response = api.get_tv_recently_aired(page_number, 30)
            eyebrow = "RECENTLY AIRED"
        elif tab == "slovak":
            response = api.get_tv_sk(page_number)
            eyebrow = "SLOVAK TV"
        else:
            response = api.get_tv_popular(page_number)
            eyebrow = "POPULAR SERIES"
        return _modern_tv_catalog_models(
            response,
            fallback_art,
            eyebrow,
            tv_genre_names,
        )
    return []


def _load_modern_search(
    query,
    fallback_art,
    movie_genre_names=None,
    tv_genre_names=None,
):
    responses = {}
    errors = []
    with ThreadPoolExecutor(max_workers=2) as executor:
        futures = {
            "movie": executor.submit(api.get_movies_search, query, 1),
            "tv": executor.submit(api.get_tv_search, query, 1),
        }
        for media_type, future in futures.items():
            try:
                responses[media_type] = future.result()
            except Exception as ex:
                errors.append(ex)
                xbmc.log(
                    "[modern_home] Could not search {0}: {1}".format(
                        media_type,
                        ex,
                    ),
                    xbmc.LOGWARNING,
                )

    if len(errors) == len(futures):
        raise errors[0]

    movies = _modern_movie_catalog_models(
        responses.get("movie", {}),
        fallback_art,
        "SEARCH • MOVIE",
        movie_genre_names,
    )
    shows = _modern_tv_catalog_models(
        responses.get("tv", {}),
        fallback_art,
        "SEARCH • TV",
        tv_genre_names,
    )
    return movies + shows


def _modern_target_params(target):
    parsed = urllib.parse.urlparse(str(target or ""))
    return dict(urllib.parse.parse_qsl(parsed.query))


def _discovery_filter_view_ready(target, genre_cache):
    params = _modern_target_params(target)
    if params.get("action") != "show_discovery_filters":
        return False
    section = params.get("section", "genre")
    if section != "genre" and section in DISCOVERY_SECTIONS:
        return True
    media_type = "tv" if params.get("media_type") == "tv" else "movie"
    return genre_cache.get(media_type) is not None


def _modern_browser_model(
    label, label2, command, target, fallback_art, description="",
    poster="", fanart="", badge="", hint="OK  •  Open", context_target=""
):
    model = _home_model(
        label, label2, command, target, fallback_art, "MEDIA HUB", label,
        label2, description, poster, fanart, poster or fanart
    )
    model["properties"].update({
        "App.Badge": badge,
        "App.Hint": hint,
        "App.ContextTarget": context_target,
    })
    return model


def _modern_browser_view(
    title, subtitle, items, fallback_art, eyebrow="MEDIA HUB",
    empty="Nothing to show yet.", fanart="", tabs=None, actions=None
):
    view = {
        "title": tr(title),
        "subtitle": tr(subtitle),
        "eyebrow": tr(eyebrow),
        "empty": tr(empty),
        "fanart": fanart or fallback_art,
        "items": items,
    }
    if tabs is not None:
        view["tabs"] = tabs
    if actions is not None:
        view["actions"] = actions
    return view


def _modern_next_page_model(params, total_pages, fallback_art):
    page = max(1, _as_int(params.get("page"), 1))
    total_pages = max(1, _as_int(total_pages, 1))
    if page >= total_pages:
        return None
    next_params = dict(params)
    next_params["page"] = page + 1
    return _modern_browser_model(
        "Next Page", tr("Page {0} of {1}", page + 1, total_pages),
        "browse", build_url(next_params), fallback_art,
        "Continue through the catalogue inside Media Hub.",
        badge="PAGE {0}".format(page + 1), hint="OK  •  Load more"
    )


def _modern_prompt_search(title):
    keyboard = xbmc.Keyboard("", tr(title))
    keyboard.doModal()
    return (
        _clean_query_value(keyboard.getText())
        if keyboard.isConfirmed() else ""
    )


def _modern_root_browser(params, fallback_art):
    action = params.get("action")
    if action == "menu_item_search":
        entries = (
            ("Search Movies", "Search the film catalogue", "menu_item_movies_search"),
            ("Search TV Series", "Search every available series", "menu_item_tvshows_search"),
        )
        title, subtitle, eyebrow, media_type = "Search", "Choose a catalogue", "SEARCH", "movie"
    elif action == "menu_item_tvshows":
        entries = (
            ("Popular", "Trending TV series", "list_tv_shows_popular"),
            ("New Releases", "Recently added series", "list_tv_shows_latest"),
            ("Recently Aired", "New seasons and episodes", "list_tv_shows_recently_aired"),
            ("Slovak", "Slovak TV catalogue", "list_tv_shows_sk"),
            ("Discover", "Mix genres, eras and ratings", "show_discovery_filters"),
            ("Search", "Find a TV series", "menu_item_tvshows_search"),
        )
        title, subtitle, eyebrow, media_type = "TV Series", "Browse every collection", "TV SERIES", "tv"
    else:
        entries = (
            ("Popular", "The most watched films", "menu_item_movies_popular"),
            ("New Releases", "Recently added movies", "menu_item_movies_latest"),
            ("Top Rated", "The highest-rated films", "menu_item_movies_toprated"),
            ("Search", "Find a movie", "menu_item_movies_search"),
            ("Discover", "Mix genres, eras and ratings", "show_discovery_filters"),
        )
        title, subtitle, eyebrow, media_type = "Movies", "Browse every collection", "MOVIES", "movie"
    items = []
    for label, label2, target_action in entries:
        query = {"action": target_action}
        if target_action == "show_discovery_filters":
            query["media_type"] = media_type
        items.append(_modern_browser_model(
            label, label2, "browse", build_url(query), fallback_art,
            "Open {0} in the modern Media Hub browser.".format(label.lower()),
            badge="OPEN"
        ))
    return _modern_browser_view(title, subtitle, items, fallback_art, eyebrow)


def _modern_catalog_browser(params, fallback_art, genre_names):
    action = params.get("action", "")
    page = max(1, _as_int(params.get("page"), 1))
    media_type = "tv" if action.startswith("list_tv") or "tvshows" in action else "movie"
    query = params.get("search_query", "")
    if action in ("menu_item_movies_search", "menu_item_tvshows_search") and not query:
        query = _modern_prompt_search(
            "Search TV series" if media_type == "tv" else "Search movies"
        )
        if not query:
            return _modern_browser_view(
                "Search", "Search was cancelled", [], fallback_art, "SEARCH",
                "Use the search button in the side rail to try again."
            )
        params = dict(params)
        params.update({"search_query": query, "page": page})

    if action == "menu_item_movies_latest":
        response, title, eyebrow = api.get_movies_latest(page), "New Movies", "NEW RELEASES"
    elif action == "menu_item_movies_toprated":
        response, title, eyebrow = api.get_movies_toprated(page), "Top Rated Movies", "TOP RATED"
    elif action == "menu_item_movies_search":
        response, title, eyebrow = api.get_movies_search(query, page), "Movie Search", "SEARCH"
    elif action == "list_tv_shows_latest":
        response, title, eyebrow = api.get_tv_latest(page), "New TV Series", "NEW SERIES"
    elif action == "list_tv_shows_recently_aired":
        response = api.get_tv_recently_aired(page, max(1, _as_int(params.get("days"), 30)))
        title, eyebrow = "Recently Aired", "NEW EPISODES"
    elif action == "list_tv_shows_sk":
        response, title, eyebrow = api.get_tv_sk(page), "Slovak TV Series", "SLOVAK TV"
    elif action == "menu_item_tvshows_search":
        response, title, eyebrow = api.get_tv_search(query, page), "TV Search", "SEARCH"
    elif action == "list_tv_shows_popular":
        response, title, eyebrow = api.get_tv_popular(page), "Popular TV Series", "POPULAR"
    else:
        response, title, eyebrow = api.get_movies_popular(page), "Popular Movies", "POPULAR"
    models = (
        _modern_tv_catalog_models(response, fallback_art, eyebrow, genre_names("tv"))
        if media_type == "tv"
        else _modern_movie_catalog_models(response, fallback_art, eyebrow, genre_names("movie"))
    )
    total_pages = response.get("total_pages", 1) if isinstance(response, dict) else 1
    next_model = _modern_next_page_model(params, total_pages, fallback_art)
    if next_model:
        models.append(next_model)
    subtitle = tr("Page {0} of {1}", page, max(1, _as_int(total_pages, 1)))
    if query:
        subtitle = "{0}  •  {1}".format(tr("Results for “{0}”", query), subtitle)
    return _modern_browser_view(
        title, subtitle, models, fallback_art, eyebrow,
        "No matching titles were found."
    )


def _modern_discovery_model(
    label,
    label2,
    command,
    target,
    fallback_art,
    *,
    selected=False,
    primary=False,
    key="",
    description="",
):
    model = _modern_browser_model(
        label,
        label2,
        command,
        target,
        fallback_art,
        description,
        badge="SELECTED" if selected else "",
        hint="OK  •  Select",
    )
    model["properties"].update({
        "App.Selected": "true" if selected else "false",
        "App.Primary": "true" if primary else "false",
        "App.FilterKey": key,
    })
    return model


def _discovery_option_target(media_type, state, section):
    return build_url(_discovery_query(
        "show_discovery_filters",
        media_type,
        state,
        section=section,
    ))


def _modern_discovery_genre_options(
    media_type,
    state,
    section,
    fallback_art,
    genre_name_map,
):
    selected_ids = _discovery_genre_ids(state)
    options = [
        _modern_discovery_model(
            "All genres",
            "",
            "browser_replace",
            _discovery_option_target(
                media_type,
                _discovery_state_with(
                    state,
                    genre_ids=None,
                    genre_names=None,
                ),
                section,
            ),
            fallback_art,
            selected=not selected_ids,
            key="all",
        )
    ]
    for genre_id, name in sorted(
        (genre_name_map or {}).items(),
        key=lambda item: _clean_query_value(item[1]).casefold(),
    ):
        genre_id = _as_int(genre_id, 0)
        name = _clean_query_value(name)
        if genre_id <= 0 or not name:
            continue
        toggled = list(selected_ids)
        if genre_id in toggled:
            toggled.remove(genre_id)
        else:
            toggled.append(genre_id)
        toggled_names = [
            _clean_query_value((genre_name_map or {}).get(value))
            for value in toggled
            if _clean_query_value((genre_name_map or {}).get(value))
        ]
        updated = _discovery_state_with(
            state,
            genre_ids=",".join(str(value) for value in toggled) or None,
            genre_names="|".join(toggled_names) or None,
        )
        options.append(_modern_discovery_model(
            name,
            "",
            "browser_replace",
            _discovery_option_target(media_type, updated, section),
            fallback_art,
            selected=genre_id in selected_ids,
            key=str(genre_id),
        ))
    return options


def _modern_discovery_period_options(
    media_type,
    state,
    section,
    fallback_art,
):
    current_year = time.gmtime().tm_year
    presets = [
        ("Any time", None, None),
        ("This year", current_year, current_year),
        ("Last 3 years", current_year - 2, current_year),
        ("Last 5 years", current_year - 4, current_year),
        ("2020s", 2020, min(current_year + 1, 2029)),
        ("2010s", 2010, 2019),
        ("2000s", 2000, 2009),
        ("1990s", 1990, 1999),
        ("1980s", 1980, 1989),
    ]
    selected_from = _valid_discovery_year(state.get("year_from"))
    selected_to = _valid_discovery_year(state.get("year_to"))
    selected_exact = _valid_discovery_year(state.get("year"))
    options = []
    for label, year_from, year_to in presets:
        updated = _discovery_state_with(
            state,
            year=None,
            year_from=str(year_from) if year_from else None,
            year_to=str(year_to) if year_to else None,
        )
        selected = (
            not year_from and not year_to
            and not selected_from and not selected_to and not selected_exact
        ) or (
            year_from == selected_from and year_to == selected_to
        )
        value = (
            ""
            if year_from is None
            else str(year_from)
            if year_from == year_to
            else "{0}–{1}".format(year_from, year_to)
        )
        display_label = (
            "{0} ({1})".format(label, value)
            if value
            else label
        )
        options.append(_modern_discovery_model(
            display_label,
            "",
            "browser_replace",
            _discovery_option_target(media_type, updated, section),
            fallback_art,
            selected=selected,
            key=label,
        ))
    custom_selected = bool(
        (selected_from or selected_to or selected_exact)
        and not any(
            (
                selected_from == year_from
                and selected_to == year_to
            )
            for _label, year_from, year_to in presets
            if year_from is not None
        )
    )
    custom_label = "Custom range…"
    if custom_selected:
        custom_label = "Custom range… ({0})".format(
            _discovery_period_label(state)
        )
    options.append(_modern_discovery_model(
        custom_label,
        "",
        "action",
        build_url(_discovery_query(
            "configure_discovery_filter",
            media_type,
            state,
            filter="release_period",
            section=section,
        )),
        fallback_art,
        selected=custom_selected,
        key="custom",
    ))
    return options


def _modern_discovery_rating_options(
    media_type,
    state,
    section,
    fallback_art,
):
    current = _as_float(state.get("minimum_rating"))
    choices = [("", "Any rating")] + [
        ("{0:.1f}".format(value / 2), "{0:.1f}+".format(value / 2))
        for value in range(12, 19)
    ]
    return [
        _modern_discovery_model(
            label,
            "",
            "browser_replace",
            _discovery_option_target(
                media_type,
                _discovery_state_with(state, minimum_rating=value or None),
                section,
            ),
            fallback_art,
            selected=(
                current is None if not value
                else current == _as_float(value)
            ),
            key=value or "any",
        )
        for value, label in choices
    ]


def _modern_discovery_vote_options(
    media_type,
    state,
    section,
    fallback_art,
):
    current = max(0, _as_int(state.get("minimum_vote_count"), 0))
    choices = (
        (0, "Any count"),
        (25, "25+ ratings"),
        (100, "100+ ratings"),
        (250, "250+ ratings"),
        (500, "500+ ratings"),
        (1000, "1,000+ ratings"),
    )
    return [
        _modern_discovery_model(
            label,
            "",
            "browser_replace",
            _discovery_option_target(
                media_type,
                _discovery_state_with(
                    state,
                    minimum_vote_count=str(value),
                ),
                section,
            ),
            fallback_art,
            selected=current == value,
            key=str(value),
        )
        for value, label in choices
    ]


def _modern_discovery_runtime_options(
    media_type,
    state,
    section,
    fallback_art,
):
    current_minimum = _valid_discovery_runtime(
        state.get("minimum_runtime")
    )
    current_maximum = _valid_discovery_runtime(
        state.get("maximum_runtime")
    )
    choices = (
        (
            ("Any length", None, None),
            ("Up to 30 min", None, 30),
            ("30–60 min", 30, 60),
            ("Over 60 min", 61, None),
        )
        if media_type == "tv"
        else (
            ("Any length", None, None),
            ("Up to 90 min", None, 90),
            ("90–120 min", 90, 120),
            ("Over 2 hours", 121, None),
        )
    )
    return [
        _modern_discovery_model(
            label,
            "",
            "browser_replace",
            _discovery_option_target(
                media_type,
                _discovery_state_with(
                    state,
                    minimum_runtime=(
                        str(minimum) if minimum is not None else None
                    ),
                    maximum_runtime=(
                        str(maximum) if maximum is not None else None
                    ),
                ),
                section,
            ),
            fallback_art,
            selected=(
                current_minimum == (minimum or 0)
                and current_maximum == (maximum or 0)
            ),
            key=(
                "any"
                if minimum is None and maximum is None
                else "{0}-{1}".format(minimum or "", maximum or "")
            ),
        )
        for label, minimum, maximum in choices
    ]


def _modern_discovery_sort_models(
    media_type,
    state,
    section,
    fallback_art,
):
    current = state.get("sort", "popularity.desc")
    return [
        _modern_discovery_model(
            label,
            "",
            "browser_replace",
            _discovery_option_target(
                media_type,
                _discovery_state_with(state, sort=value),
                section,
            ),
            fallback_art,
            selected=current == value,
            key=value,
        )
        for value, label in _discovery_sort_options(media_type)
    ]


def _modern_discovery_chip_models(media_type, state, fallback_art):
    chips = []
    genre_names = _discovery_genre_names(state)
    genre_ids = _discovery_genre_ids(state)
    if genre_ids:
        visible_genre_names = genre_names[:3]
        if len(genre_names) > 3:
            visible_genre_names.append(
                tr("+{0} more", len(genre_names) - 3)
            )
        chips.append(
            (
                " · ".join(visible_genre_names)
                if visible_genre_names else _discovery_genre_label(state),
                "genres",
                "genre",
            )
        )

    if (
        _valid_discovery_year(state.get("year"))
        or _valid_discovery_year(state.get("year_from"))
        or _valid_discovery_year(state.get("year_to"))
    ):
        chips.append(
            (_discovery_period_label(state), "period", "release_period")
        )
    if state.get("minimum_rating"):
        chips.append(
            (
                "{0}+".format(state["minimum_rating"]),
                "rating",
                "minimum_rating",
            )
        )
    minimum_vote_count = max(
        0,
        _as_int(state.get("minimum_vote_count"), 0),
    )
    if minimum_vote_count:
        chips.append(
            (
                tr(
                    "{0}+ ratings",
                    "{0:,}".format(minimum_vote_count),
                ),
                "ratings-count",
                "minimum_vote_count",
            )
        )
    if (
        _valid_discovery_runtime(state.get("minimum_runtime"))
        or _valid_discovery_runtime(state.get("maximum_runtime"))
    ):
        chips.append(
            (
                _discovery_runtime_label(state),
                "runtime",
                "runtime",
            )
        )
    chips.append(
        (
            tr(_discovery_sort_label(state.get("sort"), media_type)),
            "sort",
            "sort",
        )
    )

    models = []
    chip_presentation = {
        "genres": ("Genres", "filter-genre.png"),
        "period": ("Release period", "filter-release-period.png"),
        "rating": ("Minimum rating", "filter-minimum-rating.png"),
        "ratings-count": ("Ratings count", "filter-vote-count.png"),
        "runtime": ("Runtime", "filter-runtime.png"),
        "sort": ("Sort by", "filter-sort-order.png"),
    }
    for label, key, section in chips:
        model = _modern_discovery_model(
            label,
            "",
            "edit_filters",
            _discovery_option_target(media_type, state, section),
            fallback_art,
            key=key,
        )
        category, icon = chip_presentation[key]
        compact_value = label
        if key == "genres" and genre_names:
            compact_value = genre_names[0]
            if len(genre_ids) > 1:
                compact_value += " +{0}".format(len(genre_ids) - 1)
        elif key == "ratings-count":
            compact_value = "{0:,}+".format(minimum_vote_count)
            if language() == SLOVAK:
                compact_value = compact_value.replace(",", " ")
        detail = " · ".join(genre_names) if key == "genres" else label
        model["properties"].update({
            "App.FilterCategory": tr(category),
            "App.FilterIcon": icon,
            "App.FilterValue": compact_value,
            "App.FilterDetail": "{0}: {1}".format(
                tr("Any of these genres") if key == "genres" and len(genre_ids) > 1
                else tr(category),
                detail or label,
            ),
        })
        if key == "genres" and len(genre_ids) > 1:
            model["properties"]["App.GenreOperator"] = "OR"
        models.append(model)
    return models


def _modern_filter_studio_view(
    params,
    media_type,
    state,
    fallback_art,
    genre_names,
):
    section = params.get("section", "genre")
    if section not in DISCOVERY_SECTIONS:
        section = "genre"
    vote_count = max(0, _as_int(state.get("minimum_vote_count"), 0))
    groups = (
        (
            "genre",
            "Genres",
            (
                _discovery_genre_label(state)
                if _discovery_genre_ids(state)
                else "All"
            ),
            bool(_discovery_genre_ids(state)),
            "filter-genre.png",
        ),
        (
            "release_period",
            "First aired" if media_type == "tv" else "Release period",
            (
                _discovery_period_label(state)
                if (
                    _valid_discovery_year(state.get("year"))
                    or _valid_discovery_year(state.get("year_from"))
                    or _valid_discovery_year(state.get("year_to"))
                )
                else "No limit"
            ),
            bool(
                _valid_discovery_year(state.get("year"))
                or _valid_discovery_year(state.get("year_from"))
                or _valid_discovery_year(state.get("year_to"))
            ),
            "filter-release-period.png",
        ),
        (
            "minimum_rating",
            "Minimum rating",
            (
                "{0}+".format(state["minimum_rating"])
                if state.get("minimum_rating")
                else "No minimum"
            ),
            bool(state.get("minimum_rating")),
            "filter-minimum-rating.png",
        ),
        (
            "minimum_vote_count",
            "Ratings count",
            "{0}+".format(vote_count) if vote_count else "No minimum",
            vote_count > 0,
            "filter-vote-count.png",
        ),
        (
            "runtime",
            "Episode length" if media_type == "tv" else "Runtime",
            _discovery_runtime_label(state),
            bool(
                _valid_discovery_runtime(state.get("minimum_runtime"))
                or _valid_discovery_runtime(state.get("maximum_runtime"))
            ),
            "filter-runtime.png",
        ),
        (
            "sort",
            "Order",
            _discovery_sort_label(state.get("sort"), media_type),
            state.get("sort", "popularity.desc") != "popularity.desc",
            "filter-sort-order.png",
        ),
    )
    section_copy = {
        "genre": (
            "Choose genres",
            "Choose one or more genres",
        ),
        "release_period": (
            "Choose the era",
            "Use a quick period or set your own range",
        ),
        "minimum_rating": (
            "Set the quality bar",
            "Choose the lowest TMDB user rating",
        ),
        "minimum_vote_count": (
            "Add rating confidence",
            "Avoid scores based on too few ratings",
        ),
        "runtime": (
            "Fit it into your evening",
            (
                "Choose an episode length"
                if media_type == "tv"
                else "Choose a movie length"
            ),
        ),
        "sort": (
            "Result order",
            "Choose what should rise to the top",
        ),
    }
    group_models = []
    for key, label, value, has_value, icon in groups:
        model = _modern_discovery_model(
            label,
            value,
            "browser_replace",
            _discovery_option_target(media_type, state, key),
            fallback_art,
            selected=section == key,
            key=key,
        )
        model["properties"]["App.HasValue"] = (
            "true" if has_value else "false"
        )
        model["properties"]["App.Icon"] = icon
        group_models.append(model)

    if section == "genre":
        options = _modern_discovery_genre_options(
            media_type,
            state,
            section,
            fallback_art,
            genre_names(media_type),
        )
    elif section == "release_period":
        options = _modern_discovery_period_options(
            media_type,
            state,
            section,
            fallback_art,
        )
    elif section == "minimum_rating":
        options = _modern_discovery_rating_options(
            media_type,
            state,
            section,
            fallback_art,
        )
    elif section == "minimum_vote_count":
        options = _modern_discovery_vote_options(
            media_type,
            state,
            section,
            fallback_art,
        )
    elif section == "runtime":
        options = _modern_discovery_runtime_options(
            media_type,
            state,
            section,
            fallback_art,
        )
    else:
        options = _modern_discovery_sort_models(
            media_type,
            state,
            section,
            fallback_art,
        )

    clear_state = _discovery_state({})
    actions = [
        _modern_discovery_model(
            "Clear all filters",
            "Remove every active filter",
            "browser_replace",
            _discovery_option_target(media_type, clear_state, "genre"),
            fallback_art,
            key="clear",
        ),
        _modern_discovery_model(
            "Show results",
            "Apply current filters",
            "apply_filters",
            build_url(_discovery_query(
                "list_discovery_results",
                media_type,
                state,
                page=1,
                section=section,
            )),
            fallback_art,
            primary=True,
            key="apply",
        ),
    ]
    view = _modern_browser_view(
        tr("Discover {0}", "TV Series" if media_type == "tv" else "Movies"),
        "Adjust your selection without leaving the content",
        [],
        fallback_art,
        "FILTERS",
    )
    view.update({
        "layout": "filter_studio",
        "media_type": media_type,
        "groups": group_models,
        "options": options,
        "actions": actions,
        "summary": _discovery_compact_summary(media_type, state),
        "active_count": _discovery_active_count(state),
        "section": section,
        "section_title": tr(section_copy[section][0]),
        "section_hint": tr(section_copy[section][1]),
    })
    return view


def _modern_filter_results_view(
    params,
    media_type,
    state,
    fallback_art,
    genre_names,
):
    page = max(1, _as_int(params.get("page"), 1))
    request_kwargs = {
        "page": page,
        "genre_ids": _discovery_genre_ids(state),
        "year": _as_int(state.get("year"), 0) or None,
        "year_from": _as_int(state.get("year_from"), 0) or None,
        "year_to": _as_int(state.get("year_to"), 0) or None,
        "sort": state.get("sort", "popularity.desc"),
        "minimum_rating": _as_float(state.get("minimum_rating")),
        "minimum_vote_count": max(
            0,
            _as_int(state.get("minimum_vote_count"), 0),
        ),
        "minimum_runtime": (
            _valid_discovery_runtime(state.get("minimum_runtime"))
            or None
        ),
        "maximum_runtime": (
            _valid_discovery_runtime(state.get("maximum_runtime"))
            or None
        ),
    }
    response = (
        api.discover_tv(**request_kwargs)
        if media_type == "tv"
        else api.discover_movies(**request_kwargs)
    )
    result_models = (
        _modern_tv_catalog_models(
            response,
            fallback_art,
            "DISCOVERY • TV",
            genre_names("tv"),
        )
        if media_type == "tv"
        else _modern_movie_catalog_models(
            response,
            fallback_art,
            "DISCOVERY • MOVIE",
            genre_names("movie"),
        )
    )
    total_pages = (
        response.get("total_pages", 1)
        if isinstance(response, dict)
        else 1
    )
    normalized_total_pages = max(1, _as_int(total_pages, 1))
    next_page_target = ""
    if page < normalized_total_pages:
        next_params = dict(params)
        next_params["page"] = page + 1
        next_page_target = build_url(next_params)

    filter_target = _discovery_option_target(
        media_type,
        state,
        params.get("section", "genre"),
    )
    actions = [
        _modern_discovery_model(
            "Edit filters",
            "Return to the current Filter Studio selections",
            "edit_filters",
            filter_target,
            fallback_art,
            primary=True,
            key="edit",
        )
    ]
    total_results = (
        max(0, _as_int(response.get("total_results"), 0))
        if isinstance(response, dict)
        else 0
    )
    formatted_count = "{0:,}".format(total_results)
    if language() == SLOVAK:
        formatted_count = formatted_count.replace(",", " ")
    title = tr("TV Series" if media_type == "tv" else "Movies")
    view = _modern_browser_view(
        title,
        tr("Results: {0}", formatted_count),
        result_models,
        fallback_art,
        "FILTERED RESULTS",
        "No titles match these filters.",
    )
    view.update({
        "layout": "filter_results",
        "media_type": media_type,
        "result_actions": actions,
        "pagination_actions": [],
        "next_page_target": next_page_target,
        "chips": _modern_discovery_chip_models(
            media_type,
            state,
            fallback_art,
        ),
        "summary": _discovery_compact_summary(media_type, state),
        "active_count": _discovery_active_count(state),
        "total_results": total_results,
    })
    return view


def _modern_discovery_browser(params, fallback_art, genre_names):
    media_type = "tv" if params.get("media_type") == "tv" else "movie"
    state = _discovery_state(params)
    if params.get("action") == "show_discovery_filters":
        return _modern_filter_studio_view(
            params,
            media_type,
            state,
            fallback_art,
            genre_names,
        )
    return _modern_filter_results_view(
        params,
        media_type,
        state,
        fallback_art,
        genre_names,
    )


def _modern_seasons_browser(params, fallback_art):
    tv_id = _as_int(params.get("tv_id"), 0)
    details = api.get_tv_details(tv_id)
    tv_title = details.get("name") or details.get("original_name") or "TV Series"
    poster = _poster_art_url(details.get("poster_path"))
    fanart = _media_art_url(details.get("backdrop_path")) or poster or fallback_art
    items = []
    for season in details.get("seasons") or []:
        number = season.get("season_number")
        if number is None:
            continue
        name = season.get("name") or "Season {0}".format(number)
        year = _extract_year(season)
        season_poster = _media_art_url(season.get("poster_path")) or poster
        target = build_url({
            "action": "list_episodes", "tv_id": tv_id, "season": number,
            "tv_title": tv_title, "poster": season_poster, "fanart": fanart
        })
        count = season.get("episode_count")
        items.append(_modern_browser_model(
            name,
            "Season {0}{1}".format(number, "  •  {0}".format(year) if year else ""),
            "browse", target, fallback_art,
            _modern_row_description(season.get("overview", "")),
            season_poster, fanart,
            "{0} EPISODES".format(count) if count is not None else "OPEN",
            ""
        ))
    view = _modern_browser_view(
        tv_title,
        tr("{0} season" if len(items) == 1 else "{0} seasons", len(items)),
        items, fallback_art, "SEASONS", "No seasons are available.", fanart
    )
    view["navigation"] = "bounded_vertical"
    return view


def _modern_episodes_browser(params, fallback_art):
    tv_id = _as_int(params.get("tv_id"), 0)
    season = _as_int(params.get("season"), 0)
    tv_title = params.get("tv_title") or "TV Series"
    poster = params.get("poster", "")
    fanart = params.get("fanart") or poster or fallback_art
    items = []
    for episode in api.get_episodes(tv_id, season, include_streams=False) or []:
        episode_id = episode.get("id")
        if episode_id is None:
            continue
        title = _get_episode_title(episode)
        # Season browsing only loads metadata; stream availability is resolved on open.
        available = True
        image = _media_art_url(
            episode.get("imageUrl") or episode.get("image_url")
        ) or poster
        target = build_url({
            "action": "show_streams", "tv_id": tv_id, "season": season,
            "episode_id": episode_id,
            "episode_number": _episode_number(episode),
            "tv_title": tv_title,
            "episode_title": title,
            "expected_runtime_minutes": _as_int(episode.get("runtime"), 0),
            "plot": episode.get("description") or episode.get("overview", ""),
            "poster": image, "fanart": fanart
        })
        air_date = episode.get("airDate") or episode.get("air_date")
        aired = _date_only(air_date) if air_date else ""
        rating = _as_float(
            episode.get("voteAverage", episode.get("vote_average")),
            0.0
        )
        runtime = _as_int(episode.get("runtime"), 0)
        metadata = "  •  ".join(
            value for value in (
                aired,
                f"{runtime} min" if runtime > 0 else "",
                f"★ {rating:.1f}" if rating else "",
            ) if value
        )
        items.append(_modern_browser_model(
            title,
            metadata,
            "browse" if available else "disabled",
            target if available else "", fallback_art,
            _modern_row_description(
                episode.get("description") or episode.get("overview", "")
            ),
            image, fanart, "CHOOSE STREAM",
            "" if available else "No stream available"
        ))
    view = _modern_browser_view(
        "{0}  •  {1}".format(tv_title, tr("Season {0}", season)),
        tr("{0} episode" if len(items) == 1 else "{0} episodes", len(items)),
        items, fallback_art, "EPISODES",
        "No episodes are available for this season.", fanart
    )
    view["navigation"] = "bounded_vertical"
    return view


def _modern_stream_models(streams, params, fallback_art, episode=None):
    is_episode = episode is not None
    title = params.get("tv_title") if is_episode else params.get("title")
    title = title or "Media Hub"
    poster = params.get("poster", "")
    fanart = params.get("fanart") or poster or fallback_art
    collections = _media_lists_snapshot()
    items = []
    ranked_streams = _streams_by_size_descending(streams)
    if not params.get("_defer_subtitles"):
        external_subtitles.schedule(ranked_streams, params)
    largest_size = max(
        (_as_float(stream.get("sizeInGB"), 0.0)
         for stream in ranked_streams),
        default=0.0,
    )
    for stream in ranked_streams:
        stream = _stream_with_preparation_status(stream)
        external_availability = external_subtitles.get(stream.get("id"), params)
        display_name = _stream_display_name(stream)
        availability_state, availability_label = (
            _stream_availability_presentation(stream)
        )
        is_torbox = _stream_is_torbox(stream)
        is_ready = _stream_is_ready(stream)
        can_download = _stream_can_download(stream)
        play_query = {
            "action": "play_movie_stream",
            "stream_id": stream.get("id", ""),
            "media_type": "episode" if is_episode else "movie",
            "title": title,
            "poster": poster,
            "fanart": fanart,
            "stream_name": display_name,
            "plot": (episode.get("description") or episode.get("overview", "")) if is_episode else params.get("plot", ""),
        }
        play_query.update(_stream_playback_query_fields(stream))
        if is_episode:
            episode_title = _get_episode_title(episode)
            play_query.update({
                "tv_id": params.get("tv_id", ""),
                "season": params.get("season", ""),
                "episode_id": params.get("episode_id", ""),
                "episode_number": _episode_number(episode),
                "tv_title": title,
                "episode_title": episode_title,
                "title": "{0} - {1}".format(title, episode_title),
            })
        else:
            play_query.update({
                "movie_id": params.get("movie_id", ""),
                "year": params.get("year", ""),
            })
        for key in ("resume_mode", "resume_seconds"):
            value = params.get(key)
            if value not in (None, ""):
                play_query[key] = value
        download_query = dict(play_query)
        download_query.update({
            "action": "download_movie_stream",
            "filename": display_name,
            "plot": (
                episode.get("description") or episode.get("overview", "")
                if is_episode else params.get("plot", "")
            ),
            "genres": params.get("genres", ""),
            "duration": params.get("duration", ""),
            "rating": params.get("rating", ""),
        })
        download_target = build_url(download_query)
        offline_query = dict(download_query)
        offline_query["offline"] = "true"
        offline_target = build_url(offline_query)
        if is_episode:
            collection_record = _collection_record_from_episode_stream(
                stream,
                params.get("tv_id", ""),
                params.get("season", ""),
                params.get("episode_id", ""),
                title,
                _get_episode_title(episode),
                poster,
                fanart,
            )
        else:
            collection_record = _collection_record_from_movie_stream(
                stream,
                params.get("movie_id", ""),
                title,
                params.get("year", ""),
                poster,
                fanart,
                duration=params.get("duration", ""),
                rating=params.get("rating", ""),
                genres=params.get("genres", ""),
            )
        item_id = _collection_id(collection_record)
        is_favourite = item_id in collections.get("favorites", {})
        if is_favourite:
            favourite_label = "Remove from Favourites"
            favourite_query = {
                "action": "remove_media_list_item",
                "collection": "favorites",
                "item_id": item_id,
            }
        else:
            favourite_label = "Add to Favourites"
            favourite_query = _collection_action_query(
                "add_media_list_item",
                "favorites",
                collection_record,
                item_id,
            )

        metadata_summary = _stream_metadata_summary(stream)
        subtitle_state, subtitle_status = _stream_preferred_subtitle_state(stream)
        external_status = external_availability.get("status")
        external_language = str(external_availability.get("language") or "").upper()
        play_query["external_subtitle_status"] = external_status or "checking"
        if external_status == "available":
            play_query.update({
                "external_subtitle_language": external_availability.get("language", ""),
                "external_subtitle_file_id": external_availability.get("fileId", ""),
                "external_subtitle_release": external_availability.get("release", ""),
                "external_subtitle_match_confidence": external_availability.get(
                    "matchConfidence", ""
                ),
            })
        if subtitle_state not in ("available", "forced"):
            if external_status == "available":
                external_label = {
                    "SK": "External SK available",
                    "CS": "External CZ available",
                    "CZ": "External CZ available",
                    "EN": "English available · Translate to Slovak with AI",
                }.get(external_language, "External subtitle available")
            elif external_status == "unavailable":
                external_label = "No external SK/CZ/EN subtitles found"
            elif external_status == "error":
                external_label = "External subtitle search failed"
            else:
                external_label = "Checking external subtitles…"
            metadata_summary = "  •  ".join(
                value for value in (metadata_summary, external_label) if value
            )
            visible_display_name = "{0}  ·  [{1}]".format(
                display_name,
                {
                    "available": {
                        "SK": "EXT SK",
                        "CS": "EXT CZ",
                        "CZ": "EXT CZ",
                        "EN": "EXT EN · AI",
                    }.get(external_language, "EXT SUB"),
                    "unavailable": "NO EXT SUB",
                    "error": "EXT ERROR",
                }.get(external_status or "checking", "EXT ?"),
            )
        else:
            visible_display_name = display_name
        if subtitle_state not in ("available", "forced") and external_status == "available":
            if external_language == "SK":
                subtitle_status = "External SK available"
            elif external_language in ("CS", "CZ"):
                subtitle_status = "External CZ available"
            elif external_language == "EN":
                subtitle_status = "English available"
            subtitle_row_state = "available"
            subtitle_row = subtitle_status
        audio_row_state, audio_row = _stream_audio_presentation(stream)
        subtitle_row_state, subtitle_row = _stream_subtitle_presentation(stream)
        if subtitle_state not in ("available", "forced") and external_status == "available":
            subtitle_row_state = "available"
            subtitle_row = subtitle_status
        subtitle_job = _subtitle_job_for_stream(stream.get("id"), play_query)
        ai_subtitle_status = _subtitle_status_text(subtitle_job, compact=True)
        ai_subtitle_detail = _subtitle_stage_text(subtitle_job) if subtitle_job else ""
        model = _modern_browser_model(
            visible_display_name,
            metadata_summary,
            "play", build_url(play_query), fallback_art,
            _stream_metadata_description(stream, title), poster, fanart,
            "",
            (
                tr("OK  •  Prepare & play    MENU  •  Actions")
                if is_torbox and not is_ready
                else tr("OK  •  Play    MENU  •  Actions")
            ),
            download_target if can_download else "",
        )
        # Stream selection is information-dense by design. Keep playback art
        # for the player/background, but do not expose a per-row thumbnail.
        model["art"]["thumb"] = ""
        model["properties"].update({
            "App.ItemType": "stream",
            "App.MetadataPending": "true" if str(stream.get("metadataStatus", "")).lower() == "pending" else "false",
            # The playback target changes when asynchronous subtitle and
            # preparation details arrive. Keep a separate stable identity so
            # the app shell can patch this row without resetting its list.
            "App.StreamId": str(stream.get("id") or ""),
            "App.RawFilename": display_name,
            "App.StreamTitle": _stream_friendly_title(stream),
            "App.StreamQualityTag": _stream_quality(stream) or tr("RES ?"),
            "App.Quality": _stream_quality(stream),
            "App.VideoCodec": _clean_query_value(stream.get("videoCodec")),
            "App.Hdr": _stream_hdr_label(stream),
            "App.Source": _stream_source_label(stream),
            "App.Subtitles": "/".join(_stream_subtitle_labels(stream)),
            "App.SubtitleState": subtitle_state,
            "App.SubtitleStatus": subtitle_status,
            "App.MetadataStatus": _clean_query_value(stream.get("metadataStatus")),
            "App.StreamResolution": _stream_resolution_label(stream),
            "App.StreamResolutionNote": _stream_resolution_note(stream),
            "App.StreamMetrics": _stream_metrics_summary(stream),
            "App.StreamVideoLabel": tr("Video").upper(),
            "App.StreamCodec": (
                _clean_query_value(stream.get("videoCodec")) or tr("CODEC ?")
            ),
            "App.StreamHdr": _stream_hdr_label(stream),
            "App.StreamSource": _stream_source_label(stream),
            "App.StreamEdition": _clean_query_value(stream.get("edition")),
            "App.StreamSize": _stream_size_label(stream),
            "App.StreamExtra": _stream_extra_summary(stream),
            "App.StreamStats": _stream_stats_summary(stream),
            "App.StreamAudioCompact": _stream_compact_tracks(stream, "audio"),
            "App.StreamSubtitlesCompact": _stream_compact_tracks(
                stream, "subtitle"
            ),
            "App.StreamProvider": _stream_provider(stream),
            "App.StreamProviderDisplay": _stream_provider_display_label(stream),
            "App.StreamCacheStatus": _stream_cache_status_label(stream),
            "App.StreamAvailability": _stream_availability(stream),
            "App.StreamAvailabilityState": availability_state,
            "App.StreamAvailabilityLabel": availability_label,
            "App.StreamProgress": (
                "{0}%".format(_stream_progress_percent(stream))
                if _stream_progress_percent(stream) is not None else ""
            ),
            "App.StreamProgressDisplay": "  •  ".join(
                value for value in (
                    ("{0}%".format(_stream_progress_percent(stream))
                     if _stream_progress_percent(stream) is not None else ""),
                    _stream_eta_label(stream)
                    if _stream_eta_label(stream) else "",
                ) if value
            ),
            "App.StreamEta": _stream_eta_label(stream),
            "App.StreamReadyState": "ready" if is_ready else availability_state,
            "App.StreamReadyLabel": availability_label,
            "App.StreamCanDownload": "true" if can_download else "false",
            "App.StreamLargest": (
                "true"
                if largest_size > 0
                and _as_float(stream.get("sizeInGB"), 0.0) == largest_size
                else "false"
            ),
            "App.StreamLargestLabel": (
                tr("Largest file").upper()
                if largest_size > 0
                and _as_float(stream.get("sizeInGB"), 0.0) == largest_size
                else ""
            ),
            "App.StreamAtmos": (
                "true"
                if _stream_audio_feature_label(stream) == "Dolby Atmos"
                else "false"
            ),
            "App.StreamMetadataBadge": _stream_metadata_badge(stream),
            "App.StreamActionHint": (
                tr("OK  PREPARE & PLAY  •  MENU")
                if is_torbox and not is_ready
                else tr("OK  PLAY  •  MENU")
            ),
            "App.StreamAudioLabel": tr("Audio").upper(),
            "App.StreamAudioLabelDisplay": _stream_state_markup(
                tr("Audio").upper(), audio_row_state
            ),
            "App.StreamAudio": audio_row,
            "App.StreamAudioDisplay": _stream_value_markup(
                audio_row, audio_row_state
            ),
            "App.StreamAudioState": audio_row_state,
            "App.StreamSubtitlesLabel": tr("Subtitles").upper(),
            "App.StreamSubtitlesLabelDisplay": _stream_state_markup(
                tr("Subtitles").upper(), subtitle_row_state
            ),
            "App.StreamSubtitles": subtitle_row,
            "App.StreamSubtitlesDisplay": _stream_value_markup(
                subtitle_row, subtitle_row_state
            ),
            "App.StreamSubtitleState": subtitle_row_state,
            "App.ExternalSubtitleStatusDisplay": (
                external_label
                if subtitle_state not in ("available", "forced")
                else ""
            ),
            "App.ExternalSubtitleStatus": external_status or "checking",
            "App.ExternalSubtitleLanguage": external_language,
            "App.ExternalSubtitleRelease": str(external_availability.get("release") or ""),
            # Generated subtitle state deliberately remains separate from
            # App.StreamSubtitles/App.Subtitles, which describe bundled tracks.
            "App.StreamAiSubtitleVisible": "true" if subtitle_job else "false",
            "App.StreamAiSubtitleStatus": ai_subtitle_status if subtitle_job else "",
            "App.StreamAiSubtitleDetail": ai_subtitle_detail,
            "App.StreamAiSubtitleState": (
                _clean_query_value(subtitle_job.get("status"))
                if subtitle_job else "none"
            ),
            "App.StreamAiSubtitleProgress": (
                str(_as_int(subtitle_job.get("progress"), 0))
                if subtitle_job else "0"
            ),
        })
        model["properties"].update(_stream_pill_properties(stream))
        if subtitle_state not in ("available", "forced"):
            external_pill = {
                "available": {
                    "SK": "EXT SK",
                    "CS": "EXT CZ",
                    "CZ": "EXT CZ",
                    "EN": "EXT EN · AI",
                }.get(external_language, "EXT SUB"),
                "checking": "EXT ?",
                "unavailable": "NO EXT SUB",
                "error": "EXT ERROR",
            }.get(external_status or "checking", "EXT ?")
            model["properties"].update({
                "App.StreamSubtitlePill1": external_pill,
                "App.StreamSubtitlePill1Tone": (
                    "sk" if external_language == "SK" else
                    "cz" if external_language in ("CS", "CZ") else
                    "en" if external_language == "EN" else "neutral"
                ),
                "App.StreamSubtitlePill1Wide": "true",
                "App.StreamSubtitlePill2": "",
                "App.StreamSubtitlePill3": "",
                "App.StreamSubtitleOverflow": "",
            })
            # The current modern stream cards render the flattened text rows;
            # the pill groups are retained as hidden fallbacks. Override both
            # normal and focused text so asynchronous results are visible in
            # the controls users actually see.
            model["properties"].update(_external_subtitle_text_properties(
                external_status,
                external_language,
            ))
        model["properties"].update(
            _stream_pill_image_properties(model["properties"])
        )
        model["properties"].update(stream_cards.properties(
            stream, quality=_stream_quality(stream),
            audio_tracks=_stream_sorted_audio_tracks(stream),
            audio_format=lambda track: _stream_audio_label(track, include_language=False),
            external=external_availability,
            expected=stream_cards.expected_minutes(params, episode),
        ))
        model["properties"].update(stream_cards.provider_properties(
            _stream_provider(stream), _stream_availability(stream), availability_label,
        ))
        if subtitle_job:
            model["properties"]["App.StreamCard.Provider"] += "[CR]" + stream_cards.text(ai_subtitle_status)
        context_actions = [
            {
                "label": tr("Technical details"),
                "label2": tr("Inspect video, audio and subtitle metadata"),
                "command": "stream_details",
                "target": "",
                "properties": {
                    "App.Badge": "INFO",
                    "App.StreamDetails": _stream_metadata_description(
                        stream, title
                    ),
                },
            },
            {
                "label": (
                    tr("Prepare & play")
                    if is_torbox and not is_ready else tr("Play")
                ),
                "label2": (
                    tr("Download with TorBox, then start playback")
                    if is_torbox and not is_ready
                    else tr("Start this stream now")
                ),
                "command": "play",
                "target": build_url(play_query),
                "properties": {"App.Badge": "PLAY"},
            },
        ]
        subtitle_context_actions = []
        if subtitle_job:
            if (
                subtitle_job.get("status") == "completed"
                and subtitle_job.get("subtitle_path")
            ):
                ai_play_query = dict(play_query)
                ai_play_query.update({
                    "force_ai_subtitle": "true",
                    "subtitle_job_id": subtitle_job.get("job_id"),
                })
                subtitle_context_actions.append({
                    "label": tr("Play with AI-translated Slovak subtitles"),
                    "label2": tr("Attach the locally stored AI SK subtitle"),
                    "command": "play",
                    "target": build_url(ai_play_query),
                    "properties": {"App.Badge": "AI SK"},
                })
            subtitle_context_actions.append({
                "label": _subtitle_status_text(subtitle_job),
                "label2": _subtitle_stage_text(subtitle_job),
                "command": "browse",
                "target": build_url({
                    "action": "show_subtitle_job",
                    "job_id": subtitle_job.get("job_id"),
                }),
                "properties": {"App.Badge": "AI SK"},
            })
        elif external_status == "available" and external_language == "EN":
            create_subtitle_query = dict(play_query)
            create_subtitle_query["action"] = "start_subtitle_translation"
            subtitle_context_actions.append({
                "label": tr("Translate English subtitles to Slovak with AI"),
                "label2": tr("Create AI SK subtitles in the background"),
                "command": "action",
                "target": build_url(create_subtitle_query),
                "properties": {"App.Badge": "AI SK"},
            })
        elif external_status == "available":
            subtitle_context_actions.append({
                "label": "External {0} available".format("SK" if external_language == "SK" else "CZ"),
                "label2": "OpenSubtitles matched subtitle; Kodi can attach it after download.",
                "command": "stream_details",
                "target": "",
                "properties": {"App.Badge": "EXT"},
            })
        elif external_status == "checking":
            subtitle_context_actions.append({
                "label": "Checking external subtitles…",
                "label2": "OpenSubtitles is being checked in the background.",
                "command": "stream_details",
                "target": "",
                "properties": {"App.Badge": "SUB"},
            })
        elif external_status == "unavailable":
            create_subtitle_query = dict(play_query)
            create_subtitle_query["action"] = "start_subtitle_translation"
            subtitle_context_actions.append({
                "label": tr("Search English subtitles and translate to Slovak with AI"),
                "label2": tr("Create AI SK subtitles in the background"),
                "command": "action",
                "target": build_url(create_subtitle_query),
                "properties": {"App.Badge": "AI SK"},
            })
        if can_download or is_torbox:
            context_actions.append({
                "label": (
                    tr("Add to offline downloads")
                    if is_torbox and not is_ready else tr("Download")
                ),
                "label2": (
                    tr("Prepare with TorBox, then download locally")
                    if is_torbox and not is_ready
                    else tr("Add this stream to the download queue")
                ),
                "command": "action",
                "target": offline_target if is_torbox and not is_ready else download_target,
                "properties": {"App.Badge": "QUEUE"},
            })
        if is_torbox and not is_ready:
            context_actions.insert(1, {
                "label": tr("Prepare in background"),
                "label2": tr("Prepare this stream without starting playback"),
                "command": "action",
                "target": build_url(dict(play_query, action="prepare_stream_background")),
                "properties": {"App.Badge": "QUEUE"},
            })
        context_actions.append({
            "label": tr("Refresh metadata"),
            "label2": tr("Check this stream again"),
            "command": "action",
            "target": build_url(dict(params, action="refresh_stream_metadata", stream_id=stream.get("id"))),
            "properties": {"App.Badge": "INFO"},
        })
        context_actions.append({
                "label": tr(favourite_label),
                "label2": (
                    tr("Remove this exact stream from your saved items")
                    if is_favourite
                    else tr("Save this exact stream for quick access")
                ),
                "command": "action",
                "target": build_url(favourite_query),
                "properties": {
                    "App.Badge": "REMOVE" if is_favourite else "SAVE"
                },
            })
        model["context_actions"] = context_actions
        if model["properties"]["App.StreamCard.RuntimeMismatch"] == "true":
            context_actions[0]["properties"]["App.StreamDetails"] += "\n\n" + tr(
                "Runtime differs significantly from the expected title. This may be another release or title; playback remains available."
            )
        model["subtitle_context_actions"] = subtitle_context_actions
        items.append(model)
    return items


def _modern_streams_browser(params, fallback_art, progressive=False):
    tv_id = _as_int(params.get("tv_id"), 0)
    season = _as_int(params.get("season"), 0)
    episode_id = _as_int(params.get("episode_id"), 0)
    episode_number = _as_int(params.get("episode_number"), 0)
    episode = ({"id": episode_id, "episode_number": episode_number,
                "title": params.get("episode_title") or "S{0:02d}E{1:02d}".format(season, episode_number),
                "description": params.get("plot", "")}
               if progressive and episode_number > 0 else next((
                   item for item in (api.get_episodes(tv_id, season, include_streams=False) or [])
                   if _as_int(item.get("id"), -1) == episode_id), None))
    if not episode:
        return _modern_browser_view(
            "Choose Stream", "Episode not found", [], fallback_art, "STREAMS"
        )
    if episode_number <= 0:
        episode_number = _episode_number(episode)
    # Episodes are intentionally loaded without streams above so the season
    # screen stays fast. The backend still serializes that omitted collection
    # as ``streams: []``, so it cannot be used to decide whether a lookup is
    # necessary here.
    context = dict(params, episode_number=episode_number, media_type="episode")
    session = browse.get(context) if progressive else None
    snapshot = session.snapshot() if session else None
    streams = snapshot["items"] if snapshot is not None else api.get_episode_streams(tv_id, season, episode_number)
    if progressive:
        context["_defer_subtitles"] = True
    items = _modern_stream_models(streams or [], context, fallback_art, episode)
    view = _modern_browser_view(
        _get_episode_title(episode),
        "{0}  •  {1}  •  {2}  •  {3}".format(
            tr(params.get("tv_title") or "TV Series"),
            tr("Season {0}", season),
            (
                tr("{0} stream", len(items))
                if len(items) == 1
                else tr("{0} streams", len(items))
            ),
            tr("Results update as streams arrive") if progressive else tr("Largest files first")
        ),
        items, fallback_art, "CHOOSE STREAM",
        "No streams are available for this episode.",
        params.get("fanart") or params.get("poster", "")
    )
    view.update({
        "layout": "stream_picker",
        "filters": _modern_stream_filter_models(),
        "expected_runtime_minutes": stream_cards.expected_minutes(context, episode),
    })
    if session:
        _progressive_view(view, session, snapshot)
    return view


def _modern_next_episode_browser(params, fallback_art, progressive=False):
    tv_title = params.get("tv_title") or "TV Series"
    resolved = _next_playable_episode(params, fast=True) if progressive else _next_playable_episode(params)
    if resolved is None:
        return _modern_browser_view(
            tv_title,
            "You are caught up",
            [],
            fallback_art,
            "NEXT EPISODE",
            "No later playable episode is available yet.",
            params.get("fanart") or params.get("poster", ""),
        )
    next_episode, next_season, next_streams = resolved

    image = _media_art_url(
        next_episode.get("imageUrl") or next_episode.get("image_url")
    ) or params.get("poster", "")
    next_params = dict(params)
    next_params.update({
        "season": next_season,
        "episode_id": next_episode.get("id", ""),
        "episode_number": _episode_number(next_episode),
        "poster": image,
        "expected_runtime_minutes": _as_int(next_episode.get("runtime"), 0),
    })
    if progressive:
        next_params["action"] = "show_streams"
        next_params["episode_title"] = _get_episode_title(next_episode)
        next_params["plot"] = next_episode.get("description") or next_episode.get("overview", "")
        view = _modern_streams_browser(next_params, fallback_art, progressive=True)
        view["resolved_target"] = build_url(next_params)
        return view
    items = _modern_stream_models(
        next_streams or [],
        next_params,
        fallback_art,
        next_episode,
    )
    episode_number = _episode_number(next_episode)
    view = _modern_browser_view(
        _get_episode_title(next_episode),
        "{0}  •  S{1:02d} E{2:02d}  •  {3}".format(
            tv_title, next_season, episode_number, tr("Choose stream")
        ),
        items,
        fallback_art,
        "NEXT EPISODE",
        "The next episode has no playable streams.",
        params.get("fanart") or image,
    )
    view.update({
        "layout": "stream_picker",
        "filters": _modern_stream_filter_models(),
        "expected_runtime_minutes": stream_cards.expected_minutes(next_params, next_episode),
    })
    return view


def _has_later_aired_episode(params):
    tv_id = _as_int(params.get("tv_id"), 0)
    season = _as_int(params.get("season"), 0)
    number = _as_int(params.get("episode_number"), 0)
    if tv_id <= 0 or number <= 0:
        return False
    details = api.get_tv_details(tv_id) or {}
    seasons = sorted({season} | {
        _as_int(item.get("season_number"), -1)
        for item in details.get("seasons") or [] if isinstance(item, dict)
        and _as_int(item.get("season_number"), -1) > season
    })
    today = datetime.date.today().isoformat()
    for season_number in seasons:
        episodes = api.get_episodes(tv_id, season_number, include_streams=False) or []
        if isinstance(episodes, dict):
            episodes = episodes.get("episodes") or []
        for episode in episodes:
            if not isinstance(episode, dict):
                continue
            episode_number = _episode_number(episode)
            aired = str(episode.get("air_date") or episode.get("airDate") or "")[:10]
            if episode_number > (number if season_number == season else 0) and aired and aired <= today:
                return True
    return False


def _modern_post_watch_browser(params, fallback_art):
    season = _as_int(params.get("season"), 0)
    number = _as_int(params.get("episode_number"), 0)
    code = "S{0:02d} E{1:02d}".format(season, number)
    common = {key: params[key] for key in (
        "tv_id", "season", "episode_id", "episode_number", "tv_title",
        "poster", "fanart") if params.get(key) not in (None, "")}
    next_target = build_url(dict(common, action="show_next_episode"))
    season_target = build_url(dict(common, action="list_episodes"))
    art = params.get("poster") or fallback_art
    items = []
    try:
        has_next = _has_later_aired_episode(params)
    except Exception as exc:
        xbmc.log("[MediaHub playback] Could not check later episodes: {0}".format(exc), xbmc.LOGWARNING)
        has_next = True
    if has_next:
        items.append(_modern_browser_model(
            tr("Play next episode"), tr("Choose a stream for the next available episode"),
            "browse", next_target, fallback_art, poster=art,
            fanart=params.get("fanart") or art, badge="NEXT"
        ))
    items.extend([
        _modern_browser_model(
            tr("View this season"), tr("Browse the other episodes"),
            "browse", season_target, fallback_art, poster=art,
            fanart=params.get("fanart") or art, badge="SEASON"
        ),
        _modern_browser_model(
            tr("Back to browsing"), tr("Return to where you were"),
            "browser_back", "", fallback_art, poster=art,
            fanart=params.get("fanart") or art, badge="BACK"
        ),
    ])
    return _modern_browser_view(
        tr("Episode finished"),
        "{0}  •  {1}  •  {2}".format(
            params.get("tv_title") or tr("TV Series"), code,
            tr("Up next") if has_next else tr("You are caught up")),
        items, fallback_art, "UP NEXT", fanart=params.get("fanart") or art,
    )


def _progressive_view(view, session, snapshot):
    view["browse_session"] = session
    external_subtitles.schedule([row for row in snapshot["items"]
        if str(row["id"]) in session.displayed
        and str(row.get("metadataStatus", "")).lower() != "pending"], session.context)
    pending = snapshot["pending"]
    total = len(snapshot["items"])
    loading_active = bool(snapshot["discovering"] or pending)
    if snapshot["discovering"]:
        status = tr("Finding streams…")
    elif pending:
        status = tr("Loading metadata… {0}/{1}", total - pending, total)
    else:
        checking = sum(external_subtitles.get(row["id"], session.context).get("status") == "checking" for row in snapshot["items"])
        loading_active = bool(checking)
        status = tr("Checking subtitles…") if checking else (snapshot["error"] or
            (tr("Some metadata is unavailable. Retry later.") if snapshot.get("metadata_errors") else ""))
    view["loading_status"] = status
    view["loading_active"] = loading_active
    if not total and (snapshot["discovering"] or snapshot["error"]):
        view["empty"] = status
    # Refresh only cached rows; progressive requests are owned by browse.Session.
    view["refresh_cached"] = True
    if snapshot["error"] or snapshot.get("metadata_errors"):
        view["actions"] = [{"label": tr("Retry"), "command": "action",
            "target": build_url(dict(session.context, action="retry_stream_browse"))}]



def _modern_movie_versions_browser(params, fallback_art, progressive=False):
    session = browse.get(params) if progressive else None
    snapshot = session.snapshot() if session else None
    versions = snapshot["items"] if snapshot is not None else (api.get_movie_versions(params.get("movie_id", "")) or [])
    if progressive:
        params = dict(params, _defer_subtitles=True)
    items = _modern_stream_models(versions, params, fallback_art)
    title = params.get("title") or "Choose Version"
    view = _modern_browser_view(
        title,
        "{0}  •  {1}".format(
            (
                tr("{0} version", len(items))
                if len(items) == 1
                else tr("{0} versions", len(items))
            ),
            tr("Results update as streams arrive") if progressive else tr("Largest files first")
        ),
        items, fallback_art, "MOVIE VERSIONS",
        "No playable versions are available.",
        params.get("fanart") or params.get("poster", "")
    )
    view.update({
        "layout": "stream_picker",
        "filters": _modern_stream_filter_models(),
        "expected_runtime_minutes": stream_cards.expected_minutes(params),
    })
    if session:
        _progressive_view(view, session, snapshot)
    return view


def _modern_download_actions_browser(params, fallback_art):
    data = _list_downloads_normalized()
    record = data.get(params.get("id"))
    if not isinstance(record, dict):
        return _modern_browser_view(
            "Download", "Download not found", [], fallback_art, "OFFLINE LIBRARY"
        )
    status = record.get("status", "")
    progress = _as_int(record.get("progress"), 0)
    items = []
    path = record.get("path", "")
    art = _download_art(record, fallback_art)
    title = _download_display_title(record)
    if status == "complete" and path and xbmcvfs.exists(path):
        items.append(_modern_browser_model(
            "Play Download", path, "play", path, fallback_art,
            "Play the completed local file.", art["poster"], art["fanart"],
            badge="PLAY"
        ))
    for label, query in _download_action_queries(record, _queue_count(data)):
        items.append(_modern_browser_model(
            label, "Manage this offline item", "action", build_url(query),
            fallback_art,
            tr(
                "Status: {0}  •  Progress: {1}%",
                tr(status.replace("_", " ").title()),
                progress,
            ),
            art["poster"], art["fanart"], badge="ACTION"
        ))
    return _modern_browser_view(
        title,
        tr(
            "Download status: {0}  •  {1}%  •  {2} / {3}",
            tr(status.replace("_", " ").title()),
            progress,
            _format_bytes(record.get("bytes_done")),
            _format_bytes(record.get("bytes_total")),
        ),
        items, fallback_art, "DOWNLOAD ACTIONS",
        "No actions are currently available.", art["fanart"]
    )


def _modern_preparation_actions_browser(params, fallback_art):
    record = preparations_db.get(params.get("id"))
    if not isinstance(record, dict):
        return _modern_browser_view(
            "TorBox preparation", "Preparation not found", [], fallback_art, "TORBOX"
        )
    status = record.get("status", "queued")
    progress = _as_int(record.get("progress"), 0)
    items = []
    if status == "ready":
        play_params = dict(record.get("play_params") or {})
        play_params.update({
            "action": "play_movie_stream",
            "stream_id": record.get("stream_id", ""),
            "availability": "ready",
            "is_ready": "true",
        })
        items.append(_modern_browser_model(
            "Play now", "The stream is ready", "play",
            build_url(play_params), fallback_art,
            "Start playback of the prepared TorBox stream.",
            _media_art_url(record.get("poster")) or fallback_art,
            _media_art_url(record.get("fanart")) or fallback_art,
            badge="PLAY",
        ))
    if status in ("queued", "preparing", "stalled"):
        items.append(_modern_browser_model(
            "Cancel preparation", "Stop waiting for this stream", "action",
            build_url({"action": "cancel_preparation", "id": record.get("id", "")}),
            fallback_art, "The stream will remain uncached.", badge="CANCEL",
        ))
    if status in ("failed", "canceled", "stalled"):
        items.append(_modern_browser_model(
            "Retry preparation", "Ask TorBox to prepare it again", "action",
            build_url({"action": "retry_preparation", "id": record.get("id", "")}),
            fallback_art, "Retry provider-side preparation.", badge="RETRY",
        ))
    return _modern_browser_view(
        record.get("title") or "TorBox preparation",
        tr(
            "TorBox  •  {0}  •  {1}%",
            tr(status.replace("_", " ").title()),
            progress,
        ),
        items, fallback_art, "TORBOX PREPARATION",
        "No actions are currently available.",
        _media_art_url(record.get("fanart")) or fallback_art,
    )


def _modern_subtitle_job_models(fallback_art, limit=None):
    records = _subtitle_db().list(limit=limit)
    items = []
    for record in records:
        status = record.get("status", "queued")
        progress = max(0, min(100, _as_int(record.get("progress"), 0)))
        message = _subtitle_job_detail(record)
        model = _modern_browser_model(
            record.get("title") or record.get("stream_name") or tr("AI Slovak subtitles"),
            _subtitle_status_text(record),
            "browse",
            build_url({
                "action": "show_subtitle_job",
                "job_id": record.get("job_id", ""),
            }),
            fallback_art,
            message,
            record.get("context", {}).get("poster", "") or fallback_art,
            record.get("context", {}).get("fanart", "") or fallback_art,
            badge="AI SK",
        )
        model["properties"].update({
            "MediaHub.Progress": str(progress),
            "App.Status": status,
            "App.Kind": "subtitle_job",
            "App.SubtitleJobId": record.get("job_id", ""),
            "App.StreamAiSubtitleStatus": _subtitle_status_text(record, compact=True),
        })
        items.append(model)
    return items


def _modern_subtitle_jobs_browser(fallback_art):
    return _modern_browser_view(
        "AI Slovak subtitles",
        "Background translation jobs and locally stored results",
        _modern_subtitle_job_models(fallback_art),
        fallback_art,
        "AI SUBTITLES",
        "No AI subtitle translations have been started.",
    )


def _modern_subtitle_job_browser(params, fallback_art):
    job_id = params.get("job_id", "")
    record = refresh_subtitle_job(job_id, notify=False)
    if not record:
        return _modern_browser_view(
            "AI Slovak subtitles", "Job not found", [], fallback_art,
            "AI SUBTITLES", "This subtitle job is not available."
        )
    status = record.get("status")
    context = dict(record.get("context") or {})
    poster = context.get("poster", "") or fallback_art
    fanart = context.get("fanart", "") or fallback_art
    items = []
    if status == "completed" and record.get("subtitle_path"):
        play_params = dict(context)
        play_params.update({
            "action": "play_movie_stream",
            "stream_id": record.get("stream_id"),
            "force_ai_subtitle": "true",
            "subtitle_job_id": record.get("job_id"),
        })
        items.append(_modern_browser_model(
            "Play with AI-translated Slovak subtitles",
            "The local AI SK subtitle will be attached",
            "play", build_url(play_params), fallback_art,
            "Start this exact stream with the generated subtitle selected.",
            poster, fanart, badge="PLAY"
        ))
    if status in SUBTITLE_ACTIVE_STATUSES:
        items.extend((
            _modern_browser_model(
                "Refresh status", _subtitle_status_text(record), "action",
                build_url({"action": "refresh_subtitle_job", "job_id": job_id}),
                fallback_art, "Ask the service for the latest progress.",
                poster, fanart, badge="REFRESH"
            ),
            _modern_browser_model(
                "Cancel translation", "Stop this background job", "action",
                build_url({"action": "cancel_subtitle_job", "job_id": job_id}),
                fallback_art, "Completed translation work may be discarded.",
                poster, fanart, badge="CANCEL"
            ),
        ))
    elif status in ("failed", "canceled", "cancelled"):
        items.append(_modern_browser_model(
            "Try again", "Create a fresh background job", "action",
            build_url({"action": "retry_subtitle_job", "job_id": job_id}),
            fallback_art, "Search for a usable source and translate again.",
            poster, fanart, badge="RETRY"
        ))
    elif status == "completed" and not record.get("subtitle_path"):
        items.append(_modern_browser_model(
            "Download subtitle result again", "Translation complete; local SRT missing",
            "action",
            build_url({"action": "refresh_subtitle_job", "job_id": job_id}),
            fallback_art,
            "Fetch and safely store the completed SRT in the Kodi profile.",
            poster, fanart, badge="REFRESH"
        ))
    subtitle = _subtitle_status_text(record)
    if record.get("total_chunks"):
        subtitle += tr(
            "  •  {0}/{1} chunks",
            _as_int(record.get("completed_chunks"), 0),
            _as_int(record.get("total_chunks"), 0),
        )
    description = _subtitle_job_detail(record)
    return _modern_browser_view(
        record.get("title") or "AI Slovak subtitles",
        subtitle,
        items,
        fallback_art,
        "AI SUBTITLE JOB",
        description,
        fanart,
    )


def _modern_downloads_browser(fallback_art, download_tab="normal"):
    download_tab = "torbox" if download_tab == "torbox" else "normal"
    tabs = [
        {
            "label": tr("Normal downloads"),
            "label2": tr("WebShare and cached TorBox files"),
            "command": "browser_replace",
            "target": build_url({
                "action": "show_downloads_menu",
                "download_tab": "normal",
            }),
            "properties": {
                "App.Tab": "normal",
                "App.Selected": "true" if download_tab == "normal" else "false",
                "App.Hint": tr("Ready to download or already downloaded"),
                "App.Icon": "nav-downloads.png",
            },
        },
        {
            "label": tr("TorBox cache"),
            "label2": tr("Streams waiting to become cached"),
            "command": "browser_replace",
            "target": build_url({
                "action": "show_downloads_menu",
                "download_tab": "torbox",
            }),
            "properties": {
                "App.Tab": "torbox",
                "App.Selected": "true" if download_tab == "torbox" else "false",
                "App.Hint": tr("Provider preparation queue"),
                "App.Icon": "nav-downloads.png",
            },
        },
    ]
    if download_tab == "torbox":
        items = _modern_preparation_items(
            fallback_art,
            limit=None,
            statuses=None,
        )
        subtitle = "TorBox cache preparation and history"
        empty = "No TorBox cache preparation records are available."
    else:
        items = _modern_home_download_items(fallback_art, limit=None)
        subtitle = "WebShare downloads and cached TorBox files"
        empty = "No normal downloads are queued or stored."
    if download_tab == "torbox":
        removable_count = sum(
            1
            for record in preparations_db.list().values()
            if record.get("status") in ("ready", "failed", "canceled")
        )
        category_label = tr("TorBox Cache")
    else:
        removable_count = len(_removable_download_history_records())
        category_label = tr("Normal Downloads")
    record_label = tr("record") if removable_count == 1 else tr("records")
    clear_action = _modern_browser_model(
        tr("Clear history ({0})", removable_count),
        tr("{0} history only", category_label),
        "confirm_action" if removable_count else "noop", build_url({
            "action": "clear_download_history",
            "download_tab": download_tab,
        }), fallback_art,
        tr(
            "Remove completed, canceled and failed records from this category "
            "without deleting files."
        ),
        badge=tr("CLEAN UP") if removable_count else tr("EMPTY"),
        hint=""
    )
    clear_action["properties"].update({
        "App.Disabled": "false" if removable_count else "true",
        "App.ConfirmTitle": tr(
            "Clear {0} {1} history {2}?",
            removable_count,
            category_label,
            record_label,
        ),
        "App.ConfirmMessage": tr(
            "Only this category's terminal history is removed. Files are kept."
        ),
        "App.ConfirmActionLabel": tr(
            "Clear {0} {1}", removable_count, record_label
        ),
    })
    actions = [clear_action]
    return _modern_browser_view(
        "Downloads", subtitle, items,
        fallback_art, "OFFLINE LIBRARY", empty, tabs=tabs, actions=actions
    )


def _modern_settings_browser(params, fallback_art):
    section = params.get("section", "about")
    addon = xbmcaddon.Addon()

    def setting_item(label, setting_id, kind, description):
        value = addon.getSetting(setting_id) or ""
        if kind == "bool":
            display = "On" if value.lower() == "true" else "Off"
        elif kind == "language":
            display = "Slovenčina" if language() == SLOVAK else "English"
        elif kind == "secret":
            display = "••••••••" if value else "Not configured"
        elif kind == "folder":
            display = value or "Not configured"
        else:
            display = value or "Default"
        return _modern_browser_model(
            label, display, "action",
            build_url({
                "action": "modern_setting", "setting": setting_id,
                "kind": kind, "section": section
            }),
            fallback_art, description,
            badge="TOGGLE" if kind == "bool" else "CHANGE"
        )

    if section == "account":
        title = "Account & API"
        items = [setting_item(
            "API Key", "api_key", "secret",
            "Authentication used for Media Hub API requests."
        )]
    elif section == "downloads":
        title = "Downloads"
        items = [
            setting_item("Download Folder", "download_path", "folder", "Where completed files are stored."),
            setting_item("Staging Folder", "download_staging_path", "folder", "Optional local staging for network destinations."),
            setting_item("Concurrent Downloads", "max_concurrent_downloads", "number", "Maximum simultaneous transfers."),
            setting_item("Retry Attempts", "download_retry_limit", "number", "Retries after a failed transfer."),
            setting_item("Speed Limit", "max_download_speed_kbps", "number", "KB/s; use 0 for unlimited."),
            setting_item("Streaming Speed Limit", "max_download_speed_streaming_kbps", "number", "KB/s while Kodi is playing media."),
        ]
    elif section == "tv":
        title = "TV Filtering"
        items = [setting_item(
            "Filter Animation", "filter_anime", "bool",
            "Hide likely anime titles from TV catalogue pages."
        )]
    elif section == "interface":
        title = "Interface"
        items = [
            setting_item(
                "Language", "ui_language", "language",
                "Choose the language used by the Media Hub interface."
            ),
            setting_item(
                "Modern Media Hub", "modern_home", "bool",
                "Use the cinematic application shell by default."
            ),
            setting_item(
                "Reduce catalog motion", "catalog_reduce_motion", "bool",
                "Disable card enlargement and moving catalog backgrounds."
            ),
        ]
    elif section == "playback":
        title = "Playback"
        items = [
            _modern_browser_model(
                "AI Slovak subtitle jobs", "Translation progress and history",
                "browse", build_url({"action": "show_subtitle_jobs"}),
                fallback_art,
                "Review active jobs, errors and locally stored subtitle results.",
                badge="AI SK"
            ),
            setting_item(
                "Prefer included SK/CZ subtitles", "subtitle_native_first", "bool",
                "Use a stream's native Slovak or Czech track before an AI result."
            ),
            setting_item(
                "Confirm AI translation", "subtitle_confirm_generation", "bool",
                "Ask before starting a potentially paid background translation."
            ),
            setting_item(
                "Auto-attach AI subtitles", "subtitle_auto_attach", "bool",
                "Attach a completed local AI SK subtitle when no preferred native track exists."
            ),
            setting_item(
                "Subtitle retention days", "subtitle_retention_days", "number",
                "Remove terminal job history and generated files after this many days; 0 keeps them."
            ),
            setting_item(
                "AI privacy acknowledgement", "subtitle_privacy_ack_v2", "bool",
                "Release filename/title metadata, movie fingerprint, and file size are "
                "queried against OpenSubtitles and the selected subtitle is downloaded. "
                "A bounded 128 KiB sample is read to calculate the fingerprint; media bytes "
                "are not sent to OpenSubtitles or OpenAI. Subtitle text and timing are sent "
                "to OpenAI; job/checkpoint and per-job result data are normally retained "
                "for 7 days, reusable translated cache data for 90 days, and completed "
                "SRT files are kept locally."
            ),
            _modern_browser_model(
                "Kodi Player", "Automatic stream and subtitle hand-off",
                "disabled", "", fallback_art,
                "Media Hub resolves your selection and hands it to Kodi's player.",
                badge="READY", hint="Managed automatically"
            ),
        ]
    else:
        title = "About"
        version = addon.getAddonInfo("version") or "0.8.0"
        items = [
            _modern_browser_model(
                "Media Hub", "Version {0}".format(version), "disabled", "",
                fallback_art, "A modern movie and TV experience for Kodi.",
                badge="KODI"
            ),
            _modern_browser_model(
                "Interface", "Custom 1080p remote-first shell", "disabled", "",
                fallback_art,
                "Every catalogue and management view shares one visual language.",
                badge="MODERN"
            ),
        ]
    return _modern_browser_view(
        title, "Media Hub preferences", items, fallback_art, "SETTINGS"
    )


def _modern_browser_loader(target, fallback_art, genre_names, progressive=False, cached_genre_names=None):
    params = _modern_target_params(target)
    action = params.get("action", "")
    if action == "post_watch":
        return _modern_post_watch_browser(params, fallback_art)
    if action == "show_continue_watching":
        return _modern_browser_view(
            "Continue Watching", "Continue from your saved position",
            _modern_continue_watching_items(fallback_art, limit=None), fallback_art,
            "Continue Watching", "Start a movie or episode to continue watching here.",
        )
    if action in ("menu_item_movies", "menu_item_tvshows", "menu_item_search"):
        return _modern_root_browser(params, fallback_art)
    if action in (
        "menu_item_movies_latest", "menu_item_movies_popular",
        "menu_item_movies_toprated", "menu_item_movies_search",
        "list_tv_shows_latest", "list_tv_shows_recently_aired",
        "list_tv_shows_popular", "list_tv_shows_sk",
        "menu_item_tvshows_search"
    ):
        return _modern_catalog_browser(params, fallback_art, cached_genre_names or genre_names)
    if action in ("show_discovery_filters", "list_discovery_results"):
        return _modern_discovery_browser(params, fallback_art,
            (cached_genre_names or genre_names) if action == "list_discovery_results" else genre_names)
    if action == "list_seasons":
        return _modern_seasons_browser(params, fallback_art)
    if action == "list_episodes":
        return _modern_episodes_browser(params, fallback_art)
    if action == "show_streams":
        return _modern_streams_browser(params, fallback_art, progressive=progressive)
    if action == "show_next_episode":
        return _modern_next_episode_browser(params, fallback_art, progressive=progressive)
    if action == "list_movie_versions":
        return _modern_movie_versions_browser(params, fallback_art, progressive=progressive)
    if action == "show_downloads_menu":
        return _modern_downloads_browser(fallback_art, params.get("download_tab"))
    if action == "show_download_actions":
        return _modern_download_actions_browser(params, fallback_art)
    if action == "show_preparation_actions":
        return _modern_preparation_actions_browser(params, fallback_art)
    if action == "show_subtitle_jobs":
        return _modern_subtitle_jobs_browser(fallback_art)
    if action == "show_subtitle_job":
        return _modern_subtitle_job_browser(params, fallback_art)
    if action == "show_favorites":
        return _modern_browser_view(
            "Favourites", "Movies, series and episodes saved for later",
            _modern_home_favorite_items(fallback_art, limit=None),
            fallback_art, "MY LIST"
        )
    if action == "show_watch_history":
        return _modern_browser_view(
            "Recently Viewed", "Continue where you left off",
            _modern_home_history_items(fallback_art, limit=None),
            fallback_art, "HISTORY"
        )
    if action == "modern_settings":
        return _modern_settings_browser(params, fallback_art)
    return _modern_browser_view(
        "Media Hub", "Compatibility destination", [], fallback_art,
        "MEDIA HUB", "No modern view is available for this destination."
    )


def _modern_setting_action(params):
    setting_id = params.get("setting", "")
    kind = params.get("kind", "text")
    if not setting_id:
        return
    addon = xbmcaddon.Addon()
    current = addon.getSetting(setting_id) or ""
    if kind == "language":
        options = [tr("English"), tr("Slovenčina")]
        selected = xbmcgui.Dialog().select(
            tr("Language"),
            options,
            preselect=1 if language() == SLOVAK else 0,
        )
        if selected in (0, 1):
            # Legacy Kodi enum settings persist their selected zero-based index.
            addon.setSetting(setting_id, str(selected))
        return
    if kind == "bool":
        addon.setSetting(setting_id, "false" if current.lower() == "true" else "true")
        return
    if kind == "folder":
        selected = xbmcgui.Dialog().browse(
            0, tr("Choose folder"), "files", "", False, False, current
        )
        if selected:
            addon.setSetting(setting_id, selected)
        return
    keyboard = xbmc.Keyboard(current, tr("Change setting"))
    keyboard.doModal()
    if not keyboard.isConfirmed():
        return
    value = _clean_query_value(keyboard.getText())
    if kind == "number" and value and not value.isdigit():
        xbmcgui.Dialog().notification(
            tr("Settings"), tr("Enter a whole number."),
            xbmcgui.NOTIFICATION_ERROR, 2000
        )
        return
    addon.setSetting(setting_id, value)


def _modern_action_handler(target):
    params = _modern_target_params(target)
    action = params.get("action", "")
    if action == "refresh_stream_metadata":
        session = browse.get(params)
        browse.refresh_stream(session, params.get("stream_id"))
        return None
    if action == "retry_stream_browse":
        browse.invalidate(params)
        params["action"] = "show_streams" if params.get("tv_id") else "list_movie_versions"
        return build_url(params)
    if action == "hide_continue_watching":
        def hide_record(records):
            record = records.get(params.get("id"))
            if isinstance(record, dict):
                record["hidden_from_home"] = True
        watch_history_db.mutate(hide_record)
        return None
    if action == "configure_discovery_filter":
        media_type = "tv" if params.get("media_type") == "tv" else "movie"
        state = _prompt_discovery_filter(
            media_type, params.get("filter"), params
        )
        return (
            build_url(_discovery_query(
                "show_discovery_filters",
                media_type,
                state,
                section=params.get("section"),
            ))
            if state is not None else None
        )
    if action == "modern_setting":
        _modern_setting_action(params)
        return None
    handlers = {
        "move_download": lambda: move_download(params.get("id"), params.get("direction")),
        "pause_download": lambda: pause_download(params.get("id")),
        "resume_download": lambda: resume_download(params.get("id")),
        "cancel_download": lambda: cancel_download(params.get("id")),
        "retry_download": lambda: retry_download(params.get("id")),
        "verify_download": lambda: verify_download(params.get("id")),
        "repair_download": lambda: repair_download(params.get("id")),
        "remove_download_history": lambda: remove_download_history(params.get("id")),
        "clear_download_history": lambda: clear_download_history(
            confirm=params.get("confirmed") != "true",
            category=params.get("download_tab", "all"),
        ),
        "clear_watch_history": clear_watch_history,
        "remove_watch_history_item": lambda: remove_watch_history_item(params.get("id")),
        "clear_media_list": lambda: clear_media_list(params.get("collection")),
        "remove_media_list_item": lambda: remove_media_list_item(
            params.get("collection"), params.get("item_id")
        ),
        "add_media_list_item": lambda: add_media_list_item(
            params.get("collection"), params
        ),
        "download_movie_stream": lambda: download_movie_stream(
            params.get("stream_id"), params.get("filename", "download"), params
        ),
        "prepare_stream_background": lambda: prepare_stream_background(
            params.get("stream_id"), params
        ),
        "cancel_preparation": lambda: cancel_preparation(params.get("id")),
        "retry_preparation": lambda: retry_preparation(params.get("id")),
        "start_subtitle_translation": lambda: start_subtitle_translation(
            params.get("stream_id"), params
        ),
        "refresh_subtitle_job": lambda: refresh_subtitle_job(params.get("job_id")),
        "cancel_subtitle_job": lambda: cancel_subtitle_job(params.get("job_id")),
        "retry_subtitle_job": lambda: retry_subtitle_job(params.get("job_id")),
    }
    handler = handlers.get(action)
    if handler:
        handler()
        if action in {
            "move_download", "pause_download", "resume_download", "cancel_download",
            "retry_download", "verify_download", "repair_download",
            "remove_download_history", "clear_download_history",
        }:
            return build_url({
                "action": "show_downloads_menu",
                "download_tab": (
                    "torbox" if params.get("download_tab") == "torbox"
                    else "normal"
                ),
            })
    return None


def _handle_modern_home_result(result):
    if not isinstance(result, dict):
        return
    if result.get("command") == "navigate" and result.get("target"):
        xbmc.executebuiltin(f"Container.Update({result.get('target')})")
    elif result.get("command") == "quit" and not result.get("quit_requested"):
        xbmc.executebuiltin("Quit")


def show_modern_home(
    handle,
    initial_target="",
    catalog_columns=6,
    catalog_rows=2,
    catalog_page_size=None,
):
    if not _addon_bool_setting("modern_home", True):
        show_main_menu(handle)
        return

    try:
        from . import app_home
    except Exception as ex:
        xbmc.log(f"[modern_home] Could not load custom window: {ex}", xbmc.LOGERROR)
        show_main_menu(handle)
        return

    try:
        fallback_art = get_addon_art_path()
        all_history_items = _modern_home_history_items(fallback_art, limit=None)
        all_favorite_items = _modern_home_favorite_items(fallback_art, limit=None)
        all_download_items = _modern_preparation_items(fallback_art, limit=None)
        all_download_items.extend(_modern_home_download_items(fallback_art, limit=None))
        history_items = all_history_items[:10]
        favorite_items = all_favorite_items[:10]
        download_items = all_download_items
        home_primary = _modern_continue_watching_items(fallback_art, include_next=False)
        home_secondary = []
        navigation = _modern_home_navigation(
            fallback_art,
            len(all_history_items),
            len(all_favorite_items),
            len(all_download_items)
        )
        settings_items = _modern_settings_items(fallback_art)
    except Exception as ex:
        xbmc.log(f"[modern_home] Could not build home content: {ex}", xbmc.LOGERROR)
        show_main_menu(handle)
        return

    # Complete the plugin directory before opening the modal window so Kodi
    # does not leave its busy overlay above the custom interface.
    xbmcplugin.setPluginCategory(handle, "Media Hub")
    try:
        xbmcplugin.setContent(handle, "files")
    except Exception:
        pass
    classic_url = build_url({"action": "classic_home"})
    fallback_item = xbmcgui.ListItem(label="Media Hub – klasické zobrazenie")
    fallback_item.setArt({"thumb": fallback_art, "fanart": fallback_art})
    xbmcplugin.addDirectoryItem(handle, classic_url, fallback_item, isFolder=True)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)

    catalog_columns = max(1, _as_int(catalog_columns, 6))
    catalog_rows = max(1, _as_int(catalog_rows, 2))
    catalog_page_size = max(
        1,
        _as_int(catalog_page_size, catalog_columns * catalog_rows),
    )
    catalog_states = {}
    stream_view_cache = {}
    catalog_lock = threading.RLock()
    genre_cache = {"movie": None, "tv": None}
    genre_locks = {"movie": threading.Lock(), "tv": threading.Lock()}

    def genre_names(media_type):
        with genre_locks[media_type]:
            if genre_cache[media_type] is None:
                try:
                    response = (
                        api.get_tv_genres()
                        if media_type == "tv"
                        else api.get_movie_genres()
                    )
                    genre_cache[media_type] = _modern_genre_name_map(response)
                except Exception as ex:
                    xbmc.log(
                        f"[modern_home] Could not load {media_type} genres: {ex}",
                        xbmc.LOGWARNING,
                    )
                    genre_cache[media_type] = {}
            return genre_cache[media_type]


    def catalog_page_loader(page, tab, page_number):
        page_number = max(1, _as_int(page_number, 1))
        key = (page, tab)
        with catalog_lock:
            state = catalog_states.setdefault(key, {
                "items": [],
                "batches": {},
                "source_page": 1,
                "emitted_items": 0,
                "exhausted": False,
                "lock": threading.RLock(),
            })
        with state["lock"]:
            if page_number in state["batches"]:
                return state["batches"][page_number]

            # Publish the first source page immediately. Further pages are
            # fetched asynchronously as the user approaches the end.
            start = state["emitted_items"]
            initial_load = page_number == 1
            end = None if initial_load else start + catalog_page_size
            while (
                (
                    state["source_page"] <= 1
                    if initial_load
                    else len(state["items"]) < end
                )
                and not state["exhausted"]
            ):
                source_items = _load_modern_catalog(
                    page,
                    tab,
                    fallback_art,
                    (genre_cache["movie"] or {}) if page == "movies" else None,
                    (genre_cache["tv"] or {}) if page == "tv" else None,
                    page_number=state["source_page"],
                )
                state["source_page"] += 1
                if not source_items:
                    state["exhausted"] = True
                    break
                state["items"].extend(source_items)

            batch = list(
                state["items"][start:]
                if initial_load
                else state["items"][start:end]
            )
            state["emitted_items"] += len(batch)
            state["batches"][page_number] = batch
            return batch

    def catalog_loader(page, tab):
        return catalog_page_loader(page, tab, 1)

    def search_loader(query):
        completed = queue.Queue()
        def fetch(kind, loader):
            try:
                completed.put((kind, loader(query, 1), None))
            except Exception as exc:
                completed.put((kind, None, exc))
        for kind, loader in (("movie", api.get_movies_search), ("tv", api.get_tv_search)):
            threading.Thread(target=fetch, args=(kind, loader), daemon=True, name="MediaHubSearch").start()
        combined, errors = [], []
        for _ in range(2):
            kind, response, error = completed.get()
            if error:
                errors.append(error)
                continue
            builder = _modern_movie_catalog_models if kind == "movie" else _modern_tv_catalog_models
            combined.extend(builder(response, fallback_art, "SEARCH", genre_cache[kind] or {}))
            yield list(combined)
        if len(errors) == 2:
            raise errors[0]

    def home_loader():
        completed = queue.Queue()
        def fetch(section):
            try:
                completed.put({section: catalog_loader(section, "popular")[:8]})
            except Exception:
                completed.put({"errors": [section]})
        for section in ("movies", "tv"):
            threading.Thread(target=fetch, args=(section,), daemon=True, name="MediaHubHomeCatalog").start()
        errors = []
        for _ in range(2):
            result = completed.get()
            errors.extend(result.get("errors") or [])
            result["errors"] = list(errors)
            yield result

    def browser_loader(target):
        params = _modern_target_params(target)
        stamp = None
        if params.get("action") in ("show_streams", "list_movie_versions") and (params.get("movie_id") or _as_int(params.get("episode_number"), 0) > 0):
            session = browse.get(params)
            files = []
            for database in (preparations_db, subtitle_jobs_db, media_lists_db):
                path = getattr(database, "_path", "")
                for candidate in (path, path + "-wal" if path else ""):
                    try:
                        files.append(os.stat(candidate).st_mtime_ns)
                    except OSError:
                        files.append(None)
            stamp = (id(session), session.revision, external_subtitles.revision(), tuple(files), language())
            cached = stream_view_cache.get(target)
            if cached and cached[0] == stamp:
                return cached[1]
        view = _modern_browser_loader(
            target, fallback_art, genre_names, progressive=True,
            cached_genre_names=lambda kind: genre_cache[kind] or {},
        )
        if stamp is not None:
            if len(stream_view_cache) >= 16:
                stream_view_cache.pop(next(iter(stream_view_cache)))
            stream_view_cache[target] = (stamp, view)
        return view

    def display_handler(view, displayed):
        session = view.get("browse_session")
        browse.deactivate_except(session)
        if session is None:
            return
        session.last_seen = time.monotonic()
        if displayed is not False:
            for model in displayed:
                properties = model.get("properties", {})
                browse.update_availability(session, properties.get("App.StreamId", ""), properties.get("App.StreamAvailability"))
        ids = (list(session.displayed) if displayed is False else
               [model.get("properties", {}).get("App.StreamId", "") for model in displayed])
        browse.mark_displayed(session, ids)

    def catalog_metadata_loader(model):
        if model.get("home_resume_metadata"):
            return _enrich_home_resume_metadata(model, genre_names(model.get("catalog_type", "movie")))
        if model.get("favorite_record"):
            return _enrich_favorite_card_model(model, genre_names(model.get("catalog_type", "movie")))
        source = dict(model.get("catalog_source") or {})
        kind = model.get("catalog_type")
        if not source or kind not in ("movie", "tv"):
            return dict(model, catalog_enriched=True)
        names = genre_names(kind)
        eyebrow = model.get("catalog_eyebrow", "")
        try:
            details = api.get_catalog_metadata(kind, source.get("id")) or {}
        except api.ApiError as exc:
            if exc.status_code not in (404, 405):
                raise
            details = {}
        if kind == "tv" and "number_of_seasons" not in details:
            # Older servers return a small catalog payload. The existing cached
            # detail endpoint supplies season counts without requiring deployment.
            try:
                full_details = api.get_tv_details(source.get("id")) or {}
                details = dict(full_details, **details)
            except Exception as exc:
                xbmc.log("[catalog] Optional TV facts unavailable: {0}".format(exc), xbmc.LOGWARNING)
        for field in ("overview", "runtime", "director", "cast", "original_name", "last_air_date", "last_episode_to_air",
                      "next_episode_to_air", "number_of_seasons", "number_of_episodes", "status", "seasons"):
            if details.get(field) not in (None, ""):
                source[field] = details[field]
        if not source.get("name") and details.get("name"):
            source["name"] = details["name"]
        builder = _modern_movie_catalog_models if kind == "movie" else _modern_tv_catalog_models
        rows = builder({"results": [source]}, fallback_art, eyebrow, names)
        updated = rows[0] if rows else dict(model)
        try:
            snapshot = watch_history_db.list()
            watch = _catalog_watch_properties(source, kind, snapshot)
            updated.setdefault("properties", {}).update(watch)
            if kind == "tv" and watch["App.CardStatus"] == tr("Continue series"):
                watch["App.CardStatus"] = _catalog_next_episode_status(source, snapshot) or watch["App.CardStatus"]
                updated["properties"].update(watch)
        except Exception as exc:
            xbmc.log("[catalog] Optional viewing state unavailable: {0}".format(exc), xbmc.LOGWARNING)
        if kind == "tv" and "RECENT" in eyebrow.upper():
            activity = _recent_tv_activity_label(source)
            if activity:
                updated["label2"] = activity
                updated.setdefault("properties", {})["App.HomeMeta"] = activity
        updated["catalog_enriched"] = True
        return updated

    def state_loader():
        return {
            "reduce_catalog_motion": _addon_bool_setting("catalog_reduce_motion"),
            "favorites": _modern_home_favorite_items(fallback_art, limit=None),
            "history": _modern_home_history_items(fallback_art, limit=10),
            "continue_watching": _modern_continue_watching_items(fallback_art, include_next=False),
            "downloads": (
                _modern_preparation_items(fallback_art, limit=None)
                + _modern_home_download_items(fallback_art, limit=None)
            ),
        }

    try:
        result = app_home.open_home(
            xbmcaddon.Addon().getAddonInfo("path"),
            navigation=navigation,
            async_loading=True,
            display_handler=display_handler,
            close_handler=browse.close,
            catalog_metadata_loader=catalog_metadata_loader,
            home_primary_loader=lambda: _modern_continue_watching_items(fallback_art, fast_next=True),
            home_primary=home_primary,
            home_secondary=home_secondary,
            favorite_items=favorite_items,
            history_items=history_items,
            download_items=download_items,
            settings_items=settings_items,
            fallback_art=fallback_art,
            logo_art=os.path.join(
                xbmcaddon.Addon().getAddonInfo("path"),
                "resources",
                "skins",
                "Default",
                "media",
                "rail-logo.png",
            ),
            catalog_loader=catalog_loader,
            catalog_page_loader=catalog_page_loader,
            catalog_columns=catalog_columns,
            reduce_catalog_motion=_addon_bool_setting("catalog_reduce_motion"),
            search_loader=search_loader,
            search_history_path=os.path.join(
                xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("profile")),
                "search-history.json",
            ),
            home_loader=home_loader,
            browser_loader=browser_loader,
            filter_view_ready=lambda target: _discovery_filter_view_ready(
                target, genre_cache
            ),
            discovery_targets={
                "movies": build_url({
                    "action": "show_discovery_filters",
                    "media_type": "movie",
                }),
                "tv": build_url({
                    "action": "show_discovery_filters",
                    "media_type": "tv",
                }),
            },
            action_handler=_modern_action_handler,
            play_handler=_play_modern_target,
            resume_choice_loader=_modern_resume_options,
            state_loader=state_loader,
            initial_target=initial_target,
        )
    except Exception as ex:
        xbmc.log(f"[modern_home] Custom window failed: {ex}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification(
            "Media Hub",
            "Moderné rozhranie sa nepodarilo otvoriť.",
            xbmcgui.NOTIFICATION_ERROR,
            3000
        )
        xbmc.executebuiltin(f"Container.Update({classic_url},replace)")
        return

    _handle_modern_home_result(result)

def show_main_menu(handle):

    _prepare_directory(handle, "Hlavné menu", "files")

    # Movies
    menuItemMovies = xbmcgui.ListItem(label="Filmy")
    menuItemMovies.setInfo('video', { 'plot': u"\u00A0" })
    _set_utility_fanart(menuItemMovies)
    urlMovies = build_url({'action': 'menu_item_movies'})
    xbmcplugin.addDirectoryItem(handle, urlMovies, menuItemMovies, isFolder=True)

    # TV Shows
    menuItemTvShows = xbmcgui.ListItem(label="Seriály")
    menuItemTvShows.setInfo('video', { 'plot': u"\u00A0" })
    _set_utility_fanart(menuItemTvShows)
    urlTvShows = build_url({'action': 'menu_item_tvshows'})
    xbmcplugin.addDirectoryItem(handle, urlTvShows, menuItemTvShows, isFolder=True)

    # Downloads
    menuItemDownloads = xbmcgui.ListItem(label="Sťahovanie")
    menuItemDownloads.setInfo('video', { 'plot': u"\u00A0" })
    _set_utility_fanart(menuItemDownloads)
    urlDownloads = build_url({'action': 'show_downloads_menu'})
    xbmcplugin.addDirectoryItem(handle, urlDownloads, menuItemDownloads, isFolder=True)

    subtitle_item = xbmcgui.ListItem(label=tr("AI Slovak subtitles"))
    subtitle_item.setInfo('video', {
        'plot': tr("Background translation jobs and locally stored results")
    })
    _set_utility_fanart(subtitle_item)
    xbmcplugin.addDirectoryItem(
        handle,
        build_url({'action': 'show_subtitle_jobs'}),
        subtitle_item,
        isFolder=True,
    )

    # Watch History
    menuItemWatchHistory = xbmcgui.ListItem(label="História pozerania")
    menuItemWatchHistory.setInfo('video', { 'plot': u"\u00A0" })
    _set_utility_fanart(menuItemWatchHistory)
    urlWatchHistory = build_url({'action': 'show_watch_history'})
    xbmcplugin.addDirectoryItem(handle, urlWatchHistory, menuItemWatchHistory, isFolder=True)

    # Favorites
    menuItemFavorites = xbmcgui.ListItem(label="Obľúbené")
    menuItemFavorites.setInfo('video', { 'plot': u"\u00A0" })
    _set_utility_fanart(menuItemFavorites)
    urlFavorites = build_url({'action': 'show_favorites'})
    xbmcplugin.addDirectoryItem(handle, urlFavorites, menuItemFavorites, isFolder=True)

    xbmcplugin.endOfDirectory(handle)


def show_subtitle_jobs(handle):
    _prepare_directory(handle, tr("AI Slovak subtitles"), "files")
    records = _subtitle_db().list()
    if not records:
        item = xbmcgui.ListItem(label=tr("No AI subtitle translations have been started."))
        _set_utility_fanart(item)
        xbmcplugin.addDirectoryItem(handle, "", item, isFolder=False)
        xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
        return
    for record in records:
        status = record.get("status")
        title = record.get("title") or record.get("stream_name") or tr("Media Hub")
        label = "[B]{0}[/B]  {1}".format(_subtitle_status_text(record, compact=True), title)
        item = xbmcgui.ListItem(label=label, label2=_subtitle_stage_text(record))
        plot = _subtitle_job_detail(record)
        item.setInfo("video", {
            "title": title,
            "plot": plot,
            "mediatype": (
                "episode"
                if record.get("context", {}).get("media_type") == "episode"
                else "movie"
            ),
        })
        context = record.get("context") or {}
        item.setArt({
            "thumb": context.get("poster", ""),
            "poster": context.get("poster", ""),
            "fanart": context.get("fanart", "") or context.get("poster", ""),
        })
        action_url = build_url({
            "action": "show_subtitle_job_actions", "job_id": record.get("job_id", "")
        })
        context_items = [(
            tr("Subtitle job actions"), "RunPlugin({0})".format(action_url)
        )]
        if status in SUBTITLE_ACTIVE_STATUSES:
            context_items.append((
                tr("Cancel translation"),
                "RunPlugin({0})".format(build_url({
                    "action": "cancel_subtitle_job", "job_id": record.get("job_id", "")
                })),
            ))
        elif status in ("failed", "canceled", "cancelled"):
            context_items.append((
                tr("Try again"),
                "RunPlugin({0})".format(build_url({
                    "action": "retry_subtitle_job", "job_id": record.get("job_id", "")
                })),
            ))
        item.addContextMenuItems(context_items, True)
        if status == "completed" and record.get("subtitle_path"):
            url = build_url({
                "action": "play_subtitle_job", "job_id": record.get("job_id", "")
            })
            item.setProperty("IsPlayable", "true")
        else:
            url = action_url
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=False)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)

def menu_item_search(handle):
    _prepare_directory(handle, "Hľadať", "files")

    movie_item = xbmcgui.ListItem(label="Hľadať filmy")
    movie_item.setInfo("video", {
        "plot": "Vyhľadať film podľa názvu a zobraziť dostupné verzie."
    })
    _set_utility_fanart(movie_item)
    xbmcplugin.addDirectoryItem(
        handle,
        build_url({"action": "menu_item_movies_search"}),
        movie_item,
        isFolder=True
    )

    tv_item = xbmcgui.ListItem(label="Hľadať seriály")
    tv_item.setInfo("video", {
        "plot": "Vyhľadať seriál podľa názvu a prejsť na série a epizódy."
    })
    _set_utility_fanart(tv_item)
    xbmcplugin.addDirectoryItem(
        handle,
        build_url({"action": "menu_item_tvshows_search"}),
        tv_item,
        isFolder=True
    )

    xbmcplugin.endOfDirectory(handle)

def show_watch_history(handle):
    _prepare_directory(handle, "História pozerania", "videos")
    try:
        xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_UNSORTED)
    except Exception:
        pass

    data = watch_history_db.list()
    records = sorted(
        data.values(),
        key=lambda record: record.get("last_played_at") or record.get("created_at") or "",
        reverse=True
    )

    if records:
        clear_item = xbmcgui.ListItem(label="Vymazať históriu pozerania")
        clear_item.setInfo('video', {'plot': 'Vymazať všetky lokálne záznamy histórie pozerania.'})
        clear_url = build_url({'action': 'clear_watch_history'})
        xbmcplugin.addDirectoryItem(handle, clear_url, clear_item, isFolder=False)
    else:
        empty_item = xbmcgui.ListItem(label="História je prázdna")
        empty_item.setInfo('video', {'plot': u"\u00A0"})
        xbmcplugin.addDirectoryItem(handle, "", empty_item, isFolder=False)
        xbmcplugin.endOfDirectory(handle)
        return

    for record in records:
        if not record.get("stream_id"):
            continue

        history_id = record.get("id") or _history_id(record)
        item = xbmcgui.ListItem(label=_history_label(record))
        item.setInfo('video', {
            'title': record.get("title") or record.get("stream_name") or "Stream",
            'plot': _history_plot(record)
        })
        art = {}
        if record.get("poster"):
            art['poster'] = record.get("poster")
            art['thumb'] = record.get("poster")
        if record.get("fanart"):
            art['fanart'] = record.get("fanart")
        if art:
            item.setArt(art)
        item.setProperty('IsPlayable', 'true')
        context_items = _history_episode_navigation_context_menu_items(record)
        context_items.extend([
            (tr("Odstrániť z histórie"), f"RunPlugin({build_url({'action': 'remove_watch_history_item', 'id': history_id})})"),
            (tr("Vymazať históriu pozerania"), f"RunPlugin({build_url({'action': 'clear_watch_history'})})")
        ])
        item.addContextMenuItems(context_items, True)

        url = build_url(_history_play_query(record))
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=False)

    xbmcplugin.endOfDirectory(handle)

def remove_watch_history_item(history_id):
    removed = watch_history_db.remove(history_id)
    if removed:
        xbmcgui.Dialog().notification("História pozerania", "Záznam odstránený", xbmcgui.NOTIFICATION_INFO, 1500)
    xbmc.executebuiltin("Container.Refresh")

def clear_watch_history():
    confirm = xbmcgui.Dialog().yesno("Vymazať históriu pozerania", "Všetky lokálne záznamy histórie pozerania budú odstránené. Pokračovať?", yeslabel="Áno", nolabel="Nie")
    if not confirm:
        return

    watch_history_db.clear_all()
    xbmc.executebuiltin("Container.Refresh")

def menu_item_movies(handle):

    _prepare_directory(handle, "Filmy", "files")

    # Latest Movies
    menuItemMoviesLatest = xbmcgui.ListItem(label="Nové ")
    menuItemMoviesLatest.setInfo('video', { 'plot': u"\u00A0" })
    _set_utility_fanart(menuItemMoviesLatest)
    urlMoviesLatest = build_url({'action': 'menu_item_movies_latest'})
    xbmcplugin.addDirectoryItem(handle, urlMoviesLatest, menuItemMoviesLatest, isFolder=True)

    # Popular Movies
    menuItemMoviesPopular = xbmcgui.ListItem(label="Populárne")
    menuItemMoviesPopular.setInfo('video', { 'plot': u"\u00A0" })
    _set_utility_fanart(menuItemMoviesPopular)
    urlMoviesPopular = build_url({'action': 'menu_item_movies_popular'})
    xbmcplugin.addDirectoryItem(handle, urlMoviesPopular, menuItemMoviesPopular, isFolder=True)

    # Top Rated Movies
    menuItemMoviesTopRated = xbmcgui.ListItem(label="Najlepšie Hodnotené")
    menuItemMoviesTopRated.setInfo('video', { 'plot': u"\u00A0" })
    _set_utility_fanart(menuItemMoviesTopRated)
    urlMoviesTopRated = build_url({'action': 'menu_item_movies_toprated'})
    xbmcplugin.addDirectoryItem(handle, urlMoviesTopRated, menuItemMoviesTopRated, isFolder=True)

    # Combined genre/year/sort/rating discovery
    menuItemMoviesDiscover = xbmcgui.ListItem(label="Prehliadať a filtrovať")
    menuItemMoviesDiscover.setInfo('video', { 'plot': "Žáner, rok, zoradenie a minimálne hodnotenie." })
    urlMoviesDiscover = build_url({'action': 'show_discovery_filters', 'media_type': 'movie'})
    xbmcplugin.addDirectoryItem(handle, urlMoviesDiscover, menuItemMoviesDiscover, isFolder=True)

    # Search
    menuItemMoviesSearch = xbmcgui.ListItem(label="Hľadať")
    menuItemMoviesSearch.setProperty('IsPlayable', 'false')
    menuItemMoviesSearch.setInfo('video', { 'plot': u"\u00A0" })
    _set_utility_fanart(menuItemMoviesSearch)
    urlMoviesSearch = build_url({'action': 'menu_item_movies_search'})
    xbmcplugin.addDirectoryItem(handle, urlMoviesSearch, menuItemMoviesSearch, isFolder=True)

    xbmcplugin.endOfDirectory(handle)

def menu_item_tvshows(handle):

    _prepare_directory(handle, "Seriály", "files")

    # Latest Tv Shows
    menuItemTvShowsLatest = xbmcgui.ListItem(label="Nové seriály")
    menuItemTvShowsLatest.setInfo('video', { 'plot': u"\u00A0" })
    _set_utility_fanart(menuItemTvShowsLatest)
    urlTvShowsLatest = build_url({'action': 'list_tv_shows_latest'})
    xbmcplugin.addDirectoryItem(handle, urlTvShowsLatest, menuItemTvShowsLatest, isFolder=True)

    # Recently aired seasons and episodes
    menuItemTvShowsRecentlyAired = xbmcgui.ListItem(label="Nové série a epizódy")
    menuItemTvShowsRecentlyAired.setInfo('video', { 'plot': u"\u00A0" })
    _set_utility_fanart(menuItemTvShowsRecentlyAired)
    urlTvShowsRecentlyAired = build_url({'action': 'list_tv_shows_recently_aired'})
    xbmcplugin.addDirectoryItem(handle, urlTvShowsRecentlyAired, menuItemTvShowsRecentlyAired, isFolder=True)

    # Popular Tv Shows
    menuItemTvShowsPopular = xbmcgui.ListItem(label="Populárne")
    menuItemTvShowsPopular.setInfo('video', { 'plot': u"\u00A0" })
    _set_utility_fanart(menuItemTvShowsPopular)
    urlTvShowsPopular = build_url({'action': 'list_tv_shows_popular'})
    xbmcplugin.addDirectoryItem(handle, urlTvShowsPopular, menuItemTvShowsPopular, isFolder=True)

    # Top Rated Tv Shows
    menuItemTvShowsSlovak = xbmcgui.ListItem(label="Slovenské")
    menuItemTvShowsSlovak.setInfo('video', { 'plot': u"\u00A0" })
    _set_utility_fanart(menuItemTvShowsSlovak)
    urlTvShowsSlovak = build_url({'action': 'list_tv_shows_sk'})
    xbmcplugin.addDirectoryItem(handle, urlTvShowsSlovak, menuItemTvShowsSlovak, isFolder=True)

    # Combined genre/year/sort/rating discovery
    menuItemTvDiscover = xbmcgui.ListItem(label="Prehliadať a filtrovať")
    menuItemTvDiscover.setInfo('video', { 'plot': "Žáner, rok prvého vysielania, zoradenie a minimálne hodnotenie." })
    urlTvDiscover = build_url({'action': 'show_discovery_filters', 'media_type': 'tv'})
    xbmcplugin.addDirectoryItem(handle, urlTvDiscover, menuItemTvDiscover, isFolder=True)

    # Search
    menuItemTvSearch = xbmcgui.ListItem(label="Hľadať")
    menuItemTvSearch.setProperty('IsPlayable', 'false')
    menuItemTvSearch.setInfo('video', { 'plot': u"\u00A0" })
    _set_utility_fanart(menuItemTvSearch)
    urlTvSearch = build_url({'action': 'menu_item_tvshows_search'})
    xbmcplugin.addDirectoryItem(handle, urlTvSearch, menuItemTvSearch, isFolder=True)

    xbmcplugin.endOfDirectory(handle)

def _discovery_sort_options(media_type):
    return DISCOVERY_SORTS

def _discovery_sort_label(sort_value, media_type="movie"):
    return dict(_discovery_sort_options(media_type)).get(sort_value, "Popular")


def _discovery_summary_parts(media_type, state):
    parts = []
    genre_names = _discovery_genre_names(state)
    genre_ids = _discovery_genre_ids(state)
    if genre_names:
        parts.append(" + ".join(genre_names))
    elif genre_ids:
        key = "{0} genre" if len(genre_ids) == 1 else "{0} genres"
        parts.append(
            tr(key, len(genre_ids))
        )
    if (
        _valid_discovery_year(state.get("year"))
        or _valid_discovery_year(state.get("year_from"))
        or _valid_discovery_year(state.get("year_to"))
    ):
        parts.append(_discovery_period_label(state))
    if state.get("minimum_rating"):
        parts.append("{0}+".format(state["minimum_rating"]))
    minimum_vote_count = max(
        0,
        _as_int(state.get("minimum_vote_count"), 0),
    )
    if minimum_vote_count:
        parts.append(
            tr("{0}+ ratings", "{0:,}".format(minimum_vote_count))
        )
    if (
        _valid_discovery_runtime(state.get("minimum_runtime"))
        or _valid_discovery_runtime(state.get("maximum_runtime"))
    ):
        parts.append(_discovery_runtime_label(state))
    parts.append(
        tr(_discovery_sort_label(state.get("sort"), media_type))
    )
    return parts


def _discovery_compact_summary(media_type, state):
    return " • ".join(_discovery_summary_parts(media_type, state))


def _discovery_summary(media_type, state):
    prefix = tr("Movies" if media_type == "movie" else "TV Series")
    return "{0}: {1}".format(
        prefix,
        _discovery_compact_summary(media_type, state),
    )

def show_discovery_filters(handle, media_type):
    media_type = "tv" if media_type == "tv" else "movie"
    state = _discovery_state()
    _prepare_directory(handle, "Prehliadať a filtrovať", "files")

    _add_discovery_filter_item(
        handle,
        "Žánre: {0}".format(tr(_discovery_genre_label(state))),
        media_type,
        "genre",
        state
    )
    period_title = (
        "Obdobie prvého vysielania"
        if media_type == "tv"
        else "Obdobie vydania"
    )
    _add_discovery_filter_item(
        handle,
        "{0}: {1}".format(
            period_title,
            tr(_discovery_period_label(state)),
        ),
        media_type,
        "release_period",
        state,
    )
    _add_discovery_filter_item(
        handle,
        "Minimálne hodnotenie: {0}".format(
            (
                "{0}+".format(state["minimum_rating"])
                if state.get("minimum_rating")
                else "Bez minima"
            )
        ),
        media_type,
        "minimum_rating",
        state
    )
    _add_discovery_filter_item(
        handle,
        "Minimálny počet hodnotení: {0}".format(
            (
                "{0:,}+".format(
                    max(0, _as_int(state.get("minimum_vote_count"), 0))
                )
                if _as_int(state.get("minimum_vote_count"), 0) > 0
                else "Bez minima"
            )
        ),
        media_type,
        "minimum_vote_count",
        state
    )
    _add_discovery_filter_item(
        handle,
        "Zoradiť: {0}".format(
            tr(_discovery_sort_label(state.get("sort"), media_type))
        ),
        media_type,
        "sort",
        state
    )

    results_item = xbmcgui.ListItem(label="[B]Zobraziť výsledky[/B]")
    results_item.setInfo('video', {'plot': _discovery_summary(media_type, state)})
    results_url = build_url(_discovery_query("list_discovery_results", media_type, state, page=1))
    xbmcplugin.addDirectoryItem(handle, results_url, results_item, isFolder=True)

    clear_item = xbmcgui.ListItem(label="Vymazať filtre")
    clear_item.setInfo('video', {'plot': "Obnoviť predvolené filtrovanie podľa popularity."})
    clear_url = build_url(_discovery_query("show_discovery_filters", media_type))
    xbmcplugin.addDirectoryItem(handle, clear_url, clear_item, isFolder=True)
    xbmcplugin.endOfDirectory(handle)

def _genre_choices(media_type):
    response = api.get_tv_genres() if media_type == "tv" else api.get_movie_genres()
    if not isinstance(response, list):
        return []
    genres = []
    for genre in response:
        if not isinstance(genre, dict):
            continue
        genre_id = genre.get("id", genre.get("Id"))
        name = _clean_query_value(genre.get("name", genre.get("Name")))
        if _as_int(genre_id, 0) > 0 and name:
            genres.append((str(_as_int(genre_id)), name))
    return sorted(genres, key=lambda value: value[1].casefold())

def _prompt_discovery_filter(media_type, filter_name, params=None):
    media_type = "tv" if media_type == "tv" else "movie"
    state = _discovery_state(params)
    dialog = xbmcgui.Dialog()

    if filter_name == "genre":
        try:
            choices = _genre_choices(media_type)
        except Exception as ex:
            xbmc.log(f"[genres] Failed to load genre catalog: {ex}", xbmc.LOGERROR)
            dialog.ok("Žánre", "Nepodarilo sa načítať zoznam žánrov.")
            return None
        current_ids = {
            str(value)
            for value in _discovery_genre_ids(state)
        }
        preselect = [
            index
            for index, (genre_id, _name) in enumerate(choices)
            if genre_id in current_ids
        ]
        multiselect = getattr(dialog, "multiselect", None)
        if callable(multiselect):
            selected = multiselect(
                "Vyberte žánre",
                [label for _, label in choices],
                preselect=preselect,
            )
            if selected is None:
                return None
            selected_choices = [
                choices[index]
                for index in selected
                if 0 <= index < len(choices)
            ]
        else:
            single_choices = [("", "Všetky žánre")] + choices
            single_preselect = (
                preselect[0] + 1
                if preselect
                else 0
            )
            selected = dialog.select(
                "Vyberte žáner",
                [label for _, label in single_choices],
                preselect=single_preselect,
            )
            if selected < 0:
                return None
            selected_choices = (
                [single_choices[selected]]
                if single_choices[selected][0]
                else []
            )
        state = _discovery_state_with(
            state,
            genre_ids=(
                ",".join(value[0] for value in selected_choices)
                or None
            ),
            genre_names=(
                "|".join(value[1] for value in selected_choices)
                or None
            ),
        )
    elif filter_name == "year":
        current_year = time.gmtime().tm_year
        choices = [("", "Všetky roky")] + [
            (str(year), str(year))
            for year in range(current_year, DISCOVERY_MIN_YEAR - 1, -1)
        ]
        current = state.get("year", "")
        preselect = next(
            (
                index
                for index, (value, _label) in enumerate(choices)
                if value == current
            ),
            0,
        )
        selected = dialog.select(
            (
                "Rok prvého vysielania"
                if media_type == "tv"
                else "Rok vydania"
            ),
            [label for _, label in choices],
            preselect=preselect,
        )
        if selected < 0:
            return None
        selected_year = choices[selected][0]
        state = _discovery_state_with(
            state,
            year=selected_year or None,
            year_from=None,
            year_to=None,
        )
    elif filter_name == "release_period":
        current_year = time.gmtime().tm_year
        choose_custom_range = True
        if not _clean_query_value((params or {}).get("section")):
            presets = (
                ("Všetky obdobia", None, None),
                ("Tento rok", current_year, current_year),
                ("Posledné 3 roky", current_year - 2, current_year),
                ("Posledných 5 rokov", current_year - 4, current_year),
                ("Vlastný rozsah…", "custom", "custom"),
            )
            current_from = _valid_discovery_year(state.get("year_from"))
            current_to = _valid_discovery_year(state.get("year_to"))
            preselect = (
                4
                if state.get("year")
                else next(
                    (
                        index
                        for index, (
                            _label,
                            year_from,
                            year_to,
                        ) in enumerate(presets)
                        if (
                            year_from == current_from
                            and year_to == current_to
                        )
                    ),
                    4 if current_from or current_to else 0,
                )
            )
            selected = dialog.select(
                "Obdobie prvého vysielania"
                if media_type == "tv"
                else "Obdobie vydania",
                [label for label, _year_from, _year_to in presets],
                preselect=preselect,
            )
            if selected < 0:
                return None
            _label, preset_from, preset_to = presets[selected]
            choose_custom_range = preset_from == "custom"
            if not choose_custom_range:
                state = _discovery_state_with(
                    state,
                    year=None,
                    year_from=(
                        str(preset_from)
                        if preset_from is not None
                        else None
                    ),
                    year_to=(
                        str(preset_to)
                        if preset_to is not None
                        else None
                    ),
                )

        if not choose_custom_range:
            return state

        years = [
            year
            for year in range(current_year + 1, DISCOVERY_MIN_YEAR - 1, -1)
        ]
        current_from = (
            _valid_discovery_year(state.get("year_from"))
            or _valid_discovery_year(state.get("year"))
            or current_year
        )
        current_to = (
            _valid_discovery_year(state.get("year_to"))
            or _valid_discovery_year(state.get("year"))
            or current_year
        )
        from_preselect = (
            years.index(current_from)
            if current_from in years
            else years.index(current_year)
        )
        selected_from = dialog.select(
            "Od roku",
            [str(year) for year in years],
            preselect=from_preselect,
        )
        if selected_from < 0:
            return None
        year_from = years[selected_from]
        to_preselect = (
            years.index(current_to)
            if current_to in years
            else years.index(current_year)
        )
        selected_to = dialog.select(
            "Do roku",
            [str(year) for year in years],
            preselect=to_preselect,
        )
        if selected_to < 0:
            return None
        year_to = years[selected_to]
        if year_from > year_to:
            dialog.ok(
                "Obdobie",
                "Začiatočný rok nemôže byť neskôr ako koncový rok.",
            )
            return None
        state = _discovery_state_with(
            state,
            year=None,
            year_from=str(year_from),
            year_to=str(year_to),
        )
    elif filter_name == "sort":
        sort_options = _discovery_sort_options(media_type)
        current = state.get("sort", "popularity.desc")
        preselect = next((index for index, value in enumerate(sort_options) if value[0] == current), 0)
        selected = dialog.select("Zoradiť výsledky", [label for _, label in sort_options], preselect=preselect)
        if selected < 0:
            return None
        state["sort"] = sort_options[selected][0]
    elif filter_name == "minimum_rating":
        choices = [("", "Bez minima")] + [
            (f"{half_step / 2:.1f}", f"{half_step / 2:.1f}+")
            for half_step in range(1, 20)
        ]
        current = state.get("minimum_rating", "")
        preselect = next((index for index, value in enumerate(choices) if value[0] == current), 0)
        selected = dialog.select("Minimálne hodnotenie", [label for _, label in choices], preselect=preselect)
        if selected < 0:
            return None
        minimum_rating, _ = choices[selected]
        if minimum_rating:
            state["minimum_rating"] = minimum_rating
        else:
            state.pop("minimum_rating", None)
    elif filter_name == "minimum_vote_count":
        choices = (
            (0, "Bez minima"),
            (25, "25+"),
            (100, "100+"),
            (250, "250+"),
            (500, "500+"),
            (1000, "1 000+"),
        )
        current = max(
            0,
            _as_int(state.get("minimum_vote_count"), 0),
        )
        preselect = next(
            (
                index
                for index, (value, _label) in enumerate(choices)
                if value == current
            ),
            0,
        )
        selected = dialog.select(
            "Minimálny počet hodnotení",
            [label for _, label in choices],
            preselect=preselect,
        )
        if selected < 0:
            return None
        state["minimum_vote_count"] = str(choices[selected][0])
    else:
        return None

    return _discovery_state(state)


def configure_discovery_filter(media_type, filter_name, params=None):
    media_type = "tv" if media_type == "tv" else "movie"
    state = _prompt_discovery_filter(media_type, filter_name, params)
    if state is None:
        return

    _replace_discovery_container(media_type, state)

def _build_movie_item(movie, genre_name="", include_hearts=False, include_rating=False):
    year = _movie_release_year(movie) or "----"
    rating = _as_float(movie.get("vote_average"), 0.0)
    hearts = _format_vote_hearts(movie.get("vote_count")) if include_hearts else ""
    rating_label = f"[COLOR FFB8860B][{rating:.1f}][/COLOR]" if include_rating else ""
    label = " ".join(value for value in (
        _movie_display_title(movie),
        f"[COLOR FFAAAAAA][{year}][/COLOR]",
        hearts,
        rating_label
    ) if value)
    item = xbmcgui.ListItem(label=label)
    poster = _poster_art_url(movie.get('poster_path'))
    fanart = _media_art_url(movie.get('backdrop_path')) or poster
    item.setArt({
        'thumb': poster,
        'poster': poster,
        'fanart': fanart
    })
    info = {
        'title': movie.get('title') or _movie_display_title(movie),
        'originaltitle': movie.get('original_title', ''),
        'plot': movie.get('overview', ''),
        'rating': rating,
        'votes': _as_int(movie.get('vote_count'), 0),
        'premiered': movie.get('release_date', ''),
        'mediatype': 'movie'
    }
    numeric_year = _as_int(year, 0)
    if numeric_year:
        info['year'] = numeric_year
    if genre_name:
        info['genre'] = genre_name
    item.setInfo('video', info)
    return item

def _build_discovery_movie_item(movie, genre_name=""):
    return _build_movie_item(
        movie,
        genre_name=genre_name,
        include_rating=True
    )

def list_discovery_results(handle, media_type):
    media_type = "tv" if media_type == "tv" else "movie"
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    state = _discovery_state(params)
    page = max(1, _as_int(params.get("page"), 1))
    request_kwargs = {
        "page": page,
        "genre_ids": _discovery_genre_ids(state),
        "year": _as_int(state.get("year"), 0) or None,
        "year_from": _as_int(state.get("year_from"), 0) or None,
        "year_to": _as_int(state.get("year_to"), 0) or None,
        "sort": state.get("sort", "popularity.desc"),
        "minimum_rating": _as_float(state.get("minimum_rating")),
        "minimum_vote_count": max(
            0,
            _as_int(state.get("minimum_vote_count"), 0),
        ),
        "minimum_runtime": (
            _valid_discovery_runtime(state.get("minimum_runtime"))
            or None
        ),
        "maximum_runtime": (
            _valid_discovery_runtime(state.get("maximum_runtime"))
            or None
        ),
    }
    category = _discovery_summary(media_type, state)
    _prepare_directory(
        handle,
        category,
        "tvshows" if media_type == "tv" else "movies"
    )

    try:
        if media_type == "tv":
            response = _classic_catalog_response(lambda: api.discover_tv(**request_kwargs)) if _classic_catalog_enabled() else api.discover_tv(**request_kwargs)
        else:
            response = _classic_catalog_response(lambda: api.discover_movies(**request_kwargs)) if _classic_catalog_enabled() else api.discover_movies(**request_kwargs)
    except Exception as ex:
        xbmc.log(f"[discovery] Failed to load {media_type} results: {ex}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Prehliadanie", "Nepodarilo sa načítať výsledky.")
        _finish_catalog_directory(handle, succeeded=False)
        return

    results = response.get("results", []) if isinstance(response, dict) else []
    total_pages = _as_int(response.get("total_pages"), 1) if isinstance(response, dict) else 1
    collections = _media_lists_snapshot()

    display_results = _filter_tv_shows(results) if media_type == "tv" else results
    if media_type == "tv":
        for show in display_results:
            item = _build_tv_show_item(
                show,
                include_vote_count=True,
                include_rating=True,
                genre_name=_discovery_genre_label(state),
            )
            _add_collection_context_menu(item, _collection_record_from_tv_show(show), collections)
            url = build_url({'action': 'list_seasons', 'tv_id': show['id']})
            xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
    else:
        for movie in display_results:
            item = _build_discovery_movie_item(
                movie,
                _discovery_genre_label(state),
            )
            _add_collection_context_menu(item, _collection_record_from_movie(movie), collections)
            xbmcplugin.addDirectoryItem(handle, _build_movie_versions_url(movie), item, isFolder=True)

    if not display_results:
        empty_item = xbmcgui.ListItem(label="Žiadne výsledky")
        empty_item.setInfo('video', {'plot': "Skúste zmeniť alebo vymazať filtre."})
        xbmcplugin.addDirectoryItem(handle, "", empty_item, isFolder=False)

    if page < total_pages:
        next_page = page + 1
        next_item = xbmcgui.ListItem(label=f"Ďalej na stranu {next_page}")
        next_url = build_url(_discovery_query(
            "list_discovery_results",
            media_type,
            state,
            page=next_page
        ))
        xbmcplugin.addDirectoryItem(handle, next_url, next_item, isFolder=True)

    _finish_catalog_directory(handle, updateListing=False)

def _prompt_catalog_search(search_query, keyboard_title):
    search_query = _clean_query_value(search_query)
    if search_query:
        return search_query

    keyboard = xbmc.Keyboard('', keyboard_title)
    keyboard.doModal()
    if not keyboard.isConfirmed():
        return ""
    return _clean_query_value(keyboard.getText())

def menu_item_movies_latest(handle):
    _prepare_directory(handle, "Nové filmy", "movies")
    page = int(dict(urllib.parse.parse_qsl(sys.argv[2][1:])).get('page', 1))
    try:
        response = _classic_catalog_response(lambda: api.get_movies_latest(page)) if _classic_catalog_enabled() else api.get_movies_latest(page)
    except Exception as ex:
        _catalog_load_failed(handle, "new movies", ex)
        return
    movies = response.get('results', [])
    total_pages = response.get('total_pages', 1)
    collections = _media_lists_snapshot()

    for movie in movies:
        item = _build_movie_item(movie, include_hearts=True)
        _add_collection_context_menu(item, _collection_record_from_movie(movie), collections)
        url = _build_movie_versions_url(movie)
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    if page < total_pages:
        nextPage = page + 1
        item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
        url = build_url({'action': 'menu_item_movies_latest', 'page': nextPage})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    _finish_catalog_directory(handle, updateListing=False)

def menu_item_movies_popular(handle):
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    filter_type = params.get('filter_type')
    year = params.get('year')
    page = int(params.get('page', 1))
    
    # If no filter type, show submenu
    if not filter_type:
        _prepare_directory(handle, "Populárne", "files")
        
        # All Times
        item = xbmcgui.ListItem(label="Všetky roky")
        item.setInfo('video', { 'plot': u"\u00A0" })
        url = build_url({'action': 'menu_item_movies_popular', 'filter_type': 'all_time'})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
        
        # By Year
        item = xbmcgui.ListItem(label="Podľa Roku")
        item.setInfo('video', { 'plot': u"\u00A0" })
        url = build_url({'action': 'menu_item_movies_popular', 'filter_type': 'by_year'})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
        
        _finish_catalog_directory(handle)
        return
    
    # If filter_type is 'by_year' but no year selected, show year selector
    if filter_type == 'by_year' and not year:
        _prepare_directory(handle, "Populárne – podľa roku", "files")
        
        import datetime
        current_year = datetime.datetime.now().year
        
        # Show years from current year back to 1940
        for yr in range(current_year, 1940, -1):
            item = xbmcgui.ListItem(label=str(yr))
            item.setInfo('video', { 'plot': u"\u00A0" })
            url = build_url({'action': 'menu_item_movies_popular', 'filter_type': 'by_year', 'year': yr})
            xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
        
        _finish_catalog_directory(handle)
        return
    
    _prepare_directory(
        handle,
        f"Populárne filmy{f' – {year}' if year else ''}",
        "movies"
    )

    # Show movies based on filter
    try:
        if filter_type == 'all_time':
            response = _classic_catalog_response(lambda: api.get_movies_popular(page)) if _classic_catalog_enabled() else api.get_movies_popular(page)
        elif filter_type == 'by_year' and year:
            response = _classic_catalog_response(lambda: api.get_movies_popular(page, year)) if _classic_catalog_enabled() else api.get_movies_popular(page, year)
        else:
            response = _classic_catalog_response(lambda: api.get_movies_popular(page)) if _classic_catalog_enabled() else api.get_movies_popular(page)
    except Exception as ex:
        _catalog_load_failed(handle, "popular movies", ex)
        return
    
    movies = response.get('results', [])
    total_pages = response.get('total_pages', 1)
    collections = _media_lists_snapshot()

    for movie in movies:
        item = _build_movie_item(movie, include_rating=True)
        _add_collection_context_menu(item, _collection_record_from_movie(movie), collections)
        url = _build_movie_versions_url(movie)
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    if page < total_pages:
        nextPage = page + 1
        extra_params = {'filter_type': filter_type}
        if year:
            extra_params['year'] = year
        item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
        url = build_url({'action': 'menu_item_movies_popular', 'page': nextPage, **extra_params})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    _finish_catalog_directory(handle, updateListing=False)

def menu_item_movies_toprated(handle):
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    filter_type = params.get('filter_type')
    year = params.get('year')
    page = int(params.get('page', 1))
    
    # If no filter type, show submenu
    if not filter_type:
        _prepare_directory(handle, "Najlepšie hodnotené", "files")
        
        # All Times
        item = xbmcgui.ListItem(label="Všetky roky")
        item.setInfo('video', { 'plot': u"\u00A0" })
        url = build_url({'action': 'menu_item_movies_toprated', 'filter_type': 'all_time'})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
        
        # By Year
        item = xbmcgui.ListItem(label="Podľa Roku")
        item.setInfo('video', { 'plot': u"\u00A0" })
        url = build_url({'action': 'menu_item_movies_toprated', 'filter_type': 'by_year'})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
        
        _finish_catalog_directory(handle)
        return
    
    # If filter_type is 'by_year' but no year selected, show year selector
    if filter_type == 'by_year' and not year:
        _prepare_directory(handle, "Najlepšie hodnotené – podľa roku", "files")
        
        import datetime
        current_year = datetime.datetime.now().year
        
        # Show years from current year back to 1990
        for yr in range(current_year, 1940, -1):
            item = xbmcgui.ListItem(label=str(yr))
            item.setInfo('video', { 'plot': u"\u00A0" })
            url = build_url({'action': 'menu_item_movies_toprated', 'filter_type': 'by_year', 'year': yr})
            xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
        
        _finish_catalog_directory(handle)
        return
    
    _prepare_directory(
        handle,
        f"Najlepšie hodnotené{f' – {year}' if year else ''}",
        "movies"
    )

    # Show movies based on filter
    if filter_type == 'all_time':
        response = _classic_catalog_response(lambda: api.get_movies_toprated(page)) if _classic_catalog_enabled() else api.get_movies_toprated(page)
    elif filter_type == 'by_year' and year:
        response = _classic_catalog_response(lambda: api.get_movies_toprated(page, year)) if _classic_catalog_enabled() else api.get_movies_toprated(page, year)
    else:
        response = _classic_catalog_response(lambda: api.get_movies_toprated(page)) if _classic_catalog_enabled() else api.get_movies_toprated(page)
    
    movies = response.get('results', [])
    total_pages = response.get('total_pages', 1)
    collections = _media_lists_snapshot()

    for movie in movies:
        item = _build_movie_item(movie, include_rating=True)
        _add_collection_context_menu(item, _collection_record_from_movie(movie), collections)
        url = _build_movie_versions_url(movie)
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    if page < total_pages:
        nextPage = page + 1
        extra_params = {'filter_type': filter_type}
        if year:
            extra_params['year'] = year
        item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
        url = build_url({'action': 'menu_item_movies_toprated', 'page': nextPage, **extra_params})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    _finish_catalog_directory(handle, updateListing=False)

def menu_item_movies_search(handle):
    _prepare_directory(handle, "Hľadať filmy", "movies")
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    search_query = _prompt_catalog_search(params.get('search_query'), 'Hľadať Filmy')
    if not search_query:
        _finish_catalog_directory(handle, succeeded=False, cacheToDisc=False)
        return

    page = max(1, _as_int(params.get('page'), 1))
    try:
        response = _classic_catalog_response(lambda: api.get_movies_search(search_query, page)) if _classic_catalog_enabled() else api.get_movies_search(search_query, page)
    except Exception as ex:
        _catalog_load_failed(handle, "movie search", ex)
        return

    movies = response.get('results', [])
    total_pages = response.get('total_pages', 1)
    collections = _media_lists_snapshot()

    for movie in movies:
        item = _build_movie_item(movie, include_hearts=True)
        _add_collection_context_menu(item, _collection_record_from_movie(movie), collections)
        xbmcplugin.addDirectoryItem(handle, _build_movie_versions_url(movie), item, isFolder=True)

    if not movies:
        empty_item = xbmcgui.ListItem(label="Žiadne filmy sa nenašli")
        empty_item.setInfo('video', {'plot': f"Pre názov „{search_query}“ neboli nájdené žiadne filmy."})
        xbmcplugin.addDirectoryItem(handle, "", empty_item, isFolder=False)

    if page < total_pages:
        next_page = page + 1
        item = xbmcgui.ListItem(label=f"Ďalej na stranu {next_page}")
        url = build_url({'action': 'menu_item_movies_search', 'page': next_page, 'search_query': search_query})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    _finish_catalog_directory(handle, updateListing=False)




    # itemTvSeriesLatest = xbmcgui.ListItem(label="Seriály - Nové")
    # url = build_url({'action': 'list_tv_shows_latest'})
    # xbmcplugin.addDirectoryItem(handle, url, itemTvSeriesLatest, isFolder=True)

    # itemTvSeriesPopular = xbmcgui.ListItem(label="Seriály - Populárne")
    # url = build_url({'action': 'list_tv_shows_popular'})
    # xbmcplugin.addDirectoryItem(handle, url, itemTvSeriesPopular, isFolder=True)

    # itemTvSeriesSk = xbmcgui.ListItem(label="Seriály - SK")
    # url = build_url({'action': 'list_tv_shows_sk'})
    # xbmcplugin.addDirectoryItem(handle, url, itemTvSeriesSk, isFolder=True)

def _get_tv_year(show):
    year = show.get("first_air_date_year")
    if year:
        return str(year)

    first_air_date = show.get("first_air_date") or ""
    return first_air_date[:4] if first_air_date else "----"

def _extract_year(item):
    for key in ("year", "first_air_date_year"):
        value = item.get(key)
        if value not in (None, ""):
            return str(value)

    for key in ("air_date", "first_air_date", "release_date"):
        value = item.get(key) or ""
        if len(value) >= 4:
            return value[:4]

    return "----"

def _get_episode_title(ep):
    return ep.get("title") or ep.get("name") or f"Episode {ep.get('episode_number', '?')}"

def _format_vote_hearts(vote_count):
    if vote_count is None:
        vote_count = 0

    if vote_count < 200:
        filled_hearts = 0
    elif vote_count < 500:
        filled_hearts = 1
    elif vote_count <= 1000:
        filled_hearts = 2
    else:
        filled_hearts = 3

    hearts = []
    for index in range(3):
        if index < filled_hearts:
            # use a softer golden tone instead of bright yellow
            hearts.append("[COLOR FFB8860B]★[/COLOR]")
        else:
            # slightly darker grey for empty stars
            hearts.append("[COLOR FF909090]☆[/COLOR]")
    return "".join(hearts)

def _date_only(value):
    value = _clean_query_value(value)
    if len(value) >= 10:
        return value[:10]
    return value

def _format_episode_ref(episode):
    if not isinstance(episode, dict):
        return ""

    season_number = episode.get("season_number")
    episode_number = episode.get("episode_number")
    if season_number in (None, "") or episode_number in (None, ""):
        return ""

    try:
        return f"S{int(season_number):02d}E{int(episode_number):02d}"
    except (TypeError, ValueError):
        return ""

def _recent_tv_activity_label(show):
    episode = show.get("last_episode_to_air") or {}
    episode_ref = _format_episode_ref(episode)
    air_date = _date_only(episode.get("air_date") or show.get("last_air_date"))

    if episode_ref and air_date:
        return f"{episode_ref} {air_date}"
    if episode_ref:
        return episode_ref
    return air_date

def _recent_tv_activity_plot(show):
    episode = show.get("last_episode_to_air") or {}
    episode_ref = _format_episode_ref(episode)
    episode_name = _clean_query_value(episode.get("name"))
    air_date = _date_only(episode.get("air_date") or show.get("last_air_date"))
    lines = []

    if episode_ref:
        title = f"Najnovšia epizóda: {episode_ref}"
        if episode_name:
            title = f"{title} - {episode_name}"
        lines.append(title)
    if air_date:
        lines.append(f"Dátum odvysielania: {air_date}")

    return "\n".join(lines)

def _build_tv_show_item(
    show,
    include_vote_count=False,
    include_hearts=True,
    include_recent_activity=False,
    include_rating=False,
    genre_name=""
):
    year = _get_tv_year(show)
    display_title = show.get("name_with_original_name") or show.get("name") or ""
    vote_count = show.get("vote_count")
    hearts = _format_vote_hearts(vote_count) if include_hearts else ""
    recent_activity = ""
    if include_recent_activity:
        recent_activity_label = _recent_tv_activity_label(show)
        if recent_activity_label:
            recent_activity = f" [COLOR FF00C8FF][{recent_activity_label}][/COLOR]"
    rating = _as_float(show.get("vote_average"), 0.0)
    rating_label = f" [COLOR FFB8860B][{rating:.1f}][/COLOR]" if include_rating else ""

    item = xbmcgui.ListItem(
        label=f"{display_title} [COLOR FFAAAAAA][{year}][/COLOR] {hearts}{rating_label}{recent_activity}".strip()
    )
    plot = show.get('overview', '')
    if include_recent_activity:
        activity_plot = _recent_tv_activity_plot(show)
        if activity_plot and plot:
            plot = f"{activity_plot}\n\n{plot}"
        elif activity_plot:
            plot = activity_plot

    poster = _poster_art_url(show.get('poster_path'))
    fanart = _media_art_url(show.get('backdrop_path')) or poster
    item.setArt({
        'thumb': poster,
        'poster': poster,
        'fanart': fanart
    })
    info = {
        'title': show.get('name') or display_title,
        'originaltitle': show.get('original_name', ''),
        'plot': plot,
        'rating': rating,
        'votes': _as_int(vote_count, 0),
        'premiered': show.get('first_air_date', ''),
        'mediatype': 'tvshow'
    }
    numeric_year = _as_int(year, 0)
    if numeric_year:
        info['year'] = numeric_year
    if genre_name:
        info['genre'] = genre_name
    item.setInfo('video', info)
    return item

def menu_item_tvshows_search(handle):
    _prepare_directory(handle, "Hľadať seriály", "tvshows")
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    search_query = _prompt_catalog_search(params.get('search_query'), 'Hľadať Seriály')
    if not search_query:
        _finish_catalog_directory(handle, succeeded=False, cacheToDisc=False)
        return

    page = max(1, _as_int(params.get('page'), 1))
    try:
        response = _classic_catalog_response(lambda: api.get_tv_search(search_query, page)) if _classic_catalog_enabled() else api.get_tv_search(search_query, page)
    except Exception as ex:
        _catalog_load_failed(handle, "TV series search", ex)
        return

    shows = _filter_tv_shows(response.get('results', []))
    total_pages = response.get('total_pages', 1)
    collections = _media_lists_snapshot()

    for show in shows:
        item = _build_tv_show_item(show, include_vote_count=True)
        _add_collection_context_menu(item, _collection_record_from_tv_show(show), collections)
        url = build_url({'action': 'list_seasons', 'tv_id': show['id']})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    if not shows:
        empty_item = xbmcgui.ListItem(label="Žiadne seriály sa nenašli")
        empty_item.setInfo('video', {'plot': f"Pre názov „{search_query}“ neboli nájdené žiadne seriály."})
        xbmcplugin.addDirectoryItem(handle, "", empty_item, isFolder=False)

    if page < total_pages:
        next_page = page + 1
        item = xbmcgui.ListItem(label=f"Ďalej na stranu {next_page}")
        url = build_url({'action': 'menu_item_tvshows_search', 'page': next_page, 'search_query': search_query})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    _finish_catalog_directory(handle, updateListing=False)

def list_tv_shows_latest(handle):
    _prepare_directory(handle, "Nové seriály", "tvshows")
    page = int(dict(urllib.parse.parse_qsl(sys.argv[2][1:])).get('page', 1))
    try:
        response = _classic_catalog_response(lambda: api.get_tv_latest(page)) if _classic_catalog_enabled() else api.get_tv_latest(page)
    except Exception as ex:
        _catalog_load_failed(handle, "new TV shows", ex)
        return
    shows = _filter_tv_shows(response.get('results', []))
    total_pages = response.get('total_pages', 1)
    collections = _media_lists_snapshot()

    for show in shows:
        item = _build_tv_show_item(show, include_vote_count=True)
        _add_collection_context_menu(item, _collection_record_from_tv_show(show), collections)
        url = build_url({'action': 'list_seasons', 'tv_id': show['id']})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    # Add "Next Page" if more pages are available
    if page < total_pages:
        nextPage = page + 1
        item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
        url = build_url({'action': 'list_tv_shows_latest', 'page': page + 1})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    # Tell Kodi this is a new folder level (updateListing=False)
    _finish_catalog_directory(handle, updateListing=False)

def list_tv_shows_recently_aired(handle, progressive=False):
    _prepare_directory(handle, "Nové série a epizódy", "tvshows")
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    page = _as_int(params.get('page'), 1)
    days = _as_int(params.get('days'), 30)
    if page < 1:
        page = 1
    if days < 1:
        days = 30

    target = sys.argv[0] + sys.argv[2]
    cached = classic_browse.catalog_snapshot(target) if progressive else None
    response = cached if cached is not None else api.get_tv_recently_aired(page, days)
    shows = _filter_tv_shows(response.get('results', []))
    total_pages = response.get('total_pages', 1)
    collections = _media_lists_snapshot()

    for show in shows:
        item = _build_tv_show_item(show, include_vote_count=True, include_recent_activity=True)
        _add_collection_context_menu(item, _collection_record_from_tv_show(show), collections)
        url = build_url({'action': 'list_seasons', 'tv_id': show['id']})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    if page < total_pages:
        nextPage = page + 1
        item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
        url = build_url({'action': 'list_tv_shows_recently_aired', 'page': nextPage, 'days': days})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    _finish_catalog_directory(handle, updateListing=False)
    if progressive:
        classic_browse.acknowledge_catalog(target, response)

def list_tv_shows_popular(handle):
    _prepare_directory(handle, "Populárne seriály", "tvshows")
    page = int(dict(urllib.parse.parse_qsl(sys.argv[2][1:])).get('page', 1))
    try:
        response = _classic_catalog_response(lambda: api.get_tv_popular(page)) if _classic_catalog_enabled() else api.get_tv_popular(page)
    except Exception as ex:
        _catalog_load_failed(handle, "popular TV shows", ex)
        return
    shows = _filter_tv_shows(response.get('results', []))
    total_pages = response.get('total_pages', 1)
    collections = _media_lists_snapshot()

    for show in shows:
        item = _build_tv_show_item(show, include_hearts=False)
        _add_collection_context_menu(item, _collection_record_from_tv_show(show), collections)
        url = build_url({'action': 'list_seasons', 'tv_id': show['id']})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    # Add "Next Page" if more pages are available
    if page < total_pages:
        nextPage = page + 1
        item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
        url = build_url({'action': 'list_tv_shows_popular', 'page': page + 1})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    # Tell Kodi this is a new folder level (updateListing=False)
    _finish_catalog_directory(handle, updateListing=False)

def list_tv_shows_sk(handle):
    _prepare_directory(handle, "Slovenské seriály", "tvshows")
    page = int(dict(urllib.parse.parse_qsl(sys.argv[2][1:])).get('page', 1))
    response = _classic_catalog_response(lambda: api.get_tv_sk(page)) if _classic_catalog_enabled() else api.get_tv_sk(page)
    shows = _filter_tv_shows(response.get('results', []))
    total_pages = response.get('total_pages', 1)
    collections = _media_lists_snapshot()

    for show in shows:
        item = _build_tv_show_item(show, include_hearts=False)
        _add_collection_context_menu(item, _collection_record_from_tv_show(show), collections)
        url = build_url({'action': 'list_seasons', 'tv_id': show['id']})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    # Add "Next Page" if more pages are available
    if page < total_pages:
        nextPage = page + 1
        item = xbmcgui.ListItem(label=f"Ďalej na stranu {nextPage}")
        url = build_url({'action': 'list_tv_shows_sk', 'page': page + 1})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    # Tell Kodi this is a new folder level (updateListing=False)
    _finish_catalog_directory(handle, updateListing=False)

def list_seasons(handle, tv_id):
    _prepare_directory(handle, "Série", "seasons")
    try:
        details = api.get_tv_details(tv_id)
    except Exception as ex:
        xbmc.log(f"[list_seasons] Failed to load TV details for tv_id={tv_id}: {ex}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("TV Show", "Could not load seasons.")
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    tv_title = details.get('name') or details.get('original_name') or f"TV {tv_id}"
    _prepare_directory(handle, tv_title, "seasons")
    poster = _poster_art_url(details.get('poster_path'))
    fanart = _media_art_url(details.get('backdrop_path')) or poster
    collections = _media_lists_snapshot()

    for season in details.get('seasons', []):
        season_number = season.get('season_number')
        if season_number is None:
            xbmc.log(
                f"[list_seasons] Skipping season without season_number for tv_id={tv_id}: keys={sorted(season.keys())}",
                xbmc.LOGWARNING
            )
            continue

        seasonName = season.get('name') or f"Séria {season_number}"
        season_year = _extract_year(season)
        season_poster = _media_art_url(season.get('poster_path')) or poster
        season_fanart = fanart or season_poster
        label = f"{seasonName} [{season_year}]"
        item = xbmcgui.ListItem(label=label)
        item.setInfo('video', {
            'title': seasonName,
            'plot': season.get('overview', ''),
            'tagline': season.get('tagline', ''),
            'season': season_number,
            'tvshowtitle': tv_title,
            'mediatype': 'season'
        })
        item.setArt({
            'thumb': season_poster,
            'poster': season_poster,
            'fanart': season_fanart
        })
        _add_collection_context_menu(
            item,
            _collection_record_from_season(tv_id, tv_title, season_number, seasonName, season_year, season_poster, season_fanart, season),
            collections
        )
        url = build_url({
            'action': 'list_episodes',
            'tv_id': tv_id,
            'season': season_number,
            'tv_title': tv_title,
            'poster': poster,
            'fanart': fanart
        })
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
    xbmcplugin.endOfDirectory(handle)

def list_episodes(handle, tv_id, season, tv_title="", poster="", fanart=""):
    category = f"{tv_title} • Séria {season}" if tv_title else f"Séria {season}"
    _prepare_directory(handle, category, "episodes")
    try:
        episodes = api.get_episodes(tv_id, season, include_streams=False)
    except Exception as ex:
        xbmc.log(f"[list_episodes] Failed to load episodes for tv_id={tv_id} season={season}: {ex}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("TV Show", "Could not load episodes.")
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    collections = _media_lists_snapshot()
    for ep in episodes:
        episode_id = ep.get('id')
        if episode_id is None:
            xbmc.log(
                f"[list_episodes] Skipping episode without id for tv_id={tv_id} season={season}: keys={sorted(ep.keys())}",
                xbmc.LOGWARNING
            )
            continue

        title = _get_episode_title(ep)
        label = title
        item = xbmcgui.ListItem(label=label)
        item.setInfo('video', {
            'title': title,
            'plot': ep.get('description') or ep.get('overview', ''),
            'season': season,
            'episode': _episode_number(ep),
            'aired': ep.get('air_date', ''),
            'tvshowtitle': tv_title,
            'mediatype': 'episode'
        })
        episode_image = _media_art_url(
            ep.get('imageUrl') or ep.get('image_url')
        )
        episode_poster = episode_image or _media_art_url(poster)
        episode_fanart = _media_art_url(fanart) or episode_image or episode_poster
        item.setArt({
            'thumb': episode_poster,
            'poster': episode_poster,
            'fanart': episode_fanart
        })
        _add_collection_context_menu(
            item,
            _collection_record_from_episode(tv_id, season, episode_id, tv_title, title, episode_poster, episode_fanart),
            collections
        )
        url = build_url({
            'action': 'show_streams',
            'tv_id': tv_id,
            'season': season,
            'episode_id': episode_id,
            'episode_number': _episode_number(ep),
            'tv_title': tv_title,
            'poster': episode_poster,
            'fanart': episode_fanart
        })
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
    xbmcplugin.endOfDirectory(handle)

def show_streams_popup(handle, tv_id, season, episode_id, episode_number=None, tv_title="", poster="", fanart="", progressive=False):
    _prepare_directory(handle, "Vybrať stream", "videos")
    # Keep direct callers compatible while the router supplies the episode number.
    if not isinstance(episode_number, int):
        fanart = poster
        poster = tv_title
        tv_title = episode_number or ""
        episode_number = None
    elif episode_number <= 0:
        episode_number = None

    episode = None
    legacy_streams = None
    if episode_number is None:
        episodes = api.get_episodes(tv_id, season, include_streams=False) if progressive else api.get_episodes(tv_id, season)
        episode = next((ep for ep in episodes if ep['id'] == int(episode_id)), None)
        if not episode:
            xbmcgui.Dialog().notification("Streams", "Episode not found.", xbmcgui.NOTIFICATION_ERROR, 2500)
            xbmcplugin.endOfDirectory(handle)
            return
        episode_number = _episode_number(episode)
        legacy_streams = None if progressive else episode.get("streams")

    context = dict(action="show_streams", tv_id=tv_id, season=season, episode_id=episode_id,
                   episode_number=episode_number, tv_title=tv_title, poster=poster, fanart=fanart)
    snapshot = classic_browse.snapshot(context) if progressive else None
    try:
        streams = snapshot["items"] if snapshot is not None else (
            legacy_streams
            if legacy_streams is not None
            else api.get_episode_streams(tv_id, season, episode_number)
        )
    except Exception as ex:
        xbmc.log(
            f"[show_streams] Failed to load streams for tv_id={tv_id} season={season} episode={episode_number}: {ex}",
            xbmc.LOGERROR,
        )
        xbmcgui.Dialog().notification("Streams", "Could not load streams.", xbmcgui.NOTIFICATION_ERROR, 2500)
        xbmcplugin.endOfDirectory(handle)
        return

    streams = list(streams or []) if progressive else _streams_by_size_descending(streams or [])
    if not streams and progressive:
        message = snapshot.get("error") or (tr("Finding streams…") if snapshot.get("discovering") else tr("No streams available for this episode."))
        xbmcplugin.addDirectoryItem(handle, build_url(dict(context, _browse_retry=uuid.uuid4().hex)), xbmcgui.ListItem(label=message), isFolder=True)
        xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
        classic_browse.acknowledge(context, sys.argv[0] + sys.argv[2], streams)
        return
    if not streams:
        xbmcgui.Dialog().notification("Streams", "No streams available for this episode.", xbmcgui.NOTIFICATION_INFO, 2500)
        xbmcplugin.endOfDirectory(handle)
        return

    collections = _media_lists_snapshot()
    for stream in streams:
        display_name = _stream_display_name(stream)
        episode_title = _get_episode_title(episode) if episode else f"S{int(season):02d}E{int(episode_number):02d}"
        history_title = f"{tv_title} - {episode_title}" if tv_title else episode_title
        stream_poster = poster
        stream_fanart = fanart
        label = _classic_stream_label(stream, display_name)
        item = xbmcgui.ListItem(
            label=label,
            label2=_classic_stream_details_label(stream),
        )
        item.setInfo('video', {
            'title': display_name,
            'plot': _stream_metadata_description(stream, history_title),
            'season': season,
            'episode': int(episode_number),
            'tvshowtitle': tv_title,
            'mediatype': 'episode'
        })
        _apply_stream_info(item, stream)
        item.setProperty('IsPlayable', 'true')
        play_query = {
            'action': 'play_movie_stream',
            'stream_id': stream['id'],
            'media_type': 'episode',
            'tv_id': tv_id,
            'season': season,
            'episode_id': episode_id,
            'episode_number': int(episode_number),
            'tv_title': tv_title,
            'episode_title': episode_title,
            'title': history_title,
            'poster': stream_poster,
            'fanart': stream_fanart,
            'stream_name': display_name
        }
        play_query.update(_stream_playback_query_fields(stream))
        url = build_url(play_query)
        download_query = {
            'action': 'download_movie_stream',
            'stream_id': stream['id'],
            'filename': display_name,
            'media_type': 'episode',
            'tv_id': tv_id,
            'season': season,
            'episode_id': episode_id,
            'episode_number': int(episode_number),
            'tv_title': tv_title,
            'episode_title': episode_title,
            'title': history_title,
            'poster': stream_poster,
            'fanart': stream_fanart,
            'plot': (episode or {}).get('description') or (episode or {}).get('overview', ''),
        }
        download_query.update(_stream_playback_query_fields(stream))
        extra_items = _classic_stream_context_items(stream, download_query, play_query)
        _add_collection_context_menu(
            item,
            _collection_record_from_episode_stream(stream, tv_id, season, episode_id, tv_title, episode_title, stream_poster, stream_fanart),
            collections,
            extra_items,
        )
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=False)

    if progressive and (snapshot.get("error") or snapshot.get("metadata_errors")):
        xbmcplugin.addDirectoryItem(handle, build_url(dict(context, _browse_retry=uuid.uuid4().hex)), xbmcgui.ListItem(label=tr("Retry")), isFolder=True)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=not progressive)
    if progressive:
        classic_browse.acknowledge(context, sys.argv[0] + sys.argv[2], streams)

def list_movie_versions(handle, movie_id, movie_title="", year="", poster="", fanart="", params=None, progressive=False):
    _prepare_directory(handle, movie_title or "Vybrať verziu", "videos")
    context = dict(params or {}, action="list_movie_versions", movie_id=movie_id,
                   title=movie_title, year=year, poster=poster, fanart=fanart)
    snapshot = classic_browse.snapshot(context) if progressive else None
    versions = snapshot["items"] if snapshot is not None else _streams_by_size_descending(api.get_movie_versions(movie_id))
    if progressive and not versions:
        message = snapshot.get("error") or (tr("Finding streams…") if snapshot.get("discovering") else tr("No playable versions are available."))
        xbmcplugin.addDirectoryItem(handle, build_url(dict(context, _browse_retry=uuid.uuid4().hex)), xbmcgui.ListItem(label=message), isFolder=True)
    collections = _media_lists_snapshot()
    params = params if isinstance(params, dict) else {}
    for version in versions:
        display_name = _stream_display_name(version)
        label = _classic_stream_label(version, display_name)
        item = xbmcgui.ListItem(
            label=label,
            label2=_classic_stream_details_label(version),
        )
        item.setInfo('video', {
            'title': display_name,
            'plot': _stream_metadata_description(version, movie_title or display_name),
            'year': _as_int(year, 0),
            'mediatype': 'movie'
        })
        _apply_stream_info(item, version)
        item.setProperty('IsPlayable', 'true')
        play_query = {
            'action': 'play_movie_stream',
            'stream_id': version['id'],
            'media_type': 'movie',
            'movie_id': movie_id,
            'title': movie_title or display_name,
            'year': year,
            'poster': poster,
            'fanart': fanart,
            'stream_name': display_name
        }
        play_query.update(_stream_playback_query_fields(version))
        url = build_url(play_query)
        download_query = {
            'action': 'download_movie_stream',
            'stream_id': version['id'],
            'filename': display_name,
            'media_type': 'movie',
            'movie_id': movie_id,
            'title': movie_title or display_name,
            'year': year,
            'poster': poster,
            'fanart': fanart,
            'plot': params.get('plot', ''),
            'genres': params.get('genres', ''),
            'duration': params.get('duration', ''),
            'rating': params.get('rating', ''),
        }
        download_query.update(_stream_playback_query_fields(version))
        extra_items = _classic_stream_context_items(version, download_query, play_query)
        _add_collection_context_menu(
            item,
            _collection_record_from_movie_stream(
                version,
                movie_id,
                movie_title,
                year,
                poster,
                fanart,
                duration=params.get('duration', ''),
                rating=params.get('rating', ''),
                genres=params.get('genres', ''),
            ),
            collections,
            extra_items,
        )
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=False)
    if progressive and versions and (snapshot.get("error") or snapshot.get("metadata_errors")):
        xbmcplugin.addDirectoryItem(handle, build_url(dict(context, _browse_retry=uuid.uuid4().hex)), xbmcgui.ListItem(label=tr("Retry")), isFolder=True)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=not progressive)
    if progressive:
        classic_browse.acknowledge(context, sys.argv[0] + sys.argv[2], versions)

def _normalized_preparation_status(payload, stream_id):
    if not isinstance(payload, dict):
        raise _StreamPreparationFailed(
            tr("TorBox returned an invalid preparation status.")
        )
    status = dict(payload)
    status["id"] = stream_id
    status["stream_id"] = stream_id
    status["provider"] = "TorBox"
    status["availability"] = _stream_availability(status)
    if "availabilityMessage" not in status and status.get("message"):
        status["availabilityMessage"] = status.get("message")
    return status


def _apply_preparation_status(params, status):
    if not isinstance(params, dict) or not isinstance(status, dict):
        return
    params["provider"] = "TorBox"
    params["availability"] = _stream_availability(status)
    params["is_ready"] = "true" if _stream_is_ready(status) else "false"
    progress = _stream_progress_percent(status)
    eta = _stream_eta_seconds(status)
    if progress is not None:
        params["progress_percent"] = str(progress)
    if eta is not None:
        params["eta_seconds"] = str(eta)
    message = _clean_query_value(
        status.get("message") or status.get("availabilityMessage")
    )
    if message:
        params["availability_message"] = message


def _create_stream_progress(status):
    progress_factory = getattr(xbmcgui, "DialogProgress", None)
    if not callable(progress_factory):
        return None
    try:
        progress = progress_factory()
        _state, message = _stream_availability_presentation(status)
        progress.create(tr("Preparing TorBox stream"), message)
        return progress
    except Exception:
        return None


def _update_stream_progress(progress, status):
    if progress is None:
        return
    percent = _stream_progress_percent(status)
    if _stream_is_ready(status):
        percent = 100
    _state, message = _stream_availability_presentation(status)
    if _stream_availability(status) == "stalled":
        message = "{0}\n{1}".format(
            message,
            tr("Waiting for seeds. Cancel to stop waiting."),
        )
    try:
        progress.update(percent if percent is not None else 0, message)
    except Exception:
        pass


def _stream_progress_cancelled(progress):
    if progress is None:
        return False
    for method_name in ("iscanceled", "isCanceled"):
        method = getattr(progress, method_name, None)
        if callable(method):
            try:
                return bool(method())
            except Exception:
                return False
    return False


def _close_stream_progress(progress):
    if progress is None:
        return
    try:
        progress.close()
    except Exception:
        pass


def _wait_for_stream_poll(seconds=STREAM_PREPARATION_POLL_SECONDS):
    monitor_factory = getattr(xbmc, "Monitor", None)
    if callable(monitor_factory):
        try:
            return not monitor_factory().waitForAbort(seconds)
        except Exception:
            pass
    kodi_sleep = getattr(xbmc, "sleep", None)
    if callable(kodi_sleep):
        kodi_sleep(max(1, int(seconds * 1000)))
    else:
        time.sleep(max(0.0, float(seconds)))
    return True


def _ensure_torbox_stream_ready(stream_id, params):
    params = params if isinstance(params, dict) else {}
    if not _stream_is_torbox(params, stream_id):
        return True

    # A cached list entry can outlive a TorBox transfer. Recheck entries that
    # looked ready, but start preparation immediately for known waiting states.
    if _stream_is_ready(params):
        status = _normalized_preparation_status(
            api.get_stream_status(stream_id), stream_id
        )
        _apply_preparation_status(params, status)
        if _stream_is_ready(status):
            return True
    else:
        status = dict(params)
        status["id"] = stream_id
        status["provider"] = "TorBox"

    progress = _create_stream_progress(status)
    try:
        if _stream_progress_cancelled(progress):
            return False

        status = _normalized_preparation_status(
            api.prepare_stream(stream_id), stream_id
        )
        _apply_preparation_status(params, status)

        poll_attempt = 0
        while True:
            _update_stream_progress(progress, status)
            if _stream_is_ready(status):
                return True
            if _stream_availability(status) == "error":
                raise _StreamPreparationFailed(
                    _clean_query_value(
                        status.get("message")
                        or status.get("availabilityMessage")
                    ) or tr("TorBox could not prepare this stream.")
                )
            if _stream_progress_cancelled(progress):
                return False
            poll_seconds = min(
                STREAM_PREPARATION_MAX_POLL_SECONDS,
                STREAM_PREPARATION_POLL_SECONDS * (2 ** min(poll_attempt, 3)),
            )
            waited = (
                _wait_for_stream_poll()
                if poll_seconds == STREAM_PREPARATION_POLL_SECONDS
                else _wait_for_stream_poll(poll_seconds)
            )
            if not waited:
                return False
            poll_attempt += 1
            if _stream_progress_cancelled(progress):
                return False

            status = _normalized_preparation_status(
                api.get_stream_status(stream_id), stream_id
            )
            _apply_preparation_status(params, status)
    finally:
        _close_stream_progress(progress)


def _resolve_playback(stream_id, params=None, notify_errors=True):
    params = params if isinstance(params, dict) else {}
    try:
        if not _ensure_torbox_stream_ready(stream_id, params):
            if notify_errors:
                xbmcgui.Dialog().notification(
                    tr("TorBox"),
                    tr("Stream preparation cancelled."),
                    xbmcgui.NOTIFICATION_INFO,
                    2500,
                )
            return None
        streamUrl = api.get_streams(stream_id)
    except api.ApiError as e:
        xbmc.log(f"[play_movie_stream] HTTP {e.status_code} for stream {stream_id}: {e.message}", xbmc.LOGERROR)
        if notify_errors:
            xbmcgui.Dialog().ok(tr("Stream error"), e.message)
        return None
    except _StreamPreparationFailed as e:
        xbmc.log(
            f"[play_movie_stream] TorBox preparation failed for stream {stream_id}: {e}",
            xbmc.LOGERROR,
        )
        if notify_errors:
            xbmcgui.Dialog().ok(tr("Stream error"), str(e))
        return None
    except URLError as e:
        xbmc.log(f"[play_movie_stream] URL error for stream {stream_id}: {e.reason}", xbmc.LOGERROR)
        if notify_errors:
            xbmcgui.Dialog().ok(tr("Stream error"), "Network issue while resolving stream.")
        return None
    except Exception as e:
        xbmc.log(f"[play_movie_stream] Unexpected error for stream {stream_id}: {e}", xbmc.LOGERROR)
        if notify_errors:
            xbmcgui.Dialog().ok(tr("Stream error"), "Could not resolve stream.")
        return None

    if not streamUrl:
        return None

    _record_watch_history(stream_id, params)
    title = params.get("title") or params.get("stream_name") or "Media Hub"
    item = xbmcgui.ListItem(label=title, path=streamUrl)
    item.setInfo("video", {
        "title": title,
        "year": _as_int(params.get("year"), 0),
        "season": _as_int(params.get("season"), 0),
        "mediatype": "episode" if params.get("media_type") == "episode" else "movie"
    })
    item.setArt({
        "thumb": params.get("poster", ""),
        "poster": params.get("poster", ""),
        "fanart": params.get("fanart", "") or params.get("poster", "")
    })
    item.setProperty("IsPlayable", "true")
    subtitle_path = _subtitle_path_for_playback(stream_id, params)
    external_subtitle = external_subtitles.is_external_path(subtitle_path)
    force_ai = _clean_query_value(
        params.get("force_ai_subtitle")
    ).lower() == "true"
    native_first = (
        _addon_bool_setting("subtitle_native_first", True) and not force_ai
    )
    if subtitle_path:
        # With native-first enabled, wait until Kodi exposes the actual
        # embedded streams. The playback monitor will select a full SK/CZ
        # track or attach this AI result when no such track exists.
        if not native_first:
            set_subtitles = getattr(item, "setSubtitles", None)
            if callable(set_subtitles):
                set_subtitles([subtitle_path])
        if external_subtitle:
            language = _external_subtitle_language_for_playback(
                stream_id, params
            )
            item.setProperty("MediaHub.ExternalSubtitle", "true")
            item.setProperty("MediaHub.ExternalSubtitleLanguage", language)
            item.setProperty(
                "MediaHub.ExternalSubtitleLabel",
                "OpenSubtitles {0}".format("SK" if language == "sk" else "CZ"),
            )
        else:
            item.setProperty("MediaHub.AiSubtitle", "true")
            item.setProperty("MediaHub.AiSubtitleLanguage", "sk")
            item.setProperty("MediaHub.AiSubtitleLabel", tr("AI-translated Slovak"))
    try:
        window = xbmcgui.Window(10000)
        window.setProperty("MediaHub.StreamId", str(stream_id))
        window.setProperty("MediaHub.FallbackSubtitlePath", subtitle_path or "")
        window.setProperty(
            "MediaHub.AiSubtitlePath",
            "" if external_subtitle else (subtitle_path or ""),
        )
        window.setProperty(
            "MediaHub.NativeFirstEnabled", "true" if native_first else "false"
        )
        window.setProperty(
            "MediaHub.NativeSubtitleIndexes",
            _clean_query_value(params.get("native_subtitle_indexes")),
        )
        window.setProperty(
            "MediaHub.NativeSubtitleMetadataKnown",
            "true"
            if _clean_query_value(
                params.get("subtitle_metadata_complete")
            ).lower() == "true"
            else "false",
        )
        window.setProperty(
            "MediaHub.NativePreferred",
            "true"
            if (
                native_first and
                _clean_query_value(params.get("native_preferred")).lower() == "true"
            )
            else "false",
        )
    except Exception:
        pass
    return streamUrl, item


def _subtitle_path_for_playback(stream_id, params=None):
    params = params if isinstance(params, dict) else {}
    force = _clean_query_value(params.get("force_ai_subtitle")).lower() == "true"
    if not force and not _addon_bool_setting("subtitle_auto_attach", True):
        return ""
    if force:
        return _completed_ai_subtitle_path(stream_id, params)
    if _clean_query_value(params.get("native_preferred")).lower() == "true":
        return ""

    availability = _external_availability_for_playback(stream_id, params)
    external_path = external_subtitles.download_for_playback(
        stream_id,
        params,
        availability,
    )
    if external_path:
        return external_path
    return _completed_ai_subtitle_path(stream_id, params)


def _completed_ai_subtitle_path(stream_id, params=None):
    params = params if isinstance(params, dict) else {}
    record = None
    job_id = _clean_query_value(params.get("subtitle_job_id"))
    if job_id:
        record = _subtitle_db().get(job_id)
    if not record:
        record = _subtitle_job_for_stream(stream_id, params)
    if not record or record.get("status") != "completed":
        return ""
    path = _clean_query_value(record.get("subtitle_path"))
    return path if path and xbmcvfs.exists(path) else ""


def _external_availability_for_playback(stream_id, params=None):
    params = params if isinstance(params, dict) else {}
    status = _clean_query_value(params.get("external_subtitle_status")).lower()
    file_id = _clean_query_value(params.get("external_subtitle_file_id"))
    if status == "available" and file_id:
        return {
            "status": "available",
            "language": _clean_query_value(
                params.get("external_subtitle_language")
            ),
            "fileId": file_id,
            "release": _clean_query_value(params.get("external_subtitle_release")),
            "matchConfidence": params.get(
                "external_subtitle_match_confidence"
            ),
        }
    return external_subtitles.get(stream_id, params)


def _external_subtitle_language_for_playback(stream_id, params=None):
    availability = _external_availability_for_playback(stream_id, params)
    language = _clean_query_value(availability.get("language")).lower()
    return "sk" if language in ("sk", "slk", "slo", "slovak") else "cs"


def _play_modern_target(target):
    params = _modern_target_params(target)
    action = params.get("action")
    if action not in ("play_movie_stream", "resume_history_stream"):
        return False
    picker_query = (
        _history_stream_picker_query(params)
        if action == "resume_history_stream" else None
    )
    if action == "resume_history_stream":
        remembered_stream, verified = _remembered_history_stream(params)
        if verified and remembered_stream is None:
            if picker_query is not None:
                return {
                    "command": "browse",
                    "target": build_url(picker_query),
                }
            return None
        if remembered_stream is not None:
            params["stream_name"] = _stream_display_name(remembered_stream)
            params.update(_stream_playback_query_fields(remembered_stream))
        params["action"] = "play_movie_stream"
    resume_choice = 1 if params.get("resume_mode") == "beginning" else 0
    resume_position = None
    if params.get("resume_mode") == "resume":
        try:
            resume_position = float(params.get("resume_seconds") or 0) or None
        except (TypeError, ValueError):
            resume_position = None
        if resume_position is None:
            try:
                resume_position = _history_resume_position(
                    watch_history_db.list().get(_history_id(params), {})
                )
            except Exception:
                resume_position = None
    resolved = _resolve_playback(
        params.get("stream_id"), params,
        notify_errors=picker_query is None,
    )
    if not resolved:
        if picker_query is not None:
            return {
                "command": "browse",
                "target": build_url(picker_query),
            }
        return None
    stream_url, item = resolved
    if resume_position is not None:
        # Let Kodi open the stream at the requested offset instead of showing
        # the first frames and correcting the position after playback starts.
        item.setProperty("StartOffset", str(resume_position))
        item.setProperty("ResumeTime", str(resume_position))
    elif resume_choice == 1:
        item.setProperty("StartOffset", "0")
        item.setProperty("ResumeTime", "0")
    if resume_choice == 1:
        _clear_modern_resume_position(params)
    player = xbmc.Player()
    try:
        register_playback(playback_context(
            params.get("stream_id"), _history_id(params), params, "modern"
        ))
    except Exception as exc:
        xbmc.log("[MediaHub playback] Could not register playback: {0}".format(exc), xbmc.LOGWARNING)
    player.play(stream_url, item)

    # Keep the Media Hub loading veil active until Kodi has accepted the
    # player, rather than handing control back while Estuary is still loading.
    for _ in range(40):
        try:
            if player.isPlayingVideo():
                break
        except Exception:
            break
        time.sleep(0.25)

    def seek_after_start():
        # Kodi can reset a seek while the stream is opening, so retry until the
        # player reports that the requested position has taken effect.
        for _ in range(40):
            try:
                if player.isPlayingVideo():
                    if resume_choice == 1:
                        player.seekTime(0)
                        break
                    elif resume_position is not None:
                        player.seekTime(resume_position)
                        time.sleep(0.5)
                        if abs(float(player.getTime()) - resume_position) <= 5:
                            break
                    else:
                        break
            except Exception:
                break
            time.sleep(0.5)

    threading.Thread(target=seek_after_start, daemon=True).start()
    return True


def play_movie_stream(handle, stream_id, params=None):
    params = params if isinstance(params, dict) else {}
    history_id = _history_id(dict(params, stream_id=stream_id))
    try:
        resume_position = _history_resume_position(
            watch_history_db.list().get(history_id, {})
        )
    except Exception:
        resume_position = None
    resolved = _resolve_playback(stream_id, params)
    if resolved:
        _stream_url, item = resolved
        if resume_position is not None:
            item.setProperty("StartOffset", str(resume_position))
            item.setProperty("ResumeTime", str(resume_position))
        try:
            register_playback(playback_context(
                stream_id, history_id, params, "classic"
            ))
        except Exception as exc:
            xbmc.log("[MediaHub playback] Could not register playback: {0}".format(exc), xbmc.LOGWARNING)
        xbmcplugin.setResolvedUrl(handle, True, listitem=item)
    else:
        xbmcplugin.setResolvedUrl(handle, False, listitem=xbmcgui.ListItem())


def show_next_episode_classic(handle, params):
    resolved = _next_playable_episode(params, fast=True)
    if resolved is None:
        _prepare_directory(handle, tr("Next episode"), "videos")
        xbmcplugin.addDirectoryItem(
            handle, "", xbmcgui.ListItem(label=tr("You are caught up")),
            isFolder=False,
        )
        xbmcplugin.endOfDirectory(handle)
        return
    episode, season, _streams = resolved
    show_streams_popup(
        handle, _as_int(params.get("tv_id"), 0), season,
        _as_int(episode.get("id"), 0), _episode_number(episode),
        params.get("tv_title") or "", params.get("poster") or "",
        params.get("fanart") or "", progressive=True,
    )

def download_movie_stream(stream_id, filename, params=None):
    # Queue only stable stream metadata. Signed URLs are deliberately obtained
    # by the worker immediately before each attempt and are never persisted.
    safe_filename = _safe_download_filename(filename)

    addon = xbmcaddon.Addon()
    default_dir = addon.getSetting("download_path") or ""
    save_dir = default_dir

    if not save_dir:
        save_dir = xbmcgui.Dialog().browse(0, "Choose save directory", "files", "", False, False, "")
        if not save_dir:
            return

    if not xbmcvfs.exists(save_dir):
        xbmcvfs.mkdirs(save_dir)

    # VFS paths (content://, smb://, storage://) can report missing; don't block on exists.
    if not xbmcvfs.exists(save_dir) and not _is_vfs_path(save_dir):
        xbmcgui.Dialog().ok("Download", "Download folder is not accessible.")
        return

    filepath = _join_path(save_dir, safe_filename)
    download_id = str(uuid.uuid4())
    created_at = now_iso()
    is_torbox = _stream_is_torbox(params, stream_id)
    needs_preparation = is_torbox and not _stream_is_ready(params)
    offline_request = _clean_query_value((params or {}).get("offline")).lower() == "true"
    record = {
        "id": download_id,
        "stream_id": stream_id,
        "filename": safe_filename,
        "path": filepath,
        "status": "waiting_preparation" if needs_preparation and offline_request else "queued",
        "progress": 0,
        "bytes_total": None,
        "bytes_done": 0,
        "attempts": 0,
        "created_at": created_at,
        "updated_at": created_at
    }
    record.update(_download_media_metadata(params))

    try:
        inserted = db.add_with_unique_path(record)
    except Exception as ex:
        xbmc.log(f"[download_movie_stream] Could not queue stream {stream_id}: {ex}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Download", "Could not add the download to the queue.")
        return

    if needs_preparation and offline_request:
        try:
            _queue_torbox_preparation(stream_id, params, inserted.get("id"))
        except Exception as ex:
            db.update(inserted.get("id"), {
                "status": "failed",
                "error": str(ex),
                "error_code": "torbox_preparation_queue_failed",
            })
            xbmcgui.Dialog().ok("Download", "Could not start TorBox preparation.")
            return

    xbmcgui.Dialog().notification(
        "Queued",
        inserted.get("filename", safe_filename),
        xbmcgui.NOTIFICATION_INFO,
        2500
    )


def _queue_torbox_preparation(stream_id, params=None, download_id=None):
    params = dict(params or {})
    existing = preparations_db.find_stream(stream_id)
    if existing:
        if download_id and not existing.get("download_id"):
            preparations_db.update(existing["id"], {"download_id": download_id})
        if existing.get("status") == "ready" and download_id:
            db.update(download_id, {
                "status": "queued",
                "queue_position": 0,
                "updated_at": now_iso(),
                "preparation_id": existing["id"],
            })
        elif existing.get("status") in ("failed", "canceled"):
            preparations_db.update(
                existing["id"],
                {
                    "status": "queued",
                    "message": "",
                    "progress": 0,
                    "eta_seconds": None,
                    "poll_attempts": 0,
                    "next_poll_at": 0,
                    "updated_at": now_iso(),
                    **({"download_id": download_id} if download_id else {}),
                },
            )
        return existing
    now = now_iso()
    record = {
        "id": str(uuid.uuid4()),
        "stream_id": str(stream_id),
        "status": "queued",
        "progress": 0,
        "eta_seconds": None,
        "message": "",
        "download_id": download_id,
        "created_at": now,
        "updated_at": now,
        "poll_attempts": 0,
        "next_poll_at": 0,
        "title": params.get("title") or params.get("stream_name") or "Stream",
        "filename": params.get("filename") or params.get("stream_name") or "Stream",
        "media_type": params.get("media_type", "movie"),
        "poster": params.get("poster", ""),
        "fanart": params.get("fanart", ""),
        "play_params": {
            key: value for key, value in params.items()
            if key not in ("action", "offline")
        },
    }
    return preparations_db.add(record)


def prepare_stream_background(stream_id, params=None):
    try:
        _queue_torbox_preparation(stream_id, params)
        xbmcgui.Dialog().notification(
            tr("TorBox"), tr("Preparation started"),
            xbmcgui.NOTIFICATION_INFO, 2500
        )
    except Exception as ex:
        xbmc.log(f"[prepare_stream_background] Could not queue {stream_id}: {ex}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification(
            tr("TorBox"), tr("Could not start preparation"),
            xbmcgui.NOTIFICATION_ERROR, 2500
        )


def cancel_preparation(preparation_id):
    record = preparations_db.get(preparation_id)
    if not record:
        return
    updated = preparations_db.update(
        preparation_id,
        {"status": "canceled", "updated_at": now_iso()},
        expected_statuses=("queued", "preparing", "stalled"),
    )
    if updated and record.get("download_id"):
        db.transition(
            record["download_id"], "waiting_preparation",
            {"status": "canceled", "updated_at": now_iso()},
        )


def retry_preparation(preparation_id):
    record = preparations_db.get(preparation_id)
    updated = preparations_db.update(
        preparation_id,
        {
            "status": "queued",
            "message": "",
            "progress": 0,
            "eta_seconds": None,
            "poll_attempts": 0,
            "next_poll_at": 0,
        },
        expected_statuses=("failed", "canceled", "stalled"),
    )
    if updated and record and record.get("download_id"):
        db.update(record["download_id"], {
            "status": "waiting_preparation",
            "error": "",
            "error_code": "",
            "updated_at": now_iso(),
        })


def show_preparation_actions(preparation_id):
    record = preparations_db.get(preparation_id)
    if not record:
        return
    status = record.get("status")
    actions = []
    if status in ("queued", "preparing", "stalled"):
        actions.append((tr("Cancel preparation"), cancel_preparation))
    if status in ("failed", "canceled", "stalled"):
        actions.append((tr("Retry preparation"), retry_preparation))
    if status == "ready":
        params = dict(record.get("play_params") or {})
        params.update({"availability": "ready", "is_ready": "true"})
        _play_modern_target(build_url(dict(
            params, action="play_movie_stream", stream_id=record.get("stream_id", "")
        )))
        return
    if not actions:
        return
    selected = xbmcgui.Dialog().select(record.get("title", "TorBox"), [label for label, _ in actions])
    if 0 <= selected < len(actions):
        actions[selected][1](preparation_id)

def show_downloads_menu(handle):
    _prepare_directory(handle, "Sťahovanie", "videos")
    try:
        xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_UNSORTED)
    except Exception:
        pass

    addon = xbmcaddon.Addon()
    max_attempts = max(1, int(addon.getSetting("download_retry_limit") or 0) + 1)
    data = _list_downloads_normalized()
    queue_total = _queue_count(data)

    clear_item = xbmcgui.ListItem(label="Vymazať históriu sťahovania")
    clear_item.setInfo('video', {
        'plot': 'Vymazať dokončené, zrušené a zlyhané záznamy bez čiastočných súborov '
                '(aktívne sťahovania a súbory zostanú zachované).'
    })
    clear_url = build_url({'action': 'clear_download_history'})
    xbmcplugin.addDirectoryItem(handle, clear_url, clear_item, isFolder=False)

    for preparation in preparations_db.list().values():
        prep_status = preparation.get("status", "queued")
        progress = _as_int(preparation.get("progress"), 0)
        title = preparation.get("title") or preparation.get("filename") or "TorBox stream"
        prep_filename = _clean_query_value(
            preparation.get("filename") or preparation.get("stream_name")
        )
        prep_item = xbmcgui.ListItem(
            label=f"[TorBox {prep_status} {progress}%] {title}",
            label2=prep_filename,
        )
        prep_item.setInfo("video", {
            "title": title,
            "plot": preparation.get("message") or "TorBox provider preparation",
        })
        prep_item.setArt(_download_art(preparation))
        prep_url = build_url({
            "action": "show_preparation_actions",
            "id": preparation.get("id", ""),
        })
        xbmcplugin.addDirectoryItem(handle, prep_url, prep_item, isFolder=False)

    downloading_items = sorted(
        [item for item in data.values() if item.get("status") in ACTIVE_DOWNLOAD_STATUSES],
        key=lambda x: (_queue_position(x), x.get("updated_at") or "", x.get("created_at") or "")
    )
    queued_items = sorted(
        [item for item in data.values() if item.get("status") in QUEUE_STATUSES],
        key=lambda x: (_queue_position(x), x.get("created_at") or "", x.get("id") or "")
    )
    history_items = sorted(
        [item for item in data.values() if item.get("status") not in ACTIVE_DOWNLOAD_STATUSES + QUEUE_STATUSES + ("waiting_preparation",)],
        key=lambda x: x.get("updated_at") or x.get("created_at") or "",
        reverse=True
    )
    items = downloading_items + queued_items + history_items

    for it in items:
        download_id = it.get("id")
        status = it.get("status", "?")
        progress = it.get("progress", 0) or 0
        filename = it.get("filename", "Unknown")
        path = it.get("path", "")
        attempts = it.get("attempts", 0) or 0
        error = it.get("error")
        position = _as_int(it.get("queue_position"), 0)
        bytes_done = it.get("bytes_done")
        bytes_total = it.get("bytes_total")
        title = _download_display_title(it)
        media_meta = _download_media_meta(it)
        art = _download_art(it)

        if status == "downloading":
            label = f"[Now {progress}%] {filename}"
        elif status == "pausing":
            label = f"[Pausing {progress}%] {filename}"
        elif status == "canceling":
            label = f"[Canceling {progress}%] {filename}"
        elif status == "repairing":
            label = f"[Repairing] {filename}"
        elif status == "finalizing":
            label = f"[Finalizing] {filename}"
        elif status == "queued":
            label = f"#{position} [Queued] {filename}"
        elif status == "paused":
            label = f"#{position} [Paused {progress}%] {filename}"
        elif status == "waiting_retry":
            label = f"#{position} [Waiting to retry {progress}%] {filename}"
        elif status == "complete":
            label = f"[[COLOR FF90EE90]Complete[/COLOR]] {filename}"
        elif status == "failed":
            label = f"[[COLOR FFFF9090]Failed[/COLOR]] {filename}"
        elif status == "canceled":
            label = f"[Canceled] {filename}"
        else:
            label = f"[{status}] {filename}"

        display_label = label.replace(filename, title, 1) if title != filename else label
        li = xbmcgui.ListItem(label=display_label, label2=filename)
        plot_lines = [
            f"Status: {status}",
            f"Progress: {progress}%",
            f"Attempts: {attempts}/{max_attempts}"
        ]
        if media_meta:
            plot_lines.insert(0, media_meta)
        if it.get("plot"):
            plot_lines.insert(0, _clean_query_value(it.get("plot")))
        if filename:
            plot_lines.insert(0, f"File name: {filename}")
        if status in QUEUE_STATUSES and position:
            plot_lines.append(f"Queue position: {position}/{queue_total}")
        elif status in ACTIVE_DOWNLOAD_STATUSES:
            plot_lines.append("Queue position: downloading now")
        if bytes_total:
            plot_lines.append(f"Downloaded: {_format_bytes(bytes_done)} / {_format_bytes(bytes_total)}")
        elif bytes_done:
            plot_lines.append(f"Downloaded: {_format_bytes(bytes_done)}")
        if path:
            plot_lines.append(f"Path: {path}")
        if error:
            plot_lines.append(f"Error: {error}")
        if status == "waiting_retry" and it.get("next_attempt_at"):
            plot_lines.append(f"Next retry: {it.get('next_attempt_at')}")
        info = {
            'title': title,
            'plot': "\n\n".join(plot_lines),
            'mediatype': 'episode' if it.get("media_type") == 'episode' else 'movie',
        }
        year = _as_int(it.get("year"), 0)
        if year:
            info['year'] = year
        if it.get("genres"):
            info['genre'] = _clean_query_value(it.get("genres"))
        rating = _as_float(it.get("rating"), 0.0)
        if rating:
            info['rating'] = rating
        if it.get("media_type") == 'episode':
            info.update({
                'tvshowtitle': _clean_query_value(it.get("tv_title")),
                'season': _as_int(it.get("season"), 0),
                'episode': _as_int(it.get("episode_number"), 0),
            })
        li.setInfo('video', info)
        li.setArt(art)

        actions = _download_action_queries(it, queue_total)
        if actions:
            li.addContextMenuItems([
                (label, f"RunPlugin({build_url(query)})")
                for label, query in actions
            ])

        url = ""
        if status == "complete" and path and xbmcvfs.exists(path):
            url = path
            li.setProperty("IsPlayable", "true")
        elif actions:
            url = build_url({'action': 'show_download_actions', 'id': download_id})

        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=False)

    xbmcplugin.endOfDirectory(handle)

def _refresh_downloads_container():
    xbmc.executebuiltin("Container.Refresh")

def _part_path(record):
    staging_path = record.get("staging_path")
    if staging_path:
        return staging_path
    path = record.get("path")
    return f"{path}.part" if path else ""

def _part_size(record):
    part = _part_path(record)
    if not part:
        return 0
    try:
        if not xbmcvfs.exists(part):
            return 0
        return xbmcvfs.Stat(part).st_size()
    except Exception:
        return 0


def _part_exists(record):
    part = _part_path(record)
    if not part:
        return False
    try:
        return bool(xbmcvfs.exists(part))
    except Exception:
        return False


def _delete_part_file(record):
    part = _part_path(record)
    if not part:
        return True
    try:
        if not xbmcvfs.exists(part):
            return True
        deleted = xbmcvfs.delete(part)
        return bool(deleted) or not xbmcvfs.exists(part)
    except Exception:
        return False


def _finalization_marker_bytes(reservation_token):
    try:
        token = str(uuid.UUID(str(reservation_token)))
    except (TypeError, ValueError, AttributeError):
        return None
    return FINALIZATION_MARKER_PREFIX + token.encode("ascii") + b"\n"


def _delete_owned_finalization_marker(record):
    marker = _finalization_marker_bytes(
        record.get("finalization_reservation_token")
    )
    path = record.get("path")
    if marker is None or not path:
        return True
    try:
        local = str(xbmcvfs.translatePath(path) or "")
    except Exception:
        local = str(path)
    if not local or _is_vfs_path(local):
        return True
    if not os.path.lexists(local):
        return True

    flags = os.O_RDONLY | getattr(os, "O_BINARY", 0)
    flags |= getattr(os, "O_NOFOLLOW", 0)
    descriptor = None
    try:
        descriptor = os.open(local, flags)
        file_stat = os.fstat(descriptor)
        if not stat.S_ISREG(file_stat.st_mode) or file_stat.st_size != len(marker):
            return False
        content = b""
        while len(content) <= len(marker):
            chunk = os.read(descriptor, len(marker) + 1 - len(content))
            if not chunk:
                break
            content += chunk
        if content != marker:
            return False
    except OSError:
        return False
    finally:
        if descriptor is not None:
            try:
                os.close(descriptor)
            except OSError:
                pass

    try:
        os.unlink(local)
        return not os.path.lexists(local)
    except OSError:
        return False

def _progress_from_part(record, default=0):
    part_size = _part_size(record)
    total = _as_int(record.get("bytes_total"), 0)
    if part_size > 0 and total > 0:
        return part_size, int(100 * part_size / total)
    return part_size, default if part_size > 0 else 0

def _run_download_action(query):
    action = query.get("action")
    download_id = query.get("id")

    if action == "move_download":
        move_download(download_id, query.get("direction"))
    elif action == "pause_download":
        pause_download(download_id)
    elif action == "resume_download":
        resume_download(download_id)
    elif action == "cancel_download":
        cancel_download(download_id)
    elif action == "retry_download":
        retry_download(download_id)
    elif action == "verify_download":
        verify_download(download_id)
    elif action == "repair_download":
        repair_download(download_id)
    elif action == "remove_download_history":
        remove_download_history(download_id)

def show_download_actions(download_id):
    data = _list_downloads_normalized()
    record = data.get(download_id)
    if not record:
        xbmcgui.Dialog().notification("Downloads", "Download not found", xbmcgui.NOTIFICATION_ERROR, 2000)
        return

    actions = _download_action_queries(record, _queue_count(data))
    if not actions:
        xbmcgui.Dialog().notification("Downloads", "No actions available", xbmcgui.NOTIFICATION_INFO, 2000)
        return

    choice = xbmcgui.Dialog().select(record.get("filename", "Download"), [label for label, _ in actions])
    if choice < 0:
        return

    _run_download_action(actions[choice][1])

def move_download(download_id, direction):
    if direction not in ("up", "down", "top", "bottom"):
        return

    def op(data):
        _normalize_queue_positions(data)
        items = [
            (item_id, record)
            for item_id, record in data.items()
            if record.get("status") in QUEUE_STATUSES
        ]
        items.sort(key=lambda item: (_queue_position(item[1]), item[1].get("created_at") or "", item[0]))

        index = next((i for i, (item_id, _) in enumerate(items) if item_id == download_id), None)
        if index is None:
            return None

        item = items.pop(index)
        if direction == "up":
            target = max(0, index - 1)
        elif direction == "down":
            target = min(len(items), index + 1)
        elif direction == "top":
            target = 0
        else:
            target = len(items)

        items.insert(target, item)
        updated_at = now_iso()
        for position, (_, record) in enumerate(items, start=1):
            record["queue_position"] = position
            record["updated_at"] = updated_at

        return item[1].get("filename", "Download")

    filename = db.mutate(op)
    if filename:
        xbmcgui.Dialog().notification("Downloads", f"Reordered {filename}", xbmcgui.NOTIFICATION_INFO, 1500)
    _refresh_downloads_container()

def pause_download(download_id):
    updated = None
    for _ in range(2):
        record = db.list().get(download_id)
        if not record:
            break
        status = record.get("status")
        target = {
            "queued": "paused",
            "waiting_retry": "paused",
            "downloading": "pausing"
        }.get(status)
        if not target:
            break
        updated = db.transition(download_id, status, {
            "status": target,
            "error": None,
            "error_code": None,
            "updated_at": now_iso()
        }, expected_revision=record.get("revision"))
        if updated:
            break

    if updated:
        title = "Pause requested" if updated.get("status") == "pausing" else "Paused"
        xbmcgui.Dialog().notification(title, updated.get("filename", "Download"), xbmcgui.NOTIFICATION_INFO, 2000)
    _refresh_downloads_container()

def resume_download(download_id):
    record = db.list().get(download_id)
    if not record or record.get("status") != "paused":
        _refresh_downloads_container()
        return
    updated = db.transition(download_id, "paused", {
        "status": "queued",
        "error": None,
        "error_code": None,
        "next_attempt_at": None,
        "owner_token": None,
        "updated_at": now_iso()
    }, expected_revision=record.get("revision"))
    if updated:
        xbmcgui.Dialog().notification("Queued", updated.get("filename", "Download"), xbmcgui.NOTIFICATION_INFO, 2000)
    _refresh_downloads_container()

def retry_download(download_id):
    record = db.list().get(download_id)
    if not record or record.get("status") not in ("failed", "canceled"):
        _refresh_downloads_container()
        return
    if record.get("error_code") == VERIFICATION_ERROR_CODE:
        repair_download(download_id)
        return

    bytes_done, progress = _progress_from_part(record, record.get("progress", 0) or 0)
    updated = db.transition(download_id, record.get("status"), {
        "status": "queued",
        "queue_position": _next_queue_position(db.list()),
        "error": None,
        "error_code": None,
        "attempts": 0,
        "next_attempt_at": None,
        "owner_token": None,
        "bytes_done": bytes_done,
        "progress": progress,
        "updated_at": now_iso()
    }, expected_revision=record.get("revision"))
    if updated:
        xbmcgui.Dialog().notification("Queued", updated.get("filename", "Download"), xbmcgui.NOTIFICATION_INFO, 2000)
    _refresh_downloads_container()

def cancel_download(download_id):
    record = db.list().get(download_id)
    if not record:
        _refresh_downloads_container()
        return

    initial_status = record.get("status")
    cancellable_statuses = (
        "queued",
        "waiting_retry",
        "paused",
        "failed",
        "downloading",
        "pausing"
    )
    if initial_status not in cancellable_statuses:
        _refresh_downloads_container()
        return

    part_size = _part_size(record)
    if _part_exists(record):
        partial_message = f"Partial data ({_format_bytes(part_size)}) will be deleted."
    else:
        partial_message = "There is no partial file to keep."
    if not xbmcgui.Dialog().yesno(
        "Cancel download",
        f"Cancel {record.get('filename', 'this download')}?\n\n{partial_message}",
        yeslabel="Cancel download",
        nolabel="Keep downloading"
    ):
        return

    cleanup_token = None
    updated = None
    was_active = False
    for _ in range(4):
        current = db.list().get(download_id)
        if not current:
            break
        status = current.get("status")
        if status == "canceling":
            updated = current
            was_active = bool(current.get("owner_token"))
            break
        if status not in cancellable_statuses:
            break

        was_active = status in ("downloading", "pausing")
        patch = {
            "status": "canceling",
            "queue_position": None,
            "next_attempt_at": None,
            "updated_at": now_iso()
        }
        if not was_active:
            cleanup_token = str(uuid.uuid4())
            patch.update({
                "owner_token": cleanup_token,
                "owner_worker_id": "ui-cleanup",
                "owner_heartbeat_at": now_iso(),
                "attempt_id": cleanup_token
            })
        updated = db.transition(
            download_id,
            status,
            patch,
            expected_revision=current.get("revision")
        )
        if updated:
            break

    if not updated:
        _refresh_downloads_container()
        return
    if was_active or cleanup_token is None:
        xbmcgui.Dialog().notification(
            "Cancel requested",
            updated.get("filename", "Download"),
            xbmcgui.NOTIFICATION_INFO,
            2000
        )
        _refresh_downloads_container()
        return

    partial_removed = _delete_part_file(updated)
    marker_removed = _delete_owned_finalization_marker(updated)
    finalization_path = updated.get("finalization_path")
    upload_removed = True
    if finalization_path:
        try:
            upload_removed = (
                not xbmcvfs.exists(finalization_path)
                or bool(xbmcvfs.delete(finalization_path))
                or not xbmcvfs.exists(finalization_path)
            )
        except Exception:
            upload_removed = False
    removed = partial_removed and upload_removed and marker_removed
    verification_error = updated.get("error_code") == VERIFICATION_ERROR_CODE
    finalized = db.update_owned(
        download_id,
        cleanup_token,
        {
            "status": "canceled",
            "bytes_done": 0 if removed else _part_size(updated),
            "progress": 0 if removed else updated.get("progress", 0),
            "owner_token": None,
            "owner_worker_id": None,
            "owner_heartbeat_at": None,
            "attempt_id": None,
            "error": (
                updated.get("error")
                if verification_error
                else None if removed else "Canceled, but some partial data could not be deleted."
            ),
            "error_code": (
                VERIFICATION_ERROR_CODE
                if verification_error
                else None if removed else "storage"
            ),
            "cleanup_pending": not removed,
            "finalization_path": None if upload_removed else finalization_path,
            "finalization_reservation_token": (
                None
                if marker_removed
                else updated.get("finalization_reservation_token")
            ),
            "updated_at": now_iso()
        },
        expected_statuses=("canceling",)
    )
    if finalized and removed:
        xbmcgui.Dialog().notification("Canceled", "Download canceled", xbmcgui.NOTIFICATION_INFO, 2000)
    elif finalized:
        xbmcgui.Dialog().ok(
            "Download canceled",
            "Canceled, but some partial data could not be deleted. The history record was kept for cleanup."
        )
    _refresh_downloads_container()


def _final_file_size(record):
    path = record.get("path")
    if not path:
        return None
    try:
        return int(xbmcvfs.Stat(path).st_size())
    except Exception:
        return None


def _authoritative_download_metadata(record, dialog_title):
    stream_id = record.get("stream_id")
    if not stream_id:
        xbmcgui.Dialog().ok(
            dialog_title,
            "This legacy record has no stream ID, so its expected size cannot be refreshed safely."
        )
        return None
    try:
        ticket = api.get_download_metadata(stream_id)
    except Exception as ex:
        xbmc.log(
            f"[downloads] Could not refresh verification metadata for {stream_id}: {ex}",
            xbmc.LOGERROR
        )
        xbmcgui.Dialog().ok(
            dialog_title,
            "Could not retrieve authoritative file metadata. Check the connection and try again."
        )
        return None
    return ticket


def _recognized_hash(value):
    if not isinstance(value, str) or not value.strip():
        return None
    text = value.strip().lower()
    if ":" in text:
        algorithm, digest = text.split(":", 1)
        algorithm = algorithm.replace("-", "")
    elif len(text) == 64:
        algorithm, digest = "sha256", text
    elif len(text) == 32:
        algorithm, digest = "md5", text
    else:
        return None
    if algorithm not in hashlib.algorithms_available:
        return None
    if not digest or any(character not in "0123456789abcdef" for character in digest):
        return None
    return algorithm, digest


def _file_hash(path, algorithm, heartbeat=None):
    digest = hashlib.new(algorithm)
    handle = None
    try:
        handle = xbmcvfs.File(path, "r")
        while True:
            if heartbeat:
                heartbeat()
            chunk = handle.read(1024 * 1024)
            if not chunk:
                break
            digest.update(bytes(chunk))
        return digest.hexdigest()
    except _RepairOwnershipLost:
        raise
    except Exception as ex:
        xbmc.log(f"[downloads] Could not hash {path}: {ex}", xbmc.LOGERROR)
        return None
    finally:
        if handle is not None:
            try:
                handle.close()
            except Exception:
                pass


def _file_matches_hash(path, expected_hash, heartbeat=None):
    specification = _recognized_hash(expected_hash)
    if not specification:
        return True
    algorithm, expected = specification
    actual = _file_hash(path, algorithm, heartbeat)
    return actual is not None and actual.lower() == expected.lower()


def _verification_failure(download_id, expected_status, record, message, actual_size=None):
    total = _as_int(record.get("bytes_total"), 0)
    actual = max(0, _as_int(actual_size, 0))
    progress = min(100, int(100 * actual / total)) if total > 0 else 0
    return db.transition(download_id, expected_status, {
        "status": "failed",
        "queue_position": None,
        "error": message,
        "error_code": VERIFICATION_ERROR_CODE,
        "bytes_done": actual,
        "bytes_total": total if total >= 0 else None,
        "expected_hash": record.get("expected_hash"),
        "progress": progress,
        "owner_token": None,
        "updated_at": now_iso()
    }, expected_revision=record.get("revision"))


def verify_download(download_id):
    record = db.list().get(download_id)
    if not record or record.get("status") != "complete":
        _refresh_downloads_container()
        return

    ticket = _authoritative_download_metadata(record, "Verify download")
    if not ticket:
        _refresh_downloads_container()
        return

    expected = _as_int(ticket.get("size_bytes"), -1)
    expected_hash = ticket.get("hash")
    record = dict(record)
    record["bytes_total"] = expected
    record["expected_hash"] = expected_hash
    actual = _final_file_size(record)
    if actual is None:
        message = "Verification failed: the downloaded file is missing. Choose Repair to download it again."
        updated = _verification_failure(download_id, "complete", record, message)
    elif expected < 0:
        message = "Verification failed: the expected file size is unavailable. Choose Repair to download it again."
        updated = _verification_failure(download_id, "complete", record, message, actual)
    elif actual != expected:
        message = (
            f"Verification failed: file is {_format_bytes(actual)}, expected {_format_bytes(expected)}. "
            "Choose Repair to resume or download it again."
        )
        updated = _verification_failure(download_id, "complete", record, message, actual)
    elif not _file_matches_hash(record.get("path"), expected_hash):
        message = "Verification failed: the file hash does not match the authoritative download metadata. Choose Repair to download it again."
        updated = _verification_failure(download_id, "complete", record, message, actual)
    else:
        updated = db.transition(download_id, "complete", {
            "verified_at": now_iso(),
            "error": None,
            "error_code": None,
            "bytes_done": actual,
            "bytes_total": expected,
            "expected_hash": expected_hash,
            "progress": 100,
            "owner_token": None,
            "updated_at": now_iso()
        }, expected_revision=record.get("revision"))
        if updated:
            xbmcgui.Dialog().notification("Verified", updated.get("filename", "Download"), xbmcgui.NOTIFICATION_INFO, 2500)

    if updated and updated.get("status") == "failed":
        xbmcgui.Dialog().ok("Download verification", updated.get("error"))
    _refresh_downloads_container()


def _move_without_overwrite(source, target):
    try:
        if not source or not target or xbmcvfs.exists(target) or not xbmcvfs.exists(source):
            return False
        if _is_vfs_path(source) or _is_vfs_path(target):
            moved = xbmcvfs.rename(source, target)
        else:
            os.rename(source, target)
            moved = True
        return bool(moved) and xbmcvfs.exists(target) and not xbmcvfs.exists(source)
    except Exception as ex:
        xbmc.log(f"[downloads] Could not move {source} to {target}: {ex}", xbmc.LOGERROR)
        return False


def _requires_local_staging(path):
    raw = str(path or "").replace("/", "\\")
    if raw.startswith("\\\\") or _is_vfs_path(str(path or "")):
        return True
    try:
        translated = str(xbmcvfs.translatePath(path) or "").replace("/", "\\")
        return translated.startswith("\\\\") or _is_vfs_path(translated)
    except Exception:
        return True


def _repair_staging_path(download_id):
    addon = xbmcaddon.Addon()
    configured = addon.getSetting("download_staging_path") or ""
    if configured and not _requires_local_staging(configured):
        root = xbmcvfs.translatePath(configured)
        staging_dir = os.path.join(root, ".mediahub-staging")
    else:
        profile = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
        staging_dir = os.path.join(profile, "download_staging")
    os.makedirs(staging_dir, exist_ok=True)
    safe_id = "".join(
        character if character.isalnum() or character in "_.-" else "_"
        for character in str(download_id)
    )
    return os.path.join(staging_dir, f"{safe_id}.part")


def _copy_vfs_to_local_and_remove(
    source,
    target,
    expected_size,
    heartbeat=None,
    final_control=None
):
    if xbmcvfs.exists(target):
        return False
    source_handle = None
    created = False
    try:
        os.makedirs(os.path.dirname(target), exist_ok=True)
        source_handle = xbmcvfs.File(source, "r")
        with open(target, "xb") as target_handle:
            created = True
            copied = 0
            while True:
                if heartbeat:
                    heartbeat()
                chunk = source_handle.read(1024 * 1024)
                if not chunk:
                    break
                view = memoryview(bytes(chunk))
                written = 0
                while written < len(view):
                    count = target_handle.write(view[written:])
                    if not count:
                        return False
                    written += count
                copied += len(view)
            target_handle.flush()
            os.fsync(target_handle.fileno())
        if copied != expected_size or os.path.getsize(target) != expected_size:
            return False
        if final_control:
            final_control()
        if not xbmcvfs.delete(source) and xbmcvfs.exists(source):
            return False
        return True
    except _RepairOwnershipLost:
        raise
    except Exception as ex:
        xbmc.log(f"[downloads] Could not stage repair data: {ex}", xbmc.LOGERROR)
        return False
    finally:
        if source_handle is not None:
            try:
                source_handle.close()
            except Exception:
                pass
        if created and xbmcvfs.exists(source):
            try:
                os.remove(target)
            except OSError:
                pass


def repair_download(download_id):
    record = db.list().get(download_id)
    if not record:
        _refresh_downloads_container()
        return

    status = record.get("status")
    if status != "complete" and not (
        status in ("failed", "canceled") and record.get("error_code") == VERIFICATION_ERROR_CODE
    ):
        _refresh_downloads_container()
        return

    ticket = _authoritative_download_metadata(record, "Repair download")
    if not ticket:
        _refresh_downloads_container()
        return
    expected = _as_int(ticket.get("size_bytes"), -1)
    expected_hash = ticket.get("hash")
    if expected <= 0:
        xbmcgui.Dialog().ok("Repair download", "The server returned an invalid expected file size.")
        return

    repair_token = str(uuid.uuid4())
    staging_path = record.get("staging_path")
    if _requires_local_staging(record.get("path")) and not staging_path:
        try:
            staging_path = _repair_staging_path(download_id)
        except Exception as ex:
            xbmc.log(f"[downloads] Could not prepare repair staging: {ex}", xbmc.LOGERROR)
            xbmcgui.Dialog().ok("Repair download", "Could not prepare the local staging folder.")
            return

    claimed = db.transition(download_id, status, {
        "status": "repairing",
        "repair_from_status": status,
        "owner_token": repair_token,
        "owner_worker_id": "ui-repair",
        "owner_heartbeat_at": now_iso(),
        "attempt_id": repair_token,
        "bytes_total": expected,
        "expected_hash": expected_hash,
        "staging_path": staging_path,
        "updated_at": now_iso()
    }, expected_revision=record.get("revision"))
    if not claimed:
        _refresh_downloads_container()
        return

    record = claimed
    last_control_check = [0.0]
    last_heartbeat = [0.0]

    def repair_heartbeat(force=False):
        current = time.monotonic()
        if not force and current - last_control_check[0] < 0.5:
            return
        current_record = db.list().get(download_id)
        if (
            not current_record
            or current_record.get("status") != "repairing"
            or current_record.get("owner_token") != repair_token
        ):
            raise _RepairOwnershipLost("Repair ownership changed")
        last_control_check[0] = current
        if not force and current - last_heartbeat[0] < 5.0:
            return
        if not db.update_owned(
            download_id,
            repair_token,
            {"owner_heartbeat_at": now_iso(), "updated_at": now_iso()},
            expected_statuses=("repairing",)
        ):
            raise _RepairOwnershipLost("Repair ownership changed")
        last_heartbeat[0] = current

    part = _part_path(record)
    actual = _final_file_size(record)
    part_exists = _part_exists(record)
    message = None
    queue_repair = False

    try:
        if actual is not None and actual == expected:
            hash_matches = _file_matches_hash(
                record.get("path"),
                expected_hash,
                repair_heartbeat
            )
            # The hash callback is throttled; force one final CAS immediately
            # before either completing or quarantining the file.
            repair_heartbeat(force=True)
            if hash_matches:
                updated = db.update_owned(download_id, repair_token, {
                    "status": "complete",
                    "verified_at": now_iso(),
                    "error": None,
                    "error_code": None,
                    "bytes_done": actual,
                    "progress": 100,
                    "owner_token": None,
                    "owner_worker_id": None,
                    "owner_heartbeat_at": None,
                    "attempt_id": None,
                    "repair_from_status": None,
                    "updated_at": now_iso()
                }, expected_statuses=("repairing",))
                if updated:
                    xbmcgui.Dialog().notification(
                        "Verified",
                        "The file is already complete.",
                        xbmcgui.NOTIFICATION_INFO,
                        2500
                    )
                _refresh_downloads_container()
                return

        if actual is not None and actual > expected:
            message = "Repair stopped because the existing file is larger than the authoritative size. It was left untouched."
        elif actual is not None and actual == expected:
            quarantine = f"{record.get('path')}.corrupt-{str(download_id)[:8]}"
            repair_heartbeat(force=True)
            if _move_without_overwrite(record.get("path"), quarantine):
                queue_repair = True
                record["quarantine_path"] = quarantine
            else:
                message = "The file has the expected size but failed its hash check and could not be quarantined."
        elif actual is not None:
            if part_exists:
                message = "Repair stopped because a partial file already exists. Neither file was overwritten."
            elif _requires_local_staging(record.get("path")):
                if _copy_vfs_to_local_and_remove(
                    record.get("path"),
                    part,
                    actual,
                    repair_heartbeat,
                    lambda: repair_heartbeat(force=True)
                ):
                    queue_repair = True
                else:
                    message = "Repair could not move the incomplete network file into local staging."
            else:
                repair_heartbeat(force=True)
                if _move_without_overwrite(record.get("path"), part):
                    queue_repair = True
                else:
                    message = "Repair could not move the incomplete file to the partial download."
        else:
            queue_repair = True
    except _RepairOwnershipLost:
        _refresh_downloads_container()
        return

    if queue_repair:
        part_size = _part_size(record)
        progress = min(100, int(100 * part_size / expected)) if expected > 0 else 0
        updated = db.update_owned(download_id, repair_token, {
            "status": "queued",
            "queue_position": _next_queue_position(db.list()),
            "error": None,
            "error_code": None,
            "attempts": 0,
            "next_attempt_at": None,
            "owner_token": None,
            "owner_worker_id": None,
            "owner_heartbeat_at": None,
            "attempt_id": None,
            "repair_from_status": None,
            "bytes_done": part_size,
            "progress": progress,
            "quarantine_path": record.get("quarantine_path"),
            "updated_at": now_iso()
        }, expected_statuses=("repairing",))
        if updated:
            xbmcgui.Dialog().notification("Repair queued", record.get("filename", "Download"), xbmcgui.NOTIFICATION_INFO, 2500)
    else:
        db.update_owned(download_id, repair_token, {
            "status": "failed",
            "queue_position": None,
            "error": message,
            "error_code": VERIFICATION_ERROR_CODE,
            "owner_token": None,
            "owner_worker_id": None,
            "owner_heartbeat_at": None,
            "attempt_id": None,
            "repair_from_status": None,
            "updated_at": now_iso()
        }, expected_statuses=("repairing",))
        xbmcgui.Dialog().ok("Repair download", message)
    _refresh_downloads_container()

def _removable_download_history_records(snapshot=None):
    snapshot = db.list() if snapshot is None else snapshot
    removable = {}
    for download_id, record in snapshot.items():
        if record.get("status") not in ("complete", "failed", "canceled"):
            continue
        if record.get("cleanup_pending") or _part_exists(record):
            continue
        finalization_path = record.get("finalization_path")
        if finalization_path:
            try:
                if xbmcvfs.exists(finalization_path):
                    continue
            except Exception:
                continue
        removable[download_id] = record.get("revision")
    return removable


def clear_download_history(confirm=True, category="all"):
    category = category if category in ("normal", "torbox") else "all"
    if confirm and not xbmcgui.Dialog().yesno(
        "Vymazať históriu sťahovania",
        "Odstránia sa dokončené, zrušené a zlyhané záznamy bez čiastočných súborov. "
        "Aktívne a čiastočné sťahovania zostanú zachované. Stiahnuté súbory sa neodstránia. Pokračovať?",
        yeslabel="Áno",
        nolabel="Nie"
    ):
        return

    removable = (
        _removable_download_history_records()
        if category in ("normal", "all") else {}
    )

    def op(data):
        removable_ids = []
        for download_id, expected_revision in removable.items():
            current = data.get(download_id)
            if not current or current.get("status") not in ("complete", "failed", "canceled"):
                continue
            if current.get("revision") != expected_revision:
                continue
            del data[download_id]
            removable_ids.append(download_id)
        _normalize_queue_positions(data)
        return len(removable_ids)

    removed = db.mutate(op) if category in ("normal", "all") else 0
    removed_preparations = (
        preparations_db.clear_terminal()
        if category in ("torbox", "all") else 0
    )
    if category == "normal":
        message = f"Removed {removed} download history record(s)"
    elif category == "torbox":
        message = f"Removed {removed_preparations} TorBox history record(s)"
    else:
        message = (
            f"Removed {removed} download and {removed_preparations} "
            "TorBox history record(s)"
        )
    xbmcgui.Dialog().notification(
        "Downloads",
        message,
        xbmcgui.NOTIFICATION_INFO,
        2000,
    )
    xbmc.executebuiltin("Container.Refresh")


def remove_download_history(download_id):
    """Remove one terminal download record without touching user files."""
    record = _list_downloads_normalized().get(download_id)
    if not record:
        xbmcgui.Dialog().notification(
            "Downloads", "Download not found", xbmcgui.NOTIFICATION_ERROR, 2000
        )
        return
    if record.get("status") not in ("complete", "failed", "canceled"):
        xbmcgui.Dialog().notification(
            "Downloads", "Active downloads cannot be removed", xbmcgui.NOTIFICATION_INFO, 2000
        )
        return
    if record.get("cleanup_pending") or _part_exists(record):
        xbmcgui.Dialog().notification(
            "Downloads", "Partial download must be kept or canceled first", xbmcgui.NOTIFICATION_INFO, 2500
        )
        return
    if record.get("finalization_path"):
        try:
            if xbmcvfs.exists(record["finalization_path"]):
                xbmcgui.Dialog().notification(
                    "Downloads", "Download finalization is still pending", xbmcgui.NOTIFICATION_INFO, 2500
                )
                return
        except Exception:
            return
    if not xbmcgui.Dialog().yesno(
        "Remove download history",
        "Remove this record? The downloaded file will not be deleted.",
        yeslabel="Yes",
        nolabel="No",
    ):
        return

    expected_revision = record.get("revision")

    def op(data):
        current = data.get(download_id)
        if not current or current.get("revision") != expected_revision:
            return False
        if current.get("status") not in ("complete", "failed", "canceled"):
            return False
        if current.get("cleanup_pending") or _part_exists(current):
            return False
        del data[download_id]
        _normalize_queue_positions(data)
        return True

    if db.mutate(op):
        xbmcgui.Dialog().notification(
            "Downloads", "Removed from history", xbmcgui.NOTIFICATION_INFO, 2000
        )
    xbmc.executebuiltin("Container.Refresh")
