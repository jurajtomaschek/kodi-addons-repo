"""Small profile-backed history for the catalogue search workspaces."""

import json
import os
import tempfile

LIMIT = 6


def normalize(value):
    history = {"movies": [], "tv": []}
    if not isinstance(value, dict):
        return history
    for page in history:
        entries = value.get(page)
        if not isinstance(entries, list):
            continue
        seen = set()
        for entry in entries:
            if not isinstance(entry, str):
                continue
            query = entry.strip()
            identity = query.casefold()
            if query and identity not in seen:
                history[page].append(query)
                seen.add(identity)
            if len(history[page]) == LIMIT:
                break
    return history


def load(path):
    if path:
        try:
            with open(path, encoding="utf-8") as source:
                return normalize(json.load(source))
        except (OSError, ValueError):
            pass
    return normalize(None)


def save(path, history):
    if not path:
        return
    directory = os.path.dirname(os.path.abspath(path))
    os.makedirs(directory, exist_ok=True)
    descriptor, staging = tempfile.mkstemp(prefix="search-history-", suffix=".json", dir=directory)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as destination:
            json.dump(normalize(history), destination, ensure_ascii=False)
        os.replace(staging, path)
    finally:
        if os.path.exists(staging):
            os.remove(staging)
