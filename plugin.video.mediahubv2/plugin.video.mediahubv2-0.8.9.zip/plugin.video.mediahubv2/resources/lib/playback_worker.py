"""Record final playback state and hand a completed title back to MediaHub."""

import json
import threading
import time
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui

from .watch_history_db import WatchHistoryDb


CONTEXT_PROPERTY = "MediaHub.PlaybackContext"
OUTCOME_PROPERTY = "MediaHub.PlaybackOutcome"
WATCHED_PERCENT = 90


def playback_context(stream_id, history_id, params, mode):
    """Only metadata needed after playback; never retain a signed stream URL."""
    fields = ("media_type", "tv_id", "season", "episode_id",
              "episode_number", "tv_title", "episode_title", "title",
              "poster", "fanart")
    context = {key: params.get(key) for key in fields if params.get(key) not in (None, "")}
    context.update(stream_id=str(stream_id), history_id=history_id, mode=mode,
                   token=str(time.time_ns()))
    return context


def register_playback(context):
    window = xbmcgui.Window(10000)
    window.clearProperty(OUTCOME_PROPERTY)
    window.setProperty(CONTEXT_PROPERTY, json.dumps(context))


def _progress(position, duration):
    if duration <= 0:
        return None
    return max(0, min(100, position / duration * 100))


class PlaybackMonitor(xbmc.Player):
    def __init__(self):
        super().__init__()
        self._context = None
        self._position = 0.0
        self._duration = 0.0
        self._sampling = threading.Event()
        self._db = WatchHistoryDb()

    def onAVStarted(self):
        window = xbmcgui.Window(10000)
        try:
            raw = window.getProperty(CONTEXT_PROPERTY)
            context = json.loads(raw) if raw else None
        except (ValueError, TypeError):
            context = None
        if not isinstance(context, dict) or not context.get("history_id"):
            return
        window.clearProperty(CONTEXT_PROPERTY)
        self._sampling.set()
        self._context = context
        self._position = self._duration = 0.0
        self._sampling = threading.Event()
        threading.Thread(target=self._sample, args=(context,), daemon=True).start()

    def _save(self, context, complete=False):
        position, duration = self._position, self._duration
        def update(data):
            record = data.get(context["history_id"])
            if not isinstance(record, dict):
                return
            if position > 0:
                record["position_seconds"] = position
            if duration > 0:
                record["duration_seconds"] = duration
                progress = _progress(position, duration)
                if progress is not None:
                    record["progress_percent"] = progress
            if complete:
                record["completed"] = True
                record["progress_percent"] = 100
                if duration > 0:
                    record["position_seconds"] = duration
        try:
            self._db.mutate(update)
        except Exception as exc:
            xbmc.log("[MediaHub playback] Could not save watch state: {0}".format(exc), xbmc.LOGWARNING)

    def _sample(self, context):
        while not self._sampling.is_set():
            if self._context is not context:
                return
            try:
                if not self.isPlayingVideo():
                    return
                self._position = max(0.0, float(self.getTime()))
                self._duration = max(0.0, float(self.getTotalTime()))
                self._save(context)
            except Exception:
                return
            if self._sampling.wait(5):
                return

    def _finish(self, reason):
        context = self._context
        if not context:
            xbmcgui.Window(10000).clearProperty(CONTEXT_PROPERTY)
            return
        self._sampling.set()
        try:
            self._position = max(self._position, float(self.getTime()))
            self._duration = max(self._duration, float(self.getTotalTime()))
        except Exception:
            pass
        progress = _progress(self._position, self._duration)
        complete = reason == "ended" or (
            reason == "stopped" and progress is not None and progress >= WATCHED_PERCENT
        )
        self._save(context, complete=complete)
        self._context = None
        window = xbmcgui.Window(10000)
        window.clearProperty(CONTEXT_PROPERTY)
        if not complete:
            return
        if context.get("mode") == "modern":
            window.setProperty(OUTCOME_PROPERTY, json.dumps(context))
        else:
            threading.Thread(target=self._return_classic, args=(context,), daemon=True).start()

    def onPlayBackEnded(self):
        self._finish("ended")

    def onPlayBackStopped(self):
        self._finish("stopped")

    def onPlayBackError(self):
        self._finish("error")

    def _return_classic(self, context):
        # Give Kodi time to close the video window before navigating its list.
        time.sleep(0.5)
        if self.isPlayingVideo():
            return
        xbmc.executebuiltin("Action(Back)")
        time.sleep(0.25)
        xbmc.executebuiltin("Container.Refresh")
        if context.get("media_type") != "episode":
            return
        from .localization import tr
        try:
            from . import ui
            if not ui._has_later_aired_episode(context):
                xbmcgui.Dialog().notification(
                    tr("Episode finished"), tr("You are caught up"),
                    xbmcgui.NOTIFICATION_INFO, 2500,
                )
                return
        except Exception as exc:
            xbmc.log("[MediaHub playback] Could not check later episodes: {0}".format(exc), xbmc.LOGWARNING)
        choice = xbmcgui.Dialog().select(
            tr("Episode finished"),
            [tr("Play next episode"), tr("Stay in this season")],
        )
        if choice != 0:
            return
        fields = {key: context[key] for key in (
            "tv_id", "season", "episode_id", "episode_number", "tv_title",
            "poster", "fanart") if context.get(key) not in (None, "")}
        fields["action"] = "show_next_episode"
        addon_id = xbmcaddon.Addon().getAddonInfo("id")
        target = "plugin://{0}/?{1}".format(addon_id, urllib.parse.urlencode(fields))
        xbmc.executebuiltin("Container.Update({0})".format(target))
