"""Bridge short-lived plugin directories to the persistent Kodi service."""
import json
import os
import tempfile
import time
import urllib.parse
import hashlib
import threading
import queue

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from . import browse, external_subtitles, api
from .localization import tr

_CATALOG_LOCK = threading.RLock()
_CATALOG_QUEUE = queue.Queue(maxsize=100)
_CATALOG_WORKERS = []
_CATALOG_RUNNING = set()
_CATALOG_STATES = {}


def _catalog_key(target):
    return hashlib.sha256((api.browse_account() + target).encode("utf-8")).hexdigest()


def catalog_snapshot(target):
    value = _read(_catalog_key(target) + ".json")
    return value.get("response") if time.time() - value.get("source_at", value.get("saved_at", 0)) < 300 else None


def acknowledge_catalog(target, response):
    _write("request.json", {"kind": "catalog", "target": target, "response": response, "time": time.time()})


def _catalog_tick(request):
    target = request["target"]
    key = _catalog_key(target)
    with _CATALOG_LOCK:
        state = _CATALOG_STATES.get(key)
        if state and time.time() - state["source_at"] >= 300 and request["response"] != state["response"]:
            state = None
        if state is None:
            if len(_CATALOG_STATES) >= 16:
                oldest = next(iter(_CATALOG_STATES))
                _CATALOG_STATES.pop(oldest)
                try:
                    os.remove(os.path.join(_directory(), oldest + ".json"))
                except FileNotFoundError:
                    pass
            state = {"response": request["response"], "revision": 0, "source_at": time.time()}
            _CATALOG_STATES[key] = state
        for row in state["response"].get("results") or []:
            identity = (key, row.get("id"))
            if row.get("_browse_enriched") or identity in _CATALOG_RUNNING:
                continue
            try:
                _CATALOG_QUEUE.put_nowait((key, target, row))
                _CATALOG_RUNNING.add(identity)
            except queue.Full:
                break
        while len(_CATALOG_WORKERS) < 2 and not _CATALOG_QUEUE.empty():
            worker = threading.Thread(target=_catalog_worker, name="MediaHubRecentTV", daemon=True)
            _CATALOG_WORKERS.append(worker)
            worker.start()
        value = dict(state, saved_at=time.time())
        if state.get("saved_revision") != state["revision"] or time.time() - state.get("last_saved", 0) >= 60:
            _write(key + ".json", value)
            state["saved_revision"] = state["revision"]
            state["last_saved"] = time.time()
        return (key, state["revision"])


def _catalog_worker():
    while True:
        key, target, row = _CATALOG_QUEUE.get()
        identity = (key, row.get("id"))
        try:
            if not _same_folder(xbmc.getInfoLabel("Container.FolderPath"), target):
                continue
            try:
                details = api.get_catalog_metadata("movie" if "title" in row else "tv", row["id"]) or {}
            except Exception:
                details = {}
            with _CATALOG_LOCK:
                for field in ("overview", "runtime", "name", "original_name", "last_air_date", "last_episode_to_air", "next_episode_to_air"):
                    if details.get(field) not in (None, ""):
                        row[field] = details[field]
                if details.get("name"):
                    row.pop("name_with_original_name", None)
                row["_browse_enriched"] = True
                if key in _CATALOG_STATES:
                    _CATALOG_STATES[key]["revision"] += 1
        finally:
            with _CATALOG_LOCK:
                _CATALOG_RUNNING.discard(identity)
            _CATALOG_QUEUE.task_done()


def _directory():
    path = os.path.join(xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("profile")), "browse")
    os.makedirs(path, exist_ok=True)
    return path


def _read(name):
    try:
        with open(os.path.join(_directory(), name), encoding="utf-8") as handle:
            return json.load(handle)
    except (OSError, ValueError):
        return {}


def _write(name, value):
    directory = _directory()
    fd, temporary = tempfile.mkstemp(dir=directory, suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(value, handle, ensure_ascii=False)
        os.replace(temporary, os.path.join(directory, name))
    finally:
        if os.path.exists(temporary):
            os.remove(temporary)


def snapshot(context):
    value = _read(browse.identity(context) + ".json")
    if time.time() - value.get("saved_at", 0) > 300:
        return {"items": [], "discovering": True, "pending": 0}
    return value


def acknowledge(context, target, rows):
    # Written after endOfDirectory; the service additionally checks Kodi's
    # active folder before scheduling enrichment or refreshing any directory.
    _write("request.json", {"context": context, "target": target,
        "displayed": [str(row["id"]) for row in rows], "time": time.time()})


def _same_folder(left, right):
    a, b = urllib.parse.urlsplit(left), urllib.parse.urlsplit(right)
    return (a.scheme, a.netloc, a.path.rstrip("/"), sorted(urllib.parse.parse_qsl(a.query))) == (
        b.scheme, b.netloc, b.path.rstrip("/"), sorted(urllib.parse.parse_qsl(b.query)))


def run():
    monitor = xbmc.Monitor()
    previous = None
    last_refresh = 0
    last_saved = 0
    saved_fingerprint = None
    last_cleanup = 0
    retry_target = None
    progress = None
    while not monitor.waitForAbort(.5):
        try:
            request = _read("request.json")
            target = str(request.get("target") or "")
            current = xbmc.getInfoLabel("Container.FolderPath")
            if not target or not _same_folder(current, target):
                browse.deactivate_except()
                if progress:
                    progress.close()
                    progress = None
                previous = None
                continue
            if request.get("kind") == "catalog":
                if progress:
                    progress.close()
                    progress = None
                fingerprint = _catalog_tick(request)
                if fingerprint != previous and time.monotonic() - last_refresh >= 2:
                    if _same_folder(xbmc.getInfoLabel("Container.FolderPath"), target):
                        xbmc.executebuiltin("Container.Refresh")
                        previous = fingerprint
                        last_refresh = time.monotonic()
                continue
            context = request.get("context") or {}
            retry = dict(urllib.parse.parse_qsl(urllib.parse.urlsplit(target).query)).get("_browse_retry")
            if retry and target != retry_target:
                browse.invalidate(context)
                retry_target = target
                previous = None
            session = browse.get(context)
            browse.deactivate_except(session)
            browse.mark_displayed(session, request.get("displayed") or [])
            value = session.snapshot()
            displayed = set(request.get("displayed") or [])
            checked = [row for row in value["items"] if str(row["id"]) in displayed
                and str(row.get("metadataStatus", "")).lower() != "pending"]
            external_subtitles.schedule(checked, context)
            checking = 0
            for row in value["items"]:
                external = external_subtitles.get(row["id"], context)
                row["externalSubtitleAvailability"] = external
                checking += external.get("status") == "checking"
            fingerprint = json.dumps(value, sort_keys=True)
            value["saved_at"] = time.time()
            if fingerprint != saved_fingerprint or time.monotonic() - last_saved >= 60:
                _write(session.key + ".json", value)
                saved_fingerprint = fingerprint
                last_saved = time.monotonic()
            pending = value["pending"] + checking
            if value["discovering"] or pending:
                if progress is None:
                    progress = xbmcgui.DialogProgressBG()
                    progress.create("Media Hub", tr("Finding streams…"))
                total = len(value["items"])
                progress.update(0 if not total else int(100 * max(0, total - value["pending"]) / total),
                    "Media Hub", tr("Finding streams…") if value["discovering"] else tr("Loading metadata… {0}/{1}", max(0, total - value["pending"]), total))
            elif progress:
                progress.close()
                progress = None
            if fingerprint != previous and time.monotonic() - last_refresh >= 2:
                # Check again immediately before the global Kodi command.
                if _same_folder(xbmc.getInfoLabel("Container.FolderPath"), target):
                    xbmc.executebuiltin("Container.Refresh")
                    previous = fingerprint
                    last_refresh = time.monotonic()
            # Bound persisted browsing snapshots; keep at most sixteen recent files.
            if time.monotonic() - last_cleanup >= 60:
                files = [os.path.join(_directory(), name) for name in os.listdir(_directory())
                         if name.endswith(".json") and name != "request.json"]
                for path in sorted(files, key=os.path.getmtime, reverse=True)[16:]:
                    os.remove(path)
                last_cleanup = time.monotonic()
        except Exception as exc:
            xbmc.log("[MediaHub browse] Background refresh failed: {0}".format(exc), xbmc.LOGWARNING)
    browse.close()
    if progress:
        progress.close()
