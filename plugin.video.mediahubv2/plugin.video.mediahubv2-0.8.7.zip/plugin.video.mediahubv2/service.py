from resources.lib.downloads_worker import DownloadsWorker
from resources.lib.torbox_worker import TorboxPreparationWorker
from resources.lib.subtitles_worker import SubtitlePlaybackMonitor, SubtitleTranslationWorker
import threading

if __name__ == "__main__":
    subtitle_playback_monitor = SubtitlePlaybackMonitor()
    preparation_worker = TorboxPreparationWorker()
    preparation_thread = threading.Thread(
        target=preparation_worker.run,
        name="TorboxPreparationWorker",
        daemon=True,
    )
    preparation_thread.start()
    subtitle_thread = threading.Thread(
        target=SubtitleTranslationWorker().run,
        name="SubtitleTranslationWorker",
        daemon=True,
    )
    subtitle_thread.start()
    DownloadsWorker().run()
