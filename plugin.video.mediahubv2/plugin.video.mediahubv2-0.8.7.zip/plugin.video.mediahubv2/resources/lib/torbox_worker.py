import time
import xbmc

from . import api
from .downloads_db import DownloadsDb, now_iso
from .torbox_preparations import TorboxPreparationsDb


class TorboxPreparationWorker:
    POLL_SECONDS = 2
    MAX_POLL_SECONDS = 15

    def __init__(self):
        self.db = TorboxPreparationsDb()
        self.downloads = DownloadsDb()
        self.monitor = xbmc.Monitor()

    def run(self):
        xbmc.log("[TorboxPreparationWorker] Started", xbmc.LOGINFO)
        while not self.monitor.abortRequested():
            try:
                self._tick()
            except Exception as ex:
                xbmc.log(f"[TorboxPreparationWorker] Loop error: {ex}", xbmc.LOGERROR)
            self.monitor.waitForAbort(self.POLL_SECONDS)
        xbmc.log("[TorboxPreparationWorker] Stopped", xbmc.LOGINFO)

    def _tick(self):
        now = time.time()
        for record in self.db.list().values():
            if record.get("status") not in ("queued", "preparing", "stalled"):
                continue
            if float(record.get("next_poll_at", 0) or 0) > now:
                continue
            self._process(record)

    def _process(self, record):
        preparation_id = record["id"]
        stream_id = record["stream_id"]
        try:
            if record.get("status") == "queued":
                status = api.prepare_stream(stream_id)
            else:
                status = api.get_stream_status(stream_id)
            status = status if isinstance(status, dict) else {}
            availability = self._availability(status)
            progress = self._number(status, "progressPercent", "progress_percent")
            eta = self._number(status, "etaSeconds", "eta_seconds")
            poll_attempts = int(record.get("poll_attempts", 0) or 0) + 1
            patch = {
                "status": self._job_status(availability),
                "availability": availability,
                "progress": progress,
                "eta_seconds": eta,
                "message": status.get("message") or status.get("availabilityMessage", ""),
                "updated_at": now_iso(),
                "poll_attempts": poll_attempts,
                "next_poll_at": time.time() + self._next_poll_delay(poll_attempts),
            }
            if availability in ("ready", "cached"):
                patch.update({"status": "ready", "next_poll_at": 0})
            elif availability == "error":
                patch.update({"status": "failed", "next_poll_at": 0})
            updated = self.db.update(
                preparation_id,
                patch,
                expected_statuses=("queued", "preparing", "stalled"),
            )
            if not updated:
                return
            if updated.get("status") == "ready":
                self._release_local_download(updated)
            elif updated.get("status") == "failed":
                self._fail_local_download(
                    updated,
                    updated.get("message") or "TorBox preparation failed",
                )
        except Exception as ex:
            self.db.update(
                preparation_id,
                {
                    "status": "stalled",
                    "message": str(ex),
                    "updated_at": now_iso(),
                    "next_poll_at": time.time() + self.MAX_POLL_SECONDS,
                },
                expected_statuses=("queued", "preparing", "stalled"),
            )

    @staticmethod
    def _number(payload, *keys):
        for key in keys:
            value = payload.get(key)
            if value not in (None, ""):
                try:
                    return max(0, int(float(value)))
                except (TypeError, ValueError):
                    pass
        return None

    @staticmethod
    def _availability(payload):
        ready = payload.get("isReady", payload.get("is_ready"))
        if ready is True or str(ready).lower() in ("true", "1", "yes"):
            return "ready"
        raw = payload.get("availability", payload.get("status", "unknown"))
        values = {0: "ready", 1: "downloading", 2: "queued", 3: "uncached", 4: "stalled", 5: "error", 7: "cached"}
        if isinstance(raw, int):
            return values.get(raw, "unknown")
        normalized = str(raw or "unknown").lower()
        if normalized.isdigit():
            return values.get(int(normalized), "unknown")
        if normalized in ("complete", "completed"):
            return "ready"
        return normalized

    @staticmethod
    def _job_status(availability):
        if availability in ("queued", "uncached"):
            return "queued"
        if availability == "stalled":
            return "stalled"
        return "preparing"

    def _next_poll_delay(self, attempts):
        return min(self.MAX_POLL_SECONDS, self.POLL_SECONDS * (2 ** min(attempts, 3)))

    def _release_local_download(self, record):
        download_id = record.get("download_id")
        if download_id:
            self.downloads.update(download_id, {
                "status": "queued",
                "queue_position": 0,
                "updated_at": now_iso(),
                "preparation_id": record["id"],
            })

    def _fail_local_download(self, record, message):
        download_id = record.get("download_id")
        if download_id:
            self.downloads.update(download_id, {
                "status": "failed",
                "error": message,
                "error_code": "torbox_preparation_failed",
                "updated_at": now_iso(),
            })
