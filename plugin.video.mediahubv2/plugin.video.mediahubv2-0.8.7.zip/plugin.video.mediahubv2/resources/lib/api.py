import json
import xbmc
import xbmcaddon
import urllib.parse

from urllib.request import build_opener, HTTPRedirectHandler, Request
from urllib.error import HTTPError

#BASE_API_URL = "https://localhost:7009"  # Make sure it's https if your server uses it
#BASE_API_URL = "http://localhost:5283"

BASE_API_URL = "https://media-vault-app-service-b8cmhsbsaefadbex.northeurope-01.azurewebsites.net"


class _NoAuthenticatedRedirects(HTTPRedirectHandler):
    """Never forward the add-on API key through an HTTP redirect."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


_AUTHENTICATED_OPENER = build_opener(_NoAuthenticatedRedirects())


def urlopen(request, **kwargs):
    """Open an authenticated backend request without following redirects."""
    return _AUTHENTICATED_OPENER.open(request, **kwargs)

class ApiError(Exception):
    def __init__(self, status_code, reason, body="", headers=None):
        self.status_code = status_code
        self.reason = reason
        self.body = body or ""
        self.headers = headers or {}
        self.message = self._extract_message()
        self.error_code = self._extract_error_code()
        super().__init__(self.message)

    def _extract_message(self):
        if not self.body:
            return f"Server returned {self.status_code}."

        try:
            payload = json.loads(self.body)
            if isinstance(payload, dict):
                return payload.get("detail") or payload.get("title") or self.body
        except Exception:
            pass

        return self.body

    def _extract_error_code(self):
        try:
            payload = json.loads(self.body)
            if not isinstance(payload, dict):
                return ""
            extensions = payload.get("extensions")
            return str(
                payload.get("errorCode")
                or payload.get("error_code")
                or (extensions.get("errorCode") if isinstance(extensions, dict) else "")
                or ""
            ).strip()
        except Exception:
            return ""

def _resolve_api_url(endpoint):
    """Resolve backend URLs without leaking the API key to another origin."""
    endpoint = str(endpoint or "").strip()
    if not endpoint:
        raise ValueError("API endpoint must be provided.")
    base = urllib.parse.urlsplit(BASE_API_URL)
    candidate = urllib.parse.urlsplit(endpoint)
    if candidate.scheme or candidate.netloc:
        if candidate.scheme not in ("http", "https"):
            raise ValueError("Unsupported API URL scheme.")
        if (
            candidate.scheme.lower() != base.scheme.lower()
            or candidate.netloc.lower() != base.netloc.lower()
        ):
            raise ValueError("Refusing a cross-origin API URL.")
        return urllib.parse.urlunsplit(candidate)
    path = candidate.path
    if not path.startswith("/"):
        path = "/" + path
    return urllib.parse.urlunsplit(
        (base.scheme, base.netloc, path, candidate.query, "")
    )


def _request(
    endpoint,
    timeout=60,
    method="GET",
    payload=None,
    accept="application/json",
    max_bytes=2 * 1024 * 1024,
):
    full_url = _resolve_api_url(endpoint)
    normalized_method = (method or "GET").upper()
    if payload is None:
        data = b"" if normalized_method in ("POST", "PUT", "PATCH") else None
    else:
        data = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    req = Request(
        full_url,
        data=data,
        method=normalized_method,
    )
    req.add_header("Accept", accept)
    if data is not None:
        req.add_header("Content-Type", "application/json")
    # Settings can change while Kodi is running. Read the credential for every
    # request instead of keeping the value captured when this module was loaded.
    req.add_header("x-api-key", xbmcaddon.Addon().getSetting("api_key"))
    
    # Routine status polling can be frequent; keep request tracing out of the
    # normal INFO log while retaining it for diagnostic builds.
    xbmc.log(
        f"Calling: {full_url}",
        getattr(xbmc, "LOGDEBUG", xbmc.LOGINFO),
    )

    try:
        # Do not supply an unverified SSL context. urllib's default context
        # performs the platform's normal certificate and hostname validation.
        with urlopen(req, timeout=timeout) as response:
            try:
                body = response.read(max_bytes + 1)
            except TypeError:  # Small test doubles and older file-like objects.
                body = response.read()
            if len(body) > max_bytes:
                raise ValueError("Server response is too large.")
            return body
    except HTTPError as e:
        status_code = e.code
        reason = e.reason
        headers = dict(e.headers.items()) if e.headers else {}
        try:
            try:
                raw_error = e.read(1024 * 1024 + 1)
            except TypeError:
                raw_error = e.read()
        finally:
            e.close()
        body = raw_error[:1024 * 1024].decode("utf-8", "replace")
        xbmc.log(f"[HTTPError] {status_code} - {reason}", xbmc.LOGERROR)
        xbmc.log(body, xbmc.LOGERROR)
        raise ApiError(status_code, reason, body, headers) from e
    except Exception as ex:
        xbmc.log(f"[Exception] {str(ex)}", xbmc.LOGERROR)
        raise


def _request_json(endpoint, timeout=60, method="GET", payload=None):
    body = _request(
        endpoint,
        timeout=timeout,
        method=method,
        payload=payload,
        accept="application/json",
    )
    if not body:
        return {}
    try:
        return json.loads(body.decode("utf-8-sig"))
    except (UnicodeDecodeError, ValueError) as exc:
        raise ValueError("Server returned invalid JSON.") from exc


def _request_text(endpoint, timeout=60, method="GET", payload=None):
    body = _request(
        endpoint,
        timeout=timeout,
        method=method,
        payload=payload,
        accept="text/plain, application/x-subrip;q=0.9, */*;q=0.1",
        max_bytes=8 * 1024 * 1024,
    )
    try:
        return body.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        raise ValueError("Server returned a non-UTF-8 subtitle result.") from exc


def _get_json(endpoint, timeout=60):
    return _request_json(endpoint, timeout=timeout, method="GET")


def _post_json(endpoint, timeout=60, payload=None):
    return _request_json(endpoint, timeout=timeout, method="POST", payload=payload)


def _delete_json(endpoint, timeout=60):
    return _request_json(endpoint, timeout=timeout, method="DELETE")

def get_tv_latest(page=1):
    return _get_json(f"/media/tmdb/tvseries/latest?page={page}")

def get_tv_recently_aired(page=1, days=30):
    params = urllib.parse.urlencode({"page": page, "days": days})
    return _get_json(f"/media/tmdb/tvseries/recently-aired?{params}")

def get_tv_popular(page=1):
    return _get_json(f"/media/tmdb/tvseries/popular?page={page}")

def get_tv_sk(page=1):
    return _get_json(f"/media/tmdb/tvseries/sk?page={page}")

def get_tv_genres(language="sk-SK"):
    params = urllib.parse.urlencode({"language": language})
    return _get_json(f"/media/tmdb/tvseries/genres?{params}")

def _normalized_genre_ids(values):
    if values is None:
        return []
    if isinstance(values, str):
        values = values.split(",")

    normalized = []
    for value in values:
        try:
            genre_id = int(value)
        except (TypeError, ValueError):
            continue
        if genre_id > 0 and genre_id not in normalized:
            normalized.append(genre_id)
    return normalized


def discover_tv(
    page=1,
    genre_id=None,
    year=None,
    sort="popularity.desc",
    minimum_rating=None,
    genre_ids=None,
    year_from=None,
    year_to=None,
    minimum_vote_count=None,
):
    params = {
        "page": page,
        "sort": sort
    }
    selected_genres = _normalized_genre_ids(genre_ids)
    if selected_genres:
        params["genreIds"] = ",".join(str(value) for value in selected_genres)
    elif genre_id is not None:
        params["genreId"] = genre_id
    if year_from is not None or year_to is not None:
        if year_from is not None:
            params["yearFrom"] = year_from
        if year_to is not None:
            params["yearTo"] = year_to
    elif year is not None:
        params["year"] = year
    if minimum_rating is not None:
        params["minimumRating"] = minimum_rating
    if minimum_vote_count is not None:
        params["minimumVoteCount"] = minimum_vote_count
    return _get_json(f"/media/tmdb/tvseries/discover?{urllib.parse.urlencode(params)}")

def get_tv_details(tv_id):
    return _get_json(f"/media/tmdb/tvseries/{tv_id}")

def get_episodes(tv_id, season, include_streams=True):
    endpoint = f"/media/tmdb/tvseries/{tv_id}/season/{season}/episodes"
    if not include_streams:
        endpoint += "?includeStreams=false"
    return _get_json(endpoint)

def get_episode_streams(tv_id, season, episode):
    return _get_json(
        f"/media/tmdb/tvseries/{tv_id}/season/{season}/episodes/{episode}/streams"
    )

def get_movies_search(query, page=1):
    params = urllib.parse.urlencode({"query": query, "page": page})
    return _get_json(f"/media/tmdb/movies/search?{params}")

def get_tv_search(query, page=1):
    params = urllib.parse.urlencode({"query": query, "page": page})
    return _get_json(f"/media/tmdb/tvseries/search?{params}")

def get_movies_latest(page=1):
    return _get_json(f"/media/tmdb/movies/latest?page={page}")

def get_movie_genres(language="sk-SK"):
    params = urllib.parse.urlencode({"language": language})
    return _get_json(f"/media/tmdb/movies/genres?{params}")

def discover_movies(
    page=1,
    genre_id=None,
    year=None,
    sort="popularity.desc",
    minimum_rating=None,
    genre_ids=None,
    year_from=None,
    year_to=None,
    minimum_vote_count=None,
):
    params = {
        "page": page,
        "sort": sort
    }
    selected_genres = _normalized_genre_ids(genre_ids)
    if selected_genres:
        params["genreIds"] = ",".join(str(value) for value in selected_genres)
    elif genre_id is not None:
        params["genreId"] = genre_id
    if year_from is not None or year_to is not None:
        if year_from is not None:
            params["yearFrom"] = year_from
        if year_to is not None:
            params["yearTo"] = year_to
    elif year is not None:
        params["year"] = year
    if minimum_rating is not None:
        params["minimumRating"] = minimum_rating
    if minimum_vote_count is not None:
        params["minimumVoteCount"] = minimum_vote_count
    return _get_json(f"/media/tmdb/movies/discover?{urllib.parse.urlencode(params)}")

def get_movies_popular(page=1, year=None):
    url = f"/media/tmdb/movies/popular?page={page}"
    if year is not None:
        url += f"&firstAirDateYear={year}"
    return _get_json(url)

def get_movies_toprated(page=1, year=None):
    url = f"/media/tmdb/movies/toprated?page={page}"
    if year is not None:
        url += f"&firstAirDateYear={year}"
    return _get_json(url)

def get_movie_versions(movie_id):
    return _get_json(f"/media/tmdb/movies/{movie_id}")

def get_streams(stream_id):
    return _get_json(f"/media/stream/{stream_id}")


def _stream_path_id(stream_id):
    value = str(stream_id or "").strip()
    if not value:
        raise ValueError("Stream ID must be provided.")
    return urllib.parse.quote(value, safe="")


def _validate_stream_status(payload):
    if not isinstance(payload, dict):
        raise ValueError("Stream preparation service returned an invalid status.")
    return payload


def get_stream_status(stream_id):
    """Return current provider readiness without starting a transfer."""
    encoded_id = _stream_path_id(stream_id)
    return _validate_stream_status(
        _get_json(f"/media/stream/{encoded_id}/status", timeout=15)
    )


def prepare_stream(stream_id):
    """Start or resume provider preparation and return its initial status."""
    encoded_id = _stream_path_id(stream_id)
    return _validate_stream_status(
        _post_json(f"/media/stream/{encoded_id}/prepare", timeout=30)
    )

def get_download_url(stream_id):
    """Compatibility helper for callers which only need the ephemeral URL."""
    return get_download_ticket(stream_id)["url"]


def get_download_ticket(stream_id):
    """Return and validate the server's authoritative download metadata."""
    encoded_id = _stream_path_id(stream_id)
    payload = _get_json(f"/media/download/{encoded_id}", timeout=15)
    if not isinstance(payload, dict):
        raise ValueError("Download service returned an invalid ticket.")

    url = payload.get("url")
    size_bytes = payload.get("sizeBytes")
    file_name = payload.get("fileName")
    if not isinstance(url, str) or not url.strip():
        raise ValueError("Download ticket does not contain a URL.")
    if isinstance(size_bytes, bool) or not isinstance(size_bytes, int):
        raise ValueError("Download ticket does not contain a valid size.")
    if size_bytes < 0:
        raise ValueError("Download ticket contains a negative size.")
    if not isinstance(file_name, str) or not file_name.strip():
        raise ValueError("Download ticket does not contain a file name.")

    # Keep the rest of the add-on independent of the backend's JSON casing.
    return {
        "url": url.strip(),
        "size_bytes": size_bytes,
        "file_name": file_name.strip(),
        "expires_at": payload.get("expiresAt"),
        "etag": payload.get("etag"),
        "hash": payload.get("hash")
    }


def get_download_metadata(stream_id):
    """Return authoritative size/hash without creating a signed provider URL."""
    payload = _get_json(f"/media/download/{stream_id}/metadata", timeout=15)
    if not isinstance(payload, dict):
        raise ValueError("Download service returned invalid metadata.")
    size_bytes = payload.get("sizeBytes")
    file_name = payload.get("fileName")
    if isinstance(size_bytes, bool) or not isinstance(size_bytes, int) or size_bytes < 0:
        raise ValueError("Download metadata does not contain a valid size.")
    if not isinstance(file_name, str) or not file_name.strip():
        raise ValueError("Download metadata does not contain a file name.")
    return {
        "size_bytes": size_bytes,
        "file_name": file_name.strip(),
        "etag": payload.get("etag"),
        "hash": payload.get("hash")
    }


def _subtitle_job_path(job_id):
    value = str(job_id or "").strip()
    if not value:
        raise ValueError("Subtitle job ID must be provided.")
    return urllib.parse.quote(value, safe="")


def _validate_subtitle_job(payload):
    if not isinstance(payload, dict):
        raise ValueError("Subtitle service returned an invalid job.")
    job_id = payload.get("jobId", payload.get("job_id"))
    status = payload.get("status")
    if not isinstance(job_id, str) or not job_id.strip():
        raise ValueError("Subtitle service omitted the job ID.")
    if not isinstance(status, str) or not status.strip():
        raise ValueError("Subtitle service omitted the job status.")
    return payload


def create_subtitle_translation_job(stream_id, target_language="sk", media_identity=None):
    stream_id = str(stream_id or "").strip()
    if not stream_id:
        raise ValueError("Stream ID must be provided.")
    request_payload = {"streamId": stream_id, "targetLanguage": target_language}
    if isinstance(media_identity, dict):
        allowed_fields = (
            "mediaType", "tmdbId", "parentTmdbId", "imdbId", "parentImdbId",
            "seasonNumber", "episodeNumber", "candidateTitles",
        )
        request_payload.update({
            key: media_identity.get(key)
            for key in allowed_fields
            if media_identity.get(key) not in (None, "")
        })
    payload = _post_json(
        "/Media/subtitles/translation-jobs",
        timeout=30,
        payload=request_payload,
    )
    return _validate_subtitle_job(payload)


def check_external_subtitle_availability(stream_id, media_identity=None):
    stream_id = str(stream_id or "").strip()
    if not stream_id:
        raise ValueError("Stream ID must be provided.")
    payload = {"streamId": stream_id}
    if isinstance(media_identity, dict):
        allowed_fields = (
            "mediaType", "tmdbId", "parentTmdbId", "imdbId", "parentImdbId",
            "seasonNumber", "episodeNumber", "candidateTitles",
        )
        payload.update({
            key: media_identity.get(key)
            for key in allowed_fields
            if media_identity.get(key) not in (None, "", [])
        })
    return _post_json(
        "/Media/subtitles/translation-jobs/availability",
        timeout=90,
        payload=payload,
    )


def download_external_subtitle(stream_id, availability, media_identity=None):
    stream_id = str(stream_id or "").strip()
    if not stream_id:
        raise ValueError("Stream ID must be provided.")
    availability = availability if isinstance(availability, dict) else {}
    language = str(
        availability.get("language")
        or availability.get("external_subtitle_language")
        or ""
    ).strip()
    file_id = str(
        availability.get("fileId")
        or availability.get("file_id")
        or availability.get("external_subtitle_file_id")
        or ""
    ).strip()
    if not language or not file_id:
        raise ValueError("External subtitle language and file ID must be provided.")

    payload = {
        "streamId": stream_id,
        "language": language,
        "fileId": file_id,
    }
    release = (
        availability.get("release")
        or availability.get("external_subtitle_release")
    )
    confidence = availability.get("matchConfidence")
    if confidence is None:
        confidence = availability.get("match_confidence")
    if confidence is None:
        confidence = availability.get("external_subtitle_match_confidence")
    if release not in (None, ""):
        payload["release"] = release
    if confidence not in (None, ""):
        payload["matchConfidence"] = confidence
    if isinstance(media_identity, dict):
        allowed_fields = (
            "mediaType", "tmdbId", "parentTmdbId", "imdbId", "parentImdbId",
            "seasonNumber", "episodeNumber", "candidateTitles",
        )
        payload.update({
            key: media_identity.get(key)
            for key in allowed_fields
            if media_identity.get(key) not in (None, "", [])
        })
    return _request_text(
        "/Media/subtitles/translation-jobs/external",
        timeout=90,
        method="POST",
        payload=payload,
    )


def get_subtitle_translation_job(job_id, url=None):
    endpoint = url or "/Media/subtitles/translation-jobs/{0}".format(
        _subtitle_job_path(job_id)
    )
    return _validate_subtitle_job(_get_json(endpoint, timeout=20))


def get_subtitle_translation_result(job_id, url=None):
    endpoint = url or "/Media/subtitles/translation-jobs/{0}/result".format(
        _subtitle_job_path(job_id)
    )
    return _request_text(endpoint, timeout=30)


def cancel_subtitle_translation_job(job_id, url=None):
    endpoint = url or "/Media/subtitles/translation-jobs/{0}".format(
        _subtitle_job_path(job_id)
    )
    return _delete_json(endpoint, timeout=20)
