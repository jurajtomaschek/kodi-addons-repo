"""Durable client-side state for AI subtitle translation jobs.

The backend is authoritative for processing, while this database remembers the
job IDs and the media context needed by Kodi after a plugin invocation exits.
"""

import datetime
import hashlib
import json
import os
import sqlite3
from contextlib import closing, contextmanager

import xbmcaddon
import xbmcvfs


ACTIVE_STATUSES = frozenset(("queued", "extracting", "translating"))
TERMINAL_STATUSES = frozenset(("completed", "failed", "canceled"))
_BUSY_TIMEOUT_MS = 10000
_RUN_SCOPED_LOCAL_FIELDS = (
    "subtitle_path",
    "result_saved_at",
    "notified_terminal",
    "result_error",
    "result_retry_count",
    "result_retry_disabled",
    "next_result_attempt_at",
    "sync_error",
    "terminal_at",
    "error_code",
)


def now_iso():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def normalize_run_attempt(value):
    """Return the non-negative backend generation for a deterministic job ID."""
    try:
        return max(0, int(value or 0))
    except (TypeError, ValueError):
        return 0


def stream_identity(stream_id, context=None):
    """Return a stable, non-sensitive key for a stream/content combination."""
    context = context if isinstance(context, dict) else {}
    parts = [
        str(stream_id or "").strip(),
        str(context.get("provider") or "").strip().lower(),
        str(context.get("media_type") or "").strip().lower(),
        str(context.get("movie_id") or "").strip(),
        str(context.get("tv_id") or "").strip(),
        str(context.get("season") or "").strip(),
        str(context.get("episode_id") or "").strip(),
        str(context.get("episode_number") or "").strip(),
    ]
    if not parts[0]:
        raise ValueError("Stream ID must be provided.")
    return hashlib.sha256("\x1f".join(parts).encode("utf-8")).hexdigest()


class SubtitleJobsDb:
    """Transactional SQLite store safe to use from the plugin and service."""

    def __init__(self, path=None):
        if path is None:
            addon = xbmcaddon.Addon()
            profile = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
            os.makedirs(profile, exist_ok=True)
            path = os.path.join(profile, "subtitle_translation_jobs.db")
        else:
            path = os.path.abspath(path)
            parent = os.path.dirname(path)
            if parent:
                os.makedirs(parent, exist_ok=True)
        self._path = path
        self._initialize()

    @property
    def path(self):
        return self._path

    def _connect(self):
        connection = sqlite3.connect(self._path, timeout=10, isolation_level=None)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA busy_timeout = {0}".format(_BUSY_TIMEOUT_MS))
        connection.execute("PRAGMA foreign_keys = ON")
        return connection

    @contextmanager
    def _write(self):
        connection = self._connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            yield connection
            connection.commit()
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    def _initialize(self):
        with closing(self._connect()) as connection:
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS subtitle_jobs (
                    job_id TEXT PRIMARY KEY,
                    stream_key TEXT NOT NULL,
                    stream_id TEXT NOT NULL,
                    status TEXT NOT NULL,
                    revision INTEGER NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    payload TEXT NOT NULL
                )
                """
            )
            connection.execute(
                "CREATE INDEX IF NOT EXISTS idx_subtitle_jobs_stream "
                "ON subtitle_jobs(stream_key, created_at DESC)"
            )
            connection.execute(
                "CREATE INDEX IF NOT EXISTS idx_subtitle_jobs_status "
                "ON subtitle_jobs(status, updated_at)"
            )

    @staticmethod
    def _record(row):
        if row is None:
            return None
        try:
            payload = json.loads(row["payload"])
        except (TypeError, ValueError):
            payload = {}
        if not isinstance(payload, dict):
            payload = {}
        payload.update({
            "job_id": row["job_id"],
            "stream_key": row["stream_key"],
            "stream_id": row["stream_id"],
            "status": row["status"],
            "revision": int(row["revision"]),
            "created_at": row["created_at"],
            "updated_at": row["updated_at"],
        })
        payload["run_attempt"] = normalize_run_attempt(payload.get("run_attempt"))
        return payload

    @staticmethod
    def _payload(record):
        payload = dict(record)
        for key in (
            "job_id", "stream_key", "stream_id", "status", "revision",
            "created_at", "updated_at",
        ):
            payload.pop(key, None)
        return json.dumps(payload, ensure_ascii=False, separators=(",", ":"))

    @staticmethod
    def _normalize_status(value):
        value = str(value or "queued").strip().lower()
        if value == "complete":
            return "completed"
        if value == "cancelled":
            return "canceled"
        return value

    def add(self, record):
        if not isinstance(record, dict):
            raise TypeError("Subtitle job record must be a dictionary.")
        job_id = str(record.get("job_id") or "").strip()
        stream_id = str(record.get("stream_id") or "").strip()
        if not job_id or not stream_id:
            raise ValueError("Subtitle job requires job_id and stream_id.")
        stream_key = str(record.get("stream_key") or "").strip()
        if not stream_key:
            stream_key = stream_identity(stream_id, record.get("context"))
        timestamp = str(record.get("created_at") or now_iso())
        updated_at = str(record.get("updated_at") or timestamp)
        stored = dict(record)
        stored.update({
            "job_id": job_id,
            "stream_key": stream_key,
            "stream_id": stream_id,
            "status": self._normalize_status(record.get("status")),
            "run_attempt": normalize_run_attempt(record.get("run_attempt")),
            "created_at": timestamp,
            "updated_at": updated_at,
        })
        if stored["status"] in TERMINAL_STATUSES and not stored.get("terminal_at"):
            stored["terminal_at"] = updated_at
        with self._write() as connection:
            existing_row = connection.execute(
                "SELECT * FROM subtitle_jobs WHERE job_id = ?", (job_id,)
            ).fetchone()
            if existing_row is None:
                connection.execute(
                    "INSERT INTO subtitle_jobs "
                    "(job_id, stream_key, stream_id, status, revision, created_at, updated_at, payload) "
                    "VALUES (?, ?, ?, ?, 1, ?, ?, ?)",
                    (
                        job_id, stream_key, stream_id, stored["status"], timestamp,
                        updated_at, self._payload(stored),
                    ),
                )
            else:
                existing = self._record(existing_row)
                if stored["run_attempt"] < existing["run_attempt"]:
                    # Concurrent plugin invocations can complete their create
                    # requests out of order. A response for an older backend
                    # run must never replace the newer local generation.
                    return existing
                if (
                    stored["run_attempt"] == existing["run_attempt"]
                    and existing["status"] in TERMINAL_STATUSES
                    and stored["status"] in ACTIVE_STATUSES
                ):
                    # A same-run create response can arrive after a poll has
                    # already persisted the terminal state. Only a strictly
                    # newer run is allowed to reactivate this job ID.
                    return existing
                # An idempotent create may return an already-completed job. Keep
                # its verified local result; a reset to queued/extracting must
                # deliberately discard the old result association.
                if (
                    stored["run_attempt"] == existing["run_attempt"]
                    and stored["status"] == "completed"
                    and existing.get("status") == "completed"
                ):
                    for key in ("subtitle_path", "result_saved_at", "terminal_at"):
                        if existing.get(key) and not stored.get(key):
                            stored[key] = existing[key]
                revision = int(existing_row["revision"]) + 1
                connection.execute(
                    "UPDATE subtitle_jobs SET stream_key = ?, stream_id = ?, status = ?, "
                    "revision = ?, created_at = ?, updated_at = ?, payload = ? WHERE job_id = ?",
                    (
                        stream_key, stream_id, stored["status"], revision,
                        timestamp, updated_at, self._payload(stored), job_id,
                    ),
                )
        return self.get(job_id)

    def get(self, job_id):
        with closing(self._connect()) as connection:
            row = connection.execute(
                "SELECT * FROM subtitle_jobs WHERE job_id = ?",
                (str(job_id),),
            ).fetchone()
            return self._record(row)

    def list(self, limit=None):
        sql = "SELECT * FROM subtitle_jobs ORDER BY created_at DESC, job_id DESC"
        values = ()
        if limit is not None:
            sql += " LIMIT ?"
            values = (max(0, int(limit)),)
        with closing(self._connect()) as connection:
            return [self._record(row) for row in connection.execute(sql, values).fetchall()]

    def active(self, limit=None):
        placeholders = ",".join("?" for _ in ACTIVE_STATUSES)
        values = tuple(sorted(ACTIVE_STATUSES))
        sql = (
            "SELECT * FROM subtitle_jobs WHERE status IN ({0}) "
            "ORDER BY updated_at, job_id"
        ).format(placeholders)
        if limit is not None:
            sql += " LIMIT ?"
            values += (max(1, int(limit)),)
        with closing(self._connect()) as connection:
            rows = connection.execute(sql, values).fetchall()
            return [self._record(row) for row in rows]

    def pending_results(self, limit=10):
        """Completed jobs whose SRT has not been saved locally yet."""
        current = now_iso()
        requested = max(1, int(limit))
        batch_size = max(50, requested * 2)
        offset = 0
        pending = []
        with closing(self._connect()) as connection:
            while len(pending) < requested:
                rows = connection.execute(
                    "SELECT * FROM subtitle_jobs WHERE status = 'completed' "
                    "ORDER BY updated_at, job_id LIMIT ? OFFSET ?",
                    (batch_size, offset),
                ).fetchall()
                if not rows:
                    break
                offset += len(rows)
                for row in rows:
                    record = self._record(row)
                    if record.get("result_retry_disabled"):
                        continue
                    if (
                        record.get("next_result_attempt_at")
                        and str(record.get("next_result_attempt_at")) > current
                    ):
                        continue
                    path = record.get("subtitle_path")
                    if path and os.path.isfile(path):
                        continue
                    pending.append(record)
                    if len(pending) >= requested:
                        break
                if len(rows) < batch_size:
                    break
        return pending

    def find_stream(self, stream_id, context=None, include_terminal=True):
        key = stream_identity(stream_id, context)
        sql = "SELECT * FROM subtitle_jobs WHERE stream_key = ?"
        values = [key]
        if not include_terminal:
            placeholders = ",".join("?" for _ in ACTIVE_STATUSES)
            sql += " AND status IN ({0})".format(placeholders)
            values.extend(sorted(ACTIVE_STATUSES))
        sql += " ORDER BY created_at DESC, job_id DESC LIMIT 1"
        with closing(self._connect()) as connection:
            return self._record(connection.execute(sql, tuple(values)).fetchone())

    def find_latest_stream_id(self, stream_id, include_terminal=True):
        """Fallback for old records/callers that do not have media context."""
        sql = "SELECT * FROM subtitle_jobs WHERE stream_id = ?"
        values = [str(stream_id)]
        if not include_terminal:
            placeholders = ",".join("?" for _ in ACTIVE_STATUSES)
            sql += " AND status IN ({0})".format(placeholders)
            values.extend(sorted(ACTIVE_STATUSES))
        sql += " ORDER BY created_at DESC, job_id DESC LIMIT 1"
        with closing(self._connect()) as connection:
            return self._record(connection.execute(sql, tuple(values)).fetchone())

    def update(
        self,
        job_id,
        patch,
        expected_statuses=None,
        expected_run_attempt=None,
    ):
        patch = patch if isinstance(patch, dict) else {}
        with self._write() as connection:
            row = connection.execute(
                "SELECT * FROM subtitle_jobs WHERE job_id = ?", (str(job_id),)
            ).fetchone()
            if row is None:
                return None
            record = self._record(row)
            if expected_statuses is not None:
                expected = {self._normalize_status(item) for item in expected_statuses}
                if record["status"] not in expected:
                    return None
            if (
                expected_run_attempt is not None
                and record["run_attempt"]
                != normalize_run_attempt(expected_run_attempt)
            ):
                return None
            if (
                "run_attempt" in patch
                and normalize_run_attempt(patch.get("run_attempt"))
                < record["run_attempt"]
            ):
                return None
            previous_status = record["status"]
            previous_updated_at = record.get("updated_at")
            previous_terminal_at = record.get("terminal_at")
            incoming_run_attempt = normalize_run_attempt(
                patch.get("run_attempt", record["run_attempt"])
            )
            if incoming_run_attempt > record["run_attempt"]:
                for key in _RUN_SCOPED_LOCAL_FIELDS:
                    record.pop(key, None)
                previous_status = ""
                previous_updated_at = None
                previous_terminal_at = None
            record.update(patch)
            record["run_attempt"] = normalize_run_attempt(record.get("run_attempt"))
            record["status"] = self._normalize_status(record.get("status"))
            record["updated_at"] = str(patch.get("updated_at") or now_iso())
            if record["status"] in TERMINAL_STATUSES:
                record["terminal_at"] = str(
                    previous_terminal_at
                    or (
                        previous_updated_at
                        if previous_status in TERMINAL_STATUSES
                        else None
                    )
                    or patch.get("backend_completed_at")
                    or patch.get("backend_updated_at")
                    or record["updated_at"]
                )
            else:
                record.pop("terminal_at", None)
            revision = int(row["revision"]) + 1
            connection.execute(
                "UPDATE subtitle_jobs SET status = ?, revision = ?, updated_at = ?, payload = ? "
                "WHERE job_id = ?",
                (
                    record["status"], revision, record["updated_at"],
                    self._payload(record), str(job_id),
                ),
            )
        return self.get(job_id)

    def delete(self, job_id):
        with self._write() as connection:
            cursor = connection.execute(
                "DELETE FROM subtitle_jobs WHERE job_id = ?", (str(job_id),)
            )
            return cursor.rowcount > 0

    def purge_before(self, cutoff_iso):
        """Delete terminal records by immutable terminal age, not retry activity."""
        placeholders = ",".join("?" for _ in TERMINAL_STATUSES)
        cutoff = _parse_timestamp(cutoff_iso)
        if cutoff is None:
            raise ValueError("A valid retention cutoff timestamp is required.")
        with self._write() as connection:
            rows = connection.execute(
                "SELECT * FROM subtitle_jobs WHERE status IN ({0})"
                .format(placeholders),
                tuple(sorted(TERMINAL_STATUSES)),
            ).fetchall()
            records = []
            for row in rows:
                record = self._record(row)
                terminal_at = _parse_timestamp(
                    record.get("terminal_at") or record.get("updated_at")
                )
                if terminal_at is not None and terminal_at < cutoff:
                    records.append(record)
            if records:
                connection.executemany(
                    "DELETE FROM subtitle_jobs WHERE job_id = ?",
                    [(record["job_id"],) for record in records],
                )
            return records


def _parse_timestamp(value):
    value = str(value or "").strip()
    if not value:
        return None
    try:
        parsed = datetime.datetime.fromisoformat(value.replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=datetime.timezone.utc)
        return parsed.astimezone(datetime.timezone.utc)
    except (TypeError, ValueError):
        return None
