import json
import os
import sqlite3
from contextlib import closing, contextmanager

import xbmcaddon
import xbmcvfs


class TorboxPreparationsDb:
    """Small persistent queue for provider-side TorBox preparation jobs."""

    def __init__(self):
        addon = xbmcaddon.Addon()
        profile = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
        os.makedirs(profile, exist_ok=True)
        self._path = os.path.join(profile, "torbox_preparations.db")
        self._initialize()

    def _connect(self):
        connection = sqlite3.connect(self._path, timeout=10, isolation_level=None)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA busy_timeout = 10000")
        return connection

    @contextmanager
    def _write(self):
        connection = self._connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            yield connection
            connection.commit()
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    def _initialize(self):
        with closing(self._connect()) as connection:
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS preparations (
                    preparation_id TEXT PRIMARY KEY,
                    stream_id TEXT NOT NULL,
                    status TEXT NOT NULL,
                    revision INTEGER NOT NULL,
                    payload TEXT NOT NULL
                )
                """
            )
            connection.execute(
                "CREATE INDEX IF NOT EXISTS idx_preparations_status "
                "ON preparations(status)"
            )

    @staticmethod
    def _record(row):
        if not row:
            return None
        try:
            record = json.loads(row["payload"])
        except (TypeError, ValueError):
            record = {}
        if not isinstance(record, dict):
            record = {}
        record["id"] = row["preparation_id"]
        record["stream_id"] = row["stream_id"]
        record["revision"] = row["revision"]
        record["status"] = row["status"]
        return record

    def list(self):
        with closing(self._connect()) as connection:
            rows = connection.execute(
                "SELECT * FROM preparations ORDER BY preparation_id"
            ).fetchall()
            return {row["preparation_id"]: self._record(row) for row in rows}

    def get(self, preparation_id):
        with closing(self._connect()) as connection:
            row = connection.execute(
                "SELECT * FROM preparations WHERE preparation_id = ?",
                (str(preparation_id),),
            ).fetchone()
            return self._record(row)

    def find_stream(self, stream_id, active_only=True):
        records = self.list().values()
        active = {"queued", "preparing", "stalled", "ready", "failed"}
        matches = [
            record for record in records
            if str(record.get("stream_id")) == str(stream_id)
            and (not active_only or record.get("status") in active)
        ]
        matches.sort(key=lambda record: record.get("created_at", ""))
        return matches[-1] if matches else None

    def add(self, record):
        preparation_id = str(record["id"])
        payload = dict(record)
        payload.pop("id", None)
        payload.pop("stream_id", None)
        payload.pop("status", None)
        payload.pop("revision", None)
        with self._write() as connection:
            connection.execute(
                "INSERT INTO preparations "
                "(preparation_id, stream_id, status, revision, payload) VALUES (?, ?, ?, ?, ?)",
                (
                    preparation_id,
                    str(record["stream_id"]),
                    record.get("status", "queued"),
                    1,
                    json.dumps(payload, ensure_ascii=False, separators=(",", ":")),
                ),
            )
        return self.get(preparation_id)

    def update(self, preparation_id, patch, expected_statuses=None):
        preparation_id = str(preparation_id)
        with self._write() as connection:
            row = connection.execute(
                "SELECT * FROM preparations WHERE preparation_id = ?",
                (preparation_id,),
            ).fetchone()
            if not row:
                return None
            record = self._record(row)
            if expected_statuses is not None and record.get("status") not in set(expected_statuses):
                return None
            record.update(patch)
            payload = dict(record)
            status = payload.pop("status", "queued")
            payload.pop("id", None)
            payload.pop("stream_id", None)
            payload.pop("revision", None)
            revision = int(row["revision"]) + 1
            connection.execute(
                "UPDATE preparations SET status = ?, revision = ?, payload = ? "
                "WHERE preparation_id = ?",
                (
                    status,
                    revision,
                    json.dumps(payload, ensure_ascii=False, separators=(",", ":")),
                    preparation_id,
                ),
            )
        return self.get(preparation_id)

    def clear_terminal(self):
        with self._write() as connection:
            cursor = connection.execute(
                "DELETE FROM preparations WHERE status IN ('ready', 'failed', 'canceled')"
            )
            return cursor.rowcount
