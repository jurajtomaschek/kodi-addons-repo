"""Background synchronization and safe storage for translated subtitles."""

import datetime
import email.utils
import os
import re
import tempfile
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from . import api
from .subtitles_db import (
    ACTIVE_STATUSES,
    SubtitleJobsDb,
    normalize_run_attempt,
    now_iso,
)
from .localization import tr


DEFAULT_POLL_SECONDS = 2
MAX_SUBTITLE_BYTES = 8 * 1024 * 1024
MAX_STATUS_POLLS_PER_CYCLE = 50
MAX_RESULT_RETRIES = 12
PERMANENT_RESULT_HTTP_STATUSES = frozenset((400, 401, 403, 404, 410, 422))


def _setting_bool(addon, setting_id, default=False):
    value = addon.getSetting(setting_id)
    if value == "":
        return default
    return value.lower() == "true"


def _safe_component(value, fallback="subtitle", maximum=80):
    value = str(value or "").strip()
    value = re.sub(r"[<>:\"/\\|?*\x00-\x1f]+", " ", value)
    value = re.sub(r"\s+", " ", value).strip(" .")
    value = (value or fallback)[:maximum].rstrip(" .") or fallback
    reserved = {
        "CON", "PRN", "AUX", "NUL",
        *("COM{0}".format(index) for index in range(1, 10)),
        *("LPT{0}".format(index) for index in range(1, 10)),
    }
    if value.split(".", 1)[0].upper() in reserved:
        value = "_" + value
    return value


def _poll_seconds(value, default=DEFAULT_POLL_SECONDS):
    try:
        return max(2, min(3600, int(value or default)))
    except (TypeError, ValueError):
        return default


def _next_poll_at(seconds, current=None):
    current = current or datetime.datetime.now(datetime.timezone.utc)
    return (current + datetime.timedelta(seconds=_poll_seconds(seconds))).isoformat()


def _retry_after_seconds(value, default=DEFAULT_POLL_SECONDS):
    try:
        return _poll_seconds(int(str(value).strip()), default=default)
    except (TypeError, ValueError):
        pass
    try:
        target = email.utils.parsedate_to_datetime(str(value))
        if target.tzinfo is None:
            target = target.replace(tzinfo=datetime.timezone.utc)
        seconds = int((target - datetime.datetime.now(datetime.timezone.utc)).total_seconds())
        return _poll_seconds(seconds, default=default)
    except (TypeError, ValueError, OverflowError):
        return _poll_seconds(default)


def _parse_timestamp(value):
    value = str(value or "").strip()
    if not value:
        return None
    try:
        timestamp = datetime.datetime.fromisoformat(value.replace("Z", "+00:00"))
        if timestamp.tzinfo is None:
            timestamp = timestamp.replace(tzinfo=datetime.timezone.utc)
        return timestamp.astimezone(datetime.timezone.utc)
    except (TypeError, ValueError):
        return None


def subtitle_output_directory(profile_path=None):
    if profile_path is None:
        profile_path = xbmcvfs.translatePath(
            xbmcaddon.Addon().getAddonInfo("profile")
        )
    directory = os.path.join(profile_path, "subtitles")
    os.makedirs(directory, exist_ok=True)
    return directory


def save_subtitle_result(record, content, profile_path=None):
    """Validate and atomically save UTF-8 SRT, returning the local path."""
    if not isinstance(content, str):
        raise ValueError("Subtitle result is not text.")
    encoded = content.encode("utf-8")
    if not encoded or len(encoded) > MAX_SUBTITLE_BYTES:
        raise ValueError("Subtitle result has an invalid size.")
    if "\x00" in content or "-->" not in content:
        raise ValueError("Subtitle result is not a valid SRT document.")

    normalized = content.lstrip("\ufeff").replace("\r\n", "\n").replace("\r", "\n")
    normalized = normalized.rstrip() + "\n"
    directory = subtitle_output_directory(profile_path)
    title = _safe_component(
        record.get("title") or record.get("stream_name") or "subtitle"
    )
    job_suffix = _safe_component(record.get("job_id"), "job", 12)
    run_attempt = normalize_run_attempt(record.get("run_attempt"))
    run_suffix = ".r{0}".format(run_attempt) if run_attempt else ""
    destination = os.path.join(
        directory, "{0}.{1}{2}.ai.sk.srt".format(
            title, job_suffix, run_suffix
        )
    )
    descriptor, temporary = tempfile.mkstemp(prefix=".subtitle-", suffix=".tmp", dir=directory)
    try:
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(normalized.encode("utf-8"))
            handle.flush()
            try:
                os.fsync(handle.fileno())
            except OSError:
                pass
        os.replace(temporary, destination)
    except Exception:
        try:
            os.unlink(temporary)
        except OSError:
            pass
        raise
    return destination


def store_subtitle_result(database, record, content):
    """Save and associate an SRT only while ``record`` is the current run."""
    job_id = record["job_id"]
    run_attempt = normalize_run_attempt(record.get("run_attempt"))
    current = database.get(job_id)
    if (
        current is None
        or current.get("status") != "completed"
        or normalize_run_attempt(current.get("run_attempt")) != run_attempt
    ):
        return None
    existing_path = current.get("subtitle_path")
    if existing_path and xbmcvfs.exists(existing_path):
        return current

    path = save_subtitle_result(record, content)
    completed = database.update(
        job_id,
        {
            "subtitle_path": path,
            "result_saved_at": now_iso(),
            "sync_error": "",
            "result_error": "",
            "result_retry_count": 0,
            "result_retry_disabled": False,
            "next_result_attempt_at": "",
        },
        expected_statuses=("completed",),
        expected_run_attempt=run_attempt,
    )
    if completed is not None:
        return completed

    # A restart can land during the filesystem write. Run-specific filenames
    # prevent corruption; remove the now-unreferenced older generation.
    latest = database.get(job_id)
    if not latest or latest.get("subtitle_path") != path:
        try:
            os.unlink(path)
        except OSError:
            pass
    return None


def normalized_status_payload(payload):
    if not isinstance(payload, dict):
        raise ValueError("Subtitle service returned an invalid job status.")
    status = str(payload.get("status") or "").strip().lower()
    if status == "complete":
        status = "completed"
    elif status == "cancelled":
        status = "canceled"
    if not status:
        raise ValueError("Subtitle service omitted the job status.")
    stage = str(payload.get("stage") or status).strip().lower()
    progress = payload.get("progressPercent", payload.get("progress_percent", 0))
    try:
        progress = max(0, min(100, int(progress or 0)))
    except (TypeError, ValueError):
        progress = 0
    poll_after_seconds = _poll_seconds(
        payload.get("pollAfterSeconds", payload.get("poll_after_seconds"))
    )
    next_retry_at = payload.get(
        "nextRetryAt",
        payload.get(
            "nextAttemptAt",
            payload.get("next_retry_at", payload.get("next_attempt_at")),
        ),
    )
    next_poll_at = _next_poll_at(poll_after_seconds)
    if stage == "retrying":
        retry_timestamp = _parse_timestamp(next_retry_at)
        poll_timestamp = _parse_timestamp(next_poll_at)
        if retry_timestamp and poll_timestamp and retry_timestamp > poll_timestamp:
            next_poll_at = retry_timestamp.isoformat()
    return {
        "status": status,
        "stage": stage,
        "progress": progress,
        "message": str(payload.get("message") or "").strip(),
        "error_code": payload.get("errorCode", payload.get("error_code")),
        "completed_chunks": payload.get(
            "completedChunks", payload.get("completed_chunks", 0)
        ),
        "total_chunks": payload.get("totalChunks", payload.get("total_chunks", 0)),
        "source_language": payload.get(
            "sourceLanguage", payload.get("source_language", "")
        ),
        "target_language": payload.get(
            "targetLanguage", payload.get("target_language", "sk")
        ),
        "backend_updated_at": payload.get(
            "updatedAt", payload.get("updated_at")
        ),
        "dispatch_state": payload.get("dispatchState", payload.get("dispatch_state", "")),
        "retry_count": payload.get("retryCount", payload.get("retry_count", 0)),
        "run_attempt": normalize_run_attempt(
            payload.get("runAttempt", payload.get("run_attempt", 0))
        ),
        "next_retry_at": next_retry_at,
        "poll_after_seconds": poll_after_seconds,
        "next_poll_at": next_poll_at,
        "cache_hit": payload.get("cacheHit", payload.get("cache_hit", False)),
        "used_forced_fallback": payload.get(
            "usedForcedFallback", payload.get("used_forced_fallback")
        ),
        "source_selection_message": payload.get(
            "sourceSelectionMessage", payload.get("source_selection_message", "")
        ),
        "source_provider": payload.get("sourceProvider", payload.get("source_provider", "")),
        "source_release": payload.get("sourceRelease", payload.get("source_release", "")),
        "source_file_id": payload.get("sourceFileId", payload.get("source_file_id", "")),
        "source_match_confidence": payload.get(
            "sourceMatchConfidence", payload.get("source_match_confidence")
        ),
        "last_polled_at": now_iso(),
    }


def _subtitle_label_is_forced(label):
    normalized = str(label or "").strip().casefold()
    return any(marker in normalized for marker in (
        "forced", "vynúten", "vynuten",
    ))


def _subtitle_label_language_rank(label):
    normalized = str(label or "").strip().casefold()
    tokens = re.findall(r"[^\W\d_]+", normalized, flags=re.UNICODE)
    for token in tokens:
        if token in ("sk", "slk", "slo", "slovak") or token.startswith("sloven"):
            return 0
    for token in tokens:
        if token in ("cs", "ces", "cze", "czech") or token.startswith(("česk", "cesk")):
            return 1
    return None


def _preferred_native_subtitle_index(player, window):
    get_streams = getattr(player, "getAvailableSubtitleStreams", None)
    if not callable(get_streams):
        return None
    streams = list(get_streams() or [])
    configured = str(
        window.getProperty("MediaHub.NativeSubtitleIndexes") or ""
    ).split(",")
    for raw_index in configured:
        try:
            index = int(raw_index.strip())
        except (TypeError, ValueError):
            continue
        if 0 <= index < len(streams) and not _subtitle_label_is_forced(streams[index]):
            return index

    metadata_known = (
        window.getProperty("MediaHub.NativeSubtitleMetadataKnown") == "true"
    )
    if metadata_known:
        return None

    candidates = []
    for index, label in enumerate(streams):
        if _subtitle_label_is_forced(label):
            continue
        rank = _subtitle_label_language_rank(label)
        if rank is not None:
            candidates.append((rank, index))
    return min(candidates)[1] if candidates else None


def _select_and_show_native_subtitle(player, index):
    set_stream = getattr(player, "setSubtitleStream", None)
    if index is None or not callable(set_stream):
        return False
    set_stream(index)
    show_subtitles = getattr(player, "showSubtitles", None)
    if callable(show_subtitles):
        show_subtitles(True)
    return True


class SubtitleTranslationWorker:
    def __init__(self, database=None, monitor=None, poll_seconds=DEFAULT_POLL_SECONDS):
        self.db = database or SubtitleJobsDb()
        self.monitor = monitor or xbmc.Monitor()
        self.poll_seconds = max(2, int(poll_seconds))
        self._last_purge = 0

    def run(self):
        xbmc.log("[Subtitles] Translation job monitor started", xbmc.LOGINFO)
        while not self.monitor.abortRequested():
            try:
                self.run_once()
            except Exception as exc:
                xbmc.log(
                    "[Subtitles] Job monitor cycle failed: {0}".format(exc),
                    xbmc.LOGERROR,
                )
            if self.monitor.waitForAbort(self.poll_seconds):
                break

    def run_once(self):
        self._purge_if_due()
        refreshed = 0
        for record in self.db.active():
            if self.monitor.abortRequested():
                return
            if not self._is_due(record):
                continue
            self._refresh(record)
            refreshed += 1
            if refreshed >= MAX_STATUS_POLLS_PER_CYCLE:
                break
        for record in self.db.pending_results():
            if self.monitor.abortRequested():
                return
            self._download_result(record)

    def _refresh(self, record):
        job_id = record["job_id"]
        run_attempt = normalize_run_attempt(record.get("run_attempt"))
        try:
            payload = api.get_subtitle_translation_job(
                job_id, url=record.get("poll_url")
            )
            patch = normalized_status_payload(payload)
            current = self.db.update(
                job_id,
                patch,
                expected_statuses=ACTIVE_STATUSES,
                expected_run_attempt=run_attempt,
            )
            if current is None:
                return
            if current["status"] == "completed":
                self._download_result(current)
            elif current["status"] == "failed":
                if self._notify_terminal(current, success=False):
                    self.db.update(
                        job_id,
                        {"notified_terminal": True},
                        expected_run_attempt=current.get("run_attempt"),
                    )
        except api.ApiError as exc:
            # A transient backend/network problem must not turn a valid job into
            # a permanent local failure. A missing backend record is terminal.
            patch = {
                "last_polled_at": now_iso(),
                "sync_error": exc.message,
            }
            retry_after = None
            for key, value in (exc.headers or {}).items():
                if str(key).lower() == "retry-after":
                    retry_after = value
                    break
            delay = _retry_after_seconds(
                retry_after,
                default=max(10, _poll_seconds(record.get("poll_after_seconds"))),
            )
            patch.update({"poll_after_seconds": delay, "next_poll_at": _next_poll_at(delay)})
            if exc.status_code == 404:
                patch.update({
                    "status": "failed",
                    "stage": "failed",
                    "error_code": "job_not_found",
                    "message": "The subtitle job is no longer available on the server.",
                })
            current = self.db.update(
                job_id,
                patch,
                expected_statuses=ACTIVE_STATUSES,
                expected_run_attempt=run_attempt,
            )
            if current and current.get("status") == "failed":
                if self._notify_terminal(current, success=False):
                    self.db.update(
                        job_id,
                        {"notified_terminal": True},
                        expected_run_attempt=current.get("run_attempt"),
                    )
        except Exception as exc:
            xbmc.log(
                "[Subtitles] Could not refresh {0}: {1}".format(job_id, exc),
                xbmc.LOGWARNING,
            )
            self.db.update(
                job_id,
                {
                    "last_polled_at": now_iso(),
                    "sync_error": str(exc),
                    "next_poll_at": _next_poll_at(
                        max(10, _poll_seconds(record.get("poll_after_seconds")))
                    ),
                },
                expected_statuses=ACTIVE_STATUSES,
                expected_run_attempt=run_attempt,
            )

    @staticmethod
    def _is_due(record, current=None):
        due = _parse_timestamp(record.get("next_poll_at"))
        if due is None:
            return True
        current = current or datetime.datetime.now(datetime.timezone.utc)
        return due <= current.astimezone(datetime.timezone.utc)

    def _download_result(self, record):
        if record.get("subtitle_path") and xbmcvfs.exists(record["subtitle_path"]):
            return
        run_attempt = normalize_run_attempt(record.get("run_attempt"))
        try:
            content = api.get_subtitle_translation_result(
                record["job_id"], url=record.get("result_url")
            )
            terminal = store_subtitle_result(self.db, record, content)
            if terminal is None:
                return
            if self._notify_terminal(terminal, success=True):
                self.db.update(
                    record["job_id"],
                    {"notified_terminal": True},
                    expected_run_attempt=run_attempt,
                )
            self._attach_to_current_playback(terminal)
        except Exception as exc:
            retry_count = max(0, int(record.get("result_retry_count") or 0)) + 1
            permanent = (
                isinstance(exc, api.ApiError)
                and exc.status_code in PERMANENT_RESULT_HTTP_STATUSES
            )
            retry_disabled = permanent or retry_count >= MAX_RESULT_RETRIES
            patch = {
                "result_error": str(exc),
                "result_retry_count": retry_count,
                "result_retry_disabled": retry_disabled,
                "next_result_attempt_at": "",
                "last_polled_at": now_iso(),
            }
            if isinstance(exc, api.ApiError) and exc.status_code == 410:
                patch.update({
                    "status": "canceled",
                    "stage": "canceled",
                    "error_code": exc.error_code or "job_cancelled",
                })
            elif (
                isinstance(exc, api.ApiError)
                and exc.status_code in (404, 422)
            ) or (retry_count >= MAX_RESULT_RETRIES and not permanent):
                # A missing/expired server artifact can be regenerated by
                # posting the same deterministic request after this local
                # record becomes failed. Explicit UI retry also recovers from
                # a bounded run of ambiguous transport failures.
                patch.update({
                    "status": "failed",
                    "stage": "failed",
                    "error_code": (
                        exc.error_code
                        if isinstance(exc, api.ApiError) and exc.error_code
                        else "result_unavailable"
                    ),
                })
            if not retry_disabled:
                retry_delay = min(300, 5 * (2 ** min(retry_count - 1, 6)))
                patch["next_result_attempt_at"] = _next_poll_at(retry_delay)
            self.db.update(
                record["job_id"],
                patch,
                expected_statuses=("completed",),
                expected_run_attempt=run_attempt,
            )
            xbmc.log(
                "[Subtitles] Could not store result {0}: {1}".format(
                    record["job_id"], exc
                ),
                xbmc.LOGERROR,
            )

    @staticmethod
    def _notify_terminal(record, success):
        if record.get("notified_terminal"):
            return False
        try:
            title = tr("AI Slovak subtitles")
            message = (
                tr("Ready for {0}", record.get("title") or tr("playback"))
                if success else
                tr("Translation needs attention")
            )
            xbmcgui.Dialog().notification(
                title,
                message,
                xbmcgui.NOTIFICATION_INFO if success else xbmcgui.NOTIFICATION_ERROR,
                3500,
            )
            return True
        except Exception:
            return False

    def _attach_to_current_playback(self, record):
        addon = xbmcaddon.Addon()
        if not _setting_bool(addon, "subtitle_auto_attach", True):
            return
        path = record.get("subtitle_path")
        if not path or not xbmcvfs.exists(path):
            return
        try:
            window = xbmcgui.Window(10000)
            if window.getProperty("MediaHub.StreamId") != str(record.get("stream_id")):
                return
            player = xbmc.Player()
            if player.isPlayingVideo():
                if (
                    _setting_bool(addon, "subtitle_native_first", True)
                    and window.getProperty("MediaHub.NativeFirstEnabled") == "true"
                ):
                    native_index = _preferred_native_subtitle_index(player, window)
                    if _select_and_show_native_subtitle(player, native_index):
                        return
                player.setSubtitles(path)
        except Exception as exc:
            xbmc.log(
                "[Subtitles] Live attach failed: {0}".format(exc), xbmc.LOGWARNING
            )

    def _purge_if_due(self):
        current = time.time()
        if current - self._last_purge < 6 * 60 * 60:
            return
        self._last_purge = current
        addon = xbmcaddon.Addon()
        try:
            days = int(addon.getSetting("subtitle_retention_days") or 30)
        except (TypeError, ValueError):
            days = 30
        if days <= 0:
            return
        cutoff = datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(days=days)
        for record in self.db.purge_before(cutoff.isoformat()):
            path = record.get("subtitle_path")
            if not path:
                continue
            try:
                directory = os.path.abspath(subtitle_output_directory())
                candidate = os.path.abspath(path)
                if os.path.commonpath((directory, candidate)) == directory and os.path.isfile(candidate):
                    os.unlink(candidate)
            except (OSError, ValueError):
                pass


class SubtitlePlaybackMonitor(xbmc.Player):
    """Prevent a completed job from attaching to a later unrelated video."""

    @staticmethod
    def _clear_stream():
        try:
            window = xbmcgui.Window(10000)
            window.clearProperty("MediaHub.StreamId")
            window.clearProperty("MediaHub.AiSubtitlePath")
            window.clearProperty("MediaHub.FallbackSubtitlePath")
            window.clearProperty("MediaHub.NativePreferred")
            window.clearProperty("MediaHub.NativeFirstEnabled")
            window.clearProperty("MediaHub.NativeSubtitleIndexes")
            window.clearProperty("MediaHub.NativeSubtitleMetadataKnown")
        except Exception:
            pass

    def onPlayBackEnded(self):
        self._clear_stream()

    def onPlayBackStopped(self):
        self._clear_stream()

    def onPlayBackError(self):
        self._clear_stream()

    def onAVStarted(self):
        """Select an included SK/CZ text track ahead of an AI result."""
        try:
            window = xbmcgui.Window(10000)
            if (
                window.getProperty("MediaHub.NativeFirstEnabled") != "true"
                and window.getProperty("MediaHub.NativePreferred") != "true"
            ):
                return
            native_index = _preferred_native_subtitle_index(self, window)
            if _select_and_show_native_subtitle(self, native_index):
                return
            ai_path = (
                window.getProperty("MediaHub.FallbackSubtitlePath")
                or window.getProperty("MediaHub.AiSubtitlePath")
            )
            set_subtitles = getattr(self, "setSubtitles", None)
            if ai_path and xbmcvfs.exists(ai_path) and callable(set_subtitles):
                set_subtitles(ai_path)
        except Exception as exc:
            xbmc.log(
                "[Subtitles] Native subtitle selection failed: {0}".format(exc),
                xbmc.LOGWARNING,
            )
