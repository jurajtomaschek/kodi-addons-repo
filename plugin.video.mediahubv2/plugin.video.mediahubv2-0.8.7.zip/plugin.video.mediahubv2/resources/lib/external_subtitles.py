"""External subtitle availability plus safe local playback caching."""

import json
import os
import re
import tempfile
import threading
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from . import api
from .subtitles_db import stream_identity

_LOCK = threading.RLock()
_RUNNING = set()
_CACHE = None
MAX_SUBTITLE_BYTES = 8 * 1024 * 1024
AVAILABLE_TTL_SECONDS = 6 * 60 * 60
UNAVAILABLE_TTL_SECONDS = 60 * 60
ERROR_TTL_SECONDS = 60
CHECKING_TTL_SECONDS = 2 * 60


def _path():
    addon = xbmcaddon.Addon()
    profile = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
    os.makedirs(profile, exist_ok=True)
    return os.path.join(profile, "external_subtitle_availability.json")


def _subtitle_directory():
    addon = xbmcaddon.Addon()
    profile = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
    path = os.path.join(profile, "external_subtitles")
    os.makedirs(path, exist_ok=True)
    return path


def _load():
    global _CACHE
    if _CACHE is not None:
        return _CACHE
    try:
        with open(_path(), "r", encoding="utf-8") as handle:
            value = json.load(handle)
        _CACHE = value if isinstance(value, dict) else {}
    except (OSError, ValueError, TypeError):
        _CACHE = {}
    return _CACHE


def _save():
    path = _path()
    temporary = path + ".tmp"
    with open(temporary, "w", encoding="utf-8") as handle:
        json.dump(_CACHE or {}, handle, ensure_ascii=False)
    os.replace(temporary, path)


def get(stream_id, context=None):
    key = stream_identity(stream_id, context)
    with _LOCK:
        return dict(_load().get(key) or {})


def download_for_playback(stream_id, context=None, availability=None):
    """Return a cached SK/CZ SRT path, downloading the identified file once."""
    context = dict(context or {})
    availability = dict(availability or get(stream_id, context))
    if str(availability.get("status") or "").lower() != "available":
        return ""
    language = _native_language(availability.get("language"))
    file_id = str(
        availability.get("fileId") or availability.get("file_id") or ""
    ).strip()
    if language is None or not re.fullmatch(r"[1-9][0-9]*", file_id):
        return ""

    path = _find_cached_subtitle(stream_id, context, language, file_id)
    if path:
        return path
    path = _subtitle_path(stream_id, context, language, file_id)
    try:
        content = api.download_external_subtitle(
            stream_id,
            availability,
            _identity(context),
        )
    except Exception as exc:
        invalidate(
            stream_id,
            context,
            file_id=file_id,
            retry_after_seconds=_retry_after_seconds(exc),
        )
        _report_download_failure(exc)
        return ""

    try:
        _validate_subtitle(content)
        _save_subtitle(path, content)
        return path
    except Exception as exc:
        _report_download_failure(exc)
        return ""


def is_external_path(path):
    try:
        directory = os.path.abspath(_subtitle_directory())
        candidate = os.path.abspath(str(path or ""))
        return bool(path) and os.path.commonpath((directory, candidate)) == directory
    except (OSError, ValueError):
        return False


def _native_language(value):
    normalized = str(value or "").strip().lower().split("-", 1)[0]
    if normalized in ("sk", "slk", "slo", "slovak"):
        return "sk"
    if normalized in ("cs", "cz", "ces", "cze", "czech"):
        return "cs"
    return None


def _subtitle_path(stream_id, context, language, file_id):
    return os.path.join(
        _subtitle_directory(),
        "mediahub-opensubtitles-{0}-{1}.srt".format(file_id, language),
    )


def _find_cached_subtitle(stream_id, context, language, file_id):
    stable = _subtitle_path(stream_id, context, language, file_id)
    if _cached_subtitle_is_valid(stable):
        return stable

    # Reuse stream-scoped files written by older add-on builds. OpenSubtitles
    # file IDs identify the subtitle itself, so the stream digest is unnecessary.
    legacy_pattern = re.compile(
        r"^mediahub-opensubtitles-[0-9a-f]{{24}}-{0}-{1}\.srt$".format(
            re.escape(file_id), re.escape(language)
        ),
        re.IGNORECASE,
    )
    try:
        for name in os.listdir(_subtitle_directory()):
            if not legacy_pattern.match(name):
                continue
            candidate = os.path.join(_subtitle_directory(), name)
            if _cached_subtitle_is_valid(candidate):
                return candidate
    except OSError:
        pass
    return ""


def _validate_subtitle(content):
    if not isinstance(content, str):
        raise ValueError("External subtitle response was not text.")
    encoded = content.encode("utf-8")
    if not encoded or len(encoded) > MAX_SUBTITLE_BYTES:
        raise ValueError("External subtitle response had an invalid size.")
    if "\x00" in content or "-->" not in content:
        raise ValueError("External subtitle response was not a valid SRT document.")


def _cached_subtitle_is_valid(path):
    try:
        if not os.path.isfile(path) or os.path.getsize(path) > MAX_SUBTITLE_BYTES:
            return False
        with open(path, "r", encoding="utf-8-sig") as handle:
            content = handle.read(MAX_SUBTITLE_BYTES + 1)
        _validate_subtitle(content)
        return True
    except (OSError, UnicodeError, ValueError):
        return False


def _save_subtitle(path, content):
    directory = os.path.dirname(path)
    descriptor, temporary = tempfile.mkstemp(
        prefix=".external-subtitle-", suffix=".tmp", dir=directory
    )
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    except Exception:
        try:
            os.unlink(temporary)
        except OSError:
            pass
        raise


def schedule(streams, context=None):
    context = dict(context or {})
    now = time.time()
    for stream in streams or []:
        if not isinstance(stream, dict):
            continue
        stream_id = str(stream.get("id") or "").strip()
        if not stream_id or _has_native_preferred(stream):
            continue
        key = stream_identity(stream_id, context)
        with _LOCK:
            cached = _load().get(key) or {}
            if _cache_entry_is_fresh(cached, now):
                continue
            if key in _RUNNING:
                continue
            _RUNNING.add(key)
            _CACHE[key] = {"status": "checking", "checkedAt": now}
            _save()
        # Do not use ThreadPoolExecutor here.  Its workers are non-daemon and
        # can keep kodi.exe alive while a subtitle availability request is
        # still waiting on the network during Kodi shutdown.
        thread = threading.Thread(
            target=_check,
            args=(key, stream_id, context),
            name="MediaHubExternalSubs",
            daemon=True,
        )
        thread.start()


def _has_native_preferred(stream):
    tracks = stream.get("subtitleTracks") or []
    for track in tracks:
        if not isinstance(track, dict) or track.get("isForced") or track.get("is_forced"):
            continue
        language = str(track.get("language") or "").lower().split("-", 1)[0]
        if language in ("sk", "slk", "slovak", "cs", "cze", "ces", "czech"):
            return True
    return bool(stream.get("hasPreferredSubtitles"))


def _check(key, stream_id, context):
    try:
        result = api.check_external_subtitle_availability(
            stream_id,
            _identity(context),
        )
        value = dict(result) if isinstance(result, dict) else {"status": "error"}
    except Exception as exc:
        xbmc.log("[Subtitles] External availability check failed: {0}".format(exc), xbmc.LOGWARNING)
        value = {"status": "error"}
    checked_at = time.time()
    value["checkedAt"] = checked_at
    if str(value.get("status") or "").lower() == "error":
        value.setdefault("retryAt", checked_at + ERROR_TTL_SECONDS)
    with _LOCK:
        _load()[key] = value
        _RUNNING.discard(key)
        try:
            _save()
        except OSError:
            pass
    # The app shell observes cache changes during its lightweight background
    # refresh and patches matching stream rows. A global Container.Refresh
    # here would rebuild the complete stream-selection route once per worker.


def invalidate(stream_id, context=None, file_id="", retry_after_seconds=None):
    """Invalidate stale availability after a provider download failure."""
    context = dict(context or {})
    key = stream_identity(stream_id, context)
    now = time.time()
    retry_after = _bounded_retry_after(retry_after_seconds)
    with _LOCK:
        current = dict(_load().get(key) or {})
        current_file_id = str(
            current.get("fileId") or current.get("file_id") or ""
        ).strip()
        if file_id and current_file_id and current_file_id != str(file_id):
            return
        _CACHE[key] = {
            "status": "error",
            "fileId": str(file_id or current_file_id),
            "checkedAt": now,
            "retryAt": now + retry_after,
        }
        try:
            _save()
        except OSError:
            pass


def _cache_entry_is_fresh(value, now=None):
    if not isinstance(value, dict):
        return False
    now = time.time() if now is None else float(now)
    status = str(value.get("status") or "").lower()
    try:
        checked_at = float(value.get("checkedAt"))
    except (TypeError, ValueError):
        return False
    ttl = {
        "available": AVAILABLE_TTL_SECONDS,
        "unavailable": UNAVAILABLE_TTL_SECONDS,
        "checking": CHECKING_TTL_SECONDS,
        "error": ERROR_TTL_SECONDS,
    }.get(status)
    if ttl is None:
        return False
    if status == "error":
        try:
            return now < float(value.get("retryAt"))
        except (TypeError, ValueError):
            pass
    return now - checked_at < ttl


def _retry_after_seconds(exc):
    headers = getattr(exc, "headers", {}) or {}
    for key, value in headers.items():
        if str(key).lower() != "retry-after":
            continue
        try:
            return _bounded_retry_after(float(value))
        except (TypeError, ValueError):
            break
    return ERROR_TTL_SECONDS


def _bounded_retry_after(value):
    try:
        seconds = int(float(value))
    except (TypeError, ValueError):
        seconds = ERROR_TTL_SECONDS
    return max(5, min(15 * 60, seconds))


def _report_download_failure(exc):
    xbmc.log(
        "[Subtitles] External subtitle download failed: {0}".format(exc),
        xbmc.LOGWARNING,
    )
    try:
        xbmcgui.Dialog().notification(
            "External subtitles",
            "External subtitles are temporarily unavailable. Playback will continue.",
            xbmcgui.NOTIFICATION_ERROR,
            4000,
        )
    except Exception:
        pass


def _identity(context):
    pairs = {
        "mediaType": ("mediaType", "media_type"),
        "tmdbId": ("tmdbId", "movie_id", "episode_id"),
        "parentTmdbId": ("parentTmdbId", "tv_id"),
        "imdbId": ("imdbId", "imdb_id"),
        "parentImdbId": ("parentImdbId", "parent_imdb_id"),
        "seasonNumber": ("seasonNumber", "season"),
        "episodeNumber": ("episodeNumber", "episode_number"),
        "candidateTitles": ("candidateTitles", "candidate_titles"),
    }
    value = {}
    for output, keys in pairs.items():
        for key in keys:
            if context.get(key) not in (None, "", []):
                value[output] = context[key]
                break
    return value
